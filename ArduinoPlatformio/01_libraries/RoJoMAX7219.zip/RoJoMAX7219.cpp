/*
  Nombre de la librería: RoJoMAX7219.h
  Versión: 20191005
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a matrices o displays
    de dígitos de leds
  
  Notas:
  - El chip funciona correctamente tanto con 3.3 como con 5V.
    Pero si encadenamos varios chips (por ejemplo 4), con 3.3V no tiene
    suficiente tensión para todos. Esto provoca que en el mejor de los
    casos cuanto más alejada está la matriz de leds del primer chip, su
    luminosidad es menor. En el peor de los casos alguna de las matrices
    de leds no se encenderá de manera aleatoria.
  - Con este chip es necesario enviar información para todas las columnas.
    Además la información se envía intercalada (envía el dato de cada columna
    para cada uno de lso chipa) y además en orden inverso.
    Para simplificar la gestión, se crea un sprite monocromo para mantener
    la memoria de vídeo.
*/

#ifndef RoJoMAX7219_cpp
#define RoJoMAX7219_cpp

#include <RoJoMAX7219.h>

//Envía una instrucción
void RoJoMAX7219::_localCommand(byte command, byte value) {
  shiftOut(_pinDIN,_pinCLK,MSBFIRST,command);
  shiftOut(_pinDIN,_pinCLK,MSBFIRST,value);
}

//Envía una instrucción a todos los chips
void RoJoMAX7219::_globalCommand(byte command, byte value) {
  //Antes de enviar una instrucción, siempre desactivamos el pin CS
  digitalWrite(_pinCS,LOW);
  //Recorremos todos los chips y enviamos la instrucción
  for(byte chip=0;chip<_chainedChips;chip++) _localCommand(command,value);
  //Fin de envío
  digitalWrite(_pinCS,HIGH);
}

//Fija el brillo de los leds
void RoJoMAX7219::setBrightness(byte brightness) {
  //El rango de valores permitidos está entre 0 y 15
  //Se podría fijar distinto brillo a cada chip. No lo haremos
  //Asignaremos el mismo a todos
  _globalCommand(0x0A,brightness & 15); //max7219_reg_intensity
}

//Dibuja la memoria de vídeo en el display
void RoJoMAX7219::draw() {
  //Recorreremos todas las columnas que gestiona un chip
  for(byte x=0;x<8;x++) {
    //Antes de enviar una serie de instrucciones, siempre desactivamos el pin CS
    digitalWrite(_pinCS,LOW);
    //Recorreremos todos los chips
    //Recordemos que la primera instrucción enviada corresponderá al chip con número de
    //secuencia más alto y la última instrucción afectará al chip 0
    for(byte chip=_chainedChips-1;chip!=255;chip--) {
      //El comando corresponde con el número de columna + 1
      //Y el valor con el byte de la columna que corresponde en la memoria de vídeo
      _localCommand(x+1,v->getPage(chip*8+x,0));
    }
    //Fn de envío
    digitalWrite(_pinCS,HIGH);
  }
}

//Reset & inicialización
void RoJoMAX7219::reset() {
  //Desconocido!
  _globalCommand(0x0B,0x07); //max7219_reg_scanLimit
  //Utilizaremos matrices de leds, no displays de dígitos  
  _globalCommand(0x09,0x00); //max7219_reg_decodeMode
  //Salimos del modo shutdown en el que se encuentran al arrancar. Los activamos!  
  _globalCommand(0x0C,0x01); //max7219_reg_shutdown
  //No hace falta hacer el test de display (encender todos los leds) 
  _globalCommand(0x0F,0x00); //max7219_reg_displayTest
  //Fijamos el brillo por defecto a 8
  setBrightness(8);
  //Borramos la memoria de vídeo
  v->clear();
  draw();
}

//Inicialización
//Devuelve true si lo consigue
bool RoJoMAX7219::begin(byte chainedChips,byte pinDIN,byte pinCS,byte pinCLK) {
  //Por lo menos tiene que haber un chip
  if(chainedChips==0) return false;
  //Creamos y dimensionamos el sprite de la memoria de vídeo
  v=new RoJoSprite(1);
  if(!v) return false;
  if(!v->setSize(chainedChips*8,8)) return false;
  //Este display tiene una profundidad de color de 1 bit (monocromo)
  _colorDepth=1;
  //Guardamos los valores de los parámetros en las variables privadas
  _chainedChips=chainedChips;
  _xMax=chainedChips*8;
  _pinDIN=pinDIN;
  _pinCS=pinCS;
  _pinCLK=pinCLK;
  //Definimos los pines de conexión como de salida
  pinMode(_pinDIN,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  pinMode(_pinCLK,OUTPUT);
  //Activamos el pin del reloj
  digitalWrite(_pinCLK,HIGH);
  //Reseteamos el display
  reset();
  //Todo Ok
  return true;
}

//Vacía la memoria de vídeo
void RoJoMAX7219::clear(RoJoColor color) {
  //Limpiamos el sprite de la memoria de vídeo
  v->clear(color);
  //Si se dibuja automáticamente...lo hacemos
  if(autoDraw) draw();
}

//Dibuja un pixel
//Devuelve true si es visible
bool RoJoMAX7219::drawPixel(int16_t x,int16_t y,RoJoColor color) {
  if(v->drawPixel(x,y,color) && autoDraw) {
    draw();
    return true;
  }
  return false;
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoMAX7219::block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor color) {
  if(v->block(x1,y1,x2,y2,color) && autoDraw) {
    draw();
    return true;
  }
  return false;
}

//Destructor
RoJoMAX7219::~RoJoMAX7219() {
  //Liberamos la memoria ocupada por la memoria de vídeo
  v->end();
  _xMax=_chainedChips=0;
}

//Anchura de display en pixels
uint16_t RoJoMAX7219::xMax() {
  return _xMax;
}

//Altura de display en pixels
uint16_t RoJoMAX7219::yMax() {
  return _yMax;
}

//Dibuja un sprite sobre la memoria de vídeo
//Sobreescribe la información existente
//Respuesta: true si hay parte visible
bool RoJoMAX7219::drawSprite(RoJoSprite *sprite,int16_t x,int16_t y) {
  if(v->drawSprite(sprite,x,y) && autoDraw) {
    draw();
    return true;
  }
  return false;
}

#endif

/*
  Nombre de la librería: RoJoMultiFS.h
  Versión: 20220511
  Autor: Ramón Junquera
  Descripción:
    Librería para facilitar la gestión del acceso a distintos tipos sistemas de archivos.
    Es capaz de trabajar con FAT sobre SD, o SPIFFS, LittleFS o FFat sobre memoria interna.
    Para todas las opciones, el sistema e intrucciones será idéntico.
    De esta menra no se puede escribir código multiplataforma.
    La configuración del tipo de sistema de archivos se define en las directivas del compilador
    que se incluyen en el archivo Platformio.ini
    La librería crea una clase que lo gestiona y la instacia en el objeto RoJoFS, que es el
    único que utilizaremos para trabajar con el sistema de archivos de manera transparente.
  Configuración:
    Tipo de FileSystem en función del valor de RoJoFileSystem definido en Platformio.ini
      0 = SD
      1 = SPIFFS
      2 = LittleFS
      3 = FFat
  Notas:
  - SPIFFS
    Es el sistema de archivos original de Espressif. Actualmente se considera obsoleto.
    Ya aparecen los warnings al compilar para ESP8266.
    ESP32 aun lo acepta sin quejas.
    Se debería evitar su uso.
  - LittleFS
    Es el sustituto de SPIFFS. Es más rápido y menos pesado. Admite estructura de carpetas
    real. Está implementado oficialmente tanto en los ESP8266 como en los ESP32
    Tiene un problema grave de diseño:
      Cuando abrimos un archivo binario para lectura/escritura y sobreescribimos/modificamos
      un byte, los bytes restantes hasta el final del archivo, son reubicados en el sistema.
      Cuanto mayor se el número de bytes desde el modificado hasta el final, más tiempo
      tardará en reaccionar.
      El tiempo de reacción se manifestará en el momento en el que solicitemos cambiar la
      posición de lectura/escritura del archivo con un seek.
      Conclusión. Si trabajas con un archivo binario, procura ubicar la información que más
      se actualizará al final del archivo. Las escrituras aleatorias no son su fuerte.
  - FFat
    Es el clásico FAT, pero para memoria interna.
    Soporta estructura de carpetas real.
    Es más pesado (consume más memoria) que LittleFS.
    La librería de gestión viene implementada en ESP32, pero no la herramienta de generación
    y transferencia de imágenes. De todas formas, se utiliza una herramienta externa.
    Para automatizar esta herramienta (que ella sola detecte el tamaño de la partición utilizada
    como sistema de archivos) es necesario que lo reconozca el sistema. Esto aun no está
    implementado en las librerías oficiales, por eso es necesario hacer un ligero cambio:
      Se debe actualizar el archivo main.py (responsable de reconocer las particiones).
      El archivo se encuentra en C:\Users\<username>\.platformio\platforms\espressif32\builder
      La versión que se adjunta se ha modificado para reconocer las particiones FFat.
    A fecha actual FFat sólo está implementado en ESP32. No en ESP8266
*/

#ifndef RoJoMultiFS_h
#define RoJoMultiFS_h

#include <Arduino.h>
//Definimos sistema de archivos
#ifdef ROJO_PIN_CS_SD //Si utilizamos una SD
  #ifdef __arm__ //Si es una Raspberry...
    #error Raspberry has not SD
  #endif
  #define RoJoFileSystem 0
  #include <SD.h>
  #define _FS SD
#else //Si no utilizamos una SD
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino...
    #error Arduino family has not internal file system
  #endif
  #ifndef RoJoFileSystem //SPIFFS
    #define RoJoFileSystem 1 
  #endif
  #if RoJoFileSystem == 1 //SPIFFS
    #ifdef ESP32
      #include <SPIFFS.h>
    #else
      #include <FS.h>
    #endif
    #define _FS SPIFFS
  #elif RoJoFileSystem == 2 //LittleFS
    #include <LittleFS.h>
    #define _FS LittleFS
  #elif RoJoFileSystem == 3 //FFat
    #ifndef ESP32
      #error Only ESP32 has FFat
    #else
      #include <FFat.h>
      #define _FS FFat
    #endif
  #endif
#endif

class RoJoMultiFS {
  protected:
  public:
    bool begin(bool formatOnFail=false);
    void end();
    bool exists(String path);
    bool mkdir(String path);
    File open(String path,const char *mode="r");
    bool remove(String path);
    bool rmdir(String path);
    #if RoJoFileSystem!=0 && !defined(__arm__) //Si no es SD...
      bool format(); //...tiene opción de formateo
      bool rename(String pathFrom,String pathTo);
    #endif
    
}; //Punto y coma obligatorio para que no de error

#include <RoJoMultiFS.cpp>

RoJoMultiFS RoJoFS; //Creamos una instancia

#endif


/*
  Nombre de la librería: RoJoMultiFS.h
  Versión: 20230216
  Autor: Ramón Junquera
  Descripción de librería:
    Librería para facilitar la gestión del acceso a distintos tipos sistemas de archivos.
    Es capaz de trabajar con FAT sobre SD, o SPIFFS, LittleFS o FFat sobre memoria interna.
    Para todas las opciones, el sistema e intrucciones será idéntico.
    De esta menra no se puede escribir código multiplataforma.
    La configuración del tipo de sistema de archivos se define en las directivas del compilador
    que se incluyen en el archivo Platformio.ini
    La librería crea una clase que lo gestiona y la instacia en el objeto RoJoFS, que es el
    único que utilizaremos para trabajar con el sistema de archivos de manera transparente.
  Configuración:
    Tipo de FileSystem en función del valor de RoJoFileSystem definido en Platformio.ini
      0 = SD
      1 = SPIFFS
      2 = LittleFS
      3 = FFat
  Descripción de sistemas de archivos:
  - SD
    El único formateo permitido es FAT32.
    El driver de Arduino sólo es capaz de leer los nombre en formato 8.3. El resto, lo leen entero.
    Es recomendable formatear la tarjeta antes de utilizarla en cada dispositivo.
    Por ejemplo, una terjeta formateada y que ha sido manipulada por un Arduino, es posible que
    presente errores si la intentamos utilizar directamente con un ESP8266.
  - SPIFFS
    Es el sistema de archivos original de Espressif. Actualmente se considera obsoleto.
    Ya aparecen los warnings al compilar para ESP8266.
    ESP32 aun lo acepta sin quejas.
    Se debería evitar su uso.
    Este formato no permite directorios
  - LittleFS
    Es el sustituto de SPIFFS. Es más rápido y menos pesado. Admite estructura de carpetas
    real. Está implementado oficialmente tanto en los ESP8266 como en los ESP32
    Tiene un problema grave de diseño:
      Cuando abrimos un archivo binario para lectura/escritura y sobreescribimos/modificamos
      un byte, los bytes restantes hasta el final del archivo, son reubicados en el sistema.
      Cuanto mayor se el número de bytes desde el modificado hasta el final, más tiempo
      tardará en reaccionar.
      El tiempo de reacción se manifestará en el momento en el que solicitemos cambiar la
      posición de lectura/escritura del archivo con un seek.
      Conclusión. Si trabajas con un archivo binario, procura ubicar la información que más
      se actualizará al final del archivo. Las escrituras aleatorias no son su fuerte.
    Tiene la particularidad de que cuando se elimina el último de los archivos de un
    directorio, también elimina el directorio.
  - FFat
    Es el clásico FAT, pero para memoria interna.
    Soporta estructura de carpetas real.
    Es más pesado (consume más memoria) que LittleFS.
    Tanto la librería de gestión como la herramienta de transferencia de imágenes vienen
    perfectametne integradas en ESP32.
    A fecha actual FFat sólo está implementado en ESP32. No en ESP8266
  Compatibilidad:
    - Arduino, ESP8266, ESP32 y Raspberry Pi
    - En RPi siempre se utiliza la librería RPiFS.h, pero se enmascara a través de librerías de
      nomenclatura estándar: FS.h, LittleFS.h y FFat.h. No hay diferencia de funcionalidades entre ellas.
  Notas:
    - ESP8266 utiliza el objeto Dir para la gestión de directorios con SPIIFS. El problema es que
      la clase Dir sigue existiendo con sistema de archivos de SD, pero no se utiliza. Por esta razón
      se crea la clase RoJoDir que se utiliza para la gestión de directorios con cualquier sistema,
      enmascarando la clase Dir cuando haga falta.

  TimeStamp
    La mayoría de los sistemas de archivos admiten una fecha para sus entradas (archivos/
    directorios).
    La lectura se puede hacer a través del método RoJoDir.fileTime o File.getLastWrite.
    Siempre devuelve la fecha en format time_t.
    RoJoDir incluye el método fileTimeString que devuelve un String formateado en:
      dd/mm/yyyy hh:mm:ss
    Para la escritura del TimeStamp, se debe definir una función a través del método
    RoJoFS.setTimeCallback que devolverá en formato time_t la fecha que se utilizará.
    En ESP8266 el sistema llama automáticamente a la función antes de cada escritura.
    En ESP32 se llamará a la función antes de RoJoFS.open y con el resultado se pondrá
    en hora el RTC interno.
    Arduino tiene un formato de función distinto. Se ha definido una función intermedia,
    transparente para el usuario, que llama a la función definida en setTimeCallback.
    Como en ESP8266 lo hace automáticamente antes de cada escritura. Por otra parte,
    la librería SD de Arduino no es capaz de leer la fecha de los archivos.
    En RPi la asignación de fecha a un archivo se hace tras cerrarlo. Por eso se pasa el
    parámetro de la función de callback en la apertura de un archivo (optativo).
  Notas:
  - El SD de ESP8266 tiene un error. Los segundos indicados siempre se duplican y se
    suman al tiempo total. Por lo tanto en este caso en concreto, es conveniente identificar
    los segundos y restar su mitad al total.
  - El SPIFFS de ESP8266 no admite TimeStamp. La fecha siempre es el 01/01/1970
*/

#ifndef RoJoMultiFS_h
#define RoJoMultiFS_h

#include <Arduino.h>
//Definimos sistema de archivos
#ifdef ROJO_PIN_CS_SD //Si utilizamos una SD
  #ifdef __arm__ //Si es una Raspberry...
    #error Raspberry has not SD
  #endif
  #define RoJoFileSystem 0
  #include <SD.h>
  #include <time.h> //Para time_t
  #define _FS SD
#else //Si no utilizamos una SD
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino...
    #error Arduino family has not internal file system
  #endif
  #ifndef RoJoFileSystem //SPIFFS
    #define RoJoFileSystem 1 
  #endif
  #if RoJoFileSystem == 1 //SPIFFS
    #ifdef ESP32
      #include <SPIFFS.h>
    #else
      #include <FS.h>
    #endif
    #define _FS SPIFFS
  #elif RoJoFileSystem == 2 //LittleFS
    #include <LittleFS.h>
    #define _FS LittleFS
  #elif RoJoFileSystem == 3 //FFat
    #ifdef ESP8266
      #error ESP8266 has not FFat
    #else
      #include <FFat.h>
      #define _FS FFat
    #endif
  #endif
#endif

//La clase Dir aparece en el ESP8266 para la gestión de directorios.
//Sirve para comprobar el interior de un directorio.
//Con sistema de archivos SD en el ESP8266, no se utilizará Dir, pero está definido.
//Por esta razon se crear la clase RoJoDir
//La clase Dir también se define en la emulación de todos los sistemas de archivos de RPi
//Quedan algunas combinaciones sin este objeto

//         SD SPIFFS LitleFS FFat
//         -- ------ ------- ----
// RPi      x   S       S      S
// ESP32    N   N       N      N
// ESP8266  N   S       N      N
// Arduino  N   x       x      x

// x = combinación inexistente
// S = Sí se utiliza el objeto Dir
// N = No se utiliza el objeto Dir

class RoJoDir {
  protected:
    #if (defined(ESP8266) && (RoJoFileSystem==1)) || defined(__arm__)
      Dir _dir;
    #else
      File _dirFile;
      String _fileName;
      uint32_t _fileSize;
      time_t _fileTime;
      bool _isDirectory;
    #endif
  public:
    RoJoDir(String path); //Constructor
    ~RoJoDir(); //Destructor
    bool next();
    String fileName();
    uint32_t fileSize();
    static String twoDigits(uint16_t v); //Formatea a 2 dígitos
    static String fileTimeString(time_t t); //dd/mm/yyyy hh:mm:ss
    time_t fileTime();
    bool isDirectory();
};

#ifndef ESP8266 //ESP32 o Arduino
  time_t (*_timeCallbackRoJoFS)()=NULL;
#endif

class RoJoMultiFS {
  protected:
  public:
    bool begin(bool formatOnFail=false); //Inicialización de sistema de archivo
    void end(); //Finalia uso de sistema de archivos
    bool exists(String path); //Existe el archivo/directorio?
    bool mkdir(String path); //Crea un directorio
    File open(String path,const char *mode="r");
    bool remove(String path); //Elimina un archivo
    bool rmdir(String path,bool force=false); //Elimina un directorio
    bool rename(String pathFrom,String pathTo); //Renombra un archivo
    RoJoDir openDir(String path); //Abre un directorio
    bool format(); //Formatea sistema de archvos
    bool delDir(String path); //Vacía un directorio
    void setTimeCallback(time_t (*cb)()); //Define función de fecha para archivos
};

#include <RoJoMultiFS.cpp>

#endif


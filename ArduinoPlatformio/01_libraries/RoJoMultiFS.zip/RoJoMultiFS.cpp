#ifndef RoJoMultiFS_cpp
#define RoJoMultiFS_cpp

#include <RoJoMultiFS.h>

#ifdef ARDUINO_ARCH_AVR //Arduino
  //Función de obtención de fecha para escritura de archivoe en Arduino
  void _timeCallbackAVR(uint16_t* date,uint16_t* time) {
    if(_timeCallbackRoJoFS) {
      time_t t=_timeCallbackRoJoFS();
      struct tm *t1=localtime(&t);
      *date=FAT_DATE(t1->tm_year+1900,t1->tm_mon+1,t1->tm_mday);
      *time=FAT_TIME(t1->tm_hour,t1->tm_min,t1->tm_sec);
    }
  }
#endif

RoJoMultiFS RoJoFS; //Creamos una instancia

//Constructor
//path en formato /dir1/dir2
RoJoDir::RoJoDir(String path) {
  #if RoJoFileSystem==1 //Si es SPIFFS...
    if(path=="/") { //Si es la raíz...
      #ifdef ESP32
        _dirFile=RoJoFS.open(path); //Intentamos abrir el directorio
        if(_dirFile) { //Si se ha podido abrir el archivo...
          if(!_dirFile.isDirectory()) _dirFile.close(); //Si no es un directorio...lo cerramos
        } //_dirFile sólo quedará abierto si todo ha salido bien
      #else //ESP8266 & RPi
        _dir=_FS.openDir(path);
      #endif
    }
    //Si no es el directorio raíz, no se inicializa nada y no se tendrá en cuenta
  #else //No es SPIFFS
    #ifdef __arm__ //RPi
      _dir=_FS.openDir(path);
    #else //ESP8266 & ESP32
      _dirFile=RoJoFS.open(path); //Intentamos abrir el directorio
      if(_dirFile) { //Si se ha podido abrir el archivo...
        if(!_dirFile.isDirectory()) _dirFile.close(); //Si no es un directorio...lo cerramos
      } //_dirFile sólo quedará abierto si todo ha salido bien
    #endif
  #endif
}

//Destructor
RoJoDir::~RoJoDir() {
  #if (defined(ESP8266) && (RoJoFileSystem==1)) || defined(__arm__)
    //No hay que hacer nada especial para finalizar un Dir
  #else
    if(_dirFile) _dirFile.close();
  #endif
}

//Siguiente archivo del directorio
//Devuelve true si existe otro archivo
bool RoJoDir::next() {
  #if (defined(ESP8266) && (RoJoFileSystem==1)) || defined(__arm__)
    return _dir.next();
  #else
    if(_dirFile) { //Si tenemos un directorio abierto...
      File file=_dirFile.openNextFile(); //Tomamos el siguiente archivo
      if(file) { //Si hemos podido abrir el siguiente item...
        _fileName=file.name();
        _fileSize=file.size();
        #if RoJoFileSystem==0 //SD
          #ifdef ARDUINO_ARCH_AVR //Arduino
            _fileTime=0; //La librería SD de Arduino no lee fechas
          #elif defined(ESP8266) //ESP8266
            _fileTime=file.getCreationTime();
          #else //ESP32
            _fileTime=file.getLastWrite(); //La lib SD de ESP32 no tiene getCreationTime
          #endif
        #elif RoJoFileSystem==1 //SPIFFS
          _fileTime=file.getLastWrite(); //SPIFFS de ESP32 no tiene getCreationTime
        #elif RoJoFileSystem==2 //LittleFS
          #ifdef ESP8266 //ESP8266
            _fileTime=file.getCreationTime();
          #else //ESP32
            _fileTime=file.getLastWrite(); //LittleFS de ESP32 no tiene getCreationTime
          #endif
        #else //FFat
          _fileTime=file.getLastWrite();
        #endif
        _isDirectory=file.isDirectory();
        file.close();
      } else { //No hay más items en el directorio...
        _dirFile.close();
      }
    }
    return _dirFile;
  #endif
};

//Nombre del archivo actual
String RoJoDir::fileName() {
  #if defined(ESP8266) && (RoJoFileSystem==1)
    return _dir.fileName().substring(1); //SPIFFS de ESP8266 siempre añade / al inicio del nombre
  #elif defined(__arm__)
    return _dir.fileName();
  #else
    return _fileName;
  #endif
};

//Tamaño del archivo actual
uint32_t RoJoDir::fileSize() {
  #if (defined(ESP8266) && (RoJoFileSystem==1)) || defined(__arm__)
    return _dir.fileSize();
  #else
    return _fileSize;
  #endif
};

//Fecha del archivo actual
time_t RoJoDir::fileTime() {
  #if (defined(ESP8266) && (RoJoFileSystem==1)) || defined(__arm__)
    return _dir.fileCreationTime();
  #else
    return _fileTime;
  #endif
}

//Formatea a 2 dígitos
String RoJoDir::twoDigits(uint16_t v) {
  String res=String(v);
  if(res.length()<2) res="0"+res;
  return res;
}

//Fecha en formato dd/mm/yyyy hh:mm:ss
String RoJoDir::fileTimeString(time_t t) {
  struct tm *t4=localtime(&t);
  return twoDigits(t4->tm_mday)+"/"+twoDigits(1+t4->tm_mon)+"/"+String(1900+t4->tm_year)+" "+twoDigits(t4->tm_hour)+":"+twoDigits(t4->tm_min)+":"+twoDigits(t4->tm_sec);
}

//La entrada actual es un directorio?
bool RoJoDir::isDirectory() {
  #if (defined(ESP8266) && (RoJoFileSystem==1)) || defined(__arm__)
    return _dir.isDirectory();
  #else
    return _isDirectory;
  #endif
};


//Inicializa sistema de archivos
//Devuelve true si lo consigue
bool RoJoMultiFS::begin(bool formatOnFail) {
  #if RoJoFileSystem==0 //Si es SD
    #ifdef ARDUINO_ARCH_AVR //Arduino
      SdFile::dateTimeCallback(_timeCallbackAVR);
    #endif
    return _FS.begin(ROJO_PIN_CS_SD);
  #else //Si no es SD
    #ifdef ESP8266
      return _FS.begin();
    #else
      return _FS.begin(formatOnFail);
    #endif
  #endif
}

//Finaliza sistema de archivos
void RoJoMultiFS::end() {
  //La librería SD no tiene método end()
  #if RoJoFileSystem > 0 //Si no es SD..
    _FS.end();
  #endif
}

//Comprueba si existe un archivo o directorio
//Path en formato /dir1/name.ext
bool RoJoMultiFS::exists(String path) {
  #if RoJoFileSystem==3 //FFat
    //El método exists de FFat sólo detecta la existencia de archivos no de directorios
    //Creamos nuestra propia rutina
    File f=_FS.open(path,"r",false);
    bool res=f;
    f.close();
    return res;
  #else
    return _FS.exists(path);
  #endif
}

//Renombra un archivo
//Paths en formato /dir1/name.ext
//Devuelve true si lo consigue
bool RoJoMultiFS::rename(String pathFrom,String pathTo) {
  #if RoJoFileSystem==0 && defined(ARDUINO_ARCH_AVR) //Si es SD de Arduino...
    //La librería de gestión de SD de Arduino NO tiene el
    //método rename. Tenemos que crear el archivo, copiar
    //su contenido y borrar el original :-(
    File f1=SD.open(pathFrom,FILE_READ); //Abrimos el archivo origen como lectura
    if(!f1) return false;
    File f2=SD.open(pathTo,FILE_WRITE); //Abrimos el archivo destino como escritura
    if(!f2) return false;
    while(f1.available()>0) f2.write((byte)f1.read());
    f2.close();
    f1.close();
    return SD.remove(pathFrom);
  #else //No es SD de Arduino...
    return _FS.rename(pathFrom,pathTo);
  #endif
}

//Formatea el File System
//Devuelve true si lo consigue
bool RoJoMultiFS::format() {
  //Notas:
  //- No se puede formatear una SD. El driver no lo permite
  //- No se puede formatear ningún sistema en una RPi
  #if RoJoFileSystem!=0 && !defined(__arm__)
    return _FS.format();
  #else
    return false;
  #endif
}

//Crea un directorio
//Formato de path: /dir1/dir2
//Puede crear un directorio de varios niveles de profundidad
//No es necesario que existan los directorios superiores previamente
//No se pueden crear directorios en SPIFFS
//Devuelve true si lo consigue
bool RoJoMultiFS::mkdir(String path) {
  #if RoJoFileSystem==1 //Si es SPIFFS...
    return false; //En SPIFFS no hay directorios!
  #else
    if(path.length()<2) return true; //Si es / o nada...ya está!
    if(exists(path)) return true; //Si ya existe...hemos terminado
    #if defined(ESP32)
      if(_timeCallbackRoJoFS) {
        time_t t=_timeCallbackRoJoFS(); 
        if(t>2082758399) t-=2082758399;
        struct timeval tv;
        tv.tv_sec=t; //Segundos
        tv.tv_usec=0; //Microsegundos
        settimeofday(&tv,NULL); //Ponemos el reloj interno en hora
      }
    #endif
    //Si no se puede crear el path anterior...terminamos mal
    if(!mkdir(path.substring(0,path.lastIndexOf("/")))) return false;
    return _FS.mkdir(path); //Creamos el path actual
  #endif
}

//Abre un archivo
//Formato de path: /dir1/name.ext
//Posibles valores de mode:
//  r : sólo lectura
//  r+ o w+: lectura/escritura
//  w : sólo escritura
File RoJoMultiFS::open(String path,const char *mode) {
  #ifdef ARDUINO_ARCH_AVR
    if(strcmp(mode,"r")==0) return _FS.open(path,FILE_READ);
    //Si tenemos que abrir en modo escritura...
    File f=_FS.open(path,FILE_WRITE);
    //Cuando se abre un archivo en modo escritura en Arduino, siempre
    //lo hace en modo APPEND y comienza a escribir desde el final
    if(f) f.seek(0); //Lo corregimos
    return f;
  #else
    #if defined(ESP32)
      if(_timeCallbackRoJoFS) {
        time_t t=_timeCallbackRoJoFS(); 
        if(t>2082758399) t-=2082758399;
        struct timeval tv;
        tv.tv_sec=t; //Segundos
        tv.tv_usec=0; //Microsegundos
        settimeofday(&tv,NULL); //Ponemos el reloj interno en hora
      }
    #endif
    #ifdef __arm__
      //En RPi, el timestamp de los archivos se realiza una vez cerrados
      //Necesitamos notificarlo en el open para que se tengo en cuenta en el close
      return _FS.open(path,mode,_timeCallbackRoJoFS);
    #else
      return _FS.open(path,mode);
    #endif
  #endif
}

//Elimina un archivo
//Formato de path: /dir1/name.ext
//Devuelve true si lo consigue
bool RoJoMultiFS::remove(String path) {
  return _FS.remove(path);
}

//Abre un directorio
//Formato de path: /dir1/dir2
RoJoDir RoJoMultiFS::openDir(String path) {
  return RoJoDir(path);
}

//Vacía un directorio
//Formato de path: /dir1/dir2
//Devuelve true si lo consigue
bool RoJoMultiFS::delDir(String path) {
  RoJoDir dir=openDir(path);
  bool res=true; //Inicialmente todo correcto
  while(dir.next() || !res) {
    String newPath=((path=="/")?"":path)+"/"+dir.fileName();
    if(dir.isDirectory()) { //Si es un directorio...
      res=delDir(newPath); //Vaciamos el directorio
      if(res) res=rmdir(newPath); //Si lo hemos vaciado, lo borramos
    } else { //Si es un archivo...
      res=remove(newPath); //...lo borramos
    }
  }
  return res;
}

//Elimina un directorio
//Parámetros:
//- path: ruta en formato /dir1/dir2
//- force: se debe vaciar primero?
//Devuelve true si lo consigue
bool RoJoMultiFS::rmdir(String path,bool force) {
  #if RoJoFileSystem==1 //Si es SPIFFS...
    return false; //En SPIFFS no hay directorios!
  #else
    if(force) {
      #if RoJoFileSystem==2 && defined(ESP8266) //LittleFS en ESP8266
        //En LittleFS de ESP8266 cuando se elimina el último de los archivos de un
        //directorio también se elimina el directorio. Por eso no necesitaremos hacer nada más.
        return delDir(path);
      #elif defined(__arm__)
        return _FS.rmdir(path,true); //Utilizamos la función de borrado forzado de RPi
      #else
        if(!delDir(path)) return false; //Si no hemos podido vaciar el directorio...error
      #endif
    }
    return _FS.rmdir(path); //Borramos el directorio que ahora está vacío
  #endif
}

//Define función de fecha para archivos
//La función debe ser de tipo: time_t myFunc()
void RoJoMultiFS::setTimeCallback(time_t (*cb)()) {
  #ifdef ESP8266
    //Nota: No funciona para SPIFFS de ESP8266. Siempre devuelve 01/01/1970
    _FS.setTimeCallback(cb);
  #else //ESP32 o Arduino o RPi
    _timeCallbackRoJoFS=cb; //Guardamos la función
  #endif
}

#endif

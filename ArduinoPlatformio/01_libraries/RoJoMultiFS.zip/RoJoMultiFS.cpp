/*
  Nombre de la librería: RoJoMultiFS.h
  Versión: 20220511
  Autor: Ramón Junquera
*/

#ifndef RoJoMultiFS_cpp
#define RoJoMultiFS_cpp

#include <RoJoMultiFS.h>

//Inicializa File System
//Devuelve true si lo consigue
bool RoJoMultiFS::begin(bool formatOnFail) {
  #if RoJoFileSystem == 0 //Si es SD
    return _FS.begin(ROJO_PIN_CS_SD);
  #else //Si no es SD
    #ifdef ESP8266
      return _FS.begin();
    #else
      return _FS.begin(formatOnFail);
    #endif
  #endif
}

//Finaliza File System
void RoJoMultiFS::end() {
  _FS.end();
}

//Comprueba si existe un archivo
bool RoJoMultiFS::exists(String path) {
  return _FS.exists(path);
}

#if RoJoFileSystem!=0 && !defined(__arm__) //Si no es SD...
  //Formatea el File System
  bool RoJoMultiFS::format() {
    return _FS.format();
  }
  //Renombra un archivo
  bool RoJoMultiFS::rename(String pathFrom,String pathTo) {
    return _FS.rename(pathFrom,pathTo);
  }
#endif

//Crea una carpeta
bool RoJoMultiFS::mkdir(String path) {
  return _FS.mkdir(path);
}

//Abre un archivo
//Posibles valores de mode:
//  r : sólo lectura
//  r+ o w+: lectura/escritura
//  w : sólo escritura
File RoJoMultiFS::open(String path,const char *mode) {
  #ifdef ARDUINO_ARCH_AVR
    if(strcmp(mode,"r")==0) return _FS.open(path,FILE_READ);
    //Si tenemos que abrir en modo escritura...
    File f=_FS.open(path,FILE_WRITE);
    //Cuando se abre un archivo en modo escritura en Arduino, siempre
    //lo hace en modo APPEND y comienza a escribir desde el final
    if(f) f.seek(0); //Lo corregimos
    return f;
  #else
    return _FS.open(path,mode);
  #endif
}

//Elimina un archivo
bool RoJoMultiFS::remove(String path) {
  return _FS.remove(path);
}

//Elimina una carpeta
bool RoJoMultiFS::rmdir(String path) {
  return _FS.rmdir(path);
}

#endif

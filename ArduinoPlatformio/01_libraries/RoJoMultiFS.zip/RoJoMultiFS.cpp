/*
  Nombre de la librería: RoJoMultiFS.h
  Versión: 20220808
  Autor: Ramón Junquera
*/

#ifndef RoJoMultiFS_cpp
#define RoJoMultiFS_cpp

#include <RoJoMultiFS.h>

//Inicializa File System
//Devuelve true si lo consigue
bool RoJoMultiFS::begin(bool formatOnFail) {
  #if RoJoFileSystem == 0 //Si es SD
    return _FS.begin(ROJO_PIN_CS_SD);
  #else //Si no es SD
    #ifdef ESP8266
      return _FS.begin();
    #else
      return _FS.begin(formatOnFail);
    #endif
  #endif
}

//Finaliza File System
void RoJoMultiFS::end() {
  //La librería SD no tiene método end()
  #if RoJoFileSystem > 0 //Si no es SD..
    _FS.end();
  #endif
}

//Comprueba si existe un archivo
bool RoJoMultiFS::exists(String path) {
  return _FS.exists(path);
}

//Renombra un archivo
//Devuelve true si lo consigue
bool RoJoMultiFS::rename(String pathFrom,String pathTo) {
  #if RoJoFileSystem==0 && defined(ARDUINO_ARCH_AVR) //Si es SD de Arduino...
    //La librería de gestión de SD de Arduino NO tiene el
    //método rename. Tenemos que crear el archivo, copiar
    //su contenido y borrar el original :-(
    File t=SD.open(pathFrom,FILE_READ); //Abrimos el archivo origen como lectura
    File f=SD.open(pathTo,FILE_WRITE); //Abrimos el archivo destino como escritura
    while(t.available()>0) f.write((byte)t.read());
    f.close();
    t.close();
    SD.remove(pathFrom);
    return true;
  #else //No es SD de Arduino...
    return _FS.rename(pathFrom,pathTo);
  #endif
}

#if RoJoFileSystem!=0 && !defined(__arm__) //Si no es SD...
  //Formatea el File System
  bool RoJoMultiFS::format() {
    return _FS.format();
  }
#endif

//Crea una carpeta
bool RoJoMultiFS::mkdir(String path) {
  return _FS.mkdir(path);
}

//Abre un archivo
//Posibles valores de mode:
//  r : sólo lectura
//  r+ o w+: lectura/escritura
//  w : sólo escritura
File RoJoMultiFS::open(String path,const char *mode) {
  #ifdef ARDUINO_ARCH_AVR
    if(strcmp(mode,"r")==0) return _FS.open(path,FILE_READ);
    //Si tenemos que abrir en modo escritura...
    File f=_FS.open(path,FILE_WRITE);
    //Cuando se abre un archivo en modo escritura en Arduino, siempre
    //lo hace en modo APPEND y comienza a escribir desde el final
    if(f) f.seek(0); //Lo corregimos
    return f;
  #else
    return _FS.open(path,mode);
  #endif
}

//Elimina un archivo
bool RoJoMultiFS::remove(String path) {
  return _FS.remove(path);
}

//Elimina una carpeta
bool RoJoMultiFS::rmdir(String path) {
  return _FS.rmdir(path);
}

#endif

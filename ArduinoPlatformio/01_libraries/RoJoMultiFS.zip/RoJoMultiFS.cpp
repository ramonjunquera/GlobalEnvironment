/*
  Nombre de la librería: RoJoMultiFS.h
  Versión: 20220201
  Autor: Ramón Junquera
*/

#ifndef RoJoMultiFS_cpp
#define RoJoMultiFS_cpp

#include <RoJoMultiFS.h>

//Inicializa File System
bool RoJoMultiFS::begin(bool formatOnFail) {
  #if RoJoFileSystem == 0 //Si es SD
    return FSTYPE.begin(ROJO_PIN_CS_SD);
  #else //Si no es SD
    #ifdef ESP8266
      return FSTYPE.begin();
    #else
      return FSTYPE.begin(formatOnFail);
    #endif
  #endif
}

//Finaliza File System
void RoJoMultiFS::end() {
  FSTYPE.end();
}

//Comprueba si existe un archivo
bool RoJoMultiFS::exists(String path) {
  return FSTYPE.exists(path);
}

#if FileSystem!=0 //Si no es SD
  //Formatea el File System
  bool RoJoMultiFS::format() {
    return FSTYPE.format();
  }
  //Renombra un archivo
  bool RoJoMultiFS::rename(String pathFrom,String pathTo) {
    return FSTYPE.rename(pathFrom,pathTo);
  }
#endif

//Crea una carpeta
bool RoJoMultiFS::mkdir(String path) {
  return FSTYPE.mkdir(path);
}

//Abre un archivo
//Posibles valores de mode:
//  r : sólo lectura
//  r+ o w+: lectura/escritura
//  w : sólo escritura
File RoJoMultiFS::open(String path,const char *mode) {
  #ifdef ARDUINO_ARCH_AVR
    if(strcmp(mode,"r")==0) return FSTYPE.open(path,FILE_READ);
    //Si tenemos que abrir en modo escritura...
    File f=FSTYPE.open(path,FILE_WRITE);
    //Cuando se abre un archivo en modo escritura en Arduino, siempre
    //lo hace en modo APPEND y comienza a escribir desde el final
    if(f) f.seek(0); //Lo corregimos
    return f;
  #else
    return FSTYPE.open(path,mode);
  #endif
}

//Elimina un archivo
bool RoJoMultiFS::remove(String path) {
  return FSTYPE.remove(path);
}

//Elimina una carpeta
bool RoJoMultiFS::rmdir(String path) {
  return FSTYPE.rmdir(path);
}

#endif

/*
  Nombre de la librería: RoJoLCD5110.h
  Versión: 20220117
  Autor: Ramón Junquera
  Descripción:
    Gestión de display Nokia LCD 5110 SPI 84x48
*/

#ifndef RoJoLCD5110_cpp
#define RoJoLCD5110_cpp

#include <RoJoLCD5110.h>

// Envía al display una colección de comandos
// Después de los comandos, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoLCD5110::_writeCommand(byte command,...) {
  //Los comandos de este display no tienen parámetros y siempre son del tipo byte

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos el comando
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0) {
    SPI.transfer((byte)paramValue); //...enviamos el parámetro
  }
  va_end(paramList); //Hemos terminado de trabajar con la lista
  digitalWrite(_pinDC,HIGH); //Modo datos
}

// Activa/Desactiva el modo hibernación
void RoJoLCD5110::sleep(bool mode) {
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startCOMM();
    //_writeCommand(mode?0xAE:0xAF,-1); //0xAE=display OFF,0xAF=display ON
    _writeCommand(mode?0x24:0x20,-1); //0x24=display OFF,0x20=display ON
  _endCOMM();
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
//Este display no permite la definición de rangos, sólo de origen de escritura.
//Las coordenadas verticales no son pixels, sino páginas, puesto que es monocromo.
void RoJoLCD5110::_setCursorRangeY(byte page) {
  _writeCommand(0x40|(page&7),-1);
}
void RoJoLCD5110::_setCursorRangeX(byte x) {
  _writeCommand(0x80|(x&0x7F),-1);
}
void RoJoLCD5110::_setCursorRange(byte x,byte page) {
  //Combinamos _setCursorRangeY y _setCursorRangeX en un sólo comando para agilizarlo
  _writeCommand(0x40|(page&7),0x80|(x&0x7F),-1);
}

//Anchura de display
uint16_t RoJoLCD5110::xMax() {
  return _xMax;
}

//Altura de display
uint16_t RoJoLCD5110::yMax() {
  return _yMax;
}

//Reset & inicialización
void RoJoLCD5110::reset() {
  //Hard reset
  digitalWrite(_pinRES,LOW);
  delay(10);
  digitalWrite(_pinRES,HIGH);
  delay(10);
  //Comenzamos una transacción
  _startCOMM();
    _writeCommand(
       0x21 //Modo extendido: activamos el display y fijamos la escritura horizontal 0x20|0x01
	    ,0x14 //Fijamos el bias a 4 (normal) 0x10|0x04
      ,-1 //Fin de parámetros
    );
  _endCOMM();
  //Salimos del modo de bajo consumo
  sleep(false);
  //Modo normal (no invertido)
  negative(false);
  //Fijamos contraste por defecto
  //Depende el voltaje tomamos el valor que mejor se ve
  #ifdef ARDUINO_ARCH_AVR //para 5V
    setContrast(50);
  #else //Para 3.3V
    setContrast(65);
  #endif
  //Borramos el display
  clear();
}

//Fija el contraste
void RoJoLCD5110::setContrast(byte level) {
  //El rango permitido es [0,127]
  _startCOMM();
    _writeCommand(
       0x21 //Activamos el modo extendido
	    ,0x80|(level&0x7F) //Fijamos el contraste
	    ,0x20 //Modo normal
      ,-1 //Fin de parámetros
    );
  _endCOMM();
}

//Borra el área de dibujo
//El color puede ser 0=negro o cualquier otro valor=blanco
void RoJoLCD5110::clear(uint16_t color) {
  //Este display no permite rellenar áreas (comando block)
  //Rellenaremos toda la memoria gráfica del color indicado
  //recorriendo todas las páginas y columnas

  //Nos aseguramos que el color es 0x00 o 0xFF
  byte c=color==0?0x00:0xFF;
  
  _startCOMM();
    _setCursorRange(); //Comenzamos en 0,0
    //Recorremos todos los bytes de la memoria de vídeo (84*48=504)
    for(uint16_t i=0;i<504;i++) SPI.transfer(c);
  _endCOMM();
}

//Display con colores invertidos blanco <-> negro
void RoJoLCD5110::negative(bool mode) {
  //mode == true  : ON=white, OFF=black
  //mode == false : ON=black, OFF=white
  _startCOMM();
    _writeCommand(mode?0x0D:0x0C,-1);
  _endCOMM();
}

// Inicia comunicación
void RoJoLCD5110::_startCOMM() {
  SPI.beginTransaction(_spiSetting);
  digitalWrite(_pinCS,LOW);
}

// Finaliza comunicación
void RoJoLCD5110::_endCOMM() {
  digitalWrite(_pinCS,HIGH);
  SPI.endTransaction();
}

//Inicialización
void RoJoLCD5110::begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM) {
  if(!freqCOMM) { //Si no se ha indicado frecuencia...
    #ifdef ARDUINO_ARCH_AVR //Para placas Arduino...
      freqCOMM=3999999; //Menos de 4MHz
    #else //Cualquier otro dispositivo...
      freqCOMM=25000000; //25MHz
    #endif
  }
  //Definimos las caraterísticas de la conexión SPI
  _spiSetting=SPISettings(freqCOMM,MSBFIRST,SPI_MODE0);
  //Inicializamos las conexiones SPI
  SPI.begin();
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif

  //Guardamos los parámetros en variables internas
  _pinDC=pinDC;
  _pinRES=pinRES;
  _pinCS=pinCS;
  //Siempre escribiremos en los pines DC, RES y CS
  pinMode(_pinDC,OUTPUT);
  pinMode(_pinRES,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinRES,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip
  //Reseteamos el display
  reset();
  //Llamamos a la inicialización de la clase padre
  RoJoGraph3::begin(); //Principalmente inicializa SPIFFS
}

//Envía un sprite al display comenzando en el origen
//La coordenada vertical 'y' debe ser múltiplo de 8
//Devuelve true si se muestra algo
bool RoJoLCD5110::drawSprite(RoJoSprite3 *sprite,int16_t x,int16_t y) {
  //Si el sprite no es monocromo...terminamos con error
  if(sprite->bytesPerPixel()) return false;
  //Si la coordenada vertical no es múltiplo de 8...terminamos con error
  if(y%8) return false;
  //Calculamos el área visible
  displayRange r=RoJoGraph3::visibleRange(x,y,sprite->xMax(),sprite->yMax(),_xMax,_yMax);
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  //Convertimos los valores verticales a páginas
  y/=8; r.y1/=8; r.y2/=8;
  
  _startCOMM();
    //Variables para optimizar el bucle
    int16_t ry2=r.y2,rx2=r.x2,offsetY;
    //Recorremos todas las páginas visibles del display
    for(int16_t dy=(int16_t)r.y1;dy<=ry2;dy++) {
      //Calculamos el offset de fila
      offsetY=dy-y;
      //Definimos el rango del cursor
      _setCursorRange(r.x1,dy);
      //Recorremos todas las columnas visibles del sprite y enviamos el valor de la página
      for(int16_t dx=(int16_t)r.x1;dx<=rx2;dx++) SPI.transfer(sprite->_videoMem[offsetY][dx-x]);
    }
  _endCOMM();
  //Todo Ok
  return true;
}

#endif

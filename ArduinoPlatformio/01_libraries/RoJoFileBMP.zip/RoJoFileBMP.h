/*
  Nombre de la librería: RoJoFileBMP.h
  Versión: 20220408
  Autor: Ramón Junquera
  Descripción:
    Gestión de archivos .bmp
  Características:
  - Se trata directamente con archivos .bmp.
  - Se permite la lectura y escritura, como si fuese un sprite, pero en archivo.
  - El archivo se mantiene abierto entre las llamadas a begin y end.
  Rendimiento:
    Por supuesto que el rendimiento de un sprite en archivo es muy inferior a uno
    mantenido en memoria. De todas maneras, el sistema de archivos influye mucho.

    Se muestra una tabla comparativa de tiempos.
    La prueba de create consiste en crear un bmp de 240x320 color de 24 bits de profundidad
    La prueba block10x10 consiste en dibujar un bloque de 10x10 en las coordenadas 50,200
    del bmp anterior.
    Para simplificar se supone que el tiempo que se tarda con una SD formateada a FAT32 es 1.

    cpu       test         SD      SPIFFS LittleFS Ffat
    ------- ----------  ---------- ------ -------- ----
    ESP8266 create      1 (3591ms)   21.1      1.7 
            block10x10  1 (  93ms)   30.3    513.8 
    ESP32   create      1 (1966ms)    3.0      3.0 1.3
            block10x10  1 (  57ms)    2.1    275.0 1.3

  Conclusiones:
  - El sistema de archivos más rápido (y recomendado) es una tarjeta SD con formato FAT32
  - Aunque LittleFS se comporta bien a la hora de crear (o leer) archivo, tiene un pésimo
    rendimiento al modificar. Esto es debido a su diseño. Más detalles en comentarios de librería
    RoJoMultiFS. Se debe evitar este sistema de archivos.
  - El rendimiento de SPIFFS es la mitad que Ffat.
  - Ffat es el format de sistema de archivos interno recomendado.
  - El orden de preferencia del sistema de archivos es:
    1. SD FAT32
    2. Ffat
    3. SPIFFS
    4. LittleFS (evitar)
  */

#ifndef RoJoFileBMP_h
#define RoJoFileBMP_h

#include <Arduino.h>
#include <RoJoGraph.h> //Funciones gráficas avanzadas

class RoJoFileBMP:public RoJoGraph {
  protected:
    uint16_t _xMax=0,_yMax=0; //Anchura y altura en pixels
    File _f;
    uint32_t _bytesPerLine; //Número de bytes por línea en el archivo (múltiplo de 4)
    uint32_t _base; //Posición de inicio de la última línea del bmp = primera línea de gráfico
    void _calcBytesPerLine(); //Calcula el número de bytes por línea
    void _write32(uint32_t value); //Escribe en el archivo un valor uint32_t en formato L->H
    virtual void _drawPixel(uint16_t x,uint16_t y,uint32_t color); //Dibuja un pixel
    virtual void _block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color); //Dibuja un rectángulo relleno
  public:
    void close();
    byte open(String filename);
    bool create(String filename,uint16_t x,uint16_t y,byte bytesPerPixel=3,uint32_t backgroundColor=0);
    virtual uint16_t xMax(); //Anchura en pixels
    virtual uint16_t yMax(); //Altura en pixels
    virtual ~RoJoFileBMP(); //Destructor
}; //Punto y coma obligatorio para que no de error

#include <RoJoFileBMP.cpp>

#endif


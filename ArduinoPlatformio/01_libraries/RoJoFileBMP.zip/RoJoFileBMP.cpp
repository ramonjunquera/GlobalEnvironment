/*
  Nombre de la librería: RoJoFileBMP.h
  Versión: 20220408
  Autor: Ramón Junquera
  Descripción:
    Gestión de archivos .bmp
*/

#ifndef RoJoFileBMP_cpp
#define RoJoFileBMP_cpp

#include <RoJoFileBMP.h>

//Cierra el archivo .bmp
void RoJoFileBMP::close() {
  if(_f) _f.close();
}

//Destructor
RoJoFileBMP::~RoJoFileBMP() {
  close();
}

//Calcula el número de bytes por línea
void RoJoFileBMP::_calcBytesPerLine() {
  if(_bytesPerPixel) _bytesPerLine=((uint32_t)_xMax)*3; //Si es color
  else { //Si es monocromo...
    _bytesPerLine=_xMax/8;
    if(_xMax%8) _bytesPerLine++;
  }
  //Ajustamos la longitud de línea a múltiplo de 4
  byte remainder=_bytesPerLine%4; //Calculamos el resto de dividir por 4
  if(remainder) _bytesPerLine+=4-remainder;
}

//Escribe en el archivo un valor uint32_t en formato L->H
void RoJoFileBMP::_write32(uint32_t value) {
  for(byte i=4;i>0;i--) {
    _f.write(byte(value & 0xFF));
    value>>=8;
  }
}

//Abre un .bmp existente. Devuelve código de error
//Tabla de errores (mismos que RoJoGraph3::infoBMP):
//  0 : No hay errores. Todo correcto
//  1 : No se puede abrir el archivo. Posiblemente no existe.
//  2 : La firma del tipo de archivo no coincide
//  3 : Anchura demasiado grande
//  4 : Altura demasiado grande
//  5 : El número de planos no es 1
//  6 : La profundidad de color no está reconocida
//  7 : Está comprimido
byte RoJoFileBMP::open(String filename) {
  if(_f) return false; //Ya tenemos un archivo abierto
  RoJoGraph::begin(); //Inicializa sistema de archivos
  uint16_t width,height;
  byte bytesPerPixel;
  byte errorCode=infoBMP(filename,&width,&height,&bytesPerPixel);
  if(errorCode) return errorCode;
  _xMax=width;
  _yMax=height;
  _bytesPerPixel=bytesPerPixel;
  _f=RoJoFS.open(filename,"r+"); //Abrimos el archivo en modo lectura/escritura
  _calcBytesPerLine(); //Calculamos los bytes por línea en el archivo
  return 0;
}

//Dibuja un pixel. Función interna. Sin comprobaciones.
void RoJoFileBMP::_drawPixel(uint16_t x,uint16_t y,uint32_t color) {
  if(_bytesPerPixel) { //Si es un bmp color...
    _f.seek(_base-(uint32_t)y*_bytesPerLine+3*(uint32_t)x);
    for(byte i=0;i<3;i++) {
      _f.write((byte)(color & 0xFF));
      color>>=8;
    }
  } else { //Si es un bmp monocromo...
    uint32_t offset=_base-(uint32_t)y*_bytesPerLine+(uint32_t)(x/8); //Calculamos la posición del byte gráfico
    _f.seek(offset); //Nos posicionamos en el byte gráfico
    byte g=_f.read(); //Leemos el valor gráfico actual
    if(color) g|=128>>(x%8); //Enciende pixel
    else g&=~(128>>(x%8)); //Apaga pixel
    _f.seek(offset); //Volvemos a posicionarnos en el mismo byte gráfico
    _f.write(g); //Escribimos el nuevo valor
  }
}

//Crea un nuevo .bmp
//Devuelve true si lo consigue
bool RoJoFileBMP::create(String filename,uint16_t x,uint16_t y,byte bytesPerPixel,uint32_t backgroundColor) {
  if(_f) return false; //Ya tenemos un archivo abierto...hemos terminado
  //Sólo se trabaja con .bmp de color real (24 bits) o monocromos
  if(bytesPerPixel!=3 && bytesPerPixel!=0) return false;
  RoJoGraph::begin(); //Inicializa sistema de archivos
  _xMax=x;
  _yMax=y;
  _bytesPerPixel=bytesPerPixel;
  _calcBytesPerLine(); //Calculamos los bytes por línea en el archivo
  _base=54+_bytesPerLine*((uint32_t)_yMax-1); //Calculamos posición de la última fila del bmp
  byte color[3];
  //Calculamos al color de background
  if(_bytesPerPixel) { //Color
    //Guardamos color en formato BGR. En backgroundColor está en formato RGB
    for(byte i=0;i<3;i++) {
      color[i]=backgroundColor & 0xFF;
      backgroundColor>>=8;
    }
  } else { //Monocromo
    color[0]=backgroundColor==0?0:0xFF;
  }
  _f=RoJoFS.open(filename,"w+"); //Abrimos el archivo como lectura/escritura
  if(!_f) return false; //No hemos podido crear el archivo
  //Necesitamos escribir la cabecera del bmp
  //offset # descripción
  //------ - -----------
  //   0   2 "BM" constante =0x42,0x4D
  //   2   4 tamaño de archivo L->H
  //   6   4 reservado (ceros)
  //  10   4 offset de inicio de datos gráficos (54=0x36,0x00,0x00,0x00)
  //  14   4 tamaño de cabecera (40=0x28,0x00,0x00,0x00)
  //  18   4 anchura en pixels L->H
  //  22   4 altura en pixels L->H
  //  26   2 número de planos (habitualmente 1=0x01,0x00)
  //  28   2 bits por pixel (habitualmente 24 para imágenes a color 24=0x18,0x00)
  //  30   4 compresión (habitualmente 0=ninguna=0x00,0x00,0x00,0x00)
  //  34   4 tamaño de imágen (cantidad de datos gráficos=anchura*altura*bytesporpixel)
  //  38   4 resolución horizontal (0x25,0x16,0x00,0x00)
  //  42   4 resolución vertical (0x25,0x16,0x00,0x00)
  //  46   4 tamaño de la tabla de color (ceros)
  //  50   4 contador de colores importantes (ceros)
  //  54   n Datos gráficos
  _f.write('B'); _f.write('M');
  uint32_t dataGraphics=((uint32_t)_yMax)*_bytesPerLine; //Calculamos bytes de datos gráficos
  _write32(dataGraphics+54); //Tamaño total del archivo
  _write32(0); //Reservado
  _write32(54); //Offset de datos gráficos
  _write32(40); //Tamaño de cabecera
  _write32(_xMax); //Anchura
  _write32(_yMax); //Altura
  _f.write(1); _f.write(0); //Número de planos

  _f.write(_bytesPerPixel==3?24:1); //Bits por pixel. 24 o 1
  _f.write(0);

  _write32(0); //Compresión
  _write32(dataGraphics); //Tamaño de imágen
  _write32(5669); //Resolución horizontal
  _write32(5669); //Resolución vertical
  _write32(0); //Tabla de color
  _write32(0); //Colores importantes
  //Cabecera completada
  //Ahora tenemos que rellenar el archivo con datos gráficos
  //Por defecto con el color indicado
  if(_bytesPerPixel) { //Color
    const byte extraBytes=_bytesPerLine-3*((uint32_t)_xMax); //Número de bytes para que sea múltiplo de 4
    for(uint16_t y=_yMax;y>0;y--) {
      for(uint16_t x=_xMax;x>0;x--) _f.write(color,3);
      for(byte i=extraBytes;i>0;i--) _f.write(0);
    }
  } else { //Monocromo
    for(uint16_t y=_yMax;y>0;y--) {
      for(uint16_t x=_bytesPerLine;x>0;x--) _f.write(color[0]);
    }
  }
  return true; //Todo Ok
}

//Anchura en pixels
uint16_t RoJoFileBMP::xMax() {
  return _xMax;
}

//Altura en pixels
uint16_t RoJoFileBMP::yMax() {
  return _yMax;
}

//Dibuja un rectángulo relleno. Función interna. Sin comprobaciones
void RoJoFileBMP::_block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color) {
  if(_bytesPerPixel) { //Si es un bmp color...
    byte _color[3];
    //Guardamos color en formato BGR
    for(byte i=0;i<3;i++) {
      _color[i]=color & 0xFF;
      color>>=8;
    }
    for(int16_t y0=0;y0<height;y0++) {
      _f.seek(_base-(y+y0)*_bytesPerLine+3*x);
      for(int16_t x0=width;x0>0;x0--) _f.write(_color,3);
      #ifdef ESP8266
        yield();
      #endif
    }
  } else { //Si es un bmp monocromo...
    for(uint16_t y0=0;y0<height;y0++) { //Recorremos todas las filas
      uint32_t byteOffset1=_base-(y+y0)*_bytesPerLine; //Offset de inicio de fila
      uint32_t byteOffset2=byteOffset1+(x+width-1)/8; //Offset de fin de bloque
      byteOffset1+=x/8; //Offset de inicio de bloque
      _f.seek(byteOffset1);
      byte currentByte=_f.read(); //Primer byte
      _f.seek(byteOffset1); //Volvemos a posicionarnos en el principio
      byte bitOffset1=x%8; //Bit de inicio
      byte bitOffset2=(x+width-1)%8; //Bit de fin
      byte mask=255;
      if(bitOffset1>0) mask=(1<<(8-bitOffset1))-1;
      if(byteOffset1==byteOffset2 && bitOffset2<7) mask&=~((1<<(7-bitOffset2))-1);
      if(color) _f.write(mask | currentByte); //Si hay que pintar
      else _f.write(~mask & currentByte); //Si hay que borrar
      if(byteOffset1!=byteOffset2) {
        mask=color>0?255:0; //Valor de bytes intermedios
        for(uint32_t i=byteOffset2-byteOffset1;i>0;i--) _f.write(mask); //bytes intermedios
        mask=255;
        if(bitOffset2<7) mask=~((1<<(7-bitOffset2))-1);
        currentByte=_f.read(); //Último byte
        _f.seek(byteOffset2); //Volvemos a posicionarnos en el último byte
        if(color) _f.write(mask | currentByte); //Si hay que pintar
        else _f.write(~mask & currentByte); //Si hay que borrar
      }
      #ifdef ESP8266
        yield();
      #endif
    }
  }
}

#endif

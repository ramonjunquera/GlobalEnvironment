/*
  Nombre de la librería: RoJoNeoPixel.h
  Versión: 20220516
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixel_cpp
#define RoJoNeoPixel_cpp

#include <RoJoNeoPixel.h>

void RoJoNeoPixel::end() {
  if(_ledsCount) {
    free(videoMem);
    #ifdef ESP32
      rmt_driver_uninstall(_channel); //Desinstalación del driver
      free(_pulseItems);
    #endif
    _ledsCount=0;
  }
}

//Destructor
RoJoNeoPixel::~RoJoNeoPixel() {
  end();
}

//Muestra el sprite de momoria de vídeo
void RoJoNeoPixel::show() {
  if(!_ledsCount) return; //Si no se ha inicializado...hemos terminado
    
  #ifdef ARDUINO_ARCH_AVR //Placas Arduino: Mega, Uno, Nano
    //Tenemos que transmitir la memoria de video actual
    //Debemos asegurarnos que han transcurrido al menos 300us desde la última
    //comunicación para que NeoPixel entienda que es una transferencia nueva.
    uint32_t deltaTime=micros()-_lastComm; //Tiempo transcurrido desde la última conexión
    //Si no han transcurrido más de 300us...los esperamos
    if(deltaTime<300) delayMicroseconds(300-deltaTime);

    //La duración de los pulsos en muy corta y las rutinas de gestión de pulsos
    //deben estar muy optimizadas.
    //Recuperar el valor de una variable de clase es más lento que hacerlo de
    //una variable local. Por eso hacemos una copia de los datos necesarios
    //en variables locales.
    byte currentChannel; //Byte de canal procesado
    byte maskChannel; //Máscara para procesar cada bit de cada canal
    byte *currentByte=(byte*)videoMem; //Puntero a byte procesado
    byte pinCommMask=_pinCommMask; //Máscara del pin en variable local
    volatile byte *pinCommPort=(byte*)_pinCommPort; //Puerto en variable local

    noInterrupts(); //Evitamos interrupciones durante el envío
    
    for(uint16_t i=_ledsCount*3;i>0;i--) { //Recorremos los 3 canales de cada led
      currentChannel=*currentByte; //Copiamos byte a procesar a variable local
      currentByte++; //Aumentamos puntero para siguiente ciclo
      maskChannel=0b10000000; //Calculamos la máscara del bit de mayor peso
      for(byte currentBit=8;currentBit>0;currentBit--) { //Recorremos los 8 bits del byte procesado
        //Debemos esperar 1.25us en pulso bajo antes de enviar un nuevo bit
        //Los procesadores lentos (Arduino) no necesitan esperar
        if((maskChannel & currentChannel) > 0) { //Si debemos enviar un 1...
          //Necesitamos un pulso de 0.8us
          *pinCommPort |= pinCommMask; //digitalWrite(_pinComm,HIGH);
          __asm__ __volatile__(
            "nop \n" // ciclo 1
            "nop \n" // ciclo 2
            "nop \n" // ciclo 3
            "nop \n" // ciclo 4
            "nop \n" // ciclo 5
          );
          *pinCommPort &= ~pinCommMask; //digitalWrite(_pinComm,LOW);
        } else { //Si debemos enviar un 0...
          //Necesitamos un pulso de 0.4us. En la práctica no es necesario
          *pinCommPort |= pinCommMask; //digitalWrite(_pinComm,HIGH);
          *pinCommPort &= ~pinCommMask; //digitalWrite(_pinComm,LOW);
        }
        maskChannel>>=1;
      }
    }
    
    interrupts(); //Reactivamos interrupciones

    //Hemos terminado de enviar todos los bytes
    //No esperaremos los ciclos LOW posteriores al último pulso, porque ya se tienen
    //en cuenta tiempo de espera al inicio del proceso
    _lastComm=micros(); //Hemos finalizado el envío. Anotamos la hora actual
  #elif defined(ESP8266)
    //Tenemos que transmitir la memoria de video actual
    //Debemos asegurarnos que han transcurrido al menos 300us desde la última
    //comunicación para que NeoPixel entienda que es una transferencia nueva.
    uint32_t deltaTime=micros()-_lastComm; //Tiempo transcurrido desde la última conexión
    //Si no han transcurrido más de 300us...los esperamos
    if(deltaTime<300) delayMicroseconds(300-deltaTime);

    //La duración de los pulsos en muy corta y las rutinas de gestión de pulsos
    //deben estar muy optimizadas.
    //Recuperar el valor de una variable de clase es más lento que hacerlo de
    //una variable local. Por eso hacemos una copia de los datos necesarios
    //en variables locales.
    byte currentChannel; //Byte de canal procesado
    byte maskChannel; //Máscara para procesar cada bit de cada canal
    byte *currentByte=(byte*)videoMem; //Puntero a byte procesado
    uint32_t pinCommMask=_pinCommMask; //Máscara del pin en variable local
    volatile uint32_t *pinCommPort=(uint32_t*)_pinCommPort; //Puerto en variable local

    noInterrupts(); //Evitamos interrupciones durante el envío
    
    for(uint16_t i=_ledsCount*3;i>0;i--) { //Recorremos los 3 canales de cada led
      currentChannel=*currentByte; //Copiamos byte a procesar a variable local
      currentByte++; //Aumentamos puntero para siguiente ciclo
      maskChannel=0b10000000; //Calculamos la máscara del bit de mayor peso
      for(byte currentBit=8;currentBit>0;currentBit--) { //Recorremos los 8 bits del byte procesado
        //Debemos esperar 1.25us en pulso bajo antes de enviar un nuevo bit
        for(byte i=6;i>0;i--) {
          __asm__ __volatile__(
            "nop \n" // ciclo 1
          );
        }
        if((maskChannel & currentChannel) > 0) { //Si debemos enviar un 1...
          //Necesitamos un pulso de 0.8us
          *pinCommPort |= pinCommMask; //digitalWrite(_pinComm,HIGH);
          for(byte i=7;i>0;i--) {
            __asm__ __volatile__(
              "nop \n" // ciclo 1
            );
          }
          *pinCommPort &= ~pinCommMask; //digitalWrite(_pinComm,LOW);
        } else { //Si debemos enviar un 0...
          //Necesitamos un pulso de 0.4us. En la práctica no es necesario
          *pinCommPort |= pinCommMask; //digitalWrite(_pinComm,HIGH);
          *pinCommPort &= ~pinCommMask; //digitalWrite(_pinComm,LOW);
        }
        maskChannel>>=1;
      }
    }
    
    interrupts(); //Reactivamos interrupciones

    //Hemos terminado de enviar todos los bytes
    //No esperaremos los ciclos LOW posteriores al último pulso, porque ya se tienen
    //en cuenta tiempo de espera al inicio del proceso
    _lastComm=micros(); //Hemos finalizado el envío. Anotamos la hora actual
  #elif defined(ESP32old)
    //Tenemos que transmitir la memoria de video actual
    //Debemos asegurarnos que han transcurrido al menos 300us desde la última
    //comunicación para que NeoPixel entienda que es una transferencia nueva.
    uint32_t deltaTime=micros()-_lastComm; //Tiempo transcurrido desde la última conexión
    //Si no han transcurrido más de 300us...los esperamos
    if(deltaTime<300) delayMicroseconds(300-deltaTime);

    //La duración de los pulsos en muy corta y las rutinas de gestión de pulsos
    //deben estar muy optimizadas.
    //Recuperar el valor de una variable de clase es más lento que hacerlo de
    //una variable local. Por eso hacemos una copia de los datos necesarios
    //en variables locales.
    byte currentChannel; //Byte de canal procesado
    byte maskChannel; //Máscara para procesar cada bit de cada canal
    byte *currentByte=(byte*)videoMem; //Puntero a byte procesado
    uint32_t pinCommMask=_pinCommMask; //Máscara del pin en variable local
    volatile uint32_t *pinCommPort=(uint32_t*)_pinCommPort; //Puerto en variable local

    portDISABLE_INTERRUPTS(); //Evitamos interrupciones durante el envío
    
    for(uint16_t i=_ledsCount*3;i>0;i--) { //Recorremos los 3 canales de cada led
      currentChannel=*currentByte; //Copiamos byte a procesar a variable local
      currentByte++; //Aumentamos puntero para siguiente ciclo
      maskChannel=0b10000000; //Calculamos la máscara del bit de mayor peso
      for(byte currentBit=8;currentBit>0;currentBit--) { //Recorremos los 8 bits del byte procesado
        //Debemos esperar 1.25us en pulso bajo antes de enviar un nuevo bit
        //Los procesadores lentos (Arduino) no necesitan esperar
        for(byte i=28;i>0;i--) {
          __asm__ __volatile__(
            "nop \n" // ciclo 1
          );
        }
        if((maskChannel & currentChannel) > 0) { //Si debemos enviar un 1...
          //Necesitamos un pulso de 0.8us
          *pinCommPort |= pinCommMask; //digitalWrite(_pinComm,HIGH);
          for(byte i=19;i>0;i--) {
            __asm__ __volatile__(
              "nop \n" // ciclo 1
            );
          }
          *pinCommPort &= ~pinCommMask; //digitalWrite(_pinComm,LOW);
        } else { //Si debemos enviar un 0...
          //Necesitamos un pulso de 0.4us. En la práctica no es necesario
          *pinCommPort |= pinCommMask; //digitalWrite(_pinComm,HIGH);
          *pinCommPort &= ~pinCommMask; //digitalWrite(_pinComm,LOW);
        }
        maskChannel>>=1;
      }
    }

    portENABLE_INTERRUPTS(); //Reactivamos interrupciones

    //Hemos terminado de enviar todos los bytes
    //No esperaremos los ciclos LOW posteriores al último pulso, porque ya se tienen
    //en cuenta tiempo de espera al inicio del proceso
    _lastComm=micros(); //Hemos finalizado el envío. Anotamos la hora actual
  #elif defined(ESP32)
    rmt_wait_tx_done(_channel,portMAX_DELAY); //Esperamos a que termine el envío anterior
    //Codificamos la memoria de video en items de pulsos
    //Recorremos todos los leds, todos sus canales y todos sus bits para llenar el array de pulsos
    for(uint16_t led=0;led<_ledsCount;led++) {
      for(byte channel=0;channel<3;channel++) {
        byte currentByte=videoMem[led].channel[channel]; //Copiamos byte a procesar a variable local
        for(byte bit=0;bit<8;bit++) {
          _pulseItems[led*24+channel*8+bit].duration0=((currentByte & 128)>0)?2:1;
          currentByte<<=1;
        }
      }
    }
    rmt_write_items(_channel,_pulseItems,_ledsCount*24,false); //Enviamos y no esperamos a que termine
  #endif
}

//Inicialización
//Devuelve true si lo consigue
bool RoJoNeoPixel::begin(uint16_t ledsCount,byte pinComm) {
  if(!ledsCount) return false; //Al menos debemos tener un led
  end(); //Nos aseguramos de borrar cualquier otra memoria de video
  videoMem=(pixelGRB*)malloc(ledsCount*3); //Reservamos nueva memoria de video
  if(!videoMem) return false; //No hay memoria
  memset((void*)videoMem,0,ledsCount*3); //Limpiamos la memoria reservada
  _ledsCount=ledsCount;

  //Definimos el puerto y el bit del pin de comunicaciones
  #ifdef ARDUINO_AVR_MEGA2560 //Si es una Mega
    //Tenemos 70 pines disponibles
    //Codificamos el puerto y el bit en un solo valor y lo guardamos en un array
    //Ya se ha tenido en cuenta el offset de algunos puertos (A,B,C,D,E,F,G)
    //de 32 bytes (0x20).
    //Utilizamos los 3 bits más bajos para guardar el bit del puerto
    //y el resto para guardar la dirección de memoria del puerto
    const uint16_t ports[] PROGMEM={368,369,372,373,421,371,2067,2068,2069,2070,300,301,302,303,2345,2344,2065,2064,347,346,345,344,272,273,274,275,276,277,278,279,327,326,325,324,323,322,321,320,351,418,417,416,2143,2142,2141,2140,2139,2138,2137,2136,299,298,297,296,392,393,394,395,396,397,398,399,2112,2113,2114,2115,2116,2117,2118,2119};
    _pinCommPort=ports[pinComm]>>3; //Calculamos la dirección del puerto
    _pinCommMask=1<<(ports[pinComm]&7); //Calculamos la máscara del pin en el puerto
  #elif defined(ARDUINO_AVR_NANO) || defined(ARDUINO_AVR_UNO) //Si es una Nano o UNO
    //Tenemos 20 pines disponibles
    //Codificamos el puerto y el bit en un solo valor y lo guardamos en un array
    //Ya se ha tenido en cuenta el offset de los puertos (B,C,D)
    //de 32 bytes (0x20).
    //Utilizamos los 3 bits más bajos para guardar el bit del puerto
    //y el resto para guardar la dirección de memoria del puerto
    const uint16_t ports[] PROGMEM={344,345,346,347,348,349,350,351,296,297,298,299,300,301,320,321,322,323,324,325};
    _pinCommPort=ports[pinComm]>>3; //Calculamos la dirección del puerto
    _pinCommMask=1<<(ports[pinComm]&7); //Calculamos la máscara del pin en el puerto
  #elif defined(ESP8266)
    //Para los 16 primeros pines [0,15] utilizamos un registro.
    //El pin 16 se gestiona en un registro independiente
    _pinCommPort=(pinComm<16)?0x60000300:0x60000768; //Calculamos la dirección del puerto
    _pinCommMask=(pinComm<16)?(1<<pinComm):1; //Calculamos la máscara del pin en el puerto
  #elif defined(ESP32old) //ESP32 método antiguo
    //Sólo utilizamos dos registros de 32 bits para controlar todos los
    //posibles pines.
    _pinCommPort=(pinComm<32)?0x3FF44004:0x3FF44010; //Calculamos la dirección del puerto
    _pinCommMask=(pinComm<32)?(1<<pinComm):(1<<(pinComm-32)); //Calculamos la máscara del pin en el puerto
  #elif defined(ESP32)
    //Reservamos memoria para los items de pulso. Cada led se codifica en 24 bits
    _pulseItems=(rmt_item32_t*)malloc(sizeof(rmt_item32_t)*_ledsCount*24);
    if(!_pulseItems) { //Si no hay memoria...
      free(videoMem); //Liberamos también la memoria de video
      _ledsCount=0; //No lo hemos inicializado
      return false; //Devolvemos error
    }
    //Todos los items de pulso tienen la misma estructura:
    //- El primer pulso es HIGH
    //- El segundo pulso es LOW
    //- El segundo pulso dura 3 unidades
    //- El segundo pulso del último item dura 750 unidades (300us)
    for(uint16_t i=0;i<_ledsCount*24;i++) {
      _pulseItems[i].level0=1;
      _pulseItems[i].level1=0;
      _pulseItems[i].duration1=3;
    }
    _pulseItems[_ledsCount*24-1].duration1=750;

    rmt_config_t configRMT;
    configRMT.rmt_mode=RMT_MODE_TX;
    configRMT.channel=_channel;
    configRMT.gpio_num=(gpio_num_t)pinComm;
    configRMT.clk_div=32;
    configRMT.mem_block_num=1;
    if(rmt_config(&configRMT)) { //Si no se puede aplicar configuración...error
      end();
      return false;
    }
    if(rmt_driver_install(_channel,0,0)) { //Si no se puede activar el canal...error
      end();
      return false;
    }
  #endif

  //Inicializamos pin de conexión
  pinMode(pinComm,OUTPUT);
  digitalWrite(pinComm,LOW);
  show(); //Mostramos memoria de video (borramos display)
  return true; //Todo Ok
}

#endif

/*
  Nombre de la librería: RoJoNeoPixel.h
  Versión: 20220516
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.

    La comunicación con el controlador de los leds (NeoPixel) se realiza por un
    único pin y de manera unidireccional: desde el dispositivo a NeoPixel.
    Cuando no se transmite, el pin se encuentra en estado LOW.
    Para transmitir un bit, activaremos el estado HIGH durante un tiempo (pulso).
    La duración del pulso dependerá del valor que queramos transmitir.
    Según las especificaciones del fabricante, los tiempos de pulso son:
    - 0.4us para valor 0
    - 0.8us para valor 1
    Además entre dos pulsos debe transcurrir un tiempo mínimo de 1.25us
    Si no se transmite nada en 300us se supone que ha finalizado la comunicación
    Para transmitir un byte enviaremos consecutívamente los bits en orden MSB
    (big endian). Desde el bit más significativo al que menos.

    Puesto que algunos de los tiempos utilizados están por debajo del microsegundo,
    no podemos utilizar la función micros para calcular las esperas.
    En procesadores lentos tampoco podemos utilizar la función digitalWrite
    porque es muy poco eficiente y pierde mucho tiempo. No se podría enviar
    el pulso de 0 (0.4us).
    Para mejorar la eficiencia se gestionan los pines escribiendo directamente en los
    puertos.

    Caso ESP32
    Para ESP32 se toma como caso especial. Aunque se puede utilizar la solución anterior
    a la que llamaremos "método antiguo" o "ESP32old" nos encontramos con la nueva
    familia de ESP32-C3 que tiene un direccionamiento distinto y ya no es compatible.
    En este caso se hace uso de las capacidades de gestión de pulsos de estos procesadores
    controlados por la librería RMT. Con esto conseguimos mayor control y compatibilidad
    con los procesadores actuales y futuros.
    El primer ejercicio es determinar el valor de clk_div para que nos facilite la gestión
    de los pulsos.
    Los valores de los pulsos cortos son:
    - 0.4us para bit 0
    - 0.8us para bit 1
    - 1.25us para separación de pulsos high
    La fórmula general es:
      unidad de pulso = clk_div/80 microsegundos
    Despejamos cls_div:
      clk_div=unidad de pulso * 80
    Si tomamos el pulso mínimo a 0.4us, tenemos:
      clk_div=0.4*80=32
    Quedando:
    - 0.4us para bit 0 = 0.4/0.4 = 1 unidad de pulso
    - 0.8us para bit 1 = 0.8/0.4 = 2 unidades de pulso
    - 1.25us para separación de pulsos high = 1.25/0.4 = 3.125 ~ 3 unidades de pulso
    Para el pulso de fin de envío:
    - 300us para fin de envío = 300/0.4 = 750 unidades de pulso
    Notas:
    - Con RMT no es necesario desactivar las interrupciones
    - Una vez solicitado el envío, devolvemos el control instantáneamente, porque al inicio
      la show() ya esperamos cualquier posible envío en progreso.
*/

#ifndef RoJoNeoPixel_h
#define RoJoNeoPixel_h

#include <Arduino.h>
#ifdef ESP32
  #include <driver/rmt.h> //Gestión de RMT exclusiva para ES32
#endif

struct pixelGRB {
  byte channel[3];
  uint32_t getColor() {
    return ((uint32_t)channel[1])<<16 | ((uint32_t)channel[0])<<8 | channel[2];
  }
  void setColor(uint32_t color) {
    //El color lo tenemos en formato RGB (00000000RRRRRRRRGGGGGGGGBBBBBBBB)
    //Lo descomponemos en canales en orden GRB, propio de NeoPixel
    channel[2]=color & 0xFF; //B
    color>>=8;
    channel[0]=color & 0xFF; //G
    channel[1]=color>>8; //R
  }
};

class RoJoNeoPixel {
  protected:
    #ifdef ARDUINO_ARCH_AVR //Placas Arduino: Mega, Uno, Nano
      //Las placas Arduino (Mega, UNO, Nano) tienen un direccionamiento de 16 bits.
      uint16_t _pinCommPort; //Puerto del pin de comunicaciones
      byte _pinCommMask; //Máscara del bit en el puerto del pin de comunicaciones
      uint64_t _lastComm=0; //Tiempo en microsegundos de última comunicación
    #elif defined(ESP8266) || defined(ESP32old) //Placas ESP8266 & ESP32 método antiguo
      //Las placas ESP8266 y ESP32 tienen un direccionamiento de 32 bits.
      uint32_t _pinCommPort; //Puerto del pin de comunicaciones
      uint32_t _pinCommMask; //Máscara del bit en el puerto del pin de comunicaciones
      uint64_t _lastComm=0; //Tiempo en microsegundos de última comunicación
    #elif defined(ESP32)
      const rmt_channel_t _channel=RMT_CHANNEL_0;
      rmt_item32_t *_pulseItems; //Puntero a array de items de pulsos
    #endif
    uint16_t _ledsCount=0; //Número de leds
  public:
    pixelGRB *videoMem; //Puntero a memoria de video
    void end();
    ~RoJoNeoPixel(); //Destructor
    bool begin(uint16_t ledsCount,byte pinComm); //Inicialización
    void show(); //Envía memoria de video actual
}; //Punto y coma obligatorio para que no de error

#include <RoJoNeoPixel.cpp> //Para guardar compatibilidad con RPi

#endif


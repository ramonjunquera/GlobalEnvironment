/*
  Nombre de la librería: RoJoXPT2046.h
  Versión: 20190830
  Autor: Ramón Junquera
  Descripción:
    Gestión del touch panel XPT2046

  Nota:
    El panel táctil XPT2046 viene acompañando a gran variedad de displays.
    No todos devuelven el mismo rango de valores.
    En algunos casos el valor por defecto (sin pulsación) de las coordenadas
    RAW coincide con valores de coordenadas reales y no por lo tanto no hay
    manera de distinguir sólo con estos datos si se está produciendo una
    pulsación.
    Así que no hay más remedio que utilizar el pin IRQ que es fiable a la
    hora de detectar pulsaciones.
*/

#ifndef RoJoXPT2046_cpp
#define RoJoXPT2046_cpp

#include <RoJoXPT2046.h> //Gestión del display

//Inicialización
void RoJoXPT2046::begin(byte pinCS,byte pinIRQ,uint32_t freqSPI) {
  //Si no se ha indicado frecuencia...utilizaremos la máxima
  if(!freqSPI) freqSPI=2999999;
  //Características de la conexión SPI
  _spiSetting=SPISettings(freqSPI,MSBFIRST,SPI_MODE0); 
  //Inicializamos las conexiones SPI
  SPI.begin();
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif

  //Guardamos los pines en variables privadas
  _pinCS=pinCS;
  _pinIRQ=pinIRQ;
  //Aplicamos el modo a cada pin
  pinMode(_pinCS,OUTPUT);
  pinMode(_pinIRQ,INPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip

  //Si no utilizamos SD (si utilizamos SPIFFS)...
  #ifndef ROJO_PIN_CS_SD
    //...lo inicializamos
    SPIFFS.begin();
  #endif
}

//Obtiene las coordenadas de hardware
//Devuelve si ha detectado pulsación
//Si no se han podido determinar las coordenadas, devuelve x=0
bool RoJoXPT2046::getRawXY(uint16_t *x,uint16_t *y) {
  //Si no hay pulsación...
  if(digitalRead(_pinIRQ)) {
    //...anotamos que en este ciclo no hay pulsación e informamos
    _lastPulseTime=0;
    return false;
  }
  //Tenemos una pulsación
  //Obtenemos sus coordenadas
  SPI.beginTransaction(_spiSetting); //Inicio de transacción
  digitalWrite(_pinCS,LOW); //Activamos el pin CS
    SPI.transfer16(0xD0); //Solicitamos de nuevo la coordenada x. La primera no es fiable
    *x=SPI.transfer16(0x90); //Anotamos la coordenada x. Solicitamos la y
    *y=SPI.transfer16(0x00); //Anotamos la coordenada y. Teminamos
  digitalWrite(_pinCS,HIGH); //Desactivamos pin CS
  SPI.endTransaction(); //Fin de transacción

  //Obtenemos el tiempo actual el microsegundos
  uint64_t now=micros();
  //Calculamos el tiempo transcurrido desde la vez anterior
  uint64_t diffTime=now-_lastPulseTime;
  //Si el ciclo anterior no tenía pulsación...
  if(_lastPulseTime==0) {
    //Con una sola medida no somos capaces de saber si las coordenadas actuales son confiables
    //Anotamos las coordenadas para el próximo ciclo
    _lastPulseX=*x;
    _lastPulseY=*y;
    //Anotamos el tiempo actual para el próximo ciclo
    _lastPulseTime=now;
    //Indicamos que no son coordenadas confiables
    *x=0;
  }
  //Si el ciclo anterior tenía pulsación...
  else {
    //Si no ha transcurrido un mínimo de tiempo...devolvemos coordenadas no confiables
    if(diffTime<350) *x=0;
    //Ha transcurrido suficiente tiempo como para hacer la comparación
    else {
      //Calcularemos la dispersión entre la medida actual y la anterior
      uint32_t disper=abs(_lastPulseX-(int32_t)*x)+abs(_lastPulseY-(int32_t)*y);
      //Calculamos el máximo de dispersión permitidas teniendo en cuenta el tiempo
      //tanscurrido entre medidas
      uint32_t disperMax=diffTime/50;
      //Anotamos las coordenadas para el próximo ciclo
      _lastPulseX=*x;
      _lastPulseY=*y;
      //Si la dispersión es mayor que el máximo permitido...las coordenadas no serán válidas
      if(disper>disperMax) *x=0;
      //Anotamos el tiempo actual para el próximo ciclo
      _lastPulseTime=now;
    }
  }
  //Hemos detectado una pulsación
  return true;
}

//Guarda en las variables privadas los valores de calibración para futuros cálculos
void RoJoXPT2046::setConfig(uint16_t xMaxDisplay,uint16_t yMaxDisplay,uint16_t xMinTS,uint16_t yMinTS,uint16_t xMaxTS,uint16_t yMaxTS) {
  //Tamaño del display
  _xMaxDisplay=xMaxDisplay; //Anchura de display
  _yMaxDisplay=yMaxDisplay; //Altura de display
  //Valores mínimos de coordenadas de hardware para que sean visibles
  _xMinTS=xMinTS;
  _yMinTS=yMinTS;
  //Valores máximos de coordenadas de hardware para que sean visibles
  _xMaxTS=xMaxTS;
  _yMaxTS=yMaxTS;
}

//Obtiene las coordenadas de pantalla
//Devuelve si ha detectado pulsación
//Si no se han podido determinar las coordenadas, devuelve x=-1
bool RoJoXPT2046::getXY(int16_t *x,int16_t *y) {
  //Coordenadas de trabajo
  uint16_t x16,y16;
  int32_t x32,y32;

  //Obtenemos las coordenadas de hardware
  //Si no se detecta pulsación...hemos terminado sin pulsación
  if(!getRawXY(&x16,&y16)) return false;
  //Se ha detectado una pulsación

  //Si las coordenadas son válidas...
  if(x16) {
    //Utilizamos un tipo mayor para hacer lo cálculos
    x32=x16; y32=y16;
    //Obtenemos las coordenadas de pantalla sin rotación
    x32=(((_xMinTS-x32)*_xMaxDisplay)/(_xMinTS-_xMaxTS));
    y32=(((_yMinTS-y32)*_yMaxDisplay)/(_yMinTS-_yMaxTS));
    //Calculamos las coordenadas en base a la rotación
    switch(_rotation) {
      case 0: //0 grados
        *x=x32;
        *y=y32;
        break;
      case 1: //90 grados
        *x=y32;
        *y=_xMaxDisplay-x32;
        break;
      case 2: //180 grados
        *x=_xMaxDisplay-x32;
        *y=_yMaxDisplay-y32;
        break;
      case 3: //270 grados
        *x=_yMaxDisplay-y32;
        *y=x32;
        break;
    }
  }
  //Si las coordenadas no son válidas...lo indicamos
  else *x=-1;
  //Pulsación detectada
  return true;
}

//Guarda la configuración en un archivo
//Parámetro: nombre de archivo de configuración (opcional)
//Respuesta: true si se consigue
bool RoJoXPT2046::saveConfig(String filename) {
  //Si no se pasa parámetro se utilizará el nombre por defecto
  if(filename.length()==0) filename=_fileConfig;

  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(_fileConfig,FILE_WRITE); //Creamos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"w"); //Creamos el archivo en SPIFFS
  #endif
  //Si hubo algún problema...devolvemos error
  if(!f) return false;
  //Nos aseguramos que escribimis desde el principio.
  //El driver SD de Arduino siempre abre en modo APPEND!
  f.seek(0);
  //Escribimos los parámetros de configuración: MaxDisplay,MinTS y MaxTS
  //La clase los guarda en variables internas del tipo uint32_t
  //Pero realmente se podrían guardar en uint16_t
  //Las convertimos para guardarlas en el archivo. Ocuparán menos
  uint16_t z=_xMaxDisplay; f.write((byte *)&z,2); //_xMaxDisplay
  z=_yMaxDisplay; f.write((byte *)&z,2); //_yMaxDisplay
  z=_xMinTS; f.write((byte *)&z,2); //_xMinTS
  z=_yMinTS; f.write((byte *)&z,2); //_yMinTS
  z=_xMaxTS; f.write((byte *)&z,2); //_xMaxTS
  z=_yMaxTS; f.write((byte *)&z,2); //_yMaxTS
  //Cerramos el archivo
  f.close();
  //Todo Ok
  return true;
}

//Recupera la configuración desde un archivo
//Parámetro: nombre de archivo de configuración (opcional)
//Devuelve true si lo consigue
bool RoJoXPT2046::loadConfig(String filename) {
  //Si no se pasa parámetro se utilizará el nombre por defecto
  if(filename.length()==0) filename=_fileConfig;

  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(_fileConfig,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
  #endif
  //Si hubo algún problema...devolvemos error
  if(!f) return false;
  //Recuperaremos los parámetros de configuración: MaxDisplay,MinTS y MaxTS
  //La clase los guarda en variables internas del tipo uint32_t
  //Pero en el archivo se guardan como uint16_t
  uint16_t z;
  f.readBytes((char *)&z,2); _xMaxDisplay=z;
  f.readBytes((char *)&z,2); _yMaxDisplay=z;
  f.readBytes((char *)&z,2); _xMinTS=z;
  f.readBytes((char *)&z,2); _yMinTS=z;
  f.readBytes((char *)&z,2); _xMaxTS=z;
  f.readBytes((char *)&z,2); _yMaxTS=z;
  //Cerramos el archivo
  f.close();
  //Todo correcto
  return true;
}

//Fija la rotación de pantalla
void RoJoXPT2046::rotation(byte rotationCode) {
  //Guardamos el código de rotación
  _rotation=rotationCode%4;
}

#endif

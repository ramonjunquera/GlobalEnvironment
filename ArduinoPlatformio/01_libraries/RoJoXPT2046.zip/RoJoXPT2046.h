/*
  Nombre de la librería: RoJoXPT2046.h
  Versión: 20190830
  Autor: Ramón Junquera
  Descripción:
    Gestión del touch panel XPT2046
*/

#ifndef RoJoXPT2046_h
#define RoJoXPT2046_h

#include <Arduino.h>
#ifdef ROJO_PIN_CS_SD //Si debemos utilizar SD...
  #ifdef __arm__ //Si es una Raspberry...
    #error Raspberry has not SD
  #endif
  //No es una Raspberry
  //Puede tener SD. Lo cargamos
  #include <SD.h> //Librería de gestión de SD
#else //Si debemos utilizar SPIFFS...
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino...
    #error Arduino family has not SPIFFS
  #endif
  //No es una placa Arduino. Puede tener SPIFFS
  //Cargamos la librería en función del dispositivo
  #ifdef ESP32 //Si es un ESP32...
    #include <SPIFFS.h> //Librería de gestión SPIFFS para ESP32
  #else //Si cualquier otra cosa (ESP8266 o RPi)...
    #include <FS.h> //Librería de gestión SPIFFS para ESP8266
  #endif
#endif
#include <SPI.h> //Gestión de comunicaciones SPI

class RoJoXPT2046 {
  private:
    byte _pinCS;
    byte _pinIRQ;
    int32_t _lastPulseX,_lastPulseY; //Últimas coordenadas raw detectadas
    uint64_t _lastPulseTime; //Tiempo en microsegundos de la última medida raw detectada
    SPISettings _spiSetting; //Características de la conexión SPI
    int32_t _xMaxDisplay=320; //Anchura de display sin rotación
    int32_t _yMaxDisplay=480; //Altura de display sin rotación
    int32_t _xMinTS=30894; //Coordenada mínima X de hardware para que sea visible
    int32_t _yMinTS=31459; //Coordenada mínima Y de hardware para que sea visible
    int32_t _xMaxTS=1393; //Coordenada máxima X de hardware para que sea visible
    int32_t _yMaxTS=1826; //Coordenada máxima Y de hardware para que sea visible
    const String _fileConfig="/xpt2046.cfg"; //Nombre de archivo de configuración
    byte _rotation=0; //Rotación actual
  public:
    void begin(byte pinCS,byte pinIRQ,uint32_t freqSPI=0); //Inicialización
    bool getRawXY(uint16_t *x,uint16_t *y); //Obtiene las coordenadas de hardware
    void setConfig(uint16_t xMaxDisplay,uint16_t yMaxDisplay,uint16_t xMinTS,uint16_t yMinTS,uint16_t xMaxTS,uint16_t yMaxTS); //Fija los valores de conversión
    bool getXY(int16_t *x,int16_t *y); //Obtiene las coordenadas de pantalla
    void rotation(byte rotationCode); //Fija la rotación
    bool saveConfig(String filename=""); //Salva la configuración en una archivo
    bool loadConfig(String filename=""); //Recupera la configuración desde un archivo
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoXPT2046.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


/*
  Autor: Ramón Junquera
  Fecha: 20210416
  Tema: Fast Fourier Transform
 */

#include "RoJoFFT.h"

//Calcula a qué potencia se ha elevado 2 para que sea v
//Función interna
//Devuelve el exponente de 2
//Ante cualquier error, devuelve 0
byte RoJoFFT::_pow2(uint16_t v) {
	if(v<4) return 0; //Por lo menos debe ser 4
	byte pow=0; //Potencia inicial
	uint16_t c=v; //Valor para cálculos
	while(!(c & 1)) {
		c>>=1;
		pow++;
	}
	if(1<<pow != v) return 0; //No es potencia exacta de 2
	return pow;
}

//Aplicar factores de ponderación
//Función interna. No se hacen comprobaciones
//Parámetros:
//  *ampli : puntero a matriz de amplitudes
//  *v: puntero a matriz de valores de cálculo
void RoJoFFT::_weighingFactors(RoJoFloatMatrix *ampli,RoJoFloatMatrix *v) {
	uint16_t samplesMinusOne=ampli->cols()-1;
	uint16_t halfSamples=ampli->cols()/2;
  float ratio2=2*PI/samplesMinusOne;
  float ratio4=2*ratio2;
  float ratio6=3*ratio2;
  float weighingFactor; //Factor de ponderacion
	float *vRow0=v->m[0]; //Puntero a fila 0 de matriz v
	float *ampliRow0=ampli->m[0]; //Puntero a fila 0 de matriz ampli
  for(uint16_t i=0;i<halfSamples;i++) { //Solo recorremos la mitad de las muestras
    //Calculamos el factor de ponderación con la fórmula de NUTTALL
    weighingFactor=0.355768-0.487396*cos(i*ratio2)+0.144232*cos(i*ratio4)-0.012604*cos(i*ratio6);
    vRow0[i]=ampliRow0[i]*weighingFactor; //De primero en adelante
    vRow0[samplesMinusOne-i]=ampliRow0[samplesMinusOne-i]*weighingFactor; //De último hacia atrás
  }
}

//Función interna. No se hacen comprobaciones
//Parámetros:ç
//  *v : puntero a matriz de valores de cálculo
void RoJoFFT::_reverseBits(RoJoFloatMatrix *v) {
	uint16_t samplesMinusOne=v->cols()-1;
	uint16_t halfSamples=v->cols()/2;
	uint16_t j=0;
	float tmp;
	uint16_t k;
	float *vRow0=v->m[0];

	for (uint16_t i=0;i<samplesMinusOne;i++) {
		if (i < j) { //swap
			tmp=vRow0[i]; vRow0[i]=vRow0[j]; vRow0[j]=tmp;
		}
		k=halfSamples; //Sólo la mitad del número de muestras
		while (k<=j) {
			j-=k;
			k>>=1;
		}
		j+=k;
	}
}

//Función interna. No se hacen comprobaciones
//Calculo de valores complejos
//Parámetros:
//  *v : puntero a matriz de valores de cálculo. Fila0=reales. Fila1=imaginarios
//  samples2pow: número de muestras representado como 2^samples2pow
void RoJoFFT::_compute(RoJoFloatMatrix *v,byte samples2pow) {
	uint16_t samples=v->cols(); //Anotamos número de muestras
	float *R=v->m[0]; //Puntero a fila 0 = valores reales
	float *I=v->m[1]; //Puntero a fila 1 = valores imaginarios
	memset((void*)I,0,samples*sizeof(float)); //Inicializamos valores imaginarios a 0
	float c1=-1,c2=0,u1,u2,t1,t2,z;
	uint16_t l2=1,l1,i1;
	for (byte l=0;l<samples2pow;l++) {
		l1=l2;
		l2<<=1;
		u1=1;
		u2=0;
		for (uint16_t j=0;j<l1;j++) {
			 for (uint16_t i=j;i<samples;i+=l2) {
					i1=i+l1;
					t1=u1*R[i1]-u2*I[i1];
					t2=u1*I[i1]+u2*R[i1];
					R[i1]=R[i]-t1;
					I[i1]=I[i]-t2;
					R[i]+=t1;
					I[i]+=t2;
			 }
			 z=u1*c1-u2*c2;
			 u2=u1*c2+u2*c1;
			 u1=z;
		}
		c2=-sqrt((1-c1)/2);
		c1=sqrt((1+c1)/2);
	}
}

//Función interna. No se hacen comprobaciones
//Calcula el módulo del número complejo
//Parámetros:
//  *v : puntero a matriz de valores de cálculo. Fila0=reales. Fila1=imaginarios
void RoJoFFT::_module(RoJoFloatMatrix *v) {
  float *R=v->m[0]; //Valores reales en fila 0
	float *I=v->m[1]; //Valores imaginarios en fila 1
	for (int16_t i=v->cols()-1;i>=0;i--) R[i]=sqrt(sq(R[i])+sq(I[i]));
}

//Cálculo de coordenadas de máximo por interpolación de parábola. Función interna
//Parámetros:
//  *coord: puntero a matriz de 3 filas (una por punto) y 2 columnas (una por dimensión x & y)
// *xMax,*yMax: punteros a coordenadas de punto máximo
void RoJoFFT::_interp(RoJoFloatMatrix *coord,float *xMax,float *yMax) {
  //Nos entregan las coordenadas x & y de 3 puntos
	//Sabemos que el punto central está próximo a un máximo
	//Calcularemos la función de la parábola que pasa por los tres puntos
	//La función será y=c1*x²+c2*x+c3
	//El objetivo es encontrar los coficientes c1, c2 y c3.
	//Puesto que tenemos 3 puntos, sustituimos sus coordenadas y creamos la siguiente matriz extendida
	//  p1x²*c1 + p1x*c2 + c3 = p1y
	//  p2x²*c1 + p2x*c2 + c3 = p2y
	//  p3x²*c1 + p3x*c2 + c3 = p3y
	RoJoFloatMatrix mExt;
	mExt.redim(3,4);
	float x;
	for(byte row=0;row<3;row++) {
		x=coord->m[row][0];
		mExt.m[row][0]=x*x; //Coeficiente de x²
		mExt.m[row][1]=x;  //Coeficiente de x
		mExt.m[row][2]=1; //Coeficiente de término independiente
		mExt.m[row][3]=coord->m[row][1]; //y
	}
	RoJoFloatMatrix coef;
	coef.linearEq(&mExt);
	mExt.end();
	//Hemos conseguido los coeficientes de la función de interpolación en la matriz coef
	//  y=c1*x²+c2*x+c3
	float *coef0=coef.m[0]; //Anotamos el puntero de la primera fila de la matriz coef
	//Necesitamos calcular su máximo
	//Calculamos la derivada: y'=2*c1*x+c2
	//La igualamos a cero: 2*c1*x+c2=0
	//Despejamos x: x=-c2/2/c1
	*xMax=-coef0[1]/2/coef0[0]; //Calculamos la x del máximo
	//Sustituimos la x del máximo en la función y calculamos la y máxima
	*yMax=coef0[0]*(*xMax)*(*xMax)+coef0[1]*(*xMax)+coef0[2];
}

//Función interna. No se hacen comprobaciones
//Cálculo de frecuencias máximas
//Parámetros:
//  *v : puntero a matriz de frecuencias (en fila 0)
//  samples2pow: número de muestras representado como 2^samples2pow
//  samplingFreq : frecuencia de muestreo
//  *maxFreqs: puntero a estructura de salida con las frecuencias y amplitudes detectados
void RoJoFFT::_maxFreqs(RoJoFloatMatrix *v,byte samples2pow,float samplingFreq,RoJoList<freqWeight_t> *maxFreqs) {
	float *freq=v->m[0];
	float weightsSum=0; //Suma acumulada de pesos
	uint16_t samples=v->cols(); //Anotamos número de muestras
	uint16_t halfSamples=samples/2;
	freqWeight_t *node; //Puntero a nodo
	RoJoFloatMatrix coord; //Matriz de coordenadas para interpolación
	coord.redim(3,2); //3 puntos y 2 coordenadas por punto
	//Sólo miramos la primera mitad de valores
	//Puesto que buscamos un máximo comenzaremos por el segundo valor y
	//llegaremos hasta el de la mitad menos uno
	for (uint16_t i=1;i<=halfSamples;i++) {
		//Para agilizar la discriminación de valores, descartamos aquellas frecuencia cuyo peso no supere
		//el 1% de la suma acumulada de pesos.
		//Es cierto que el peso no tiene porqué coincidir con el máximo, pero podemos considerar la diferencia
		//como despreciable. Así evitamos interpolar.
		if(freq[i]>weightsSum/100) { //Si este peso se puede tener en cuenta...
		  if ((freq[i-1]<freq[i]) && (freq[i]>freq[i+1])) { //Si es un máximo...
			  for(int8_t c=-1;c<2;c++) { //Recorremos desde la frecuencia anterior a la siguiente...
				  coord.m[c+1][0]=(i+c)*samplingFreq/samples; //x
			  	coord.m[c+1][1]=freq[i+c]; //y
				}
				node=new freqWeight_t; //Creamos un nuevo nodo
				float yMax,xMax; //Máxima coordenada y & coordenada x para y máximo
				_interp(&coord,&xMax,&yMax); //Calculamos coordenadas de punto máximo por interpolación de parábola
				node->ampli=yMax; //Guardamos el peso de la frecuencia
				weightsSum+=yMax; //Añadimos el peso actual al acumulado
				node->freq=xMax; //Guardamos la frecuencia máxima interpolada
				maxFreqs->add(node); //Añadimos el nodo a la lista
			}
		}
	}
	coord.end();
	//Hemos terminado de detectar y anotar las frecuencias máximas
	//Debemos repasar la lista y descartar las que no superen el 1% del peso acumulado
	//Recorremos los nodos en orden inverso para poder borrarlos sin afectar al contador
	for(int16_t i=maxFreqs->count()-1;i>=0;i--) {
		maxFreqs->index(&node,i); //Obtenemos el nodo del índice actual
    if(node->ampli<weightsSum/100) { //Si el peso del nodo actual no alcanza el 1% del acumulado de total de pesos...
			maxFreqs->remove(i); //...no tendremos en cuenta el valor (eliminamos el nodo)
		} else { //Si el peso se puede considerar...
		  //Cambiaremos el peso por la amplitud
			//Calculamos la amplitud como 6*peso/número de muestras
      node->ampli=6*node->ampli/samples; 
		}
	}
}

//Inicialización y cálculo
//Parámetros:
//  *ampli: puntero a matriz de amplitudes (entrada)
//  samplingFreq: frecuencia de muestreo
//  *freqs: puntero a matriz de respuesta (2 columnas: frecuancia y amplitud)
//Devuelve códifo de error:
//  0: sin errores
//  1: la matriz de amplitudes sólo puede tener una fila
//  2: número de muestras inválido
//  3: sin memoria para reservar matriz de valores de cálculo
byte RoJoFFT::begin(RoJoFloatMatrix *ampli,float samplingFreq,RoJoFloatMatrix *freqs) {
	RoJoList<freqWeight_t> maxFreqs; //Lista donde guardaremos las frecuencias máximas detectadas
	if(ampli->rows()!=1) return 1; //La matriz de amplitudes sólo puede tener una fila
	uint16_t samples=ampli->cols(); //Anotamos el número de muestras
	byte samples2pow=_pow2(samples); //Calculamos la potencia de 2 para que de número de muestras
	if(!samples2pow) return 2; //Si no es potencia de 2 o el valor es incorrecto...error
	RoJoFloatMatrix v; //Matriz para guardar valores de cálculo. Fila 0 -> reales, fila 1 -> imaginarios
	if(!v.redim(2,samples)) return 3; //Si no se puede dimensionar...error
	_weighingFactors(ampli,&v); //Aplicamos los factores de ponderación
  _reverseBits(&v);
  _compute(&v,samples2pow); //Cálculo de valores complejos
	_module(&v); //Calcula los módulos de los números complejos
	_maxFreqs(&v,samples2pow,samplingFreq,&maxFreqs); //Cálculo de frecuencias máximas
	v.end(); //Liberamos memoria de matriz de valores de cálculo
	samples=maxFreqs.count(); //Reaprovechamos la variable para guardar el número de frecuencias detectadas
	freqs->redim(samples,2); //Redimensionamos matriz respuesta con tantas filas como frecuencias detectadas
	freqWeight_t *node; //Puntero a nodo
	for(int16_t i=samples-1;i>=0;i--) { //Recorremos todas las frecuencias detectadas
	  maxFreqs.index(&node,i); //Recuperamos nodo
    freqs->m[i][0]=node->freq; //Guardamos frecuencia
		freqs->m[i][1]=node->ampli; //Guardamos amplitud
	}
	maxFreqs.clear(); //Vaciamos la lista
	return 0; //Todo Ok
}
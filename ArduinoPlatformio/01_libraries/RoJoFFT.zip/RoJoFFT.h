/*
  Autor: Ramón Junquera
  Fecha: 20210416
  Tema: Fast Fourier Transform
 */

#ifndef RoJoFFT_h
#define RoJoFFT_h

#include <Arduino.h>
#include <RoJoFloatMatrix.h> //Gestión de matrices de coma flotante
#include <RoJoList.h> //Gestión de listas

//Estructura de nodo para lista de resultados
struct freqWeight_t {
  float freq;
  float ampli;
};

//Cálculo de la transformada rápida de Fourier
class RoJoFFT {
  protected:
    byte _pow2(uint16_t v); //Calcula a qué potencia se ha elevado 2 para que sea v
    void _weighingFactors(RoJoFloatMatrix *ampli,RoJoFloatMatrix *v); //Aplicar factores de ponderación
    void _reverseBits(RoJoFloatMatrix *v);
    void _compute(RoJoFloatMatrix *v,byte samples2pow);
    void _module(RoJoFloatMatrix *v); //Calcula el módulo del número complejo
    void _maxFreqs(RoJoFloatMatrix *v,byte samples2pow,float samplingFreq,RoJoList<freqWeight_t> *maxFreqs); //Cálculo de frecuencias máximas
  public:
    void _interp(RoJoFloatMatrix *coord,float *xMax,float *yMax); //Cálculo de punto máximo por interpolación
    byte begin(RoJoFloatMatrix *ampli,float samplingFreq,RoJoFloatMatrix *freqs); //Inicialización y cálculo
};

#ifdef __arm__
  #include <RoJoFFT.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

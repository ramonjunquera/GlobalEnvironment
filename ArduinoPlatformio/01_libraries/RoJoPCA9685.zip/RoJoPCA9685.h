/*
  Nombre de la librería: RoJoPCA9685.h
  Autor: Ramón Junquera
  Fecha: 20220217
  Descripción:
    Gestión de módulo PCA9685 para salida de señales PWM
  Notas:
  - Si no se indica ningún identificador I2C, se tomará por defecto el 0x40
*/

#ifndef RoJoPCA9685_h
#define RoJoPCA9685_h

#include <Arduino.h>
#include <Wire.h> //Gestión de I2C

class RoJoPCA9685 {
  private:  //Definición de métodos/variables privadas
    byte _idI2C; //Identificador en en bus I2C
    void _write(byte address,byte value);
    uint16_t _max[16],_min[16]; //Arrays de valores máximos (180º) y mínimos (0º) de servos
  public: //Definición de métodos/variables públicas
    RoJoPCA9685(byte idI2C=0x40); //Constructor
    void reset();
    void setFreq(uint16_t freq=1525); //Fija frecuencia de PWM
    void begin(byte pinSDA=255,byte pinSCL=255);
    bool setPWM(byte channel, uint16_t off,uint16_t on=0); //Configura PWM de un canal
    void setServoLimits(byte channel,uint16_t minValue,uint16_t maxValue); //Fija límites de servo
    void setServoDegrees(byte channel,byte degrees); //Fija un servo a un ángulo
}; //Punto y coma obligatorio para que no de error

#include <RoJoPCA9685.cpp>

#endif

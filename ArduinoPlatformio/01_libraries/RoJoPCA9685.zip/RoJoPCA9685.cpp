/*
  Nombre de la librería: RoJoPCA9685.h
  Autor: Ramón Junquera
  Fecha: 20220217
  Descripción:
    Gestión de módulo PCA9685 para salida de señales PWM
*/

#ifndef RoJoPCA9685_cpp
#define RoJoPCA9685_cpp

#include <RoJoPCA9685.h>

//Constructor
RoJoPCA9685::RoJoPCA9685(byte idI2C) {
  _idI2C=idI2C;
}

void RoJoPCA9685::_write(byte address,byte value) {
  Wire.beginTransmission(_idI2C);
  Wire.write(address);
  Wire.write(value);
  Wire.endTransmission();
}

void RoJoPCA9685::reset() {
  //Antes de resetear, apagamos todos los canales del módulo
  //Para ello les asignamos a todos a la vez un inicio de 0 y un final de 0
  //Param 0: 0xFA : dirección base para todos los canales
  //Param 1: 0 : all leds on LB
  //Param 2: 0 : all leds on HB
  //Param 3: 0 : all leds off LB
  //Param 4: 0 : all leds off HB
  byte buffer[5]={0xFA,0,0,0,0};
  Wire.beginTransmission(_idI2C);
  Wire.write(buffer,5);
  Wire.endTransmission();

  _write(0x00,0x80); //PCA9685_MODE1, MODE1_RESTART. Comando reset
  //Una petición de reset tarda aproximadamente 500 microsegundos
  //en dejar el módulo operativo de nuevo.
  //Por seguridad nosotros esperaremos un milisegundo
  delay(1);
  setFreq(); //Fijamos la frecuencia máxima
}

//Fija frecuencia de PWM en Hz
//Rango permitido de frecuencias [24,1525]
//Devuelve true si lo consigue
void RoJoPCA9685::setFreq(uint16_t freq) {
  //Nos aseguramos que la frecuencia esté en los límites permitidos
  if(freq<24) freq=24;
  if(freq>1525) freq=1525;
  //Calculamos el prescaler con la fórmula:
  //  prescaler=max_freqInternal/freqPWM/4096-0.5
  //  prescaler=25000000/freqPWM/4096-0.5
  //  prescaler=6103.5156/freqPWM-0.5
  byte prescaler=6103.5156/(float)freq-0.5;
  _write(0x00,0x10); //Comando: PCA9685_MODE1. Valor: sleep para que el cambio no afecte
  _write(0xFE,prescaler); //Comando: PCA9685_PRESCALE. Valor: prescale calculado
  _write(0x00,0xA0); //Comando: PCA9685_MODE1. Valor: despierta en modo normal con auto incremento
  delay(5); //Tarda un momento en despertar
}; 

void RoJoPCA9685::begin(byte pinSDA,byte pinSCL) {
  //Inicializamos el protocolo I2C
  #if defined(ARDUINO_ARCH_AVR) || defined(__arm__) //Si es una placa Arduino o una RPi ...
    //En las placas Arduino o RPi, no se pueden seleccionar los pines I2C
    //Los posibles pines I2C no se tendrán en cuenta
    Wire.begin();
  #else //No es una placa Arduino ni RPi. Es una ESP.
    //Si se ha indicado pin de I2C (SDA & SCL)...activamos el I2C personalizado
    if(pinSCL<255) Wire.begin(pinSDA,pinSCL);
    //...y si no...usamos una I2C con los pines por defecto
    else Wire.begin();
  #endif
  Wire.setClock(400000); //Fijamos la frecuencia del bus I2C a 400KHz
  reset();
  //Fijamos los valores por defecto máximo y mínimos de los servos
  for(byte c=0;c<16;c++) {
    _min[c]=170;
    _max[c]=610;
  }
}

//Configura PWM de un canal
//  channel: [0,15]
//  off: [0,4095] tick de apagado
//  on: [0,4095] tick de encendido (por defecto 0)
//Devuelve true si lo consigue
bool RoJoPCA9685::setPWM(byte channel, uint16_t off,uint16_t on) {
  if(channel>15 || off>4095 || on>4095 || on>off) return false;
  Wire.beginTransmission(_idI2C);
  Wire.write(0x06+4*channel); //Wire.write(PCA9685_LED0_ON_L + 4 * channel);
  Wire.write(on&0xFF);
  Wire.write(on>>8);
  Wire.write(off&0xFF);
  Wire.write(off>>8);
  Wire.endTransmission();
  return true; //Todo Ok
}

//Fija los valores límite de un servo para un canal (0 y 180 grados)
void RoJoPCA9685::setServoLimits(byte channel,uint16_t minValue,uint16_t maxValue) {
  //Guardamos los valores
  _min[channel]=minValue;
  _max[channel]=maxValue;
}

//Fija un servo a un ángulo
void RoJoPCA9685::setServoDegrees(byte channel,byte degrees) {
  setPWM(channel,(float)(_max[channel]-_min[channel])*(float)degrees/180.0+(float)_min[channel]);
}

#endif

/*
  Nombre de la librería: RoJoESP32PWML.h
  Versión: 20191001
  Autor: Ramón Junquera
  Descripción:
    Gestión de PWM para placas ESP32 usando el método ledc

    A fecha actual el paquete de instrucciones para compatibilizar las placas ESP32 con el IDE
    de Arduino no está totalmente desarrollado.
    Concretamente la instrucción analogWrite para gestionar PWM no existe.
    Se ha creado la función con el mismo nombre y parámetros que la original.
    La única diferencia es que devolverá false si no ha podido completarse.

    Con el método ledc disponemos de 16 canales (timers) de una resolución máxima de 15 bits.
    Para guardar compatibilidad con la instrucción original de Arduino, fijaremos la resolución 
    a 8 bits. Por lo tanto tendremos 256 niveles de intensidad de PWM.
    Cada canal puede ser programado con su propia amplitud de onda.
    Una vez configurado un canal se asocia a un pin, que tendrá el estado de la onda.
    Por lo tanto, con esta librería podremos tener un máximo de 16 pines PWM con valores distintos.

    Con una resolución de 8 bits podemos alcanzar una frecuencia máxima de 312500 Hz.
    Es la frecuencia que utilizaremos para evitar parpadeos.

    Los canales pueden ser utilizados por otras funciones (por ejemplo Tone), por eso debemos
    asegurarnos de no interferir ni modificar la configuración de un canal en uso.
    Para diferenciar si está en uso, leeremos la frecuencia del canal.
    Si no es cero, suponemos que alguien lo está utilizando.
    Para que esta regla funcione no aseguraremos de asignar una frecuencia nula a un canal
    antes de dejar de utilizarlo.

    La función encarga de:
    - Comprobar si ya existe un canal que tenga asignado el pin solicitado para reutilizarlo.
    - Desactivar canales cuyo nivel es 0
    - Buscar canales libres para nuevas peticiones.
*/

#include <RoJoAnalogWriteESP32L.h>

//Asigna un nivel PWM a un pin
//Devuelve true si lo consigue
bool analogWrite(byte pin,byte level) {
  //Array con los pines asignados a cada canal. Inicialmente todos desasignados
  //Utilizamos 255 porque nunca hay tantos pines.
  static byte _pinsPWM[16]={255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255};

  //El pin está asignado a algún canal?
  for(byte ch=0;ch<16;ch++) { //Recorremos todos los canales
    if(_pinsPWM[ch]==pin) { //Si el canal actual esta asignado a este pin...
      if(level) ledcWrite(ch,level); //Si el nivel es distinto de cero...cambiamos el nivel PWM del canal
      else { //Si el nivel es cero...
        ledcDetachPin(pin); //...desasignamos el pin del canal
        digitalWrite(pin,LOW); //Ponemos el pin a low. Forzamos que quede apagado
        _pinsPWM[ch]=255; //Anotamos que está desasignado
        ledcSetup(ch,0,8); //Anulamos la frecuencia de este canal para que sea reconocido como libre
      }
      return true; //Hemos terminado correctamente
    }
  }
  //Hemos recorrido todos los canales y ninguno está asignado al pin indicado
  if(level) { //Si el nivel de PWM es mayor que cero para el nuevo pin...
    //Buscaremos un canal libre
    for(byte ch=0;ch<16;ch++) { //Recorremos todos los canales
      if(ledcReadFreq(ch)==0.0) { //Si el canal actual no se está utilizando...
        ledcSetup(ch,312500,8); //Fijamos la máxima frecuencia con una resolución de 8 bits para este canal
        _pinsPWM[ch]=pin; //Anotamos el pin asoociado a ese canal
        ledcWrite(ch,level); //Fijamos el nivel al solicitado
        ledcAttachPin(pin,ch); //Asociamos el pin al canal
        return true; //Hemos terminado correctamente
      }
    }
    //Hemos recorrido todos los canales y no hemos encontrado ninguno libre :-(
    return false; //No lo hemos conseguido
  }
  //Se quiere aplicar un nivel 0 a un pin nuevo
  digitalWrite(pin,LOW); //Es lo mismo que apagarlo
  return true; //Todo correcto
}


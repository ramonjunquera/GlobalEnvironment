/*
  Nombre de la librería: RoJoM5Bala.h
  Versión: 20201110
  Autor: Ramón Junquera
  Descripción:
    Gestión de módulo Bala para M5 Stack
	Nota:
    Es imprescindible que el módulo tenga alimentación. Ya sea por la
    batería interna o por cable. De lo contrario influirá en el bus I2C
    impidiendo que otros dispositivos puedan ser controlados.
*/

#ifndef RoJoM5Bala_cpp
#define RoJoM5Bala_cpp

#include <RoJoM5Bala.h>

//Asigna potencia los motores
//Los valores de las potencias deben estar entre -255 y 255
//Valores positivos = adelante = opuesto a la botonera
void RoJoM5Bala::set(int16_t p0,int16_t p1) {
	static int16_t last0=100,last1=100;
	p0=constrain(p0,-255,255);
	p1=constrain(p1,-255,255);
	if(last0==p0 && last1==p1) return;
	last0=p0; last1=p1;
	Wire.beginTransmission(_idI2C);
	Wire.write(0x00); //Asignamos potencia
	Wire.write((byte*)&p0,2);
	Wire.write((byte*)&p1,2);
	Wire.endTransmission();
}

//Inicialización
//Devuelve true si lo consigue
bool RoJoM5Bala::begin(int pinSDA,int pinSCL) {
  Wire.begin(pinSDA,pinSCL,400000);
  Wire.beginTransmission(_idI2C);
  if(Wire.endTransmission()) return false; //El módulo no está conectado/encendido
  set(0,0); //paramos los motores
  return true; //Todo Ok
}

//Lee los valores de los encoders
//Devuelve true si ha podido leerlos
bool RoJoM5Bala::get(int16_t *e0,int16_t *e1) {
	//Nota:
	//Los enconders guardan el desplazamiento de cada rueda desde la última comprobación
	//El desplazamiento puede ser tanto positivo como negativo.
	//Si miramos el dispositivo bala desde arriba, con la botonera del M5 en la parte inferior,
	//tenemos que el primer motor es el izquierdo, y el segundo el derecho.
	//El encoder del primer motor arroja valores positivos cuando el dispositivo se desplaza hacia
	//adelante (hacia la botonera). Pero el encoder derecho lo hace al revés.
	//Para simplificar los cálculos posterior, se cambiará al signo al encoder derecho.
	//Finalmente devolverá resultados positivos para ambos encoders cuandos se desplace hacia
	//adelante y negativos hacia atrás.
	Wire.beginTransmission(_idI2C);
	Wire.write(0x04); // encoder reg addr
	Wire.endTransmission();
	Wire.beginTransmission(_idI2C);
	Wire.requestFrom((int)_idI2C,(int)4);
	if (Wire.available()) {
		Wire.readBytes((byte*)e0,2);
		Wire.readBytes((byte*)e1,2);
		*e1=-*e1; //Cambiamos de signo al encoder derecho
		return true;
	}
	return false;
}

#endif

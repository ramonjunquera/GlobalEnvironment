/*
  Tema: LittleFS para ESP32
  Fecha: 20211112
  Autor: Ramón Junquera

  Descripción:
  El formato de sistema de archivos SPIFFS pasa a estar obsoleto en favor de LittleFS, que mejora
  su rendimiento.
  En ESP8266 ya se incluyen las libreráis por defecto, pero en ESP32 no.
  He tomado las librerías creadas por Lorol (https://github.com/lorol/LITTLEFS) y las he modificado
  para que se comporten de igual manera que las oficiales en ESP8266.
  Este es el listado de cambios:
  - El objeto por defecto pasa de LITTLEFS a LittleFS
  - Cuando se inicializa el sistema con begin, si no detecta el formato correcto, lo formatea
    automáticamente.
  - Cuando se elimina una carpeta vacía, si todas sus superiores también están vacías, también se eliminan.
  - Si borramos un archivo, dejamos la carpeta vacía y todas las carpetas superiores también están vacías,
    también se borran las carpetas.

  Pendiente:
  - En ESP32 cuando solicitamos el nombre de un nodo (carpeta/archivo) nos devuelve el path completo
    comenzando por /. En ESP8266 sólo devuelve el nombre del nodo. La carpeta raíz tendía un nombre de
    longitud 0.
    Para guardar compatibilidad se podrían añadir las siguientes líneas:
      String filename=file.name();
      #ifdef ESP32
        filename=filename.substring(filename.lastIndexOf('/')+1);
      #endif
*/

#ifdef ESP32

#ifndef _LittleFS_H_
#define _LittleFS_H_

#include <FS.h>

namespace fs {
  class LittleFSFS : public FS {
    public:
      LittleFSFS();
      ~LittleFSFS();
      bool begin(bool formatOnFail = true, const char *basePath = "/littlefs", uint8_t maxOpenFiles = 10, const char *partitionLabel = "spiffs");
      bool format();
      size_t totalBytes();
      size_t usedBytes();
      void end();
    private:
      char *partitionLabel_;
    };
}

extern fs::LittleFSFS LittleFS;

#endif

#endif
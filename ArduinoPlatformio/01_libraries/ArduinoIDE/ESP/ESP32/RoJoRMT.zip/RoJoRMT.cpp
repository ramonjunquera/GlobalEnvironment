/*
  Nombre de la librería: RoJoRMT.h
  Versión: 20220510
  Autor: Ramón Junquera
  Descripción:
    Facilita el envío y recepción de información a través de una conexión de luz
    (láser o IR) con protocolo con paridad por RMT.

  Notas:
  - Cuando se envía, no se devuelve el control hasta que finaliza la transmisión
*/

#ifndef RoJoRMT_cpp
#define RoJoRMT_cpp

#include <RoJoRMT.h>

//Inicialización
//- pin
//- Tx: Se transmitirá?. true=Tx, false=Rx
//- clk_div: divisor del reloj
//- sizeInternalRxBuffer: tamaño del buffer de recepción interno en bytes
//- channel: canal RMT
//Devuelve el código de error
//  0 : Sin errores
//  1 : No se puede aplicar la configuración de RMT
//  2 : No se puede activar el canal
//  3 : No se puede obtener el buffer circular
//  4 : No se puede activar el servicio de recepción
byte RoJoRMT::begin(byte pin,bool Tx,byte clk_div,uint16_t sizeInternalRxBuffer,rmt_channel_t channel) {
  if(_init) end(); //Si ya se había inicializado previamente...lo finalizamos
  rmt_config_t configRMT;
  configRMT.rmt_mode=Tx?RMT_MODE_TX:RMT_MODE_RX;
  configRMT.channel=_channel=channel;
  configRMT.gpio_num=(gpio_num_t)pin;
  configRMT.clk_div=clk_div;
  configRMT.mem_block_num=1;
  configRMT.rx_config.idle_threshold=11; 
  if(rmt_config(&configRMT)) return 1; //Si no se puede aplicar configuración...error
  if(rmt_driver_install(configRMT.channel,Tx?0:55*sizeInternalRxBuffer+1,0)) return 2; //Si no se puede activar el canal...error
  if(!_Tx) { //Si es una recepción...
    if(rmt_get_ringbuf_handle(configRMT.channel,&_rb)) return 3; //Si no podemos obtener el puntero del buffer circular...error
    if(rmt_rx_start(configRMT.channel,1)) return 4; //Si no podemos activar el servicio...error
  }
  _Tx=Tx;
  _init=true; //Se ha inicializado correctamente
  return 0; //Sin errores
}

//Finalización
void RoJoRMT::end() {
  if(_init) {
    rmt_driver_uninstall(_channel); //Desinstalación del driver
   _init=false; //Nunca se ha inicializado
  }
}

//Codifica el byte value en items de pulso y los guarda en el array pulseItemsBase
void RoJoRMT::_code(byte value,rmt_item32_t *pulseItemsBase) {
  byte paridad=0;
  rmt_item32_t *currentItem;
  for(byte i=0;i<4;i++) { //Codificamos el bit
    currentItem=&pulseItemsBase[i]; //Tomamos el item actual
    //Primer bit
    currentItem->level0=1;
    //currentItem->duration0=minPulseTicks;
    currentItem->duration0=_minPulseTicksTx0;
    if(value & 128) { //Si el bit es 1...
      currentItem->duration0++;
      paridad++;
    }
    value<<=1;
    //Segundo bit
    currentItem->level1=0;
    currentItem->duration1=_minPulseTicksTx1;
    if(value & 128) { //Si el bit es 1...
      currentItem->duration1++;
      paridad++;
    }
    value<<=1;
  }
  currentItem=&pulseItemsBase[4]; //Tomamos el último item (paridad)
  currentItem->level0=1;
  //Si el contador de bits 1 es impar...el pulso HIGH será de pulseTicks*3
  currentItem->duration0=(paridad%2>0)?_minPulseTicksTx0+3:_minPulseTicksTx0+2;
  currentItem->level1=0;
  currentItem->duration1=_minPulseTicksTx1;
}

//Envío
//- *TxBuffer: puntero a buffer de datos a enviar
//- sizeTxBuffer: número de bytes a enviar
//Devuelve código de error
//  0 : Si errores
//  1 : Aun no se ha inicializado
//  2 : Se ha configurado como Rx, no Tx
//  3 : Falta memoria para almacenar los items de pulso
byte RoJoRMT::Tx(byte *TxBuffer,uint16_t sizeTxBuffer) {
  if(!_init) return 1;
  if(!_Tx) return 2;
  //Reservamos memoria para los items de pulso
  rmt_item32_t *pulseItems=(rmt_item32_t*)malloc(sizeof(rmt_item32_t)*sizeTxBuffer*5);
  if(!pulseItems) return 3; //Si no hay memoria...error
  for(uint16_t i=0;i<sizeTxBuffer;i++) _code(TxBuffer[i],&pulseItems[i*5]); //Codificamos los distintos bytes
  rmt_write_items(_channel,pulseItems,sizeTxBuffer*5,true); //Enviamos y esperamos a que termine
  free(pulseItems); //Liberamos la memoria de items de pulso
  return 0; //Sin errores
}

//Decodifica y normaliza los valores de un item de pulso según protocolo
void RoJoRMT::_decodeValuesFromItems(rmt_item32_t *pulseItem,byte *value0,byte *value1) {
  *value0=pulseItem->duration0-_minPulseTicksRx0;
  *value1=pulseItem->duration1;
  if(*value1) *value1-=_minPulseTicksRx1;
  //Serial.printf("* %u - %u : %u - %u\n",pulseItem->duration0,pulseItem->duration1,*value0,*value1);
}

//Decodifica los items de pulso
//Parámetros:
//- res: puntero a array de bytes donde se almacenará el resultado decodificado
//- totalBytes: númeo de bytes decodificados
//- pulseItemsBase: puntero a array de items de pulso
//- totalItems: número de items de pulso
//Devuelve true si se han detectado errores
bool RoJoRMT::_decode(byte *res,uint16_t *totalBytes,rmt_item32_t *pulseItemsBase,size_t totalItems) {
  bool errors=false;
  uint16_t currentByte=0;
  size_t indexItem=0;
  byte indexItemInByte=0;
  byte paridad=0;
  byte v0,v1; //Valores decodificados de un item de pulso
  *totalBytes=0; //Inicialmente no se ha decidificado ningún byte
  while(indexItem<totalItems) {
    _decodeValuesFromItems(&pulseItemsBase[indexItem],&v0,&v1);
    if(v0>=2 && v0<=3 && v1==0 && indexItemInByte==4 && (paridad+v0-2)%2==0) { //Si es un item de paridad correcto...
      res[(*totalBytes)++]=currentByte; //Guardamos el byte recibido
      currentByte=0;
      indexItemInByte=0;
      paridad=0;
    } else if(v0<2 && v1<2 && indexItemInByte<4){ //Si es un item de información correcto...
      currentByte<<=1;
      if(v0) { //Si es 1...
        currentByte++;
        paridad++;
      }
      currentByte<<=1;
      if(v1) { //Si es 1...
        currentByte++;
        paridad++;
      }
      indexItemInByte++;
    } else { //Si es un item corrupto...
      currentByte=0;
      indexItemInByte=0;
      paridad=0;
      errors=true;
    }
    indexItem++;
  }
  return errors;
}

//Recepción
//- *RxBuffer: puntero a buffer de datos recibidos. Predimensionado
//- *sizeRxBuffer: puntero a número de bytes recibidos
//Devuelve código de error:
//  0 : Sin errores
//  1 : Aun no se ha inicializado
//  2 : Se ha configurado como Tx, no Rx
//  3 : Recepción con errores
byte RoJoRMT::Rx(byte *RxBuffer,uint16_t *sizeRxBuffer) {
  if(!_init) return 1;
  if(_Tx) return 2;
  *sizeRxBuffer=0; //Inicialmente no se ha recibido nada
  size_t rx_size=0; //Número de items recibidos
  //Leemos del buffer circular de entrada los items que contiene ahora mismo. No esperamos.
  rmt_item32_t* items=(rmt_item32_t*)xRingbufferReceive(_rb,&rx_size,0);
  if(!items) return 0; //No se he recibido nada. Salimos sin errores
  rx_size/=4; //Número de items de pulso recibidos
  byte errorCode=0;
  //Si no hay suficientes items de pulso para un byte, o hay error en la decodificación...error
  if(rx_size<5 || _decode(RxBuffer,sizeRxBuffer,items,rx_size)) errorCode=3;
  vRingbufferReturnItem(_rb,(void*)items); //Liberamos los items leidos del buffer circular
  return errorCode;
}

#endif

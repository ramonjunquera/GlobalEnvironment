/*
  Nombre de la librería: RoJoPAL.h
  Versión: 20220203
  Autor: Ramón Junquera
  Descripción:
    Gestión de señal de vídeo compuesta PAL
*/

//Comprobamos que la placa es compatible
#if not defined(ARDUINO_ARCH_ESP32)
  #error Library RoJoPAL is only compatible with ESP32 family devices
#endif 

#ifndef RoJoPAL_h
#define RoJoPAL_h

#include <Arduino.h>
#include <driver/i2s.h>
#include <RoJoSprite.h> //Gestión de sprites

#define _RoJoPAL_samplesPerLine 852 //852*0.075=63.9 microsegundos
#define _RoJoPAL_signalNull 0 //Señal DAC nula
#define _RoJoPAL_signalBase 12<<8 //Señal DAC base
#define _RoJoPAL_signalBlack 7<<8 //Señal DAC de negro puro
#define _RoJoPAL_signalWhite 75<<8 //Señal DAC de blanco puro
#define _RoJoPAL_xMaxDisplay 690 //Máxima resolución horizontal de pantalla
#define _RoJoPAL_xMaxVisible 653 //Máxima resolución horizontal visible
#define _RoJoPAL_yMaxDisplay 304 //Máxima resolución vertical de pantalla
#define _RoJoPAL_yMaxVisible 218 //Máxima resolución vertical visible

class RoJoPAL {
  private:
    uint16_t _tone[256]; //Correlación de tonos con valor DAC
    uint16_t _line[_RoJoPAL_samplesPerLine]; //Muestras de una línea de pantalla
    uint16_t _linePos; //Posición de escritura en la memoria de línea
    RoJoSprite *_spr; //Sprite de imágen a mostrar
    uint16_t _marginLeft; //Número de pixels negros de borde izquierdo
    uint16_t _marginUp; //Número de pixels (líneas) de borde superior
    uint16_t _marginDown; //Número de pixels (líneas) de borde inferior
    void _fillLine(uint16_t signal,uint16_t counter); //Llena la memoria de línea con una senal un número determinado de veces
    void _fillLineLong(); //Escribe un pulso largo en media memoria de línea
    void _fillLineShort(); //Escribe un pulso corto en media memoria de línea
    void _fillLineBlack(); //Escribe una línea negra en la memoria de línea
    void _fillLineBase(); //Escribe una señal de base en media memoria de línea
    void _fillLineMedium(); //Escribe un pulso medio en media memoria de línea
    void _sendVideoRow(); //Envía las muestras contenidas en la dirección line
    void _showSprite(); //Dibuja la líneas del sprite
  public:
    bool begin(RoJoSprite *spr,byte pinRCA=25);
    void _sendVideoFrame(); //Envía un fotograma
};

#include <RoJoPAL.cpp>

//Inicialización y creación del objeto PAL
bool PAL_begin(RoJoSprite *spr,byte pinRCA=25);
void PAL_end(); //Finaliza el refresco de pantalla

#endif

#ifndef RoJoFtpServer_cpp
#define RoJoFtpServer_cpp

#include <RoJoFtpServer.h>

time_t _timeStampFTP=0; //TimeStamp de archivos

//Función de obtención de fecha para escritura de archivos
time_t _timeCallbackFTP() {
  return _timeStampFTP;
}

//Inicialización
//Devuelve true si lo consigue
bool RoJoFtpServer::begin(String ftpUser,String ftpPassword) {
  if(!RoJoFS.begin()) return false; //Si no se ha podido inicializar correctamente el sistema de archivos...error
  _ip=WiFi.localIP(); //Anotamos la dirección ip local asignada
  //Si no tiene dirección asignada porque hemos creado nosotros el punto de acceso wifi...tomamos la dirección de ahí
  if(_ip[0]+_ip[1]+_ip[2]+_ip[3]==0) _ip=WiFi.softAPIP();
  _ftpUser=ftpUser; _ftpPassword=ftpPassword; //Anotamos las credenciales
  _ftpServer=new WiFiServer(_portFtp);
  _dataServer=new WiFiServer(_portData);
  _ftpServer->begin(_portFtp); _dataServer->begin(_portData);
  _millisNextCheck=0; //El siguiente refresco será inmediatamente
  _timeOutNextCheck=millis()+_timeOut; //Momento de desconexión automática por inactividad
  return true; //Todo Ok
}

//Añade un nivel a _currentPath
String RoJoFtpServer::_currentPathAdd(String path) {
  return _currentPath+(_currentPath=="/"?"":"/")+path;
}

//Desconectamos cliente actual
void RoJoFtpServer::_clientDisconnect() {
  if(_ftpClient.connected()) {
    _ftpClient.println("221 Goodbye"); //Nos despedimos
    _ftpClient.stop(); //Finalizamos la comunicación
  }
  //Inicializamos todas las variables para la nueva conexión
  _loginLevel=0; //nadie ha hecho login
  _rBuffer=""; //Vaciamos el buffer de recepción
  _currentPath="/"; //Recuperamos el path por defecto
}

//Lee línea de comandos recibida
String RoJoFtpServer::_readCommandLine() {
  while(_ftpClient.available()) { //Leemos mientras haya más info pendiente de recibir
    char readChar=_ftpClient.read(); //Leemos el siguiente carácter pendiente por recibir
    if(readChar=='\\') readChar='/'; //Siempre utilizaremos la barra / para evitar confusiones
    if(readChar=='\n') { //Si es fin de línea...
      String commandLine=_rBuffer; //Guardamos temporalmente el buffer de recepción con la línea de comandos recibida...
      _rBuffer=""; //...para poder vaciarlo
      return commandLine;
    }
    //El carácter recibido NO es un fin de línea
    if(readChar!='\r') { //No tendremos en cuenta \r
      if(_rBuffer.length() > _rBufferMaxLength) { //Si estamos superando la longitud máxima de un comando...
        Serial.println("Error. Superada la longitud máxima de un comando: "+_rBuffer);
        _clientDisconnect(); //Directamente finalizamos la conexión
        return "";
      }
      _rBuffer+=readChar; //Aun podemos añadir un carácter más al buffer de recepción
    }
    //Como hemos recibido algo, aumentamos el tiempo de desconexión por inactividad
    _timeOutNextCheck=millis()+_timeOut;
  }
  //No tenemos más caracteres pendientes por recibir
  return ""; //Aun no tenemos una línea de comandos completa
}

//Abre la conexión de datos. Espera la conexión de un nuevo cliente
//Devuelve si lo ha conseguido
bool RoJoFtpServer::_openDataConnection() {
  uint32_t maxMillis=millis()+10000; //Timeout de 10 segundos
  //Esperamos una conexión al servidor de datos mientras no alcancemos el tiempo máximo
  while(!_dataServer->hasClient() && maxMillis-millis()<_maxTimeOut) yield();
  //Si hemos conseguido una conexión...anotamos su cliente
  if(_dataServer->hasClient()) _dataClient=_dataServer->accept();
  //Respondemos que es correcto si se mantiene la conexión o si tiene información
  //pendiente de ser procesada.
  //En ESP8266 con el comando STOR y archivos muy pequeños, se envía el contenido del
  //archivo al servidor de datos y se cierra la conexión. Para cuando vamos a mirar el
  //estado de la conexión ya está cerrada, pero al menos nos queda el contenido recibido
  //en el buffer de entrada. Esto no ocurre en ESP32.
  return _dataClient.connected() || _dataClient.available();
}

//Obtiene el valor entero desde un String y devuelve el String recortado
String RoJoFtpServer::_getInt(String s,byte *value) {
  *value=s.toInt();
  return s.substring(String(*value).length()+1);
}

void RoJoFtpServer::_processCommandLine(String commandLine) {
  if(!commandLine.length()) return; //Si la línea está vacía...hemos terminado
  //La línea de comando contiene algo!
  Serial.println("commandLine=#"+commandLine+"#");
  int spcIndex=commandLine.indexOf(' '); //Posición del primer espacio
  String command,parameters;
  if(spcIndex<0) { //Si no se ha encontrado ningún espacio...
    command=commandLine; //El comando el todo lo recibido
    parameters=""; //No tiene parámetros
  } else { //Se ha encontrado algún espacio...
    command=commandLine.substring(0,spcIndex);
    parameters=commandLine.substring(spcIndex+1);
  }
  //Tenemos la línea de comando separada en comando y parámetros
  if(command=="USER") { //Indicar usuario para login
    if(parameters==_ftpUser) { //Usuario correcto...
      _loginLevel=1; //Usuario correcto, falta contraseña
      _ftpClient.println("331 User ok. Password required");
    } else { //Usuario incorrecto...
      _loginLevel=0; //Falta usuario y contraseña
      _ftpClient.println("530 User not found");
    }
  } else if(command=="PASS") { //Indicar contraseña de usuario para login
    if(_loginLevel) { //Si se ha validado previamente el usuario o usuario y contraseña...
      if(parameters==_ftpPassword) { //Contraseña correcta...
        _loginLevel=2; //Usuario y contraseña correctas
        _ftpClient.println("230 Password ok");
      } else { //Contraseña incorrecta...
        _loginLevel=1; //Usuario ok, contraseña ko
        _ftpClient.println("530 Wrong password");
      }
    } else { //No se ha validado previamente el usuario...
      _ftpClient.println("530 Validate user first");
    }
  } else if(_loginLevel<2) { //Si aun no se ha identificado...
    _ftpClient.println("Not logged in.");
  } else if(command=="CWD") { //Cambio de directorio de trabajo
    String newCurrentPath="";
    if(parameters.startsWith("/")) newCurrentPath=parameters; //Path absoluto
    else newCurrentPath=_currentPathAdd(parameters); //Path relativo
    if(RoJoFS.exists(newCurrentPath)) { //Si el path existe...
      _currentPath=newCurrentPath;
      _ftpClient.println("250 Ok. Current directory is "+_currentPath);
    } else _ftpClient.println("450 Path unknown");
  } else if(command=="PWD") { //Solicitud de directorio actual
    _ftpClient.println("257 "+_currentPath+" is your current directory");
  } else if(command=="TYPE") { //Tipo de transferencia
    //Realmente no tendremos en cuenta el tipo de transferencia
    //Siempre haremos transferencias binarias para asegurar
    if(parameters=="A") { //ASCII...
      _ftpClient.println("200 TYPE is now ASCII");
    } else if(parameters=="I") { //Binary...
      _ftpClient.println("200 TYPE is now 8-bit binary");
    } else { //¿?
      _ftpClient.println("504 Unknow TYPE");
    }
  } else if(command=="PASV") { //Modo pasivo
    //Respondemos: "227 Entering Passive Mode (172,16,0,110,195,89)."
    //Correspondiente a la dirección ip del servidor: 172.16.0.110
    //Y el puerto de transmisión de datos: 195*256+89=50009
    _ftpClient.println("227 Entering Passive Mode ("+String(_ip[0])+","+String(_ip[1])+","+String(_ip[2])+","+String(_ip[3])+","+String(_portData >> 8)+","+String (_portData & 255)+").");
  } else if(command=="SYST") { //Tipo de sistema operativo
    #ifdef ESP32
      _ftpClient.println("215 ESP32");
    #else
      _ftpClient.println("215 ESP8266");
    #endif
  } else if(command=="FEAT") { //Soporta nuevas funcionalidades/features?
    _ftpClient.println("211-Extensions suported:");
    _ftpClient.println(" MLSD"); //Soporta MLSD=Listado de archivos de carpeta actual
    _ftpClient.println(" MFMT"); //Soporta MDMD=Asignar timestamp a entrada
    _ftpClient.println("211 End.");
  } else if(command=="STAT") { //Status/Version
    _ftpClient.println("211 RoJo FTP v"+_ver);
  } else if(command=="MLSD") { //Listado de directorio actual
    //Extensión MLSD (Listing for Machine Procesing)
    //Si no hemos encontrado un cliente conectado al servidor de datos...error
    if(!_openDataConnection()) _ftpClient.println("425 No data connection MLSD");
    else { //Tenemos un cliente en la conexión de datos!
      _ftpClient.println("150 Accepted data connection");
      RoJoDir dir=RoJoFS.openDir(_currentPath);
      uint16_t dirEntryCount=0; //Número de entradas del directorio
      while(dir.next()) {
        //Obtenemos la fecha de la entrada en formato dd/mm/yyyy hh:mm:ss
        String t=dir.fileTimeString(dir.fileTime());
        //Reformateamos la cadena a yyyymmddhhmmss
        //0123456789012345678
        //dd/mm/yyyy hh:mm:ss
        t=t.substring(6,10)+t.substring(3,5)+t.substring(0,2)+t.substring(11,13)+t.substring(14,16)+t.substring(17);
        if(dir.isDirectory()) {
          _dataClient.println("Type=dir;modify="+t+"; "+dir.fileName());
        } else {
          _dataClient.println("Type=file;Size="+String(dir.fileSize())+";modify="+t+" "+dir.fileName());
        }
        dirEntryCount++;
      }
      //Informamos del total de archivos en formato
      //226-options_ -a -l
      //226 23 matches total
      _ftpClient.println("226-options: -a -l");
      _ftpClient.println("226 "+String(dirEntryCount)+" matches total");
      _dataClient.stop(); //Fin de conexión de datos
    }

  } else if(command=="STOR") { //Recibe archivo
    if(parameters=="") _ftpClient.println("501 No file name");
    else { //Tenemos nombre de archivo
      File f=RoJoFS.open(_currentPathAdd(parameters),"w");
      if(!f) _ftpClient.println("451 Can't create file "+parameters);
      else { //Hemos podido abrir el archivo para escritura
        if(!_openDataConnection()) { //Si no encontramos cliente en el servidor de datos...
          _ftpClient.println("425 No data connection");
          f.close();
        } else { //Tenemos un cliente conectado en el servidor de datos
          _ftpClient.println("150 Connected to port "+String(_portData));
          while(_dataClient.available()) f.write(_dataClient.read());
          _ftpClient.println("226 File successfully transferred");
          f.close();
          _dataClient.stop();
        }
      }
    }
  } else if(command=="MKD") { //Crear directorio
    if(!RoJoFS.mkdir(_currentPathAdd(parameters)))
        _ftpClient.println("450 Can't create path for "+parameters);
    else _ftpClient.println("257 Dir "+parameters+" created."); //Ok
  } else if(command=="DELE") { //Borrar un archivo
    if(!RoJoFS.remove(_currentPathAdd(parameters))) 
        _ftpClient.println("450 Can't delete file "+parameters);
      else _ftpClient.println("250 File "+parameters+" deleted");
  } else if(command=="RMD") { //Borra un directorio
    if(!RoJoFS.rmdir(_currentPathAdd(parameters)))
      _ftpClient.println("501 Can't delete dir "+parameters);
    else _ftpClient.println("250 Deleted "+parameters);
  } else if(command=="RETR") { //Envía archivo al cliente
    File f=RoJoFS.open(_currentPathAdd(parameters)); //Abrimos como sólo lectura
    if(!f) _ftpClient.println("550 File "+parameters+" not found");
    else { //Hemos podido abrir el archivo como sólo lectura
        if(!_openDataConnection()) { //Si no encontramos cliente en el servidor de datos...
        _ftpClient.println("425 No data connection");
        f.close();
      } else { //Tenemos un cliente conectado en el servidor de datos
        _ftpClient.println("150 Connected to port "+String(_portData));
        while(f.available()) _dataClient.write(f.read());
        _ftpClient.println("226 File successfully transferred");
        f.close();
        _dataClient.stop();
      }
    }
  } else if(command=="RNFR") { //Rename From file/dir
    _renameFrom=_currentPathAdd(parameters);
    if(!RoJoFS.exists(_renameFrom)) {
      _ftpClient.println("550 File "+_renameFrom+" not found");
      _renameFrom="";
    } else _ftpClient.println("350 RNFR accepted - file exists, ready for destination");
  } else if(command=="RNTO") { //Rename To file/dir
    if(_renameFrom.length()==0) _ftpClient.println("503 Need RNFR before RNTO");
    else {
      if(!RoJoFS.rename(_renameFrom,_currentPathAdd(parameters))) 
        _ftpClient.println("451 Rename to "+parameters+" failure");
      else _ftpClient.println("250 Rename done");
      _renameFrom="";
    }
  } else if(command=="CDUP") { //Subir un nivel en el directorio actual
    if(_currentPath!="/") {
      //Quitamos el último nivel
      _currentPath=_currentPath.substring(0,_currentPath.lastIndexOf("/"));
      //Si hemos llegado a raíz
      if(_currentPath=="") _currentPath="/";
    }
    _ftpClient.println("250 Ok. Current directory is "+_currentPath);
  } else if(command=="MFMT") { //File Modification Time
    //                             0123456789012345678901234
    //parameters tiene el formato: 20230217185435 perro.txt
    if(parameters.charAt(14)!=' ') _ftpClient.println("550 Unable to retrieve time");
    else { //Parece que los parámetros son correctos
      //Componemos la fecha
      struct tm t;
      t.tm_year=parameters.substring(0,4).toInt()-1900;
      t.tm_mon=parameters.substring(4,6).toInt()-1;
      t.tm_mday=parameters.substring(6,8).toInt();
      t.tm_hour=parameters.substring(8,10).toInt();
      t.tm_min=parameters.substring(10,12).toInt();
      t.tm_sec=parameters.substring(12,14).toInt();
      _timeStampFTP=mktime(&t); //Fijamos la fecha a utilizar para TimeStamp
      String fileName=_currentPathAdd(parameters.substring(15)); //Nombre de archivo con path
      RoJoFS.setTimeCallback(_timeCallbackFTP); //Fijamos función de callback
      File f=RoJoFS.open(fileName,"r+"); //Abrimos lectura/excritura
      f.close(); //Sin modificar, cerramos. Ya se ha actualizado la fecha
      RoJoFS.setTimeCallback(NULL); //Anulamos función de callback
      _ftpClient.println("213 "+parameters); //Ok
    }
  } else _ftpClient.println("500 Command not supported"); //Comando no reconocido
}

//Refresco de comunicaciones
void RoJoFtpServer::refresh() {
  if(_millisNextCheck-millis()<_maxTimeOut) return; //Si todavía no toca hacer el refresco...hemos terminado
  
  //Nota: El servidor sólo atenderá un cliente concurrente por motivos de capacidad
  if (_ftpServer->hasClient()) { //Si descubrimos una nueva solicitud de conexión...
    Serial.println("Detectada nueva conexión");
    _clientDisconnect(); //Desconectamos la actual
    _ftpClient=_ftpServer->accept(); //Y tomamos la nueva como la actual
    _ftpClient.println("220 Welcome to RoJo FTP v"+_ver); //Saludamos
    _timeOutNextCheck=millis()+_timeOut; //Momento de desconexión automática por inactividad
  }
  String commandLine=_readCommandLine(); //Obtenemos la línea de comandos recibida
  _processCommandLine(commandLine);
  _millisNextCheck=millis()+200; //Siguiente refresco en 200ms
  //Si hemos alcanzado el tiempo máximo de inactividad...desconectamos al cliente
  if(_timeOutNextCheck-millis()>_maxTimeOut) _clientDisconnect();
}

//Devuelve ip del servidor
IPAddress RoJoFtpServer::getIP() {
  return _ip;
}

#endif //RoJoFtpServer_cpp
/*
  Autor: Ramón Junquera
  Descripción: Servidor FTP
  Fecha: 20230210

  Descripción:
  - Basado en la RFC oficial de servidor FTP: https://www.rfc-editor.org/rfc/rfc959
  - Las extensiones (MLSD) se basan en la RFC oficial: https://www.rfc-editor.org/rfc/rfc3659.txt
  - El servidor es muy simple.
  - No admite encriptación, sólo texto plano.
  - Funciona en modo pasivo: sólo responde a nuestros comandos.
  - Sólo admite una conexión simultánea.
  - Sólo permite un usuario y una contraseña para conectar.
  - Admite distintos sistemas de almacenamiento de archivos, pero siempre con posibilidad de
    utilizar carpetas (SPIFFS queda descartado).
  - Está probado con el cliente FTP de FileZilla
  - No se incluye el comando LIST para listar el contenido del directorio actual, porque
    tiene limitaciones. No distingue entre archivo y directorio. En su lugar se implementa
    el comando MLSD que hace lo mismo y sí los distingue.
  
  Ejemplos de secuencias típicas de comandos:
  - Inicialización
      USER esp #Se indica el usuario
      PASS esp #Se indica la contraseña
      SYST #Se solicita información sobre el sistema operativo
      FEAT #Se pregunta por las extensiones soportadas
      CWD / #Se fija raíz como directorio inicial
      PWD #Se verifica que raíz es el directorio actual
      TYPE I #Modo binario
      PASV #Se pasa a modo pasivo
      MLSD #Se solicita listado de contenido de directorio actual
  - Refresco de directorio
      PASV #Se pasa a modo pasivo
      MLSD #Se solicita listado de contenido de directorio actual
  - Bajar directorio
      CWD mydir #Cambia directorio relativo
      PWD #Se verifica que se ha podido cambiar de directorio
      PASV #Se pasa a modo pasivo
      MLSD #Se solicita listado de contenido de directorio actual
  - Subir un nivel de directorio
      CDUP #Subimos un nivel el directorio actual
      PWD #Se verifica que se ha podido cambiar de directorio
      PASV #Se pasa a modo pasivo
      MLSD #Se solicita listado de contenido de directorio actual
  - Subir un archivo al servidor
      TYPE A #Modo ASCII
      PASV #Se pasa a modo pasivo
      STOR adios.txt #Trasnferir archivo
  - Borrar un archivo/directorio del servidor
      DELE adios.txt #Borrar archivo/directorio
  - Renombrar archivo/directorio en el servidor
      RNFR adios.txt #Nombre original del archivo/directorio
      RNTO adios3.txt #Nombre destino del archivo/directorio
  - Transferir archivo de servidor a cliente
      TYPE I #Modo binario
      PASV #Se pasa a modo pasivo
      MLSD #Se solicita listado de contenido de directorio actual
      TYPE A #Modo ASCII
      PASV #Se pasa a modo pasivo
      RETR adios3.txt #Recuperación de archivo

  Notas:
  - En ESP8266 no se permite incluir el objeto WiFiServer como variable de clase (en ESP32
    sí). Por lo tanto, en su lugar se definen punteros a los que se les asignará este
    objeto en el método begin.
*/

#ifndef RoJoFtpServer_h
#define RoJoFtpServer_h

#include <Arduino.h>
#include <RoJoMultiFS.h>
#ifdef ESP32
  #include <WiFi.h> //Para crear el servidores
#elif defined(ESP8266)
  #include <ESP8266WiFi.h> //Para crear el servidores
#else
  #error Device unknown. Only sopport ESP32 & ESP8266
#endif
#include <WiFiClient.h>

class RoJoFtpServer {
  private:
    const String _ver="20230208"; //Versión
    const uint16_t _portFtp=21; //Puerto de escucha de servidor FTP
    const uint16_t _portData=50009; //Puerto de escucha de servidor para transmisión de datos
    const uint16_t _rBufferMaxLength=263; //Máxima longitud de un comando con parámetros
    const uint32_t _timeOut=1000*60; //Tiempo máximo de inactividad para desconexión automática
    const uint32_t _maxTimeOut=-1-1000*60*60*24; //Un día antes del máximo
    WiFiServer *_ftpServer; //Servidor de comandos de FTP
    WiFiServer *_dataServer; //Servidor de transmisión de datos
    WiFiClient _ftpClient;
    WiFiClient _dataClient;
    String _ftpUser; //Usuario de acceso a FTP
    String _ftpPassword; //Contraseña de usuario de acceso a FTP
    byte _loginLevel; //0=Sin login,1=Usuario correcto falta contraseña,2=Credenciales ok (usuario y contraseña)
    uint32_t _millisNextCheck; //Tiempo en milisegundos para el siguiente refresco
    uint32_t _timeOutNextCheck; //Tiempo de milisegundos para desconexión automática por inactividad
    String _rBuffer; //Buffer de recepción
    void _clientDisconnect();
    String _readCommandLine(); //Lee línea de comandos recibida
    void _processCommandLine(String commandLine);
    String _currentPath; //Directorio actual. Sin / al final
    bool _openDataConnection();
    String _getInt(String s,byte *value); //Obtiene el valor entero y devuelve el String recortado
    String _renameFrom=""; //Path a renombrar
    String _currentPathAdd(String path); //Añade un nivel a _currentPath
    IPAddress _ip; //Dirección ip del servidor
  public:
    bool begin(String uname, String pword); //Inicialización
    void refresh(); //Refresco de servidor
    IPAddress getIP(); //Devuelve ip del servidor
};

#include <RoJoFtpServer.cpp>

#endif //RoJoFtpServer_h

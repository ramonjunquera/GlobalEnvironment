/*
  Nombre de la librería: RoJoTimerESP8266.h
  Versión: 20221026
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP8266 para la gestión de timers
*/

#ifndef RoJoTimerESP8266_h
#define RoJoTimerESP8266_h

#ifdef ESP8266 //Sólo compatible con ESP8266

#include <Arduino.h>

class RoJoTimerESP8266 {
  private:  //Definición de métodos/variables privadas
    void _start(uint32_t microseconds,void (*callback)(),bool oneTime); //Inicia el timer
  public: //Definición de métodos/variables públicas
    void attach(float seconds, void (*callback)()); //Activa el timer indefinidamente
    void attach_ms(uint32_t milliseconds, void (*callback)()); //Activa el timer indefinidamente
    void once(float seconds, void (*callback)()); //Activa el timer una vez
    void once_ms(uint32_t milliseconds, void (*callback)()); //Activa el timer una vez
    void detach(); //Detiene el timer
    bool active(); //El timer está activo?
}; //Punto y coma obligatorio para que no de error

#include <RoJoTimerESP8266.cpp>

#endif

#endif  
#ifndef RoJoServo_cpp
#define RoJoServo_cpp

#include <RoJoServo.h>

static byte _RoJoServo_servoCount=0; //Número de servos. Inicialmente ninguno
static _RoJoServo_servoConfig *_RoJoServo_servoConfigs; //Array de configuraciones de servos
static byte _RoJoServo_currentServo; //Servo que se está procesando actualmente
static uint16_t _RoJoServo_usCycleMin; //Duración en microsegundos del ciclo mínimo
static uint16_t _RoJoServo_currentUsCycle; //Tiempo consumido de ciclo
static uint64_t _RoJoServo_clock; //Tiempo actual en us

#ifdef ESP8266
  RoJoTimerESP8266 timerAVR1; //Objeto de gestión del timer
#elif defined(ESP32)
  RoJoTimerESP32 timerAVR1; //Objeto de gestión del timer
#endif

//Asigna un ángulo a un servo. Función interna. Sin comprobaciones
//Parámetros:
//  servoIndex : índice del servo
//  angle : ángulo en grados [0,180]
//Devuelve true si lo consigue
void _RoJoServo_setAngle(byte servoIndex,byte angle) {
  _RoJoServo_servoConfig &servo=_RoJoServo_servoConfigs[servoIndex];
  servo.angle=angle;
  servo.usAngle=(float)(servo.us180-servo.us0)/180.0*angle+servo.us0;
}

//Función de interrupción
void _iFunction() {
  //Finalizamos el pulso activo
  if(_RoJoServo_currentServo==_RoJoServo_servoCount) { //Si se acaba de procesar el último pulso bajo...
    _RoJoServo_currentServo=0; //El siguiente servo será el primero
    _RoJoServo_currentUsCycle=0; //Reseteamos el tiempo consumido de ciclo
  } else { //Si se ha procesado un pulso alto...
    _RoJoServo_servoConfig &servo=_RoJoServo_servoConfigs[_RoJoServo_currentServo];
    digitalWrite(servo.pin,LOW); //Terminamos el pulso alto
    if(servo.enabled & servo.isMoving) { //Si está activo y en movimiento...
      if(_RoJoServo_clock>=servo.t1) { //Si hemos terminado...
        _RoJoServo_setAngle(_RoJoServo_currentServo,servo.angle1); //Hemos alcanzado el ángulo destino
        servo.isMoving=false; //Ya no nos moveremos más
      } else { //Aun no hemos terminado...
        byte angle=(servo.t0)?
          servo.angle0+servo.deltaAngle/(1.0+exp(-(_RoJoServo_clock-servo.speed_deltaT2)/100000.0)): //Sigmoid
          servo.angle1-servo.speed_deltaT2*(servo.t1-_RoJoServo_clock); //Lineal
        if(angle!=servo.angle) _RoJoServo_setAngle(_RoJoServo_currentServo,angle); //Actualizamos el ángulo si es necesario
      }
    }
    _RoJoServo_currentServo++; //Pasamos al siguiente servo
  }
  //Hemos finalizado el pulso activo
  //Buscamos el siguiente pulso. Mientras no encontremos un servo activo...pasamos al siguiente
  while((_RoJoServo_currentServo<_RoJoServo_servoCount && !_RoJoServo_servoConfigs[_RoJoServo_currentServo].enabled) || (_RoJoServo_currentServo==_RoJoServo_servoCount && _RoJoServo_currentUsCycle>=_RoJoServo_usCycleMin)) {
    _RoJoServo_currentServo++; //Siguiente servo
    if(_RoJoServo_currentServo>_RoJoServo_servoCount) { //Si tenemos que reiniciar el ciclo...
      _RoJoServo_currentServo=0; //Primer servo
      _RoJoServo_currentUsCycle=0; //Reset duración del ciclo actual
    }
  }
  //Tenemos localizado el siguiente pulso. Puede ser de un servo o el pulso bajo de final de ciclo
  if(_RoJoServo_currentServo==_RoJoServo_servoCount) { //Si tenemos que procesar el último pulso bajo...
    if(_RoJoServo_currentUsCycle<_RoJoServo_usCycleMin) { //Si no hemos alcanzado la duración mínima de ciclo...
      //No hace falta cambiar el estado de ningún pin
      //La duración del último pulso bajo es la diferencia entre la duración del ciclo y lo que llevamos consumido
      _RoJoServo_clock+=_RoJoServo_usCycleMin-_RoJoServo_currentUsCycle; //Actualizamos el reloj global
      timerAVR1.once((float)(_RoJoServo_usCycleMin-_RoJoServo_currentUsCycle)/1000000.0,_iFunction);
    } else { //Hemos superado la duración mínima de un pulso
      timerAVR1.once(0,_iFunction); //Llamamos de nuevo a la función sin demora
    }
  } else { //Tenemos que procesar un pulso alto de un servo activo...
    _RoJoServo_servoConfig &servo=_RoJoServo_servoConfigs[_RoJoServo_currentServo];
    digitalWrite(servo.pin,HIGH); //Activamos el pulso alto
    //Incrementamos el tiempo de ciclo consumido con la duración del pulso alto del ángulo actual
    _RoJoServo_currentUsCycle+=servo.usAngle;
    _RoJoServo_clock+=servo.usAngle; //Actualizamos el reloj global
    timerAVR1.once((float)servo.usAngle/1000000.0,_iFunction);
  }
}

void RoJoServo::end() {
  timerAVR1.detach();
  if(_RoJoServo_servoCount) free(_RoJoServo_servoConfigs); //Si hay servos...liberamos memoria
  _RoJoServo_servoCount=0; //Ya no hay servos
}

//Destructor
RoJoServo::~RoJoServo() {
  end();
}

//Inicialización
//Parámetros:
//  - servoCount : número de servos > 0
//  - us180default : duración en microsegundos por defecto para ángulo de 180 grados
//  - usCycleMin : duración mínima de un ciclo completo en microsegundos
//Devuelve true si lo consigue
bool RoJoServo::begin(byte servoCount,uint16_t us180default,uint16_t usCycleMin) {
  if(!servoCount) return false; //Al menos debemos tener un servo
  end();
  _RoJoServo_servoConfigs=(_RoJoServo_servoConfig*)malloc(servoCount*sizeof(_RoJoServo_servoConfig));
  if(!_RoJoServo_servoConfigs) return false; //Sin memoria
  _RoJoServo_servoCount=servoCount; //Guardamos número de servos
  for(byte i=0;i<servoCount;i++) { //Inicializamos los servos
    _RoJoServo_servoConfig &servo=_RoJoServo_servoConfigs[i];
    servo.enabled=false;
    servo.pin=255;
    servo.us0=450;
    servo.us180=us180default;
    servo.angle=0;
    servo.usAngle=servo.us0;
  }
  _RoJoServo_usCycleMin=usCycleMin; //Guardamos la duración del ciclo mínimo
  _RoJoServo_currentServo=_RoJoServo_servoCount; //Simulamos que regresamos de procesar el último pulso bajo
  _RoJoServo_clock=0; //Reseteamos el reloj global
  _iFunction();
  return true; //Todo OK
}

//Fija configuración para un servo
//  - us0 = duración de pulso alto en microsegundos para 0 grados
//  - us180 = duración de pulso alto en microsegundos para 180 grados
//Devuelve true si lo consigue
bool RoJoServo::setCfg(byte servoIndex,byte pin,uint16_t us0,uint16_t us180) {
  if(servoIndex>=_RoJoServo_servoCount) return false;
  if(us180<=us0) return false;
  _RoJoServo_servoConfig &servo=_RoJoServo_servoConfigs[servoIndex];
  servo.enabled=false;
  servo.pin=pin;
  servo.us0=us0;
  servo.us180=us180;
  servo.angle=0;
  servo.usAngle=us0;
  servo.isMoving=false;
  pinMode(pin,OUTPUT);
  digitalWrite(pin,LOW);
  return true; //Todo OK
}

//Activa/Desactiva un servo
bool RoJoServo::enable(byte servoIndex,bool enabled) {
  if(servoIndex>=_RoJoServo_servoCount) return false; //Servo fuera de rango
  _RoJoServo_servoConfigs[servoIndex].enabled=enabled;
  if(!enabled) _RoJoServo_servoConfigs[servoIndex].isMoving=false; //Si lo desactivamos, se para
  return true; //Todo OK
}

//Devuelve el ángulo de un servo
//Si el índice del servo está fuera de rango, siempre devuelve 0
byte RoJoServo::getAngle(byte servoIndex) {
  if(servoIndex>=_RoJoServo_servoCount) return 0; //Servo fuera de rango
  return _RoJoServo_servoConfigs[servoIndex].angle;
}

//Se está moviendo un servo?
//Si el índice del servo está fuera de rango, siempre devuelve false
bool RoJoServo::isMoving(byte servoIndex) {
  if(servoIndex>=_RoJoServo_servoCount) return false; //Servo fuera de rango
  return _RoJoServo_servoConfigs[servoIndex].isMoving;
}

//Mueve un servo a un ángulo determinado
//Parámetros:
//  servoIndex : índice del servo
//  angle : ángulo en grados [0,180]
//  speedMode : modo de velocidad : 0=instantáneo, 1=constante, 2=variable
//  speed : velocidad angular en grados/segundo. Siempre >0
//  waitUntilEnd : debe esperar a que se alcance el ángulo antes de devolver el control?
//Devuelve true si lo consigue
bool RoJoServo::move(byte servoIndex,byte angle,byte speedMode,float speed,bool waitUntilEnd) {
  if(servoIndex>=_RoJoServo_servoCount) return false; //Servo fuera de rango
  if(angle>180) return false; //Ángulo fuera de rango
  if(speed<=0) return false; //Velocidad fuera de rango
  if(speedMode>2) return false; //Modo de velocidad fuera de rango
  _RoJoServo_servoConfig &servo=_RoJoServo_servoConfigs[servoIndex];
  servo.isMoving=false; //Paramos cualquier movimiento previo
  if(angle==servo.angle) return true; //Si no hay que cambiar el ángulo...hemos terminado
  if(speedMode) { //Si debemos gestionar la velocidad...
    servo.deltaAngle=(float)angle-(float)servo.angle;
    speed/=1000000; //de grados/s a grados/us
    servo.t1=_RoJoServo_clock+abs(servo.deltaAngle)/speed; //Tiempo final
    servo.angle1=angle; //Ángulo destino
    if(speedMode==1) { //Si la velocidad es constante...
      servo.speed_deltaT2=(angle>servo.angle)?speed:-speed; //Velocidad angular con signo
      servo.t0=0; //Indica que tendrá velocidad constante
    } else { //Si la velocidad es variable...
      servo.angle0=servo.angle; //Ángulo inicial
      servo.t0=_RoJoServo_clock; //Tiempo inicial
      servo.speed_deltaT2=((float)_RoJoServo_clock+(float)servo.t1)/2; //Tiempo medio
    }
    servo.isMoving=true;
    //if(waitUntilEnd) while(servo.isMoving) delay(1);
    if(waitUntilEnd) while(servo.isMoving) delayMicroseconds(1000);
  } else _RoJoServo_setAngle(servoIndex,angle); //Velocidad instantánea
  return true; //Todo OK
}

#endif
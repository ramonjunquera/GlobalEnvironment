/*
  Nombre de la librería: RoJoSSD1306tiny
  Autor: Ramón Junquera
  Fecha: 20220503
  Descripción:
    Gestión de display OLED SSD1306 I2C 0.96" 128x64/0.96" 128x32 
    
*/

#ifndef RoJoSSD1306tiny_h
#define RoJoSSD1306tiny_h

#include <Arduino.h>
#include <TinyWireM.h> //Gestión de comunicaciones I2C para ATtiny85

class RoJoSSD1306tiny {
  private:
    const byte _oledId=0x3C; //Identificador del display en en bus I2C
    byte _pages=8; //Número de páginas. 8 para 128x64 y 4 para 128x32
    void _setCursorRange(byte x1=0,byte page1=0,byte x2=127,byte page2=7);
  public:
    bool begin(bool halfRows=false); //Inicialización
    void clear(byte value=0); //Escribe el valor en todo el display
    void lineV(byte x); //Dibuja una línea vertical
}; //Punto y coma obligatorio para que no de error

#endif

/*
  Nombre de la librería: RoJoVL53L1X.h
  Versión: 20220222
  Autor: Ramón Junquera
  Descripción:
    Tomando como base la librería oficial desarrollada por Pololu en https://github.com/pololu/vl53l1x-arduino
    se deriva la clase añadiendo nuevas funcionalidades que simplifican su uso.
    Se usa la librería VL53L1X.h versión 1.3.0
    La librería original ha sido modificada para que guarde compatibilidad con Raspberry Pi
  Nuevas funcionalidades:
    - Ya no es necesario llamar a la librería Wire en el programa principal, ni inicializarla.
    - El método init no debería utilizarse. En su lugar usaremos el método begin, que nos permite definir los
      pines I2C que vamos utilizar (si el dispositivo lo soporta).
    - Se añade el método hardReset para reiniciar el sensor a los valores por defecto mediante el pin XSHUT.
      También resetea el identificador I2C.
    - Se añade el método enabled para activar/desactivar el sensor por el pin de reset.
    - Se añade el método multiBegin para inicialización de varios sensores
*/

#ifndef RoJoVL53L1X_h
#define RoJoVL53L1X_h

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#include <VL53L1X.h> //Librería original de gestión de sensor LIDAR

//Clase derivada de VL53L1X
class RoJoVL53L1X:public VL53L1X {
  public:
    bool begin(byte pinSDA=255,byte pinSCL=255); //Inicialización
    void hardReset(byte pinRES); //Reset a configuración de fábrica
    void enabled(byte pinRES,bool status); //Activa/Desactiva el sensor por el pin de reset
    static byte multiBegin(byte countSensors,const byte* idI2C,const byte* pinRES,RoJoVL53L1X* sensors,byte pinSDA=255,byte pinSCL=255); //Inicialización múltiple
};

#include <RoJoVL53L1X.cpp>

#endif


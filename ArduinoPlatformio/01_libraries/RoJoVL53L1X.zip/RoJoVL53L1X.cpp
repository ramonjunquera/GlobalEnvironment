/*
  Nombre de la librería: RoJoVL53L1X.h
  Versión: 20220222
  Autor: Ramón Junquera
*/

#ifndef RoJoVL53L1X_cpp
#define RoJoVL53L1X_cpp

#include <RoJoVL53L1X.h>

//Inicialización
//Parámetros:
//  pinSDA y pinSCL: Conexión I2C. Opcional.
//Respuesta: true si la inicialización es Ok
bool RoJoVL53L1X::begin(byte pinSDA,byte pinSCL) {
  //Nota:
  //Suponemos que el sensor tiene el identificador I2C por defecto (0x29)
  //Si queremos cambiarlo, tendrá que ser siempre después de la inicialización

  //Inicializamos el protocolo I2C
  #if defined(ARDUINO_ARCH_AVR) || defined(__arm__) //Si es una placa Arduino o una RPi ...
    //En las placas Arduino o RPi, no se pueden seleccionar los pines I2C
    //Los posibles pines I2C no se tendrán en cuenta
    Wire.begin();
  #else //No es una placa Arduino ni RPi. Es una ESP.
    //Si se ha indicado pin de I2C (SDA & SCL)...activamos el I2C personalizado
    if(pinSCL<255) Wire.begin(pinSDA,pinSCL);
    //...y si no...usamos una I2C con los pines por defecto
    else Wire.begin();
  #endif

  Wire.setClock(400000); //Según el manual, el sensor soporta 400KHz

  //Fijamos tiempo de espera máximo para recibir el eco de la señal a 500ms.
  //La teoría dice que con 127ms tendríamos suficiente incluso para recibir el eco de una distancia de 4m.
  setTimeout(500);

  if (!init()) return false; //Si no podemos inicializar el sensor...error

  //Seleccionamos el modo de medida de distancia
  //Podemos elegir entre Short, Medium y Long
  //Se debería seleccionar el modo más pequeño que admita las medidas que vamos a realizar, porque
  //tendremos más exactitud le afectará menos la iluminación ambiental
  setDistanceMode(VL53L1X::Long);
  //Limitamos el tiempo que tarda en hacerse una medida
  //El valor está en us. 50000us = 50ms
  setMeasurementTimingBudget(50000);
  //Activamos el modo de lecturas contínuas
  //Indicamos que se hará una lectura cada 50ms.
  //Este valor debe ser como mínimo el tiempo que hemos definido anteriormente con setMeasurementTimingBudget
  startContinuous(50);
  return true; //Todo Ok
}

//Resetea el sensor a la configuración de fábrica (incluido el identificador I2C)
void RoJoVL53L1X::hardReset(byte pinRES) {
  //Nota:
  //Puesto que el reseteo es externo a través del pin XSHUT, no importa qué identificador
  //I2C tenga asignado.
  enabled(pinRES,false); //Apagamos
  enabled(pinRES,true); //Encendemos
}

//Activa/Desactiva el sensor por el pin de reset
void RoJoVL53L1X::enabled(byte pinRES,bool status) {
  if(status) digitalWrite(pinRES,HIGH); //Señal normal (igual que desconectado)
  else { //Desactivar
    pinMode(pinRES,OUTPUT); //Configuramos pin de reset
    digitalWrite(pinRES,LOW); //Señal de reset
    setAddress(0x29); //Hemos reseteado el sensor al identificador I2C por defecto (0x29=41)
    delay(150); //Damos un momento a que termine de arrancar
  }
}

//Inicialización de múltiples sensores
//Parámetros:
//  countSensors: número de sensores
//  idI2C: puntero a array de bytes con los identificadores I2C
//  pinRED: puntero a array de bytes con los pines de reset (XSHUT) de los sensores
//  pinSDA y pinSCL: Conexión I2C. Opcional.
//Devuelve código de error:
//  0: Sin errores
//  1: Al menos se debe inicializar un sensor
//  2: El identificador I2C por defecto (0x29) sólo puede ir en última posición
//  3: No se pueden repetir identificadores I2C
//  4: Error en la inicialización de un sensor
byte RoJoVL53L1X::multiBegin(byte countSensors,const byte* idI2C,const byte* pinRES,RoJoVL53L1X* sensors,byte pinSDA,byte pinSCL) {
  if(!countSensors) return 1; //Por lo menos debe haber uno!
  //Recorremos los sensores desde el primero al penúltimo...
  for(byte i=0;i<countSensors-1;i++) {
    //Si el identificador tiene el valor por defecto...terminamos con error
    if(idI2C[i]==0x29) return 2;
    //Recorremos los sensores desde el siguiente hasta el último...
    //...si hay alguno repetido, terminamos con error
    for(byte j=i+1;j<countSensors;j++) if(idI2C[i]==idI2C[j]) return 3;
  }
  //Todo correcto!

  //Desactivamos todos los sensores
  for(byte i=0;i<countSensors;i++) sensors[i].enabled(pinRES[i],false);
  for(byte i=0;i<countSensors;i++) { //Recorremos todos los sensores
    sensors[i].enabled(pinRES[i],true); //Activamos el sensor
    //Si no podemos inicializar el sensor...finalizamos con error
    if (!sensors[i].begin(pinSDA,pinSCL)) return 4;
    sensors[i].setAddress(idI2C[i]); //Asignamos el nuevo identificador
  }
  return 0; //Todo Ok
}

#endif


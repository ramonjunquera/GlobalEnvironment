/*
  Nombre de la librería: _RoJoLCD1602A.h
  Versión: 20220119
  Autor: Ramón Junquera
  Descripción:
    Gestión base de display LCD de 16x2
*/

#ifndef _RoJoLCD1602A_cpp
#define _RoJoLCD1602A_cpp

#include <_RoJoLCD1602A.h>

//Envía un byte al display seleccionando el modo (comando=LOW o carácter=HIGH)
void _RoJoLCD1602A::_send(byte value,bool mode) {
  //dummy
}

//Luz de fondo. LOW=off, HIGH=on
void _RoJoLCD1602A::backlight(bool status) {
  //dummy
  //_backlight=status;
}

//Borra el display y pone el cursor en home
void _RoJoLCD1602A::clear() {
  _send(0x01,LOW); //Comando de borrado de pantalla
  delayMicroseconds(1540); //Según el manual tarda 1.53ms
}

//Pone el cursor en la posición 0,0
void _RoJoLCD1602A::home() {
  _send(0x02,LOW); //Comando de cursor a home
  delayMicroseconds(1540); //Según el manual tarda 1.53ms
}

//Posiciona el cursor en unas coordenadas
void _RoJoLCD1602A::pos(byte col,byte row) {
  //Nos aseguramos que las coordenadas no salgan de los rangos permitidos
  //Recordemos que una fila tiene 64 caracteres, aunque sólo visualicemos 16
  // 0b1F00CCCC donde C=columna [0,63] y F=Fila [0,1]
  _send(0x80+(col & 0x0F)+64*(row & 0x01),LOW);
  delayMicroseconds(40); //Segun el manual debemos esperar 39us. Esperamos 40us
}

//Activa/desactiva el display
void _RoJoLCD1602A::enable(bool status) {
  //Mantiene en memoria su contenido. Sólo deja de mostrarlo
  
  if(status) _displaycontrol |= 0x04; //Si se debe activar...
  else _displaycontrol &= ~0x04; //Si se debe desactivar...
  _send(_displaycontrol,LOW); //Enviamos el comando
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
}

//Activa/desactiva el parpadeo del cursor
void _RoJoLCD1602A::blink(bool status) {
  if(status) _displaycontrol |= 0x01; //Si se debe activar...
  else _displaycontrol &= ~0x01; //Si se debe desactivar...
  _send(_displaycontrol,LOW); //Enviamos el comando
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
}

//Muestra/oculta el cursor
void _RoJoLCD1602A::cursor(bool status) {
  if(status) _displaycontrol |= 0x02; //Si se debe mostrar...
  else _displaycontrol &= ~0x02; //Si se debe ocultar...
  _send(_displaycontrol,LOW); //Enviamos el comando
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
}

//Define una carácter personalizado
void _RoJoLCD1602A::createChar(byte charNum, byte charMap[]) {
  //Sólo se pueden modificar los 8 primeros caracteres

  //Enviamos comando para definir caracter
  _send(0x40 | ((charNum & 0x07) << 3),LOW);
  delayMicroseconds(40);
  //Enviamos los 8 bytes (filas) que definen el gráfico
  //Puesto que la matriz tiene 5 columnas, sólo se tendrán en cuenta los 5 bits de
  //menor peso
  for (byte i=0;i<8;i++) {
    _send(charMap[i],HIGH); //Enviamos el byte de gráficos
    delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  }
}

//Muestra el texto indicado en la posición del cursor
void _RoJoLCD1602A::print(String txt) {
  for(byte i=0;i<txt.length();i++) { //Recorremos todos los caracteres de la cadena
    _send(txt[i],true); //Enviamos el carácter al display
    delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  }
}

//Muestra un carácter en la posición del cursor
void _RoJoLCD1602A::printChar(char ch) {
  _send(ch,HIGH);
  delayMicroseconds(44); //Según el manual debemos esperar 43us. Esperamos 44us
}

#endif

/*
  Nombre de la librería: RoJoSSD1681.h
  Versión: 20211210
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RoJoSSD1681 SPI 200x200 e-paper black/white/red
    Basado en la librería GxEPD2
    También se reconoce como: GDEH0154Z90 o GxEPD2_154_Z90c
*/

#ifndef RoJoSSD1681_cpp
#define RoJoSSD1681_cpp

#include <RoJoSSD1681.h>

//Anchura de display
uint16_t RoJoSSD1681::xMax() {
  return _xMax;
}

//Altura de display
uint16_t RoJoSSD1681::yMax() {
  return _yMax;
}

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoSSD1681::_writeCommand(byte command,...) {
  //Este display recibe los comandos en modo comandos y los parámetros en modo
  //datos. El fortmato de todos ellos es byte.

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  Serial.print("\nCommand ");
  _sendSPI(command); //Enviamos el comando
  Serial.print(" : ");
  digitalWrite(_pinDC,HIGH); //Modo datos
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0) {
    _sendSPI(paramValue); //...enviamos el parámetro
    Serial.print(",");
  }
  va_end(paramList); //Hemos terminado de trabajar con la lista
}

//Esperamos hasta que el display admita nuevos comandos
void RoJoSSD1681::_waitPinBusy() {
  Serial.print("\n_waitPinBusy");
  do {
    delay(1);
  }
  while(digitalRead(_pinBusy));
}

//Define rango X & Y
//Si no se entregan parámetros se toma todo el área del display
//Función interna. No se comprueba la coherencia de parámetros
void RoJoSSD1681::_setCursorRange(byte x1,byte x2,byte y1,byte y2) {
  //Definimos ventana de dibujo
    //0x44: Set RAM X - address. Start / End position
    //x0/8: XStart
    //x1/8: XEnd
    _writeCommand(0x44,x1>>3,x2>>3,-1);
    //0x45: Set RAM Y - address. Start / End position
    //y0,0: YStart LoByte/HiByte
    //y1,0: YEnd LoByte/HiByte
    _writeCommand(0x45,y1,0,y2,0,-1);
  //Colocamos el cursor en el primer pixel de la ventana de dibujo
    //0x4E: Set RAM X address counter
    //x0/8: Columna inicial
    _writeCommand(0x4E,x1>>3,-1);
    //0x4F: Set RAM Y address counter
    //y0,0: Fila inicial LoByte/HiByte
    _writeCommand(0x4F,y1,0,-1);
}

//Refresca el contenido del display y muestra la imagen enviada
void RoJoSSD1681::show() {
  SPI.beginTransaction(_spiSetting);
    //0x22: Display Update Control 2
    //0xF7: Enable clock signal: Enable Analog, Load temperature value, DISPLAY with DISPLAY Mode 1, Disable Analog, Disable OSC
    _writeCommand(0x22,0xF7,-1);
    //0x20: Master Activation
    _writeCommand(0x20,-1);
    _waitPinBusy(); //Esperamos hasta que el display admita nuevos comandos
  SPI.endTransaction();
}

//Borra el área de dibujo
//  color: 0=blanco, 1=negro, 2=rojo
void RoJoSSD1681::clear(byte color) {
  //Códigos de colores
  //WHITE -> w=0xFF,r=0x00
  //BLACK -> w=0X00,r=0X00
  //RED   -> w=0x00,r=0xFF
  byte w=0,r=0; //Valores iniciales para la capa blanca y roja. Color negro
  if(color==0) w=0xFF; //Si es blanco
  else if(color==2) r=0xFF; //Si es rojo
  SPI.beginTransaction(_spiSetting);
    _setCursorRange(); //Seleccionamos todo el display
    _writeCommand(0x24,-1); //Write RAM (Black White)
    for(uint16_t i=5000;i>0;i--) _sendSPI(w);
    _writeCommand(0x26,-1); //Write RAM (Red)
    for(uint16_t i=5000;i>0;i--) _sendSPI(r);
  SPI.endTransaction();
} 

//Reset. Salir de hibernación
void RoJoSSD1681::reset() {
  //Hard reset
  digitalWrite(_pinRES,LOW);
  delay(20);
  digitalWrite(_pinRES,HIGH);
  _waitPinBusy(); //Esperamos hasta que el display admita nuevos comandos

  SPI.beginTransaction(_spiSetting);
    _writeCommand(0x12,-1); //SW RESET
  SPI.endTransaction();
  _waitPinBusy(); //Esperamos hasta que el display admita nuevos comandos

  SPI.beginTransaction(_spiSetting);
    //0x01: Driver Output Control
    //199,0: Last row LoByte/Hibyte
    //0: Orden de arriba a abajo
    _writeCommand(0x01,199,0,0,-1);
    //0x11: Data Entry mode settings
    //3: Cada nuevo dato incrementa x. Al finalizar la fila pasamos a la siguiente
    _writeCommand(0x11,3,-1);
    //0x3C: Border Wavefront Control
    //5: Fix Level Setting for VBD = VSS. GS Transition control = Follow LUT (Output VCOM @ RED). GS Transition setting for VBD = LUT1
    _writeCommand(0x3C,0x05,-1);
    //Read built-in temperature sensor. Internal temperature sensor. Prescindible
    //_writeCommand(0x18,0x80,-1);
    //0x22: Display Update Control 2
    //0xC0: Enable clock signal. Enable analog
    _writeCommand(0x22,0xC0,-1);
    //0x20: Master Activation
    _writeCommand(0x20,-1);
    _waitPinBusy(); //Esperamos hasta que el display admita nuevos comandos
  SPI.endTransaction();

  clear(); //Borramos el display
  show(); //Mostramos el display vacío

  //A continuación se debería:
  //- Definir la ventana de dibujo
  //- Enviar las imágenes de cada capa
  //- Refrescar diplay
  //- ...
  //- Hibernar
}

//Inicialización
void RoJoSSD1681::begin(byte pinRES,byte pinDC,byte pinCS,byte pinBusy,uint32_t freqCOMM) {
  //Si no se ha indicado frecuencia...la decidiremos nosotros
  if(!freqCOMM) {
    #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
      freqCOMM=10000000; //10 MHz para no interferir con la SD
    #else //Si utilizamos SPIFFS...
      freqCOMM=79999999; //<80 MHz
    #endif
  }

  //Definimos las caraterísticas de la conexión SPI
  _spiSetting=SPISettings(freqCOMM,MSBFIRST,SPI_MODE0);
  //Inicializamos las conexiones SPI
  SPI.begin();
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif

  //Guardamos los parámetros en variables internas
  _pinDC=pinDC;
  _pinRES=pinRES;
  _pinCS=pinCS;
  _pinBusy=pinBusy;
  //Configuramos modo de los pines
  pinMode(_pinDC,OUTPUT);
  pinMode(_pinRES,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  pinMode(_pinBusy,INPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinRES,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip
  //Reseteamos el display
  reset();
}

//Envía un byte por SPI
void RoJoSSD1681::_sendSPI(byte a) {
  //Nota.
  //Para enviar un byte por SPI es suficiente con SPI.transfer(a);
  //Si lo hacemos así con este display obtendremos muchos errores de conexión
  //Para mantener el sincronismo, nos obliga a operar con el pin CS: ponerlo
  //en LOW, enviar y volver a ponerlo en HIGH
  digitalWrite(_pinCS,LOW);
  Serial.print(a,HEX);
  SPI.transfer(a);
  digitalWrite(_pinCS,HIGH);
}

//Envía datos gráficos de un área de un sprite monocromo
void RoJoSSD1681::_sendPartialSprite(RoJoSprite2 *sprite,byte x1,byte x2,byte y1,byte y2) {
  //Función interna. Sin validaciones. El sprite debe ser monocromo. x1 y x2 son múltiplos de 8
  byte bc; //byte de columna
  byte x8; //x*8
  x1>>=3; x2>>=3; //Convertimos coordenadas horizontales a bytes de columna
  for(byte y=y1;y<=y2;y++) { //Recorremos filas visibles de sprite
    for(byte x=x1;x<=x2;x++) { //Recorremos bytes de columnas visibles de sprite
      bc=0; //reset de byte de columna
      x8=x*8; //Para no tener que calcularlo en cada iteracción del siguiente bucle
      //Recorremos bits de byte de columna y añadimos el bit procesado al byte de columna
      for(byte b=0;b<8;b++) bc=(bc<<1)+sprite->getPixel(x8+b,y);
      _sendSPI(bc); //Enviamos el byte de columna
    }
  }
}

/*
//Envía datos gráficos de un área de un sprite monocromo
void RoJoSSD1681::_sendPartialSprite(RoJoSprite2 *sprite,byte x1,byte x2,byte y1,byte y2) {
  //Función interna. Sin validaciones. El sprite debe ser monocromo. x1 y x2 son múltiplos de 8
  byte bc; //byte de columna
  byte x8; //x*8
  x1>>=3; x2>>=3; //Convertimos coordenadas horizontales a bytes de columna
  for(byte y=y1;y<=y2;y++) { //Recorremos filas visibles de sprite
    for(byte x=x1;x<=x2;x++) { //Recorremos bytes de columnas visibles de sprite
      bc=0; //reset de byte de columna
      x8=x*8; //Para no tener que calcularlo en cada iteracción del siguiente bucle
      //Recorremos bits de byte de columna y añadimos el bit procesado al byte de columna
      for(byte b=0;b<8;b++) bc=(bc<<1)+sprite->getPixel(x8+b,y);
      _sendSPI(bc); //Enviamos el byte de columna
    }
  }
}
*/

//Dibuja a partir de 2 sprites, uno por capa
//Parámetros:
//  spriteW : sprite monocromo para la capa blanca (anchura múltiplo de 8)
//  spriteR : sprite monocromo para la capa roja
//  x : coordenada horizontal (debe ser múltiplo de 8)
//  y : coordenada vertical
//Devuelve código de error:
//  0 : Ok
//  1 : Error. x no es múltiplo de 8
//  2 : Error. La anchura no es múltiplo de 8
//  3 : Error. Los sprites no son monocromos
//  4 : Error. Los sprites no tienen el mismo tamaño
byte RoJoSSD1681::drawSprite(RoJoSprite2 *spriteW,RoJoSprite2 *spriteR,int16_t x,int16_t y) {
  if(x%8) return 1; //Si x no es múltiplo de 8...error
  if(spriteW->xMax()%8) return 2; //Si la anchura no es múltiplo de 8...error
  //Si los sprites no son monocromos...error
  if(spriteW->bytesPerPixel()>0 || spriteR->bytesPerPixel()>0) return 3;
  //Si los sprites tienen distinto tamaño...error
  if(spriteW->xMax()!=spriteR->xMax() || spriteW->yMax()!=spriteR->yMax()) return 4;
  //Calculamos el área visible
  //Puesto que la clase actual no hereda de RoJoGraph2, utilizamos el método estático
  displayRange r=RoJoGraph2::visibleRange(x,y,spriteW->xMax(),spriteW->yMax(),_xMax,_yMax);
  //Si no hay área visible...no hay nada que dibujar. Terminamos sin error
  if(!r.visible) return 0;
  SPI.beginTransaction(_spiSetting);
    _setCursorRange(r.x1,r.x2,r.y1,r.y2); //Seleccionamos el rango visible del display
    byte sx1=r.x1-x,sy1=r.y1-y,sx2=r.x2-x,sy2=r.y2-y; //Calculamos rango visible de sprite
    _writeCommand(0x24,-1); //Write RAM (Black White)
    _sendPartialSprite(spriteW,sx1,sx2,sy1,sy2); //Enviamos a capa blanca datos gráficos de área visible
    _writeCommand(0x26,-1); //Write RAM (Red)
    _sendPartialSprite(spriteR,sx1,sx2,sy1,sy2); //Enviamos a capa roja datos gráficos de área visible
  SPI.endTransaction();
  return 0; //Todo Ok
}

//Dibuja un sprite monocromo en una capa
//Parámetros:
//  sprite : sprite monocromo (anchura múltiplo de 8)
//  x : coordenada horizontal (debe ser múltiplo de 8)
//  y : coordenada vertical
//  layer : código de capa false=0=capa blanca,true=1=capa roja
//Devuelve código de error:
//  0 : Ok
//  1 : Error. x no es múltiplo de 8
//  2 : Error. La anchura no es múltiplo de 8
//  3 : Error. El sprite no es monocromo
byte RoJoSSD1681::drawSprite(RoJoSprite2 *sprite,int16_t x,int16_t y,bool layer) {
  if(x%8) return 1; //Si x no es múltiplo de 8...error
  if(sprite->xMax()%8) return 2; //Si la anchura no es múltiplo de 8...error
  //Si el sprite no es monocromo...error
  if(sprite->bytesPerPixel()) return 3;
  //Calculamos el área visible
  //Puesto que la clase actual no hereda de RoJoGraph2, utilizamos el método estático
  displayRange r=RoJoGraph2::visibleRange(x,y,sprite->xMax(),sprite->yMax(),_xMax,_yMax);
  //Si no hay área visible...no hay nada que dibujar. Terminamos sin error
  if(!r.visible) return 0;
  SPI.beginTransaction(_spiSetting);
    _setCursorRange(r.x1,r.x2,r.y1,r.y2); //Seleccionamos el rango visible del display
    byte sx1=r.x1-x,sy1=r.y1-y,sx2=r.x2-x,sy2=r.y2-y; //Calculamos rango visible del sprite
    //Enviamos el comando de la capa a actualizar: 0x26=red,0x24=white
    _writeCommand(layer?0x26:0x24,-1); //Write RAM
    _sendPartialSprite(sprite,sx1,sx2,sy1,sy2); //Enviamos datos gráficos de área visible
  SPI.endTransaction();
  return 0; //Todo Ok
}

//Envía datos gráficos de un área de un sprite de tonos de gris
void RoJoSSD1681::_sendPartialSpriteG(RoJoSprite2 *sprite,byte x1,byte x2,byte y1,byte y2,byte cMin,byte cMax) {
  //Función interna. Sin validaciones. El sprite debe ser monocromo. x1 y x2 son múltiplos de 8
  byte bc; //byte de columna
  byte x8; //x*8
  x1>>=3; x2>>=3; //Convertimos coordenadas horizontales a bytes de columna
  for(byte y=y1;y<=y2;y++) { //Recorremos filas visibles de sprite
    for(byte x=x1;x<=x2;x++) { //Recorremos bytes de columnas visibles de sprite
      bc=0; //reset de byte de columna
      x8=x*8; //Para no tener que calcularlo en cada iteracción del siguiente bucle
      //Recorremos bits de byte de columna y añadimos el bit procesado al byte de columna
      for(byte b=0;b<8;b++) {
        uint32_t color=sprite->getPixel(x8+b,y);
        bc=(bc<<1)+(color>=cMin && color<=cMax);
      }
      _sendSPI(bc); //Enviamos el byte de columna
    }
  }
}

//Dibuja a partir de un sprite de tonos de grises
//Parámetros:
//  sprite : sprite de escala de grises (anchura múltiplo de 8)
//  x : coordenada horizontal (debe ser múltiplo de 8)
//  y : coordenada vertical
//Devuelve código de error:
//  0 : Ok
//  1 : Error. x no es múltiplo de 8
//  2 : Error. La anchura no es múltiplo de 8
//  3 : Error. El sprite no es de escala de grises
byte RoJoSSD1681::drawSpriteG(RoJoSprite2 *sprite,int16_t x,int16_t y) {
  //Nota. Descomposición de colores:
  // 0x00 -> negro
  // 0xFF -> blanco
  // cualquier otro tono se considerará rojo
  if(x%8) return 1; //Si x no es múltiplo de 8...error
  if(sprite->xMax()%8) return 2; //Si la anchura no es múltiplo de 8...error
  if(sprite->bytesPerPixel()!=1) return 3; //Si no es escala de grises...error
  //Calculamos el área visible
  //Puesto que la clase actual no hereda de RoJoGraph2, utilizamos el método estático
  displayRange r=RoJoGraph2::visibleRange(x,y,sprite->xMax(),sprite->yMax(),_xMax,_yMax);
  //Si no hay área visible...no hay nada que dibujar. Terminamos sin error
  if(!r.visible) return 0;
  SPI.beginTransaction(_spiSetting);
    _setCursorRange(r.x1,r.x2,r.y1,r.y2); //Seleccionamos el rango visible del display
    byte sx1=r.x1-x,sy1=r.y1-y,sx2=r.x2-x,sy2=r.y2-y; //Calculamos rango visible de sprite
    _writeCommand(0x24,-1); //Write RAM (Black White)
    _sendPartialSpriteG(sprite,sx1,sx2,sy1,sy2,255,255); //Capa blanca
    _writeCommand(0x26,-1); //Write RAM (Red)
    _sendPartialSpriteG(sprite,sx1,sx2,sy1,sy2,1,254); //Capa roja
  SPI.endTransaction();
  return 0; //Todo Ok
}

//Envía datos gráficos de un área de un archivo bmp
void RoJoSSD1681::_sendPartialBMP(File *f,uint32_t offsetBase,uint32_t bytesPerRow,uint16_t height,uint16_t x1,uint16_t x2,uint16_t y1,uint16_t y2,byte cMin,byte cMax) {
  //Función interna. Sin validaciones. El archivo debe estar abierto y comprobado. x1 y x2 son múltiplos de 8
  //En caso de utilizar una SD, tanto el display como el acceso a archivos se realiza por SPI.
  //No podemos mantener las dos conexiones abiertas al mismo tiempo.
  //Para evitarlo, abriremos la conexión con el display sólo cuando queramos enviar y la cerraremos a continuación.
  //Es un proceso más lento, pero compatible con todos los sistemas de archivos.
  byte bc; //byte de columna
  uint16_t c; //Color promedio
  uint16_t x18=x1>>3,x28=x2>>3; //Calculamos bytes de columnas = x1/8 & x2/8
  byte colorChannels[3]; //Componentes de color de un pixel
  for(uint16_t y=y1;y<=y2;y++) { //Recorremos las filas visibles del archivo
    f->seek(offsetBase-bytesPerRow*y+3*x1); //Calculamos y posicionamos el offset en el archivo
    for(byte x=x18;x<=x28;x++) { //Recorremos bytes de columnas visibles de archivo
      bc=0; //reset de byte de columna
      for(byte b=0;b<8;b++) { //Recorremos bits de byte de columna
        f->read(colorChannels,3); //Leemos los componentes de color
        c=0; //reset color promedio
        for(byte i=0;i<3;i++) c+=colorChannels[i]; //Calulamos la suma de canales
        c/=3; //Y dividimos por número de canales. Ya tenemos el tono promedio
        bc=(bc<<1)+(c>=cMin && c<=cMax); //Añadimos bit con las condiciones de tono
      }
      SPI.beginTransaction(_spiSetting);
        _sendSPI(bc); //Enviamos el byte de columna calculado
      SPI.endTransaction();
    }
  }
}

//Dibuja un archivo .bmp en unas coordenadas
//El bmp debe tener 24 bits de profundidad de color
//Respuesta: código de error
byte RoJoSSD1681::drawBMP(String filename,int16_t x,int16_t y) {
  //Requerimientos:
  //- La coordenada x debe ser múltiplo de 8
  //- El bmp debe tener 24 bits de profundidad de color
  //- No puede estar comprimido
  //- Su anchura debe ser múltiplo de 8

  //Descomposición de colores:
  // negro (0x00,0x00,0x00) -> negro
  // blanco (0xFF,0xFF,0xFF) -> blanco
  // cualquier otro color se considerará rojo

  //Tabla de errores (los 8 primeros son los de infoBMP):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe.
  //  2 : La firma del tipo de archivo no coincide
  //  3 : Anchura demasiado grande
  //  4 : Altura demasiado grande
  //  5 : El número de planos no es 1
  //  6 : La profundidad de color no está reconocida
  //  7 : Está comprimido
  //  8 : La coordenada x no es multiplo de 8
  //  9 : La anchura no es múltipo de 8
  // 10 : No tiene un profundidad de color de 24 bits

  //Formato BMP
  //CABECERA
  //offset # descripción
  //------ - -----------
  //   0   2 "BM" constante
  //   2   4 tamaño de archivo
  //   6   4 reservado
  //  10   4 offset de inicio de datos gráficos
  //  14   4 tamaño de cabecera
  //  18   4 anchura en pixels
  //  22   4 altura en pixels
  //  26   2 número de planos (habitualmente 1)
  //  28   2 bits por pixel (habitualmente 24 para imágenes a color)
  //  30   4 compresión (habitualmente 0=ninguna)
  //  34   4 tamaño de imágen
  //  38   4 resolución horizontal
  //  42   4 resolución vertical
  //  46   4 tamaño de la tabla de color
  //  50   4 contador de colores importantes

  //DATOS GRÁFICOS
  //Se guardan por filas
  //Las filas están invertidas. La primera que encontramos corresponde a la última de la imágen
  //El número de bytes de una fila debe ser múltiplo de 4. Si no lo es, se completarán con bytes vacíos
  //Por cada fila, las columnas van en orden: de izquierda a derecha
  //El primer dato gráfico contendrá información sobre el pixel de abajo a la izquierda
  //En monocromo los valores están invertidos

  RoJoGraph2::begin(); //Inicializamos SPIFFS si fuese necesario

  if(x%8) return 8; //La coordenada x no es multiplo de 8

  //Declaración de variables
  byte errorCode=0; //Código de error a devolver
  uint16_t width,height; //Anchura y altura
  byte bytesPerPixel;
  
  //Leemos los valores del archivo bmp
  errorCode=RoJoGraph2::infoBMP(filename,&width,&height,&bytesPerPixel);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  if(width%8) return 9; //La anchura no es múltiplo de 8
  if(bytesPerPixel!=3) return 10; //No tiene una profundidad de 24 bits (no es color)

  //Calculamos el área visible
  displayRange r=RoJoGraph2::visibleRange(x,y,width,height,_xMax,_yMax);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;
  //Hay área visible

  //Calculamos el número de bytes que contiene una línea
  uint32_t bytesPerRow;
  if(bytesPerPixel) bytesPerRow=width*3; //color
  else { //monocromo
    bytesPerRow=width/8;
    if(width%8) bytesPerRow++;
  }
  //El número de bytes de una línea debe ser múltiplo de 4
  if(bytesPerRow%4) bytesPerRow+=4-(bytesPerRow%4);

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
  #endif
  //Suponemos que no hay errores de apertura en el archivo, porque lo hemos
  //probado hace un momento con infoBMP

  //Leemos el offset de inicio de datos gráficos
  uint32_t offsetBase=0; //Offset de datos gráficos. Base (primer pixel)
  f.seek(10);
  f.read((byte *)&offsetBase,4);
  //El offset con el que trabajaremos será el del primer pixel de la primera línea
  offsetBase+=(uint32_t)bytesPerRow*((uint32_t)height-1);

  #ifdef ESP8266
    ESP.wdtDisable(); //Desactivamos WatchDog mientras dibujamos
  #endif

  SPI.beginTransaction(_spiSetting);
    _setCursorRange(r.x1,r.x2,r.y1,r.y2); //Seleccionamos el rango visible del display
    uint16_t sx1=r.x1-x,sy1=r.y1-y,sx2=r.x2-x,sy2=r.y2-y; //Calculamos rango visible de sprite
    _writeCommand(0x24,-1); //Write RAM (Black White)
  SPI.endTransaction();
  _sendPartialBMP(&f,offsetBase,bytesPerRow,height,sx1,sx2,sy1,sy2-y,255,255); //Capa blanca

  SPI.beginTransaction(_spiSetting);
    _writeCommand(0x26,-1); //Write RAM (Red)
  SPI.endTransaction();
  _sendPartialBMP(&f,offsetBase,bytesPerRow,height,sx1,sx2,sy1,sy2-y,1,254); //Capa roja

  #ifdef ESP8266
    ESP.wdtEnable(1000); //Reactivamos las interrupciones de WatchDog
  #endif

  f.close(); //hemos terminado de utilizar el archivo
  return 0; //Todo Ok
}

void RoJoSSD1681::sleep() {
  SPI.beginTransaction(_spiSetting);
    _writeCommand(0x10,0x01,-1); //Enter Deep Sleep Mode 1
  SPI.endTransaction();
}

#endif
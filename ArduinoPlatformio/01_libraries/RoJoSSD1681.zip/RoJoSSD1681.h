/*
  Nombre de la librería: RoJoSSD1681.h
  Versión: 20220201
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RoJoSSD1681 SPI 200x200 e-paper black/white/red
    Basado en la librería GxEPD2
    También se reconoce como: GDEH0154Z90 o GxEPD2_154_Z90c
*/

#ifndef RoJoSSD1681_h
#define RoJoSSD1681_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoGraph.h> //Gestión de gráficos avanzados
#include <RoJoMultiFS.h>

class RoJoSSD1681 {
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    byte _pinBusy; //Pin Busy de display
    static const byte _xMax=200; //Anchura en pixels
    static const byte _yMax=200; //Altura en pixels
    SPISettings _spiSetting; //Características de la conexión SPI
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _waitPinBusy(); //Esperamos hasta que el display admita nuevos comandos
    void _setCursorRange(byte x1=0,byte x2=_xMax-1,byte y1=0,byte y2=_yMax-1); //Define  rango X & Y
    void _sendPartialSprite(RoJoSprite *sprite,byte x1,byte x2,byte y1,byte y2); //Envio parcial de sprite
    void _sendPartialSpriteG(RoJoSprite *sprite,byte x1,byte x2,byte y1,byte y2,byte cMin,byte cMax); //Envio parcial de sprite gris
    void _sendPartialBMP(File *f,uint32_t offsetBase,uint32_t bytesPerRow,uint16_t height,uint16_t x1,uint16_t x2,uint16_t y1,uint16_t y2,byte cMin,byte cMax); //Envio parcial de bmp
    void _sendSPI(byte a); //Envía un byte por SPI
  public:
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void reset(); //Reset
    void show(); //Refresca el contenido del display y muestra la imagen enviada
    void clear(byte color=0); //Borra el display
    void begin(byte pinRES,byte pinDC,byte pinCS,byte pinBusy,uint32_t freqCOMM=0); //Inicialización
    byte drawSprite(RoJoSprite *spriteW,RoJoSprite *spriteR,int16_t x=0,int16_t y=0); //Dibuja capas en sprite
    byte drawSprite(RoJoSprite *sprite,int16_t x,int16_t y,bool layer); //Dibuja un sprite monocromo en una capa
    byte drawSpriteG(RoJoSprite *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite gris
    byte drawBMP(String filename,int16_t x=0,int16_t y=0); //Dibuja un bmp directamente de un archivo
    void sleep();
}; //Punto y coma obligatorio para que no de error

#include <RoJoSSD1681.cpp>

#endif


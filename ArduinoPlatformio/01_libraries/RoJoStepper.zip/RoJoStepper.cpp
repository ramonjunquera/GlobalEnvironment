
#ifndef RoJoStepper_cpp
#define RoJoStepper_cpp

#include <RoJoStepper.h>

static byte _RoJoStepper_stepperCount=0; //Número de motores. Inicialmente ninguno
static _RoJoStepper_stepperConfig *_RoJoStepper_stepperConfigs; //Array de configuraciones de motores
static const RoJoStepper_SeqType _RoJoStepper_seqTypes[3]={ //Definición de tipos de secuencias de pasos
  {8,{B1000,B1100,B0100,B0110,B0010,B0011,B0001,B1001}}, //MaxPrecission
  {4,{B1100,B0110,B0011,B1001,0,0,0,0}}, //MaxTorque
  {4,{B1000,B0100,B0010,B0001,0,0,0,0}}  //MinPower
};

#ifdef ESP8266
  RoJoTimerESP8266 timerAVR1; //Objeto de gestión del timer
#elif defined(ESP32)
  RoJoTimerESP32 timerAVR1; //Objeto de gestión del timer
#elif defined(__arm__)
  RoJoTimerRPi timerAVR1; //Objeto de gestión del timer
#endif

//Función de interrupción
void _iFunction() {
  for(byte stepperIndex=0;stepperIndex<_RoJoStepper_stepperCount;stepperIndex++) { //Recorremos todos los motores
    _RoJoStepper_stepperConfig &stepper=_RoJoStepper_stepperConfigs[stepperIndex];
    if(stepper.enabled) { //Si el motor está activo...
      if(stepper.currentPos!=stepper.destinationPos) { //Si se tiene que mover...
        //Tenemos que dar el siguiente paso
        //Calculamos si el paso a dar será positivo o negativo, en función de la 
        //posición actual y la de destino
        int32_t delta=(stepper.currentPos < stepper.destinationPos)?1:-1;
        //Incrementamos el paso actual en delta y lo mantenemos entre los límites de la secuencia
        stepper.currentStep+=delta;
        stepper.currentStep%=_RoJoStepper_seqTypes[stepper.seqType].stepsCount;
        //Incrementamos la posición actual en delta
        stepper.currentPos+=delta;
        //Debemos aplicar el estado correspondiente al paso actual a los pines de salida
        //Recorremos los 4 pines...y aplicamos el estado que le corresponde para el paso actual
        for(byte p=0;p<4;p++) digitalWrite(stepper.pinout[p],_RoJoStepper_seqTypes[stepper.seqType].stepsStatus[stepper.currentStep] & (1<<p));
      }
    }
  }
}

void RoJoStepper::end() {
  timerAVR1.detach(); //Desactivamos el timer
  if(_RoJoStepper_stepperCount) free(_RoJoStepper_stepperConfigs); //Si hay motores...liberamos memoria
  _RoJoStepper_stepperCount=0; //Ya no hay motores
}

//Destructor
RoJoStepper::~RoJoStepper() {
  end();
}

//Inicialización
//- stepperCount : número de motores
//- usDelay : tiempo mínimo entre pasos en microsegundos
//Devuelve true si lo consigue
bool RoJoStepper::begin(byte stepperCount,uint16_t usDelay) {
  if(!stepperCount) return false; //Al menos debemos tener un motor
  end();
  _RoJoStepper_stepperConfigs=(_RoJoStepper_stepperConfig*)malloc(stepperCount*sizeof(_RoJoStepper_stepperConfig));
  if(!_RoJoStepper_stepperConfigs) return false; //Sin memoria
  _RoJoStepper_stepperCount=stepperCount; //Guardamos número de motores
  for(byte i=0;i<stepperCount;i++) { //Inicializamos los motores
    _RoJoStepper_stepperConfig &stepper=_RoJoStepper_stepperConfigs[i];
    stepper.enabled=false;
    stepper.pinout[0]=stepper.pinout[1]=stepper.pinout[2]=stepper.pinout[3]=255;
    stepper.seqType=0;
    stepper.currentStep=0;
    stepper.currentPos=0;
    stepper.destinationPos=0;
  }
  timerAVR1.attach((float)usDelay/1000000.0,_iFunction); //Activamos el timer
  return true; //Todo OK
}

//Fija configuración para un servo
//- stepperIndex = índice del motor
//- *pinout = puntero a array de 4 bytes con los pines de conexión en formato:
//  - TinyMiniA : B-,A-,B+,A+
//  - 28BYJ-48 : IN4,IN3,IN2,IN1
//- sequenceType = tipo de secuencia 0=MaxPrecission,1=MaxTorque,2=MinPower
//Devuelve true si lo consigue
bool RoJoStepper::setCfg(byte stepperIndex,const byte *pinout,byte sequenceType) {
  if(stepperIndex>=_RoJoStepper_stepperCount) return false;
  if(sequenceType>2) return false;
  _RoJoStepper_stepperConfig &stepper=_RoJoStepper_stepperConfigs[stepperIndex];
  stepper.enabled=false;
  stepper.currentPos=0;
  stepper.destinationPos=0;
  stepper.currentStep=0;
  stepper.seqType=sequenceType; //Tipo de secuencia
  for(byte i=0;i<4;i++) {
    stepper.pinout[i]=pinout[i];
    pinMode(pinout[i],OUTPUT);
  }
  return true; //Todo OK
}

//Activa/Desactiva un servo
bool RoJoStepper::enable(byte stepperIndex,bool enabled) {
  if(stepperIndex>=_RoJoStepper_stepperCount) return false; //Motor fuera de rango
  _RoJoStepper_stepperConfigs[stepperIndex].enabled=enabled;
  return true; //Todo OK
}

//Obtiene la posición actual
int32_t RoJoStepper::getPos(byte stepperIndex) {
  if(stepperIndex>=_RoJoStepper_stepperCount) return 0; //Motor fuera de rango
  return _RoJoStepper_stepperConfigs[stepperIndex].currentPos;
}

//Se está moviendo?
bool RoJoStepper::isMoving(byte stepperIndex) {
  if(stepperIndex>=_RoJoStepper_stepperCount) return false; //Motor fuera de rango
  return _RoJoStepper_stepperConfigs[stepperIndex].currentPos!=_RoJoStepper_stepperConfigs[stepperIndex].destinationPos;
}

//Resetea la posición actual y destino a 0
bool RoJoStepper::reset(byte stepperIndex) {
  if(stepperIndex>=_RoJoStepper_stepperCount) return false; //Motor fuera de rango
  _RoJoStepper_stepperConfigs[stepperIndex].currentPos=_RoJoStepper_stepperConfigs[stepperIndex].destinationPos=0;
  return true; //Todo OK
}


bool RoJoStepper::move(byte stepperIndex,int32_t destination,bool waitUntilEnd) {
  if(stepperIndex>=_RoJoStepper_stepperCount) return false; //Motor fuera de rango
  _RoJoStepper_stepperConfigs[stepperIndex].destinationPos=destination;
  if(waitUntilEnd) while(isMoving(stepperIndex)) delay(1);
  return true; //Todo OK
}

#endif
/*
  Nombre de la librería: RoJoStepper.h
  Autor: Ramón Junquera
  Fecha: 20221109
  Descripción:
    Gestión de un motor paso a paso.

  Parámetro usDelay mínimo por modelo, voltaje y tipo de secuencia:
     modelo   V   MaxPrecission MaxTorque MinPower
    --------- --- ------------- --------- --------
    28BYJ-48  5             970      1980     2030
    TinyMiniA 5             300       580      690
    TinyMiniA 3.3           490       870      ---

  Recorrido máximo de modelo TinyMiniA:
    secuencia     pasos
    ------------- -----
    MaxPrecission  2580
    MaxTorque      1790
    MinPower       1790

  Barrido angular de modelo 28BYJ-48
    secuencia     pasos/360º
    ------------- ----------
    MaxPrecission       4096
    MaxTorque           2048
    MinPower            2048
*/

#ifndef RoJoStepper_h
#define RoJoStepper_h

#include <Arduino.h>
#ifdef ARDUINO_ARCH_AVR
  #include <RoJoTimerAVR1.h>
#elif defined(ESP8266)
  #include <RoJoTimerESP8266.h>
#elif defined(ESP32)
  #include <RoJoTimerESP32.h>
#elif defined(__arm__)
  #include <RoJoTimerRPi.h>
#endif

struct _RoJoStepper_stepperConfig {
  byte pinout[4]; //Puntero a array constante de 4 bytes
  int32_t currentPos; //Posición actual
  int32_t destinationPos; //Posición destino
  byte currentStep; //Paso actual
  byte seqType; //Tipo de secuencia
  bool enabled; //Motor activo?
};

//Estructura con los tipos de secuencias de pasos
struct RoJoStepper_SeqType {
  byte stepsCount; //Número de pasos para completar un ciclo
  byte stepsStatus[8]; //Configuración de los imanes
};

class RoJoStepper {
  public: //Definición de métodos/variables públicas
    bool begin(byte stepperCount=1,uint16_t usDelay=2060);
    void end();
    ~RoJoStepper();
    bool setCfg(byte stepperIndex,const byte *pinout,byte sequenceType);
    bool enable(byte stepperIndex,bool enabled=true);
    int32_t getPos(byte stepperIndex=0);
    bool isMoving(byte stepperIndex=0);
    bool move(byte stepperIndex=0,int32_t destination=0,bool waitUntilEnd=true);
    bool reset(byte stepperIndex); //Resetea la posición actual y destino a 0
}; //Punto y coma obligatorio para que no de error

#include <RoJoStepper.cpp>

#endif

/*
  Nombre de la librería: RoJoNeoPixel2AtomMatrix.h
  Versión: 20220516
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixelAtomMatrix_h
#define RoJoNeoPixelAtomMatrix_h

#include <Arduino.h>
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoNeoPixel.h>

class RoJoNeoPixelAtomMatrix:public RoJoNeoPixel {
  private:
    byte _XY2Index(byte x,byte y);
  public:
    const uint16_t xMax=5; //Anchura de display
    const uint16_t yMax=5; //Altura de display
    bool begin(); //Inicialización
    bool drawPixel(byte x,byte y,uint32_t color);
    uint32_t getPixel(int16_t x,int16_t y); //Devolvemos color de pixel
    bool clear(uint32_t color=0);
    bool drawSprite(RoJoSprite *source,int16_t x=0,int16_t y=0); //Dibuja un sprite en unas coordenadas
}; //Punto y coma obligatorio para que no de error

#include <RoJoNeoPixelAtomMatrix.cpp>

#endif


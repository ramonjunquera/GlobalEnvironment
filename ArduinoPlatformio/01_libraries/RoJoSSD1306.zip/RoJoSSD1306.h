/*
  Nombre de la librería: RoJoSSD1306.h
  Versión: 20220503
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SSD1306 I2C 0.96" 128x64/0.96" 128x32 
  
  Notas:
    - La conexión de este display es por I2C. No tiene pines CLK, DC o CS como en SPI
    - Una conexión de datos o comandos se distingue por el primero de los bytes enviados
      en una transmisión. 0x00 para comandos y 0x40 para datos.
    - No se pueden mezclar datos y comandos en la misma transmisión
    - Existe un límite de datos enviados en cada transmisión, definido por el tamaño del
      buffer de I2C, que a su vez depende de cada dispositivo.
*/

#ifndef RoJoSSD1306_h
#define RoJoSSD1306_h

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
//#define UseSD

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#include <RoJoSprite.h> //Gestión de sprites

class RoJoSSD1306 {
  private:
    //Máximo número de bytes a enviar en una conexión I2C (incluido el primer byte de tipo)
    //Depende del tamaño del buffer I2C, que depende del tipo de dispositivo
    #if defined(ESP32) || defined(ESP8266) //Placas ESP
      const byte _maxBufferLenthI2C=127;
    #elif defined(ARDUINO_ARCH_AVR) //Placas Arduino
      const byte _maxBufferLenthI2C=31;
    #elif defined(__arm__) //RPi
      const byte _maxBufferLenthI2C=127; //Confirmar //DEBUG
    #else //En cualquier otro dispositivo no reconocido
      const byte _maxBufferLenthI2C=31; //Tomaremos el valor más bajo
    #endif
    const byte _oledId=0x3C; //Identificador del display en en bus I2C
    byte _pinRES; //Pin de reset
    const byte _xMax=128; //Anchura de display en pixels
    byte _yMax=64; //Altura de display en pixels
    void _setCursorRange(byte x1=0,byte page1=0,byte x2=127,byte page2=7); //Define  rango X & Y
    void _setCursorRangeX(byte x1=0,byte x2=127); //Define rango X
    void _setCursorRangeY(byte page1=0,byte page2=7); //Define rango Y

  public:
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void negative(bool reserveMode); //Fija el display en modo negativo (blanco <-> negro)
    void setContrast(byte level); //Fija el contraste
    void sleep(bool mode); //Activa/Desactiva el modo hibernación
    void reset(); //Reset
    void begin(byte pinSDA=255,byte pinSCL=255,byte pinRES=255,bool halfRows=false); //Inicialización
    void clear(uint32_t color=0); //Borra el área de dibujo
    bool drawSprite(RoJoSprite *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    bool drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x=0,int16_t y=0); //Sincroniza dos sprites y envía las diferencias al display
};

#include <RoJoSSD1306.cpp>

#endif


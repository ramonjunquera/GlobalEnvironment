/*
  Nombre de la librería: RoJoSSD1306.h
  Versión: 20220218
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED I2C 0.96" 128x64 SSD1306

  Nota:
  El tamaño del buffer I2C de las distintas placas nos limita el número
  de bytes que podemos enviar en una petición.
  Tras muchas pruebas estos son los resultados:
    UNO/Nano:  16 bytes
    ESP8266:   30 bytes
    ESP32:     29 bytes
    RPi:      128 bytes
    
  Nota: En RPi el flujo del buffer de escritura lo gestiona la propia
  función, por lo tanto no tendría límite. Lo fijamos en 128 bytes que
  es la longitud de una fila.

  Nota:
  La memoria de vídeo del display es de 1Kb.
  El driver tiene una memoria de vídeo de trabajo (videoMem) y una memoria de vídeo del display (_videoMem)
  La memoria de vídeo de trabajo permite leer y escribir información directamente.
  La memoria de vídeo del display mantiene la información que se está mostrando en ese instante en el
  display (la última enviada).
  El método show() se encarga de sincronizar ambas. Las compara y envía solo las diferencias.
  Este sistema consige una tasa de refresco mucho más alta. El movimiento de un sprite por pantalla es
  muchísimo más rápido.
  Supnemos que lo que más ralentiza es el envío de la información por el bus I2C.
  Esto es cierto en placas rápidas (ESP/RPi). En placas lentas (Mega) la diferencia es mínima.
*/

#ifndef RoJoSSD1306_cpp
#define RoJoSSD1306_cpp

#include <RoJoSSD1306.h>

//Anchura de display en pixels
uint16_t RoJoSSD1306::xMax() {
  return _xMax;
}
//Altura de display en pixels
uint16_t RoJoSSD1306::yMax() {
  return _yMax;
}

//Display con colores invertidos blanco <-> negro
void RoJoSSD1306::negative(bool reverseMode) {
  //Fija el display en modo invertido/normal (blanco <-> negro)
  //Por defecto se encuentra en modo invertido
  //  reverseMode = false -> pixel encendido = blanco
  //  reverseMode = true  -> pixel encendido = negro
  
  //Creamos un array de bytes con todos los comandos
  byte commandBuffer[]= {
    0x00 //Indicamos que a continuación se enviarán comandos
    ,(byte)(reverseMode?0xA7:0xA6) //Dependiendo del parámetro aplicamos un modo u otro
  };
  //Enviamos el array por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar comandos
}

//Fija el contraste
void RoJoSSD1306::setContrast(byte level) {
  //Creamos un array de bytes con todos los comandos
  byte commandBuffer[]= {
     0x00 //Indicamos que a continuación se enviarán comandos
    ,0x81 //Ajustamos el contraste
    ,level //Al mínimo
  };
  //Enviamos el array por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
    Wire.write(commandBuffer,3);
  Wire.endTransmission(); //Hemos terminado de enviar comandos
}

//Define  rango X & Y
void RoJoSSD1306::_setCursorRange(byte x1,byte page1,byte x2,byte page2) {
  byte commandBuffer[]={
    0x00, //Enviamos comandos
    0x22, //Comando para definir el rango de páginas que utilizaremos : [0,7]
    page1, //Página inicial
    page2, //Página final
    0x21, //Comando para definir el rango de columnas que utilizaremos: [0,127]
    x1, //Columna inicial
    x2 //Columna final
  };
  Wire.beginTransmission(_oledId);
    Wire.write(commandBuffer,7);
  Wire.endTransmission();
}
//Define rango Y
void RoJoSSD1306::_setCursorRangeY(byte page1,byte page2) {
  byte commandBuffer[]={
     0x00 //Enviamos comandos
    ,0x22 //Comando para definir el rango de páginas que utilizaremos : [0,7]
    ,page1 //Página inicial
    ,page2 //Página final
  };
  Wire.beginTransmission(_oledId);
    Wire.write(commandBuffer,4);
  Wire.endTransmission();
}
//Define rango X
void RoJoSSD1306::_setCursorRangeX(byte x1,byte x2) {
  byte commandBuffer[]={
     0x00 //Enviamos comandos
    ,0x21 //Comando para definir el rango de columnas que utilizaremos: [0,127]
    ,x1 //Columna inicial
    ,x2 //Columna final
  };
  Wire.beginTransmission(_oledId);
    Wire.write(commandBuffer,4);
  Wire.endTransmission();
}

//Borra el área de dibujo
//El color puede ser 0=negro o cualquier otro valor=blanco
void RoJoSSD1306::clear(uint32_t color) {
  //Este display no permite rellenar áreas (comando block)
  //Rellenaremos toda la memoria gráfica del color indicado

  //Nos aseguramos que cualquier color distinto de cero corresponde con el valor de página 0xFF
  byte fillColor=color==0?0x00:0xFF;
  _setCursorRange(); //Definimos todo el display como área de dibujo
  Wire.beginTransmission(_oledId); //Abrimos comunicación con el display
  byte sentBytes=1; //Número de bytes enviados en la transmisión actual. 1 porque incluirmos el byte de tipo de transmisión
  Wire.write(0x40); //Enviaremos byte de tipo de transmisión (datos gráficos)
  for(uint16_t i=1024;i>0;i--) { //Llenaremos todas las páginas del display
    if(sentBytes>=_maxBufferLenthI2C) { //Si hemos enviado el máximo de bytes en esta transmisión
      sentBytes=1; //Reseteamos el número de bytes enviados
      Wire.endTransmission(); //Finalizamos la transmisión obligando a enviarla
      Wire.beginTransmission(_oledId); //Abrimos una nueva transmisión
      Wire.write(0x40); //Enviamos el byte de tipo de transmisión
    }
    Wire.write(fillColor); //Escribimos el color
    sentBytes++; //Hemos enviado un byte más
  }
  Wire.endTransmission(); //Hemos terminado esta transmisión
}

// Activa/Desactiva el modo hibernación
void RoJoSSD1306::sleep(bool mode) {
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado

  //Creamos un array de bytes con todos los comandos
  byte commandBuffer[]= {
    0x00, //Indicamos que a continuación se enviarán comandos
    (byte)(mode?0xAE:0xAF) //0xAE=display OFF,0xAF=display ON
  };
  //Enviamos el array por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
    Wire.write(commandBuffer,2);
  Wire.endTransmission(); //Hemos terminado de enviar comandos
}

//Reset & inicialización
void RoJoSSD1306::reset() {
  //Si se ha definido pin de reset...
  if(_pinRES<255) {
    //...hacemos un hard reset
    pinMode(_pinRES,OUTPUT);
    digitalWrite(_pinRES,LOW);
    delay(50);
    digitalWrite(_pinRES,HIGH);
    delay(100);
  }
  //Secuencia de inicialización.
  //Creamos un array de bytes con todos los comandos
  byte commandBuffer[]= {
    0x00, //Indicamos que a continuación se enviarán comandos

    0x8D, //Rango de voltaje
    0x14, //Voltaje igual o superior a 3.3V

    0x20, //Orden de escritura gráfica
    0x00, //Modo horizontal

    0xC8, //Orientación vertical con los pines de conexión en la parte superior
    0xA1, //Orientación horizontal. De izquierda a derecha 0-->127

    0xDA, //Filas entrelazadas
    0x10 //Modo no entrelazado
  };

  //Enviamos el array por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
    Wire.write(commandBuffer,9);
  Wire.endTransmission(); //Hemos terminado de enviar comandos

  //Modo normal : no negativo : fondo=negro,dibujo=blanco
  negative(false);
  //Fijamos contraste poe defecto
  setContrast(30);
  
  //Borramos el display
  clear();
  //Salimos del modo de bajo consumo
  sleep(false);
}

//Inicialización del display
//Permite fijar el pin CS de la SD, el pin SDA de I2C, el pin SCL de I2C y el pin reset
//del display (si lo tiene).
void RoJoSSD1306::begin(byte pinSDA,byte pinSCL,byte pinRES) {
  _pinRES=pinRES; //Guardamos pin de reset

  //Inicializamos el protocolo I2C
  #if defined(ARDUINO_ARCH_AVR) || defined(__arm__) //Si es una placa Arduino o una RPi ...
    //En las placas Arduino o RPi, no se pueden seleccionar los pines I2C
    //Los posibles pines I2C no se tendrán en cuenta
    Wire.begin();
  #else //No es una placa Arduino ni RPi. Es una ESP.
    //Si se ha indicado pin de I2C (SDA & SCL)...activamos el I2C personalizado
    if(pinSDA<255 && pinSCL<255) Wire.begin(pinSDA,pinSCL);
    //...y si no...usamos una I2C con los pines por defecto
    else Wire.begin();
  #endif
  
  //Fijamos la frecuencia del bus I2C a 700KHz
  //Sólo será efectiva si la velocidad del procesador está selecionada al máximo
  Wire.setClock(700000);
  //Hacemos un reset & inicialización
  reset();
}

//Envía un sprite al display
//La coordenada vertical 'y' debe ser múltiplo de 8
//Devuelve true si se muestra algo
bool RoJoSSD1306::drawSprite(RoJoSprite *sprite,int16_t x,int16_t y) {
  //Si el sprite no es monocromo...terminamos con error
  if(sprite->bytesPerPixel()!=0) return false;
  //Si la coordenada vertical no es múltiplo de 8...terminamos con error
  if(y%8) return false;
  //Calculamos el área visible
  displayRange r=RoJoGraph::visibleRange(x,y,sprite->xMax(),sprite->yMax(),_xMax,_yMax);
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;
  //Parte del área es visible

  y>>=3; r.y1>>=3; r.y2>>=3; //Convertimos los valores verticales a páginas
  _setCursorRange(r.x1,r.y1,r.x2,r.y2); //Fijamos el área de dibujo

  #ifdef ESP8266
    ESP.wdtDisable(); //Desactivamos WatchDog mientras enviamos la información por I2C
  #endif
  Wire.beginTransmission(_oledId); //Abrimos comunicación con el display
  int16_t dyMax=r.y2-y,dxMax=r.x2-x; //Variables para optimizar los bucles
  byte *offsetRow;
  byte sentBytes=1; //Número de bytes enviados en la transmisión actual. 1 porque incluirmos el byte de tipo de transmisión
  Wire.write(0x40); //Enviaremos datos gráficos
  for(int16_t dy=r.y1-y;dy<=dyMax;dy++) { //Recorremos todas las páginas visibles del sprite
    offsetRow=sprite->_videoMem[dy];
    for(int16_t dx=r.x1-x;dx<=dxMax;dx++) { //Recorremos todas las columnas visibles del sprite
      if(sentBytes>=_maxBufferLenthI2C) { //Si hemos enviado el máximo de bytes en esta transmisión
        sentBytes=1; //Reseteamos el número de bytes enviados
        Wire.endTransmission(); //Finalizamos la transmisión obligando a enviarla
        Wire.beginTransmission(_oledId); //Abrimos una nueva transmisión
        Wire.write(0x40); //Enviamos el byte de tipo de transmisión
      }
      Wire.write(offsetRow[dx]); //Enviamos el valor de la página
      sentBytes++; //Hemos enviado un byte más
    }
  }
  Wire.endTransmission(); //Hemos terminado de enviar datos
  #ifdef ESP8266
    ESP.wdtEnable(1000); //Reactivamos las interrupciones de WatchDog
  #endif
  return true; //Todo Ok
}

//Sincroniza dos sprites y envía las diferencias al display.
//Los sprites deben tener el mismo tamaño
//Respuesta: true si todo es correcto
bool RoJoSSD1306::drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x,int16_t y) {
  //Se detectan las diferencias entre los dos sprites y se escriben sobre el sprite destino
  //y se envían al display.
  //Finalmente el sprite destino queda igual que el origen.

  //Nota. El offset vertical (y) debe ser múltiplo de 8 para poder enviar las páginas completas

  //Anotamos las medidas del sprite origen
  int16_t xMaxSprite=source->xMax();
  int16_t yMaxSprite=source->yMax();
  //Si los sprites tienen distinto tamaño...terminamos con error
  if(xMaxSprite!=(int16_t)destination->xMax() || yMaxSprite!=(int16_t)destination->yMax()) return false;
  //Si alguno de los sprites no es monocromo...terminamos con error
  if(source->bytesPerPixel()!=0 || destination->bytesPerPixel()!=0) return false;
  //Si 'y' no es múltiplo de 8...terminamos con error
  if((y%8)>0) return false;
  //Comprobamos si tiene parte visible
  displayRange r=RoJoGraph::visibleRange(x,y,xMaxSprite,yMaxSprite,_xMax,_yMax);
  //Si no es visible...terminamos correctamente
  if(!r.visible) return true;
  //El sprite es total o parcialmente visible
  //En el display se dibujará el sprite en el rango: r.x1,r.y1,r.x2,r.y2
  //Se mostrará el siguiente rango del sprite: r.x1-x,r.y1-y,r.x2-x,r.y2-y
  //Es más sencillo recorrer las filas y columnas del sprite y si se detectan
  //diferencias, hacer la conversión a coordenadas de display
  
  //En sprites monocromos la medida vertical es la página, no el pixel
  //Recalculamos todas las medidas verticales a páginas
  y>>=3; r.y1>>=3; r.y2>>=3;
  //Calculamos la última página y columna a procesar en el sprite
  //Reaprovechamos variables
  xMaxSprite=r.x2-x; yMaxSprite=r.y2-y;

  bool selectedRangeY; //Se ha seleccionado el rango vertical con la fila procesada?
  int16_t xSprite; //Columna procesada. Coordenada x del sprite
  byte *offsetRowSource,*offsetRowDestination;
  
  byte sentBytes; //Número de bytes enviados en la transmisión actual
  
  //Recorremos todas las páginas visibles del sprite
  for(int16_t ySprite=r.y1-y;ySprite<=yMaxSprite;ySprite++) {
    offsetRowSource=source->_videoMem[ySprite];
    offsetRowDestination=destination->_videoMem[ySprite];
    //Por ahora no se ha inicializado el rango vertical para la página actual
    selectedRangeY=false;
    //Comenzamos por la primera columna
    xSprite=r.x1-x;
    //Mientras no hayamos procesado todas las columnas...
    while(xSprite<=xMaxSprite) {
      //Si el valor de la página actual no se ha modificado...
      if(offsetRowSource[xSprite]==offsetRowDestination[xSprite]) {
        //...no tenemos en cuenta este valor de página. Pasaremos al siguiente
        xSprite++;
      }
      else { //El pixel actual ha sido modificado...
        //Si no se ha seleccionado la página actual...
        if(!selectedRangeY) {
          //...lo hacemos ahora. Convertimos a coordenadas de display
          _setCursorRangeY(y+ySprite);
          //y lo anotamos
          selectedRangeY=true;
        }
        //Consideramos este valor de página como procesado
        //Actualizamos su valor en el sprite destino
        offsetRowDestination[xSprite]=offsetRowSource[xSprite];
        //Por ahora la última columna modificada es la primera
        int16_t lastChangedColumn=xSprite;
        //Columna procesada = la siguiente a la primera
        int16_t processedColumn=xSprite+1;
        //Mientras llevemos menos de 5 pixels sin modificar...
        while(processedColumn-lastChangedColumn<=5) {
          //Si el valor de la página de la columna procesada ha cambiado...
          if(offsetRowSource[processedColumn]!=offsetRowDestination[processedColumn]) {
            //...anotamos que la última columna con cambios es la actual
            lastChangedColumn=processedColumn;
            //Consideramos este valor de página como procesado
            //Actualizamos su valor en el sprite destino
            offsetRowDestination[processedColumn]=offsetRowSource[processedColumn];
          }
          //Aumentamos la posición de la columna procesada
          processedColumn++;
        } //end while
        //Seleccionamos como rango horizontal desde la columna actual hasta la última modificada
        //Convertimos a coordenadas de display
        _setCursorRangeX(x+xSprite);
        //Enviamos los datos gráficos
        
        Wire.beginTransmission(_oledId); //Abrimos comunicación con el display
        Wire.write(0x40); //Enviaremos byte de tipo de transmisión (datos gráficos)
        sentBytes=1; //Número de bytes enviados en la transmisión actual =1 porque incluirmos el byte de tipo de transmisión
        for(int16_t x0=xSprite;x0<=lastChangedColumn;x0++) {
          if(sentBytes>=_maxBufferLenthI2C) { //Si hemos enviado el máximo de bytes en esta transmisión
            sentBytes=1; //Reseteamos el número de bytes enviados
            Wire.endTransmission(); //Finalizamos la transmisión obligando a enviarla
            Wire.beginTransmission(_oledId); //Abrimos una nueva transmisión
            Wire.write(0x40); //Enviamos el byte de tipo de transmisión
          }
          Wire.write(offsetRowSource[x0]); //Escribimos el valor de la página
          sentBytes++; //Hemos enviado un byte más
        }
        Wire.endTransmission(); //Hemos terminado esta transmisión
        //La primera columna pasará a ser la actual
        xSprite=processedColumn;
      }
    }
  }
  return true; //Todo Ok
}

#endif


/*
  Nombre de la librería: RoJoSSD1306tiny
  Autor: Ramón Junquera
  Fecha: 20210504
  Descripción:
    Gestión de display OLED I2C 0.96" 128x64 SSD1306
*/

#ifndef RoJoSSD1306tiny_h
#define RoJoSSD1306tiny_h

#include <Arduino.h>
#include <TinyWireM.h> //Gestión de comunicaciones I2C para ATtiny85

class RoJoSSD1306tiny {
  private:
    const byte _oledId=0x3C; //Identificador del display en en bus I2C
    void _setCursorRange(byte x1=0,byte page1=0,byte x2=127,byte page2=7);
  public:
    bool begin(); //Inicialización
    void clear(byte value=0); //Escribe el valor en todo el display
    void lineV(byte x); //Dibuja una línea vertical
}; //Punto y coma obligatorio para que no de error

#endif

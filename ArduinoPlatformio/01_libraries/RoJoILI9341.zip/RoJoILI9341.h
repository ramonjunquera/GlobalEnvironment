/*
  Nombre de la librería: RoJoILI9341.h
  Versión: 20220120
  Autor: Ramón Junquera
  Descripción:
    Gestión de display ILI9341 SPI 240x320
*/

#ifndef RoJoILI9341_h
#define RoJoILI9341_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite3.h> //Gestión de sprites
#include <RoJoGraph3.h> //Gestión de gráficos avanzados

class RoJoILI9341:public RoJoGraph3 {
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    byte _pinBackLight; //Pin BackLight de display
    void _setCursorRangeX(int16_t x1,int16_t x2); //Define rango X
    void _setCursorRangeY(int16_t y1,int16_t y2); //Define rango Y
    void _setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2); //Define  rango X & Y
    const uint16_t _xMaxDefault=240; //Anchura de display sin rotación
    const uint16_t _yMaxDefault=320; //Altura de display sin rotación
    uint16_t _xMax; //Anchura de display teniendo en cuenta la rotación
    uint16_t _yMax; //Altura de display teniendo en cuenta la rotación
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _startCOMM(); //Inicia comunicación
    void _endCOMM(); //Finaliza comunicación
    SPISettings _spiSetting; //Características de la conexión SPI
    #ifdef ARDUINO_M5STACK_FIRE
      byte _rotationCodes[4]={0b10101000,0b00001000,0b01101000,0b11001000}; //Configuraciones de rotación
    #else
      byte _rotationCodes[4]={0b01001000,0b00101000,0b10001000,0b11101000}; //Configuraciones de rotación
    #endif
  public:
    void sleep(bool mode); //Activa/Desactiva el modo hibernación
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    bool block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color); //Dibuja un rectángulo relleno
    void reset(); //Reset
    bool drawPixel(int16_t x,int16_t y,uint32_t color); //Dibuja un pixel
    void begin(byte pinRES,byte pinDC,byte pinCS,byte pinBackLight=255,uint32_t freqCOMM=0); //Inicialización
    bool drawSprite(RoJoSprite3 *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo
    bool drawSpriteSync(RoJoSprite3 *source,RoJoSprite3 *destination,int16_t x=0,int16_t y=0); //Sincroniza dos sprites
    void backLight(bool status); //Gestiona la luz de fondo
    void rotation(byte r); //Configura la rotación
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoILI9341.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


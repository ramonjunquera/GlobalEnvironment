/*
  Nombre de la librería: RoJoGraph2.h
  Versión: 20211201
  Autor: Ramón Junquera
  Descripción:
    Funciones gráficas avanzadas
*/

#ifndef RoJoGraph3_cpp
#define RoJoGraph3_cpp

#include <RoJoGraph3.h>

//Compone el color que corresponde a la actual profundidad de color
uint32_t RoJoGraph3::getColor(byte R,byte G,byte B) {
  uint32_t color=0;
  switch(_bytesPerPixel) {
    case 0: //monocromo
      color=R+G+B>0;
      break;
    case 1: //grises
      color=(R+G+B)/3;
      break;
    case 2: //color 0bRRRRRGGGGGGBBBBB
      color=(R & 0b11111000)<<8 | (G & 0b11111100)<<3 | (B>>3);
      break;
    case 3: //color real 0b00000000RRRRRRRRGGGGGGGGBBBBBBBB
      color=(uint32_t)R<<16 | G<<8 | B;
      break;
  }
  return color;
}

//Descompone el color con la actual profundidad de color
//Si bytesPerPixel==255 se tendrá en cuenta la profundidad de color de la clase
void RoJoGraph3::getColor(uint32_t color,byte *R,byte *G,byte *B,byte bytesPerPixel) {
  if(bytesPerPixel==255) bytesPerPixel=_bytesPerPixel;
  switch(bytesPerPixel) {
    case 0: //monocromo
      if(color) *R=*G=*B=255;
      else *R=*G=*B=0;
      break;
    case 1: //grises
      *R=*G=*B=color;
      break;
    case 2: //color 0bRRRRRGGGGGGBBBBB
      *R=(color>>8) & 0b11111000;
      *G=(color>>3) & 0b11111100;
      *B=(color<<3) & 0b11111000;
      break;
    case 3: //color real 0b00000000RRRRRRRRGGGGGGGGBBBBBBBB
      *R=color>>16;
      *G=(color>>8) & 0xFF;
      *B=color & 0xFF;
      break;
  }
}

//Inicialización
void RoJoGraph3::begin() {
  //Creamos este método porque en ESP32 no se puede inicializar LittleFS
  //dentro de un constructor. Da un error en tiempo de ejecución
  //Este método debe ser llamado siempre por las clases hijas

  //Si no utilizamos SD (si utilizamos LittleFS)...
  #ifndef ROJO_PIN_CS_SD
    LittleFS.begin(); //Si no reconoce el formato, lo formatea automáticamente
  #endif
}

//Anchura de display (dummy)
uint16_t RoJoGraph3::xMax() {
  //Necesario para calcular rangos visibles del display y clear
  return 0;
}

//Altura de display (dummy)
uint16_t RoJoGraph3::yMax() {
  //Necesario para calcular rangos visibles del display y clear
  return 0;
}

//Calcula el rango visible de un objeto
//Parámetros:
//  x,y : coordenadas del objeto
//  width,height : anchura y altura del objeto
//  displayWidth,displayHeight : anchura y altura de la pantalla
//Respuesta: estructura con las coordenadas de display ocupadas por objeto
displayRange RoJoGraph3::visibleRange(int16_t x,int16_t y,uint16_t width,uint16_t height,uint16_t displayWidth,uint16_t displayHeight) {
  displayRange res; //Creamos estructura de respuesta
  if(width!=0 && height!=0 && displayWidth!=0 && displayHeight!=0) { //Si tiene dimensión...
    //Si parte del bloque está dentro de pantalla...
    if(x<(int16_t)displayWidth && y<(int16_t)displayHeight && x+width>0 && y+height>0) {
      res.visible=true;
      //Calculamos la zona de pantalla que ocupará
      res.x1=x<0?0:x;
      res.y1=y<0?0:y;
      res.x2=x+width-1; if(res.x2>=displayWidth) res.x2=displayWidth-1;
      res.y2=y+height-1; if(res.y2>=displayHeight) res.y2=displayHeight-1;
    }
  }
  return res; //Devolvemos respuesta
}

//Calcula el rango visible de un objeto. La anchura y altura pueden ser negativos
//Parámetros:
//  x,y : coordenadas del objeto
//  width,height : anchura y altura del objeto
//  displayWidth,displayHeight : anchura y altura de la pantalla
//Respuesta: estructura con las coordenadas de display ocupadas por objeto
displayRange RoJoGraph3::visibleRange(int16_t *x,int16_t *y,int16_t *width,int16_t *height,uint16_t displayWidth,uint16_t displayHeight) {
  displayRange res; //Creamos estructura de respuesta
  if(*width<0) { //Si la anchura es negativa...
    *x+=*width;
    *width=-*width;
  }
  if(*height<0) { //Si la altura es negativa...
    *y+=*height;
    *height=-*height;
  }
  uint16_t widthPositive=*width;
  uint16_t heightPositive=*height;
  return visibleRange(*x,*y,widthPositive,heightPositive,displayWidth,displayHeight);
}

//Calcula el rango visible de un objeto
//Parámetros:
//  x,y : coordenadas del objeto
//  width,height : anchura y altura del objeto
//Respuesta: estructura con las coordenadas de display ocupadas por objeto
displayRange RoJoGraph3::visibleRange(int16_t x,int16_t y,uint16_t width,uint16_t height) {
  return visibleRange(x,y,width,height,xMax(),yMax());
}

//Calcula el rango visible de un objeto. La anchura y altura pueden ser negativos
//Parámetros:
//  x,y : coordenadas del objeto
//  width,height : anchura y altura del objeto
//Respuesta: estructura con las coordenadas de display ocupadas por objeto
displayRange RoJoGraph3::visibleRange(int16_t *x,int16_t *y,int16_t *width,int16_t *height) {
  return visibleRange(x,y,width,height,xMax(),yMax());
}

//Dibuja un pixel (dummy)
//Devuelve true si el pixel es visible
bool RoJoGraph3::drawPixel(int16_t x,int16_t y,uint32_t color) {
  //Necesario porque es la base para todas las funciones gráficas de RoJoGraphs
  
  //Estructura:
  //  Comprobación si hay área visible
  //  Si no es visible terminamos con error
  //  Comandos para dibujo de un pixel en el display
  //  Todo Ok

  //Hacemos una operación simple con cada parámetro para que no de el warning de variable no usadas
  x++; y++; color++;
  return false;
}

//Dibuja un rectángulo relleno
//Devuelve true si tiene parte visible
bool RoJoGraph3::block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color) {
  //Función genérica. Dibuja el bloque pixel a pixel

  //Comprobamos si hay área visible
  displayRange r=visibleRange(&x,&y,&width,&height);
  //Si no es visible...terminamos
  if(!r.visible) return false;
  //El bloque tiene parte visible

  //Para evitar cambio de tipos en el bucle
  uint16_t rx2=r.x2,ry2=r.y2;
  //Recorremos todas las filas y columnas y dibujamos el pixel
  for(uint16_t row=r.y1;row<=ry2;row++)
    for(uint16_t col=r.x1;col<=rx2;col++)
      drawPixel(row,col,color);
  //Todo Ok
  return true;
}

//Borra el área de dibujo
void RoJoGraph3::clear(uint32_t color) {
  block(0,0,xMax(),yMax(),color);
}

//Información de archivo .spr
byte RoJoGraph3::infoSprite(String filename,uint16_t *width,uint16_t *height,byte *bytesPerPixel) {
  //Tabla de errores:
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida

  //Formato sprite
  //CABECERA
  //offset # descripción
  //------ - -----------
  //   0   1 profundidad de color 0=monocromo, 1=gris, 2=color, 3=color real
  //   1   2 anchura en pixels
  //   3   2 altura en pixels
  //   5   ? datos gráficos

  //DATOS GRÁFICOS
  //Se guardan por filas (en color) o páginas (en monocromo)

  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos LittleFS...
    //...ya se inicializó en el constructor
    File f=LittleFS.open(filename,"r"); //Abrimos el archivo en LittleFS
  #endif
  if(!f) return 1;

  byte colorDepth=f.read();
  if(colorDepth!=1 && colorDepth!=8 && colorDepth!=16 && colorDepth!=24) return 2;
  *bytesPerPixel=colorDepth/8;
  f.read((byte*)width,2);
  f.read((byte*)height,2);
  f.close();
  return 0; //Todo Ok
}

//Dibuja un archivo .spr en unas coordenadas
//Sobreescribe la información existente
//Interpreta cualquier profundidad de color
//Respuesta: código de error
byte RoJoGraph3::drawSprite(String filename,int16_t x,int16_t y) {
  //Tabla de errores (los primeros son los de infoSprite):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida
  //Declaración de variables
  uint16_t width,height; //Anchura y altura
  byte bytesPerPixel;
  //Leemos los valores del archivo bmp
  byte errorCode=infoSprite(filename,&width,&height,&bytesPerPixel);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Calculamos el área visible
  displayRange r=visibleRange(x,y,width,height);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos LittleFS...
    //...ya se inicializó en el constructor
    File f=LittleFS.open(filename,"r"); //Abrimos el archivo en LittleFS
  #endif
  //Suponemos que no hay errores de apertura en el archivo, porque lo hemos
  //probado hace un momento con infoSprite

  uint32_t bytesPerRow;
  uint16_t ry2=r.y2,rx1=r.x1,rx2=r.x2; //Optimización de bucles
  uint32_t offsetBase=5+rx1-x; //Offset de datos gráficos. Incluimos el offset de x

  #ifdef ESP8266
    ESP.wdtDisable(); //Desactivamos WatchDog mientras dibujamos
  #endif

  if(bytesPerPixel) { //Si es un sprite color...
    bytesPerRow=width*_bytesPerPixel; //Número de bytes que contiene una línea
    uint32_t color=0;
    byte R,G,B; //Componentes de color
    for(uint16_t row=r.y1;row<=ry2;row++) { //Recorremos las filas visibles del display
      f.seek(offsetBase+bytesPerRow*(row-y)); //Posicionamos offset en archivo
      for(uint32_t col=rx1;col<=rx2;col++) { //Recorremos las columnas visibles del display
        f.read((byte*)&color,_bytesPerPixel); //Leemos el color
        getColor(color,&R,&G,&B,bytesPerPixel); //Pasamos el color a 24 bits
        drawPixel(col,row,getColor(R,G,B)); //Dibujamos el pixel
      }
    }
  } else { //Si es un sprite monocromo...
    bytesPerRow=width; //Número de bytes que contiene una página
    uint32_t colorWhite=getColor(255,255,255);
    uint16_t page1=r.y1>>3,page2=ry2>>3; //Calculamos página inicial y final visibles
    uint16_t row;
    byte value;
    for(uint16_t page=page1;page<=page2;page++) { //Recorremos las páginas visibles del display
      f.seek(offsetBase+bytesPerRow*(page-page1)); //Posicionamos offset en archivo
      for(uint16_t col=rx1;col<=rx2;col++) { //Recorremos las columnas visibles del display
        value=f.read();
        for(byte rowInPage=0;rowInPage<8;rowInPage++) { //Recorremos las filas de la página
          row=(page<<3)+rowInPage; //Calculamos la fila
          if(row<=ry2) { //Si la fila es visible...
            if(value & 1) drawPixel(col,row,colorWhite); //pixel ON
            else drawPixel(col,row,0); //pixel OFF
          } else break; //Si esta fila ya no es visible...salimos del bucle
          value>>=1;
        }
      }
    }
  }
  
  #ifdef ESP8266
    ESP.wdtEnable(1000); //Reactivamos las interrupciones de WatchDog
  #endif
  
  f.close(); //Hemos terminado de utilizar el archivo
  return 0; //Todo Ok
}

//Información de archivo .bmp
byte RoJoGraph3::infoBMP(String filename,uint16_t *width,uint16_t *height,byte *bytesPerPixel) {
  //Tabla de errores:
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe.
  //  2 : La firma del tipo de archivo no coincide
  //  3 : Anchura demasiado grande
  //  4 : Altura demasiado grande
  //  5 : El número de planos no es 1
  //  6 : La profundidad de color no está reconocida
  //  7 : Está comprimido

  //Formato BMP
  //CABECERA
  //offset # descripción
  //------ - -----------
  //   0   2 "BM" constante
  //   2   4 tamaño de archivo
  //   6   4 reservado
  //  10   4 offset de inicio de datos gráficos
  //  14   4 tamaño de cabecera
  //  18   4 anchura en pixels
  //  22   4 altura en pixels
  //  26   2 número de planos (habitualmente 1)
  //  28   2 bits por pixel (habitualmente 24 para imágenes a color)
  //  30   4 compresión (habitualmente 0=ninguna)
  //  34   4 tamaño de imágen
  //  38   4 resolución horizontal
  //  42   4 resolución vertical
  //  46   4 tamaño de la tabla de color
  //  50   4 contador de colores importantes

  //DATOS GRÁFICOS
  //Se guardan por filas
  //Las filas están invertidas. La primera que encontramos corresponde a la última de la imágen
  //El número de bytes de una fila debe ser múltiplo de 4. Si no lo es, se completarán con bytes vacíos
  //Por cada fila, las columnas van en orden: de izquierda a derecha
  //El primer dato gráfico contendrá información sobre el pixel de abajo a la izquierda

  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos LittleFS...
    //...ya se inicializó en el constructor
    File f=LittleFS.open(filename,"r"); //Abrimos el archivo en LittleFS
  #endif
  if(!f) return 1; //Si no se ha podido abrir el archivo...error

  byte errorCode=0; //Código de error a devolver. Inicialmente no hay error
  byte buffer[34];
  uint32_t tmp32;
  uint16_t tmp16;
  f.read(buffer,34); //Leemos los 34 primeros bytes del archivo
  if(buffer[0]!='B' || buffer[1]!='M') errorCode=2;
  else {
    tmp32=*((uint32_t*)(buffer+18)); //Anotamos anchura
    if(tmp32>65535) errorCode=3; //Si la anchura tiene más de 16bits...error
    else {
      *width=tmp32; //Anotamos anchura
      tmp32=*((uint32_t*)(buffer+22)); //Anotamos altura
      if(tmp32>65535) errorCode=4; //Si la altura tiene más de 16bits...error
      else {
        *height=tmp32; //Anotamos anchura
        //Si el número de planos es distinto de 1...error
        if(*((uint16_t*)(buffer+26))!=1) errorCode=5;
        else {
          tmp16=*((uint16_t*)(buffer+28)); //Anotamos profundidad de color
          //Si la profundidad de color no es reconocida...error
          if(tmp16!=1 && tmp16!=24) errorCode=6;
          else {
            *bytesPerPixel=(tmp16==1?0:3); //O monocromo 0 o color real 3
            //Si está comprimido...error
            if(*((uint32_t*)(buffer+30))) errorCode=7;
          }
        }
      }
    }
  }
  f.close(); //Hemos terminado de utilizar el archivo
  return errorCode; //Devolvemos código de error
}

//Dibuja un archivo .bmp en unas coordenadas
//Sobreescribe la información existente
//Interpreta cualquier profundidad de color
//Respuesta: código de error
byte RoJoGraph3::drawBMP(String filename,int16_t x,int16_t y) {
  //Tabla de errores (los 8 primeros son los de infoBMP):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe.
  //  2 : La firma del tipo de archivo no coincide
  //  3 : Anchura demasiado grande
  //  4 : Altura demasiado grande
  //  5 : El número de planos no es 1
  //  6 : La profundidad de color no está reconocida
  //  7 : Está comprimido
  //  8 : No se puede cargar un bmp color en una sprite monocromo ni a la inversa

  //Formato BMP
  //CABECERA
  //offset # descripción
  //------ - -----------
  //   0   2 "BM" constante
  //   2   4 tamaño de archivo
  //   6   4 reservado
  //  10   4 offset de inicio de datos gráficos
  //  14   4 tamaño de cabecera
  //  18   4 anchura en pixels
  //  22   4 altura en pixels
  //  26   2 número de planos (habitualmente 1)
  //  28   2 bits por pixel (habitualmente 24 para imágenes a color)
  //  30   4 compresión (habitualmente 0=ninguna)
  //  34   4 tamaño de imágen
  //  38   4 resolución horizontal
  //  42   4 resolución vertical
  //  46   4 tamaño de la tabla de color
  //  50   4 contador de colores importantes

  //DATOS GRÁFICOS
  //Se guardan por filas
  //Las filas están invertidas. La primera que encontramos corresponde a la última de la imágen
  //El número de bytes de una fila debe ser múltiplo de 4. Si no lo es, se completarán con bytes vacíos
  //Por cada fila, las columnas van en orden: de izquierda a derecha
  //El primer dato gráfico contendrá información sobre el pixel de abajo a la izquierda
  //En monocromo los valores están invertidos

  //Declaración de variables
  byte errorCode=0; //Código de error a devolver
  uint16_t width,height; //Anchura y altura
  byte bytesPerPixel;
  
  //Leemos los valores del archivo bmp
  errorCode=infoBMP(filename,&width,&height,&bytesPerPixel);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Calculamos el área visible
  //DEBUG
  //displayRange r=visibleRange(x,y,width,height);
  displayRange r=visibleRange(x,y,width,height,xMax(),yMax());
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;
  //Hay área visible

  //Calculamos el número de bytes que contiene una línea
  uint32_t bytesPerRow;
  if(bytesPerPixel) bytesPerRow=width*3; //color
  else { //monocromo
    bytesPerRow=width/8;
    if(width%8) bytesPerRow++;
  }
  //El número de bytes de una línea debe ser múltiplo de 4
  if(bytesPerRow%4) bytesPerRow+=4-(bytesPerRow%4);

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos LittleFS...
    //...ya se inicializó en el constructor
    File f=LittleFS.open(filename,"r"); //Abrimos el archivo en LittleFS
  #endif
  //Suponemos que no hay errores de apertura en el archivo, porque lo hemos
  //probado hace un momento con infoBMP

  //Leemos el offset de inicio de datos gráficos
  uint32_t offsetBase=0; //Offset de datos gráficos. Base (primer pixel)
  f.seek(10);
  f.read((byte *)&offsetBase,4);
  //El offset con el que trabajaremos será el del primer pixel de la primera línea
  offsetBase+=(uint32_t)bytesPerRow*((uint32_t)height-1);

  #ifdef ESP8266
    ESP.wdtDisable(); //Desactivamos WatchDog mientras dibujamos
  #endif
  
  //Diferenciaremos la rutina de decodificación gráfica dependiendo de la profundidad de color
  if(bytesPerPixel) { //Si es color...
    byte colorChannels[3]; //Componentes de color de un pixel
    uint16_t rx1=r.x1,rx2=r.x2,ry2=r.y2;
    offsetBase+=(r.x1-x)*3; //Sumamos el offset de x
    for(uint16_t row=r.y1;row<=ry2;row++) { //Recorremos las filas visibles del display
      f.seek(offsetBase-bytesPerRow*(row-y)); //Calculamos y posicionamos el offset en el archivo
      for(uint16_t col=rx1;col<=rx2;col++) { //Recorremos las columnas visibles del display
        f.read(colorChannels,3); //Leemos los componentes de color
        //El orden de lectura también es little endian -> BGR Lo ordenamos a RGB
        //Escribimos el color en el pixel procesado
        drawPixel(col,row,getColor(colorChannels[2],colorChannels[1],colorChannels[0]));
      }
    }
  } else { //Si es monocromo...
    byte readBits=0; //bits leidos
    byte pendingBits=0; //Bits pendientes de leer de readBits
    uint16_t rx1=r.x1,rx2=r.x2,ry2=r.y2;
    byte x8r=(rx1-x)%8; //Resto de 8 de la columna inicial
    offsetBase+=(rx1-x)/8;
    //Recorremos las filas visibles del display
    for(uint16_t row=r.y1;row<=ry2;row++) {
      //Calculamos y posicionamos el offset en el archivo
      f.seek(offsetBase-bytesPerRow*(row-y));
      pendingBits=0;
      if(x8r) {
        readBits=f.read();
        readBits<<=x8r;
        pendingBits=8-x8r;
      }
      //Recorremos todas las columnas visibles del display
      for(uint16_t col=rx1;col<=rx2;col++) {
        //Si no tenemos bits pendientes de leer...
        if(!pendingBits) {
          readBits=f.read(); //Leemos un nuevo byte
          pendingBits=8; //Ya tenemos 8 nuevos bits pendientes por leer
        }
        //Dibujamos el pixel con el color que corresponde
        drawPixel(col,row,readBits<128);
        //Ya tenemos un bit menos
        readBits<<=1;
        pendingBits--;
      }
    }
  }

  #ifdef ESP8266
    ESP.wdtEnable(1000); //Reactivamos las interrupciones de WatchDog
  #endif

  f.close(); //hemos terminado de utilizar el archivo
  return errorCode; //Devolvemos código de error
}


//Dibuja una línea utilizando el algoritmo de Bresenham
//Devuelve true si lo consigue
void RoJoGraph3::line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint32_t color) {
  int16_t tmp; //Para swap
  const bool steep=abs(y2-y1)>abs(x2-x1);
  
  if(steep) {
    tmp=x1;x1=y1;y1=tmp;
    tmp=x2;x2=y2;y2=tmp;
  }
 
  if(x1>x2) {
    tmp=x1;x1=x2;x2=tmp;
    tmp=y1;y1=y2;y2=tmp;
  }
 
  int16_t dx=x2-x1;
  int16_t dy=abs(y2-y1);
 
  int16_t err=dx/2;
  const int16_t ystep=y1<y2?1:-1;
 
  for(;x1<=x2;x1++) {
    if(steep) drawPixel(y1,x1,color);
    else drawPixel(x1,y1,color);
 
    err-=dy;
    if(err<0) {
      y1+=ystep;
      err+=dx;
    }
  }
}

//Dibuja un rectángulo sin relleno
//Devuelve si tiene parte visible
bool RoJoGraph3::rect(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t borderColor) {
  bool visible=block(x,y,width,1,borderColor); //Dibujamos el borde superior
  if(height>1) { //Si tiene borde inferior...
    visible|=block(x,y+height-1,width,1,borderColor); //...lo dibujamos
    if(height>2) { //Si tiene bordes laterales...
      visible|=block(x,y+1,1,height-2,borderColor); //...dibujamos el borde izquierdo
      if(width>1) visible|=block(x+width-1,y+1,1,height-2,borderColor); //Si tiene borde derecho...lo dibujamos
    }
  }
  return visible; //Respondemos si tiene parte visible
}

//Dibuja un triángulo sin relleno
void RoJoGraph3::triangle(int16_t x1,int16_t y1,int16_t x2,int16_t y2,int16_t x3,int16_t y3,uint32_t borderColor) {
  line(x1,y1,x2,y2,borderColor);
  line(x1,y1,x3,y3,borderColor);
  line(x2,y2,x3,y3,borderColor);
}

//Dibuja un triángulo relleno
void RoJoGraph3::triangleFill(int16_t x0,int16_t y0,int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint32_t fillColor) {
  int16_t tmp; //Para swap

  //Ordenamos en vertical: y0 <= y1 <= y2
  if(y0>y1) {
    tmp=x0;x0=x1;x1=tmp;
    tmp=y0;y0=y1;y1=tmp;
  }
  if(y1>y2) {
    tmp=x1;x1=x2;x2=tmp;
    tmp=y1;y1=y2;y2=tmp;
  }
  if(y0>y1) {
    tmp=x0;x0=x1;x1=tmp;
    tmp=y0;y0=y1;y1=tmp;
  }

  //Inicio y final de segmento horizontal
  int16_t a,b;

  //Si la primera y última coordenada vertical coinciden...
  if(y0==y2) {
    //Sólo tendremos que dibujar una línea horizontal
    //Calcularemos sus coordenadas horizontales con el mínimo (a) y el máximo (b)
    a=b=x0;
    if(x1<a) a=x1; else if(x1>b) b=x1;
    if(x2<a) a=x2; else if(x2>b) b=x2;
    //Dibujamos una línea horizontal
    block(a,y1,b-a+1,1,fillColor);
    //Hemos terminado
    return;
  }
  //El triángulo no forma una línea horizontal

  //Definición de variables
  int16_t dx01=x1-x0;
  int16_t dy01=y1-y0;
  int16_t dx02=x2-x0;
  int16_t dy02=y2-y0;
  int16_t dx12=x2-x1;
  int16_t dy12=y2-y1;
  int16_t sa=0;
  int16_t sb=0;
  int16_t last; //Última coordenada vertical a dibujar/rellenar
  int16_t y; //Coordenada vertical procesada

  //Calculamos la coordenada vertical hasta la que tenemos que dibujar/rellenar
  //Si la parte inferior del triángulo es horizontal...esa será la última
  if(y1==y2) last=y1;
  //Y si no...dibujaremos hasta una antes de llegar a la coordenada vertical intermedia
  else last=y1-1;
  
  //Dibujamos la parte superior del triángulo. Desde y0 a y1
  for (y=y0;y<=last;y++) {
    //Calculamos los extremos
    a=x0+sa/dy01;
    b=x0+sb/dy02;
    
    sa+=dx01;
    sb+=dx02;

    block(a,y,b-a+1,1,fillColor);
  }

  //Dibujamos la parte inferior del triángulo. Desde y1 a y2
  //Si y1==y2 no se dibuja nada
  sa=dx12*(y-y1);
  sb=dx02*(y-y0);
  for(;y<=y2;y++) {
    //Calculamos los extremos
    a=x1+sa/dy12;
    b=x0+sb/dy02;
    
    sa+=dx12;
    sb+=dx02;

    block(a,y,b-a+1,1,fillColor);
  }
}

//Dibuja una circunferencia
void RoJoGraph3::circle(int16_t x0,int16_t y0,int16_t r,uint32_t color) {
  int16_t f=1-r,ddF_x=1,ddF_y=-2*r,x=0,y=r;
  drawPixel(x0,y0+r,color);
  drawPixel(x0,y0-r,color);
  drawPixel(x0+r,y0,color);
  drawPixel(x0-r,y0,color);
  while (x<y) {
    if(f>=0) {
      y--;
      ddF_y+=2;
      f+=ddF_y;
    }
    x++;
    ddF_x+=2;
    f+=ddF_x;
    drawPixel(x0+x,y0+y,color);
    drawPixel(x0-x,y0+y,color);
    drawPixel(x0+x,y0-y,color);
    drawPixel(x0-x,y0-y,color);
    drawPixel(x0+y,y0+x,color);
    drawPixel(x0-y,y0+x,color);
    drawPixel(x0+y,y0-x,color);
    drawPixel(x0-y,y0-x,color);
  }
}

//Dibuja un círculo
void RoJoGraph3::disk(int16_t x,int16_t y,int16_t r,uint32_t color) {
  int16_t f=1-r,ddF_x=1,ddF_y=-2*r,x1=0,y1=r;
  block(x,y-r,1,2*r,color); //Línea vertical
  while(x1<y1) {
    if(f>=0) {
      y1--;
      ddF_y+=2;
      f+=ddF_y;
    }
    x1++;
    ddF_x+=2;
    f+=ddF_x;
    block(x+x1,y-y1,1,2*y1,color);
    block(x-x1,y-y1,1,2*y1,color);
    block(x+y1,y-x1,1,2*x1,color);
    block(x-y1,y-x1,1,2*x1,color);
  }
}

//Dibuja una elipse con o sin relleno
void RoJoGraph3::_ellipse(int16_t x,int16_t y,uint16_t rx,uint16_t ry,uint32_t color,bool fill) {
  int32_t rx0=rx,ry0=ry; //Homogeneizamos tipos de variables
  //Si algún radio es inferior a 2...no dibujamos nada
  if(rx<2 || ry<2) return;
  int32_t x1,y1;
  int32_t rx2=rx0*rx0; //Cuadrado del radio horizontal
  int32_t ry2=ry0*ry0; //Cuadrado del radio vertical
  int32_t fx2=4*rx2;
  int32_t fy2=4*ry2;
  int32_t s;

  for(x1=0,y1=ry0,s=2*ry2+rx2*(1-2*ry0);ry2*x1<=rx2*y1;x1++) {
    if(fill) {
      block(x-x1,y+y1,2*x1,1,color);
      block(x-x1,y-y1,2*x1,1,color);
    }
    else {
      drawPixel(x+x1,y+y1,color);
      drawPixel(x-x1,y+y1,color);
      drawPixel(x-x1,y-y1,color);
      drawPixel(x+x1,y-y1,color);
    }
    if(s>=0) {
      s+=fx2*(1-y1);
      y1--;
    }
    s+=ry2*(4*x1+6);
  }

  for(x1=rx0,y1=0,s=2*rx2+ry2*(1-2*rx0);rx2*y1<=ry2*x1;y1++) {
    if(fill) {
      block(x-x1,y+y1,2*x1,1,color);
      block(x-x1,y-y1,2*x1,1,color);
    }
    else {
      drawPixel(x+x1,y+y1,color);
      drawPixel(x-x1,y+y1,color);
      drawPixel(x-x1,y-y1,color);
      drawPixel(x+x1,y-y1,color);
    }
    if(s>=0) {
      s+=fy2*(1-x1);
      x1--;
    }
    s+=rx2*(4*y1+6);
  }
}
void RoJoGraph3::ellipse(int16_t x,int16_t y,uint16_t rx,uint16_t ry,uint32_t color) {
  _ellipse(x,y,rx,ry,color,false);
}
void RoJoGraph3::ellipseFill(int16_t x,int16_t y,uint16_t rx,uint16_t ry,uint32_t color) {
  _ellipse(x,y,rx,ry,color,true);
}


//Imprime el texto indicado basado en una fuente en el display
//Se indica el color del texto
//Respuesta: true si lo consigue
bool RoJoGraph3::printOver(String filenameFon,String text,uint32_t textColor,int16_t x,int16_t y) {
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filenameFon,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos LittleFS...
    //...ya se inicializó en el constructor
    File f=LittleFS.open(filenameFon,"r"); //Abrimos el archivo en LittleFS
  #endif
  //Si hubo algún problema...hemos terminado
  if(!f) return false;
  //Definimos variables de trabajo
  byte charMin; //Primer carácter ASCII incluido en librería
  byte charMax; //Último carácter ASCII incluido en librería
  byte charCurrent; //Carácter procesado
  byte charWidth; //Anchura de carácter procesado
  byte charPages=0; //Altura en páginas
  byte pageByte; //Byte gráfico actualmente procesado
  uint16_t charOffset; //Offset de datos gráficos del carácter en el archivo de fuentes
  //Leemos ASCII del primer carácter de la fuente
  f.readBytes((char *)&charMin,1);
  //Leemos ASCII del último carácter de la fuente
  f.readBytes((char *)&charMax,1);
  //Leemos el número de páginas
  f.readBytes((char *)&charPages,1);

  //Variable para guardar la posición x en la que estamos
  //escribiendo en el sprite
  uint16_t xx=0;
  //Recorremos todos los caracteres del string
  for(byte i=0;i<text.length();i++) {
    //Extraemos el carácter procesado
    charCurrent=text[i];
    //Si el carácter está dentro del rango de la fuente...
    //(si no pertenece a la fuente, no lo tenemos en cuenta)
    if(charCurrent>=charMin && charCurrent<=charMax) {
      //Si no es el primer carácter...dejaremos una separación
      if(xx>0) xx++;
      //Obtenemos la anchura del carácter
      f.seek(3+3*(charCurrent-charMin));
      f.read((byte *)&charWidth,1);
      //Obtenemos el índice de inicio de los datos gráficos del carácter
      f.read((byte *)&charOffset,2);
      //Posicionamos el offset para leer los datos gráficos
      f.seek(charOffset);
      //Recorremos todas las páginas de altura
      for(byte p=0;p<charPages;p++) {
        //Recorremos las columnas que forman el carácter
        for(byte c=0;c<charWidth;c++) {
          //Leemos el byte de la página
          f.read((byte *)&pageByte,1);
          //Recorremos todos sus bits
          for(byte b=0;b<8;b++) {
            //Si el pixel está activo...lo activamos
            if((1<<b) & pageByte) drawPixel(x+xx+c,y+p*8+b,textColor);
          }
        }
      }
      //El siguiente caracter lo comenzaremos a escribir a una distancia
      //igual a la anchura del carácter escrito
      xx+=charWidth;
    }
  }
  //Hemos terminado de utilizar el archivo de fuentes
  f.close();
  //Todo correcto
  return true;
}

//Devuelve el número de bytes por pixel 0=monocromo,1=gris,2=color,3=color real
byte RoJoGraph3::bytesPerPixel() {
  return _bytesPerPixel;
}

//Información sobre el tamaño de un texto
//Devuelve true si la respuesta es válida
bool RoJoGraph3::infoPrint(String filenameFon,String text,uint16_t *width,uint16_t *heigth) {
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filenameFon,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos LittleFS...
    //...ya se inicializó en el constructor
    File f=LittleFS.open(filenameFon,"r"); //Abrimos el archivo en LittleFS
  #endif
  //Si hubo algún problema...hemos terminado
  if(!f) return false;
  //Definimos variables de trabajo
  byte charMin; //Primer carácter ASCII incluido en librería
  byte charMax; //Último carácter ASCII incluido en librería
  byte charCurrent; //Carácter procesado
  byte charWidth; //Anchura de carácter procesado
  byte charPages=0; //Altura en páginas
  //Leemos ASCII del primer carácter de la fuente
  f.readBytes((char *)&charMin,1);
  //Leemos ASCII del último carácter de la fuente
  f.readBytes((char *)&charMax,1);
  //Leemos el número de páginas
  f.readBytes((char *)&charPages,1);

  //Calculamos la anchura del sprite = suma de la anchura de todos los
  //caracteres y espacios separadores
  //Inicialmente la anchura del sprite es 0
  *width=0;
  //Recorremos todos los caracteres del texto
  for(uint16_t i=0;i<text.length();i++) {
    //Extraemos el carácter procesado
    charCurrent=text[i];
    //Si el carácter pertenece a los caracteres de la fuente...
    //(si no pertenece a la fuente, no lo tenemos en cuenta)
    if(charCurrent>=charMin && charCurrent<=charMax) {
      //...este carácter será representado
      //Si este no es el primer carácter, añadiremos una
      //columna de separación.
      if(*width>0) (*width)++;
      //Obtenemos la anchura del carácter
      f.seek(3+3*(charCurrent-charMin));
      f.read((byte *)&charWidth,1);
      //Añadimos la anchura del carácter
      *width+=charWidth;
    }
  }
  //Tenemos calculada la anchura del sprite en *width

  //Hemos terminado de utilizar el archivo de fuentes
  f.close();
  //La altura en pixels serán las páginas*8
  *heigth=(uint16_t)charPages*8;
  //Todo Ok
  return true;
}

#endif

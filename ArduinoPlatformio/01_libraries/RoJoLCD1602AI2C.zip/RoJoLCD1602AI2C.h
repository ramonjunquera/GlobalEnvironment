/*
  Nombre de la librería: RoJoLCD1602AI2C.h
  Versión: 20220118
  Autor: Ramón Junquera
  Descripción:
    Gestión de display LCD de 16x2 por conexión I2C
  Notas:
    El adaptador es un simple expansor de puertos conectado por I2C.
    Cada byte enviado corresponde con un pin con la siguiente distribución:
      bit
       7 - D4
       6 - D5
       5 - D6
       4 - D7
       3 - A/LED+. Backlight power supply
       2 - E. Operation Enable. LOW=disabled, HIGH=enabled
       1 - RW. Read/Write. LOW=Write, HIGH=Read
       0 - RS. Register Select. LOW=command, HIGH=character
    Estos son los mismos pines que utilizamos en una conexión directa y son suficientes
    para poder controlar el display.
*/

#ifndef RoJoLCD1602A_h
#define RoJoLCD1602A_h

#include <Arduino.h>
#include <_RoJoLCD1602A.h>
#include <Wire.h>

class RoJoLCD1602AI2C:public _RoJoLCD1602A {
  private:
    const byte _I2Cid=0x27; //Identificador I2C del adaptador
    virtual void _send(byte value,bool mode); //Envía un byte al display seleccionando el modo (comando o carácter)
    virtual void _sendHalf(byte value); //Envía el medio byte inferior
  public:
    void begin(); //Inicialización
    virtual void backlight(bool status); //Luz de fondo. LOW=off, HIGH=on
};

#ifdef __arm__
  #include <RoJoLCD1602AI2C.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

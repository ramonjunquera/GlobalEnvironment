/*
  Nombre de la librería: RoJoLCD1602AI2C.h
  Versión: 20220119
  Autor: Ramón Junquera
  Descripción:
    Gestión de display LCD de 16x2 por conexión I2C
*/

#ifndef RoJoLCD1602AI2C_cpp
#define RoJoLCD1602AI2C_cpp

#include <RoJoLCD1602AI2C.h>

//Envía un byte al display seleccionando el modo (comando=LOW o carácter=HIGH)
void RoJoLCD1602AI2C::_send(byte value,bool mode) {
  //Debemos enviar dos medios bytes. Primero el superior y después el inferior
  //Recordamos la correspondencia de bits y pines
  // bit  7  6  5  4  3  2  1  0
  // pin D4 D5 D6 D7  A  E RW RS

  byte halfByteConfig=(_backlight<<3)+mode; //Medio byte inferior a enviar con configuración
  byte sendByte=(value & 0xF0)+halfByteConfig; //Calculamos byte de envío con la mitad superior de datos
  Wire.beginTransmission(_I2Cid);
    Wire.write(sendByte+4); //Enviamos dato activando el pulso para que lea los datos
    delayMicroseconds(1); //El pulso debe durar un mínimo de 300ns. Esperaremos 1000ns
    Wire.write(sendByte); //Enviamos dato desactivando el pulso
    delayMicroseconds(1); //Damos tiempo para que se pueda distinguir el siguiente pulso
    sendByte=(value<<4)+halfByteConfig; //Calculamos byte de envío con la mitad inferior de datos
    Wire.write(sendByte+4); //Enviamos dato activando el pulso para que lea los datos
    delayMicroseconds(1); //El pulso debe durar un mínimo de 300ns. Esperaremos 1000ns
    Wire.write(sendByte); //Enviamos dato desactivando el pulso
	Wire.endTransmission();
  delayMicroseconds(1); //Damos tiempo para que se pueda distinguir el siguiente pulso
}

//Luz de fondo. LOW=off, HIGH=on
void RoJoLCD1602AI2C::backlight(bool status) {
  _backlight=status;
  Wire.beginTransmission(_I2Cid);
		Wire.write(_backlight<<3); //Enviamos dato vacío, activando sólo el pin de backlight
	Wire.endTransmission();
}

//Inicialización
void RoJoLCD1602AI2C::begin() {
  Wire.begin();
  delay(50); //El display necesita 40ms para su inicializacion según el manual. Le daremos 50ms
  
  //Fijamos el modo de envío de 4 bits
  //El procedimiento es bastante curioso. Para que funcione correctamente en todas las 
  //situaciones, debemos activar 3 veces el modo de envío de 8 bits y a continuación el de 4 bits
  byte lowHalfByte=_backlight<<3;
  Wire.beginTransmission(_I2Cid);
		Wire.write(0x30+lowHalfByte); //Enviamos medio byte alto del comando 0x30 = modo de envío 8 bits
    delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
    Wire.write(0x30+lowHalfByte); //Enviamos medio byte alto del comando 0x30 = modo de envío 8 bits
    delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
    Wire.write(0x30+lowHalfByte); //Enviamos medio byte alto del comando 0x30 = modo de envío 8 bits
    delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
    Wire.write(0x30+lowHalfByte); //Enviamos medio byte alto del comando 0x30 = modo de envío 8 bits
    delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
    Wire.write(0x20+lowHalfByte); //Enviamos medio byte alto del comando 0x20 = modo de envío 4 bits
    delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
	Wire.endTransmission();

  _send(_displaycontrol,LOW); //Enviamos el comando que fija el comportamiento del display
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  _send(0x06,LOW); //Comando para fijar el modo de entrada (0x04) + de izquierda a derecha (0x02)
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  clear(); //Limpiamos la pantalla
}

#endif

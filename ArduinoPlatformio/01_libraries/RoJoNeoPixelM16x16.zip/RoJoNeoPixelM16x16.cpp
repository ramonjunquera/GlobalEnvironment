/*
  Nombre de la librería: RoJoNeoPixelM16x16.h
  Versión: 20220517
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixelM16x16_cpp
#define RoJoNeoPixelM16x16_cpp

#include <RoJoNeoPixelM16x16.h>

//Inicialización
//Devuelve true si lo consigue
bool RoJoNeoPixelM16x16::begin(byte pin) {
  return RoJoNeoPixel::begin(xMax*yMax,pin);
}

//Convierte coordenadas en índice
byte RoJoNeoPixelM16x16::_XY2Index(byte x,byte y) {
  if(y%2) return y*16+x; //Fila impar
  return y*16+15-x; //Fila par
}

//Dibuja pixel en memoria de video
//Devuelve true si lo consigue
bool RoJoNeoPixelM16x16::drawPixel(byte x,byte y,uint32_t color) {
  if(!_ledsCount) return false; //No inicializado
  if(x>xMax || y>yMax) return false; //Fuera de rango
  pixelGRB pixel;
  pixel.setColor(color);
  videoMem[_XY2Index(x,y)]=pixel;
  return true;
}

//Devolvemos color de un pixel
//Si seleccionamos unas coordenadas fuera de rango, devuelve 0
uint32_t RoJoNeoPixelM16x16::getPixel(int16_t x,int16_t y) {
  if(x<0 || x>=xMax || y<0 || y>=yMax) return 0; //Si fuera de rango...color negro
  return videoMem[_XY2Index(x,y)].getColor();
}

//Borra el display
//Devuelve true si lo consigue
bool RoJoNeoPixelM16x16::clear(uint32_t color) {
  if(!_ledsCount) return false; //No inicializado
  pixelGRB pixel;
  pixel.setColor(color);
  for(uint16_t i=0;i<_ledsCount;i++) videoMem[i]=pixel; //Llenamos la memoria de video
  return true;
}

//Dibuja un sprite en unas coordenadas
bool RoJoNeoPixelM16x16::drawSprite(RoJoSprite *source,int16_t x,int16_t y) {
  if(!_ledsCount) return false; //No inicializado
  displayRange r=source->visibleRange(-x,-y,xMax,yMax); //Comprobamos si hay área visible
  if(!r.visible) return true; //Si no es visible...terminamos
  pixelGRB pixel;
  uint16_t ry2=r.y2,rx1=r.x1,rx2=r.x2;
  for(uint16_t y0=r.y1;y0<=ry2;y0++) {
    for(uint16_t x0=rx1;x0<=rx2;x0++) {
      pixel.setColor(source->getPixel(x0,y0));
      videoMem[_XY2Index(x0+x,y0+y)]=pixel;
    }
  }
  return true;
}

#endif

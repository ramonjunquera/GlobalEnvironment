/*
  Tema: Librería de gestión de Servomotores para familia Arduino
  Fecha: 20221102
  Autor: Ramón Junquera

  Funcionamiento de un servo:
  Un servomotor sólo necesita un pin de datos.
  El ángulo de giro es proporcional a la duración de un pulso alto.

  Definición de tiempos:
  - Duración de pulso: tiempo que se mantiene la señal a HIGH en la línea de datos
  - Duración de ciclo: duración de pulso alto + duración de pulso bajo

  Magnitudes de tiempo prácticas según fabricante:
  - Duración de pulso alto para 0 grados: 500us
  - Duración de pulso alto para 180 grados: 2500us
  - Duración mínima de ciclo: 15000us
  - Duración máxima de ciclo: 65535us (puede ser más)

  Cálculo de frecuencias:
  - Frecuencia mínima = 1/periodo = 1/65535us = 1/65.535ms = 1/0.065535s = 15.3Hz
  - Frecuencia máxima = 1/periodo = 1/15000us = 1/15ms = 1/0.015s = 66.7Hz

  Deducciones:
  El pulso más largo (180 grados = 2500us) toma un 2500/65535*100=3.8% de la duración del ciclo.
  Eso quiere decir que la mayor parte del tiempo la pasa manteniendo el pulso bajo.

  Timers:
  Para controlar los tiempos con precisión utilizaremos interrupciones (timers).
  Para los dispositivos de la familia Arduino (UNO, Nano, Mega), se utiliza la interrupción del
  timer 1, que es común a todos ellos, para generar una señal de pulso.
  Puesto que sólo utiliza la interrupción 1, es suficiente con la librería RoJoTimerAVR1.h
  Al utilizar la interrupción 1 quedarán inutilizado el PWM para los pines 9 y 10.

  Método1 de control de varios servos:
  Con la limitación de un único timer, podríamos tomar el tiempo total de duración de ciclo y hacer saltar la
  interrupción con una frecuecia constante.
  En la función de interrupción llevaríamos un control de la posición en la que nos encontramos dentro del
  periodo del ciclo completo.
  Así podríamos cambiar el estado del pulso, dependiendo de sus límites y ángulo solicitado.
  - Ventajas:
    - Podemos controlar tantos servos como queramos, sin limitación. Dentro de la función de interrupción incluimos 
      un bucle que gestiones el estado del pulso para cada servo.
  - Inconvenientes
    - Puesto que la mayor parte del tiempo de ciclo, el pulso se mantiene bajo, estaríamos desperdiciendo mucha
      potencia de cálculo. En cada interrupción se gestionan todos los servos a la vez.
    - La resolución (control de tiempos) no es muy fina. Tendríamos menos interrupciones que grados.
  - Conclusión: método descartado

  Método2 de control de varios servos:
  Utilizando una única interrupción, podríamos gestionar sólo un servo, controlando la duración del pulso alto, y
  al terminar, controlar otro servo distinto mientras el primero mantiene su pulso bajo.
  El número de servos está acotado por cuántos pulsos altos de duración máxima consecutivos puede albergar un ciclo
  completo.
  - Duración máxima de pulso alto (180 grados) = 2500us
  - Duración de ciclo = 65535us
  - Número de pulsos altos por ciclo = 65535/2500 = 26.2 pulsos
  Redondeando a la baja tenemos que podemos gestionar 26 pulsos de duración máxima dentro de un ciclo.
  Este sería el límite de servos que podremos controlar con una sola interrupción, siempre que controlemos los servos
  consecutivamente. Estamos tomando 65535 como valor máximo, pero en la práctica el valor es mayor.
  - Ventajas:
    - Control de tiempos muy preciso. Sin problema para ajustar hasta el grado.
    - La función de interrupción es muy liviana y sólo salta cuando hay algún cambio no periódicamente.
  - Inconconvenientes:
    - Limitación de número de servos controlados. Sabemos que al menos soporta 26.
  - Conclusión: método aceptado

  Ajuste de duración de ciclo:
  La función de inicialización (begin) permitirá el parámetro usCycleMin con la duración en microsegundos del mínimo ciclo.
  En cada ciclo se tendrá en cuenta este valor y se intentará que la duración del ciclo sea mínima (para
  aumentar la frecuencia), teniendo en cuenta el número de servos y la duración mínima.

  Valores reales vs teóricas:
  Aunque el fabricante nos indique que la duración de los pulsos de 0 y 180 grados son 500us y 2500us, debido a los
  cálculos de la librería de interrupciones y las llamadas internas, los valores reales no coinciden
  Teniendo en cuenta la experiencia, se tomarán los siguientes valores:
  - Duración de pulso alto para 0 grados: 450us
  - Duración de pulso alto para 180 grados: 2200us
  - Duración mínima de ciclo: 13500us

  Control de tiempos:
  La función micros() nos devuelve un uint32_t con los microsegundos transcurridos desde el último reset del procesador.
  El valor máximo de tiempo que puede almacenar es de (2^32-1)/1000000/60=71.6 minutos.
  El sistema puede estar funcionando durante más tiempo. No es un límite válido.
  Se crea la variable _RoJoServo_clock del tipo uint64_t que puede contener (2^64-1)/1000000/60/60/24/365=584942 años.
  Esta variable acumulará los tiempos dedicados a timers.

  Velocidad angular constante:
  Utilizaremos la siguiente fórmula para al cálculo del ángulo en el tiempo:
    angle=t1-speed*(t1-t)
  Y t1 lo calcularemos como:
    t1=t0+abs(a1-a0)/speed
  Por lo tanto, para calcular el ángulo en función del tiempo, sólo necesitaremos almacenar los valores de t1 y speed

  Velocidad angular variable:
  El movimiento comienza y finaliza despacio.
  Utilizaremos la función sigmoide (sigmoid) en vez de una lineal como en el caso anterior.
  La función sigmoidea original es y=1/(1+exp(-x)).
  Está acotada en vertical entre el 0 y 1.
  Horizontalmente es una función continua.
  Adaptamos la función a nuestros límites con:
    angle(t)=angle0+(angle1-angle0)/(1+exp(-(t-(t0+t1)/2)/100000))
  Donde:
  - t0 = tiempo inicial
  - t1 = tiempo final
  - angle0 = ángulo inicial
  - angle1 = ángulo final
  Podemos simplificar:
  - (angle1-angle0) como deltaAngle o diferencia de ángulos o rango a barrer
  - (t0+t1)/2 como deltaT2 o tiempo medio
  La fórmula queda como:
    angle(t)=angle0+deltaAngle/(1+exp(-(t-deltaT2)/100000))
  La contante 100000 undica la suavidad del movimiento
  En la función sigmoide original tenemos que para valores que se alejan 5 unidades del eje y, ya consigen un 99% del
  valor final. Puesto que nosotros trabajamos con microsegundos podemos contruior la siguiente tabla:
       k     us
    ------ ------
         1      5
         2     10
        10     50
     60000 300000
    100000 500000
  La relación entre las columnas es us=5*k
  Con k=100000 tenemos que los primeros y los últimos 500000us=0.5s reducirá la velocidad

  Notas:
  - Existe una incompatibilidad con la función delay() con ESP32. Da un error de excepción general
    En su lugar se puede utilizar delayMicroseconds.
  - Existe una incompatibilidad con la función delayMicroseconds() con Arduino. Con independencia del
    valor del parámetro, nunca espera nada. Se debe utilizar delay().
*/

#ifndef RoJoServo_h
#define RoJoServo_h

#include <Arduino.h>
#ifdef ARDUINO_ARCH_AVR
  #include <RoJoTimerAVR1.h>
#elif defined(ESP8266)
  #include <RoJoTimerESP8266.h>
#elif defined(ESP32)
  #include <RoJoTimerESP32.h>
#elif defined(__arm__)
  #include <math.h>
  #include <RoJoTimerRPi.h>
#endif

struct _RoJoServo_servoConfig {
  byte pin=255;
  uint16_t us0; //Duración en microsegundos de pulso alto para 0 grados
  uint16_t us180; //Duración en microsegundos de pulso alto para 180 grados
  bool enabled; //Servo activo?
  byte angle; //[0,180] Ángulo actual
  uint16_t usAngle; //Duración de pulso alto del ángulo actual
  bool isMoving; //Se está moviendo?
  float speed_deltaT2; //Velocidad angular en grados/s en veloicidad constante y tiempo medio en velocidad variable
  uint64_t t1; //Tiempo final del movimiento
  byte angle1; //Ángulo destino
  byte angle0; //Ángulo inicial
  uint64_t t0; //Tiempo inicial
  float deltaAngle; //t1-t0
};

class RoJoServo {
private:
public:
  bool begin(byte servoCount=1,uint16_t us180default=2200,uint16_t usCycleMin=13500);
  void end();
  ~RoJoServo();
  bool setCfg(byte servoIndex,byte pin,uint16_t us0=450,uint16_t us180=2200);
  bool enable(byte servoIndex,bool enabled=true);
  byte getAngle(byte servoIndex=0);
  bool isMoving(byte servoIndex=0);
  bool move(byte servoIndex=0,byte angle=0,byte speedMode=0,float speed=30,bool waitUntilEnd=true);
};

#include <RoJoServo.cpp>

#endif

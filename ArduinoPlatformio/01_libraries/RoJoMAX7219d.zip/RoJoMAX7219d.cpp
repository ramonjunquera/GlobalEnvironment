/*
  Nombre de la librería: RoJoMAX7219d.h
  Versión: 20211014
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a display de dígitos de leds
*/

#ifndef RoJoMAX7219d_cpp
#define RoJoMAX7219d_cpp

#include <RoJoMAX7219d.h>

//Envía una instrucción
void RoJoMAX7219d::_localCommand(byte command, byte value) {
  shiftOut(_pinDIN,_pinCLK,MSBFIRST,command);
  shiftOut(_pinDIN,_pinCLK,MSBFIRST,value);
}

//Envía una instrucción a todos los chips
void RoJoMAX7219d::_globalCommand(byte command, byte value) {
  digitalWrite(_pinCS,LOW); //Antes de enviar una instrucción, siempre desactivamos el pin CS
  //Recorremos todos los chips y enviamos la instrucción
  for(byte chip=0;chip<_chainedChips;chip++) _localCommand(command,value);
  digitalWrite(_pinCS,HIGH); //Fin de envío
}

//Fija el brillo de los leds
void RoJoMAX7219d::setBrightness(byte brightness) {
  //El rango de valores permitidos está entre 0 y 15
  //Se podría fijar distinto brillo a cada chip. No lo haremos
  //Asignaremos el mismo a todos
  _globalCommand(0x0A,brightness & 15); //max7219_reg_intensity
}

//Dibuja la memoria de vídeo en el display
void RoJoMAX7219d::draw() {
  const byte chainedChips8=_chainedChips*8-1;
  for(byte x=0;x<8;x++) { //Recorreremos todas las columnas que gestiona un chip
    const byte chainedChips8x=chainedChips8-x;
    //Antes de enviar una serie de instrucciones, siempre desactivamos el pin CS
    digitalWrite(_pinCS,LOW);
    //Recorreremos todos los chips
    //Recordemos que la primera instrucción enviada corresponderá al chip con número de
    //secuencia más alto y la última instrucción afectará al chip 0
    for(byte chip=_chainedChips-1;chip!=255;chip--) {
      //El comando corresponde con el número de columna + 1
      //Y el valor con el byte de la columna que corresponde en la memoria de vídeo
      _localCommand(x+1,videoMem[chainedChips8x-chip*8]);
    }
    digitalWrite(_pinCS,HIGH); //Fn de envío
  }
}

//Reset & inicialización
void RoJoMAX7219d::reset() {
  //No se restinge el número de segmentos por dígito. Se dibujarán todos
  _globalCommand(0x0B,0x07); //max7219_reg_scanLimit
  //La decodificación se producen en origen
  _globalCommand(0x09,0x00); //max7219_reg_decodeMode
  //Salimos del modo shutdown en el que se encuentran al arrancar. Los activamos!  
  _globalCommand(0x0C,0x01); //max7219_reg_shutdown
  //No hace falta hacer el test de display (encender todos los leds)
  _globalCommand(0x0F,0x00); //max7219_reg_displayTest
  //Fijamos el brillo por defecto a 8
  setBrightness(8);
  //Borramos la memoria de vídeo
  clear();
  //Si no se ha actualizado...lo hacemos manualmente
  if(!autoDraw) draw();
}

//Inicialización
//Devuelve true si lo consigue
bool RoJoMAX7219d::begin(byte chainedChips,byte pinDIN,byte pinCS,byte pinCLK) {
  //Por lo menos tiene que haber un chip
  if(chainedChips==0) return false;
  //Reservamos memoria suficiente para todos los chips
  videoMem=new byte[chainedChips*8];
  //Si no hemos podido reservar memoria...terminamos con error
  if(!videoMem) return false;
  //Guardamos los valores de los parámetros en las variables privadas
  _chainedChips=chainedChips;
  _pinDIN=pinDIN;
  _pinCS=pinCS;
  _pinCLK=pinCLK;
  //Definimos los pines de conexión como de salida
  pinMode(_pinDIN,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  pinMode(_pinCLK,OUTPUT);
  digitalWrite(_pinCS,HIGH); //Activamos el pin CS
  reset(); //Reseteamos el display
  return true; //Todo Ok
}

//Vacía la memoria de vídeo
void RoJoMAX7219d::clear() {
  //Borramos la memoria de video
  int8_t offset=_chainedChips*8;
  while(--offset>=0) videoMem[offset]=0;
  if(autoDraw) draw(); //Si se dibuja automáticamente...lo hacemos
}

//Destructor
RoJoMAX7219d::~RoJoMAX7219d() {
  delete videoMem; //Liberamos la memoria ocupada por la memoria de video
}

//Muestra un carácter (digit display)
void RoJoMAX7219d::print(int16_t x,byte charCode,bool dot) {
  if(x<0 || x>=_chainedChips*8) return; //Si no es visible...hemos terminado
  videoMem[x]=_chars[charCode]+128*dot; //Escribimos el caracter
  if(autoDraw) draw(); //Si se dibuja automáticamente...lo hacemos
}

//Muestra un número entero en el display
void RoJoMAX7219d::printInt(int64_t number,byte startPos,byte digits,bool leftZeros) {
  if(!digits) return; //Si la longitud es cero...hemos terminado
  if(number<0) { //Si el número es negativo...
    //El primer carácter es un menos
    print(startPos,17,false);
    //Ahora mostraremos un número positivo
    number=-number;
    //Comenzaremos en la siguiente posición
    startPos++;
    //Tendremos un dígito menos
    digits--;
  }
  //Definimos variable que contendrá el código de carácter
  byte charCode;
  //Recorremos todos los dígitos
  for(byte d=digits;d>0;d--) {
    //Obtenemos el código del carácter a mostrar (unidades)
    charCode=number%10;
    //Si lo que queda del número es cero...
    //...y no se deben mostrar...
    //...y no es el primer dígito escrito...
    //...el carácter a mostrar será un espacio
    if(!number && !leftZeros && digits!=d) charCode=16;
    //Mostramos el dígito de unidades sin punto
    print(startPos+d-1,charCode,false);
    //Eliminamos las unidades
    number/=10;
  }
  if(autoDraw) draw(); //Si se dibuja automáticamente...lo hacemos
}

//Muestra un número decimal en el display
void RoJoMAX7219d::printDec(double number,byte startPos,byte intDigits,byte fracDigits,bool leftZeros) {
  //Se indican como parámetros el valor a mostrar, el número de digitos enteros (signo incluido),
  //el número de dígitos decimales y si se debe rellenar las posiciones iniciales con ceros
  bool intZero=((int64_t)number)==0; //La parte entera es cero?
  //Pasamos a la parte entera tantos decimales como nos indiquen
  for(byte i=0;i<fracDigits;i++) number*=10;
  //Escribimos el número entero con signo incluido
  printInt((int64_t)number,startPos,intDigits+fracDigits,leftZeros);
  //Si la cifra de las unidades es visible...
  if(startPos+intDigits-1<_chainedChips*8) {
    //Si no hay que poner ceros a la izquierda...
    //...y la parte entera era cero...
    //...escribimos un cero como cifra de unidades
    if(!leftZeros && intZero) videoMem[startPos+intDigits-1]=_chars[0];
    //Activamos el punto en las unidades
    videoMem[startPos+intDigits-1]+=128;
  }
  if(autoDraw) draw(); //Si se dibuja automáticamente...lo hacemos
}

#endif

﻿/*
  Nombre de la librería: RoJoMAX7219d.h
  Versión: 20211014
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a display de dígitos de leds

  Recordemos pinouts
  
  De 4-digits led display:

       12 11 10  9  8  7
       C0  a  f C1 C2  b
        ¦  ¦  ¦  ¦  ¦  ¦
  ¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦
  ¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦
  ¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦¦
        ¦  ¦  ¦  ¦  ¦  ¦
        e  d  h  c  g C3
        1  2  3  4  5  6

  Distribución de segmentos:
  
        a
      ¦¦¦¦¦¦
    ¦¦      ¦¦
  f ¦¦      ¦¦ b
    ¦¦  g   ¦¦
      ¦¦¦¦¦¦
    ¦¦      ¦¦
  e ¦¦      ¦¦ c
    ¦¦      ¦¦
      ¦¦¦¦¦¦     ¦¦ h
        d

  De MAX7219:
           
    24  23 22  21  20 19  18  17  16 15  14  13
   DOUT C5 C1  C6  C4 V+ ISET C8  C3 C7  C2  CLK
    │   │   │   │   │   │  │   │   │  │   │  │
  ███████████████████████████████████████████████
  ███████████████████████████████████████████████
    ████████████████ MAX7219 █████████████████████
  ███████████████████████████████████████████████
  ███████████████████████████████████████████████
    │   │  │   │   │  │   │   │   │  │   │   │
   DIN  F1 F5 GND  F7 F3  F4  F8 GND F6  F2 LOAD      
    1   2   3  4   5   6   7  8   9  10  11  12      
        
        
  DIN = Primero de los tres pines conectados a la placa
  LOAD = Segundo de los tres pines conectados a la placa
  CLK = Tercero de los tres pines conectados a la placa
  DOUT = Salida a conectar con la pata DIN del siguiente chip de la cadena
  GND = Tierra
  V+ = Alimentación. Funciona a 3.3V. Sugeridos 5V
  ISET = Siempre estará conectado a V+ a través de una resistencia
  Fx = Filas
  Cx = Columnas
  
  La librería RoJoMAX7219d es una variación de RoJoMAX7219, de la que se ha
  eliminado el trabajo con sprites para reducir el consumo de memoria.
  Especialmente diseñada para trabajar con el chip MAX7219 y con displays
  de led de dígitos.
  Permite definir caracteres especiales, aunque ya tiene un alfabeto por defecto.

  Notas:
  - La memoria de video es pública para que pueda ser accedida por el usuario.
    Así podrá escribir caracteres personalizados directamente.
  - La memoria de video representa los caracteres de izquierda a derecha.
    La posición 0 es la que se encuentra más a la izquierda.
  - La codificación de los segmentos en un byte de la memoria de videos es .abcdefg
  - La identificación de los chips encadenados en de mayor a menor.
    El último chip es el 0.
*/

#ifndef RoJoMAX7219d_h
#define RoJoMAX7219d_h

#include <Arduino.h>

class RoJoMAX7219d {
  private:
    byte _pinDIN;
    byte _pinCS;
    byte _pinCLK;
    byte _chainedChips=0; //Número de chips MAX7219 encadenados
    void _localCommand(byte command, byte value); //Envía un único comando
    void _globalCommand(byte command, byte value); //Envía un comando a todos los chips
    //Definición de los caracteres que se pueden mostrar en display de dígitos
    //Formato de bits abcdefgh
    const byte _chars[19]= { 
      0b01111110 // 0 = 0
     ,0b00110000 // 1 = 1
     ,0b01101101 // 2 = 2
     ,0b01111001 // 3 = 3
     ,0b00110011 // 4 = 4
     ,0b01011011 // 5 = 5
     ,0b01011111 // 6 = 6
     ,0b01110010 // 7 = 7
     ,0b01111111 // 8 = 8
     ,0b01111011 // 9 = 9
     ,0b01110111 //10 = A
     ,0b00011111 //11 = b
     ,0b01001110 //12 = C
     ,0b00111101 //13 = d
     ,0b01001111 //14 = E
     ,0b01000111 //15 = F
     ,0b00000000 //16 = space
     ,0b00000001 //17 = -
     ,0b01100011 //18 = º
    };
  public:
    bool autoDraw=true; //Refresco automático. Por defecto sí
    ~RoJoMAX7219d(); //Destructor
    void reset(); //Reset
    byte *videoMem=NULL; //Puntero a memoria de vídeo
    bool begin(byte chainedChips,byte pinDIN, byte pinCS, byte pinCLK);
    void setBrightness(byte brightness); //Fija el brillo de los leds
    void draw(); //Dibuja la memoria de vídeo en el display
    void clear(); //Limpia la memoria de vídeo
    void print(int16_t x,byte charCode,bool dot); //Muestra un carácter (digit display)
    void printInt(int64_t number,byte startPos,byte digits,bool leftZeros); //Muestra un entero (digit display)
    void printDec(double number,byte startPos,byte intDigits,byte fracDigits,bool leftZeros); //Muestra un decimal (digit display)
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoMAX7219d.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


/*
  Nombre de la librería: RoJoNeoPixelM32x8.h
  Versión: 20220517
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixelM32x8_h
#define RoJoNeoPixelM32x8_h

#include <Arduino.h>
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoNeoPixel.h>

class RoJoNeoPixelM32x8:public RoJoNeoPixel {
  private:
    byte _XY2Index(byte x,byte y);
  public:
    const uint16_t xMax=32; //Anchura de display
    const uint16_t yMax=8; //Altura de display
    bool begin(byte pin); //Inicialización
    bool drawPixel(byte x,byte y,uint32_t color);
    uint32_t getPixel(int16_t x,int16_t y); //Devolvemos color de pixel
    bool clear(uint32_t color=0);
    bool drawSprite(RoJoSprite *source,int16_t x=0,int16_t y=0); //Dibuja un sprite en unas coordenadas
}; //Punto y coma obligatorio para que no de error

#include <RoJoNeoPixelM32x8.cpp>

#endif


/*
  Nombre de la librería: RoJoSSD1331.h
  Versión: 20220107
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 0.95" 96x64 SSD1331
    Permite la gestión de sprites
*/

#ifndef RoJoSSD1331_h
#define RoJoSSD1331_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite3.h> //Gestión de sprites
#include <RoJoGraph3.h> //Gestión de gráficos avanzados

class RoJoSSD1331:public RoJoGraph3 {
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    SPISettings _spiSetting; //Características de la conexión SPI
    void _setCursorRangeX(int16_t x1,int16_t x2); //Define rango X
    void _setCursorRangeY(int16_t y1,int16_t y2); //Define rango Y
    void _setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2);
    const byte _xMax=96; //Anchura de display
    const byte _yMax=64; //Altura de display
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _fill(bool f); //Activa/desactiva el relleno de los rectángulos
    void _rect(byte x1,byte y1,byte x2,byte y2,uint32_t colorBorder,uint32_t colorFill); //Dibuja un rectángulo. Función interna
    void _startCOMM(); //Inicia una transacción SPI
    void _endCOMM(); //Finaliza una transacción SPI
  public:
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void reset();
    bool drawPixel(int16_t x,int16_t y,uint32_t color); //Dibuja un pixel
    bool rect(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t colorBorder,uint32_t colorFill); //Dibuja un rectángulo con borde y relleno
    bool rect(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t colorBorder); //Dibuja un rectángulo sin relleno
    void copy(byte x1,byte y1,byte x2,byte y2,byte x3,byte y3); //Copia un área en otra
    void darker(byte x,byte y,byte width,byte height); //Hace una zona más oscura
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint32_t color); //Dibuja una línea
    bool block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color=0); //Dibuja un rectángulo relleno de un color
    void sleep(bool mode); //Activa/Desactiva modo hibernación
    void begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM=0); //Inicialización
    byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo
    bool drawSprite(RoJoSprite3 *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    bool drawSpriteSync(RoJoSprite3 *source,RoJoSprite3 *destination,int16_t x=0,int16_t y=0); //Sincroniza dos sprites
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoSSD1331.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


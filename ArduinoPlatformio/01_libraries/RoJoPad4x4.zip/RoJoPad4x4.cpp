/*
  Nombre de la librería: RoJoPad4x4.h
  Versión: 20220511
  Autor: Ramón Junquera
  Descripción:
    Gestión de teclado de membrana de 4x4.
*/

#ifndef RoJoPad4x4_cpp
#define RoJoPad4x4_cpp

#include <RoJoPad4x4.h>

//Constructor
//Se pasan los pines de conexión
RoJoPad4x4::RoJoPad4x4(byte pin1,byte pin2,byte pin3,byte pin4,byte pin5,byte pin6,byte pin7,byte pin8) { 
  //Guardamos los valores de los pines
  _pinRows[0]=pin1;
  _pinRows[1]=pin2;
  _pinRows[2]=pin3;
  _pinRows[3]=pin4;
  _pinCols[0]=pin5;
  _pinCols[1]=pin6;
  _pinCols[2]=pin7;
  _pinCols[3]=pin8;
  //Mapearemos los pines de filas como salidas y los de columnas como entradas con resistencias PULLUP
  for(byte p=0;p<4;p++) {
    pinMode(_pinRows[p],OUTPUT);
    pinMode(_pinCols[p],INPUT_PULLUP);
  }
}

//Devuelve el carácter del botón pulsado actualmente
//Si no hay ninguno devuelve 0
char RoJoPad4x4::_get() {
  //Apagamos todos los pines de salida
  for(byte p=0;p<4;p++) digitalWrite(_pinRows[p],HIGH);
  
  for(byte f=0;f<4;f++) { //Recorreremos todas las filas
    digitalWrite(_pinRows[f],LOW); //Activamos la fila actual
    for(byte c=0;c<4;c++) { //Recorremos todas las columnas
      if(!digitalRead(_pinCols[c])) { //Si encontramos una señal LOW en la columna actual...
        //...es que tenemos pulsado el botón de la fila f y la columna c
        //Devolvemos el carácter correspondiente a la tecla pulsada
        return _chars[f*4+c];
      }
    }
    //Hemos terminado de recorrer todas las columnas de la fila actual y no hemos encontrado ninguna tecla pulsada
    //Desactivaremos la fila actual y pasaremos a la siguiente
    digitalWrite(_pinRows[f],HIGH);
  }
  //No hemos encontrado ninguna tecla pulsada
  return 0;
}

//Devuelve el carácter del botón pulsado si es distinto al de la última vez.
//Si no hay ninguno pulsado o nuevo, devuelve 0
char RoJoPad4x4::get() {
  uint32_t now=millis(); //Tomamos nota de la hora actual
  char selectedChar=0; //Carácter pulsado. Inicialmente, ninguno
  char currentChar=_get(); //Obtenemos el carácter del botón pulsado ahora mismo
  if(currentChar==_lastChar) return 0; //Si es como el anterior...devolvemos que no hay nueva pulsación
  //if(now-_lastTime>delayTime) selectedChar=currentChar; //Si podemos aceptar una nueva pulsación...será la actual
  if(now-_lastTime>delayTime && _lastChar==0) selectedChar=currentChar; //Si podemos aceptar una nueva pulsación...será la actual
  _lastChar=currentChar; //La última pulsación será la actual
  _lastTime=now; //Tomamos nota del momento del cambio para esperar el tiempo indicado y evitar el efecto rebote
  return selectedChar; //Devolvemos el nuevo carácter
}

#endif



/*
  Nombre de la librería: RoJoPad4x4.h
  Versión: 20220511
  Autor: Ramón Junquera
  Descripción:
    Gestión de teclado de membrana de 4x4.
*/

#ifndef RoJoPad4x4_h
#define RoJoPad4x4_h

#include <Arduino.h>

class RoJoPad4x4 {
  private:
    byte _pinRows[4]; //Array de pines de filas
    byte _pinCols[4]; //Array de pines de columnas
    const char _chars[16]={'1','2','3','A','4','5','6','B','7','8','9','C','*','0','#','D'};
    char _lastChar=0; //Carácter anterior 0=ninguno
    uint32_t _lastTime=0; //Momento del último cambio
    char _get(); //Obtiene el carácter pulsado actualmente
  public:
    //Tiempo de espera (en milisegundos) para evitar efecto rebote, tanto al pulsar como al soltar
    uint32_t delayTime=50;
    //Constructor. Se pasan los pines de conexión
    RoJoPad4x4(byte pin1,byte pin2,byte pin3,byte pin4,byte pin5,byte pin6,byte pin7,byte pin8);
    //Devuelve el carácter del botón pulsado si es distinto al de la última vez
    char get();
}; //Punto y coma obligatorio para que no de error

#include <RoJoPad4x4.cpp>

#endif

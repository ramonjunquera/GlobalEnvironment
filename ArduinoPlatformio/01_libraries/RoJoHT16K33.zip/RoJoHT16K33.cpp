/*
 Nombre de la librería: RoJoHT16K33.h
  Versión: 20211221
  Autor: Ramón Junquera
  Descripción:
    Gestión de chip HT16K33 para control de display de leds de 15 segmentos
*/

#ifndef RoJoHT16K33_cpp
#define RoJoHT16K33_cpp

#include <RoJoHT16K33.h>

//Constructor. Inicialización I2C
RoJoHT16K33::RoJoHT16K33(byte pinSDA,byte pinSCL) {
  #ifdef ESP8266
    if(pinSDA==255) {
      pinSDA=D1;
      pinSCL=D2;
    }
    Wire.begin(pinSDA,pinSCL);
  #elif defined(ESP32)
    if(pinSDA==255) {
      pinSDA=21;
      pinSCL=22;
    }
    Wire.begin(pinSDA,pinSCL);
  #else
    //Las placas Arduino o Raspberry Pi, no pueden seleccionar los pines I2C
    Wire.begin();
  #endif
}

//Entrar en hibernación?
void RoJoHT16K33::sleep(bool status) {
  Wire.beginTransmission(_id);
    Wire.write(0x20+!status); //0x20 sleep on, 0x21 sleep off
  Wire.endTransmission();
}

//Aplica estado de display & blinking
void RoJoHT16K33::_setConfig() {
  Wire.beginTransmission(_id);
    Wire.write(0x80+(_blink<<1)+_enable);
  Wire.endTransmission();
}

//Activar display?
void RoJoHT16K33::enable(bool status) {
  _enable=status;
  _setConfig();
}

//Frecuencia de parpadeo
// 0 = 0Hz
// 1 = 2Hz
// 2 = 1Hz
// 3 = 0.5Hz 
void RoJoHT16K33::blink(byte freqId) {
  _blink=freqId & 0b00000011; //Nos aseguramos que estamos en rango
  _setConfig();
}

//Nivel de brillo [0,15]
void RoJoHT16K33::setBrightness(byte brightness) {
  Wire.beginTransmission(_id);
    Wire.write(0xE0+(brightness & 0x0F)); //Aseguramos el rango del brillo
  Wire.endTransmission();
}

//Inicialización
void RoJoHT16K33::begin() {
  sleep(false); //Despertamos
  _enable=true; //Display activo
  _blink=0; //Sin parpadeo
  _setConfig(); //Aplicamos configuración
  setBrightness(); //Máximo brillo
  autoDraw=true;
}


//Dibuja memoria de video en el display
void RoJoHT16K33::draw() {
  Wire.beginTransmission(_id);
    Wire.write(0); //Enviamos datos gráficos
    for(byte d=0;d<4;d++) { //Recorremos todos los dígitos
      Wire.write(videoMem[d] & 0x00FF); //LoByte
      Wire.write(videoMem[d] >> 8); //HiByte
    }
  Wire.endTransmission();
}

//Escribe una cadena en la memoria de video a partir de una posición
void RoJoHT16K33::print(String txt,byte pos) {
  while(pos<4 && txt.length()>0) {
    byte c=txt[0];
    #ifdef __arm__
      if(c>=32 && c<=126) videoMem[pos++]=_chars15segments[c-32];
    #else 
      if(c>=32 && c<=126) videoMem[pos++]=pgm_read_word_near(&_chars15segments[c-32]);
    #endif
    txt=txt.substring(1);
  }
  if(autoDraw) draw(); //Si se dibuja automáticamente...lo hacemos
}

//Muestra un carácter (digit display)
void RoJoHT16K33::print(byte x,byte charCode,bool dot) {
  if(x>3) return;
  if(charCode<32 || charCode>126) return;
  #ifdef __arm__ 
    videoMem[x]=_chars15segments[charCode-32]+0b0100000000000000*dot; //Escribimos el caracter
  #else 
    videoMem[x]=pgm_read_word_near(&_chars15segments[charCode-32])+0b0100000000000000*dot; //Escribimos el caracter
  #endif 
  if(autoDraw) draw(); //Si se dibuja automáticamente...lo hacemos
}

//Vacía la memoria de vídeo
void RoJoHT16K33::clear() {
  for(byte i=0;i<4;i++) videoMem[i]=0;
  if(autoDraw) draw(); //Si se dibuja automáticamente...lo hacemos
}

#endif

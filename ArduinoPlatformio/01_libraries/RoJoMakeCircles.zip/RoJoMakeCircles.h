/*
 * Autor: Ramón Junquera
 * Fecha: 20200824
 * Tema: Generador de puntos de anillos concéntricos
 */

#ifndef RoJoMakeCircles_h
#define RoJoMakeCircles_h

#define PI 3.1415926535897932384626433832795

#include <Arduino.h>
#include <RoJoFloatMatrix.h> //Gestión de matrices

//Genera puntos de anillos centrados en el eje de coordenadas
class RoJoMakeCircles {
  private:
    float _rand(float maxValue); //Generador de números aleatorios
  public:
    RoJoMakeCircles(); //Constructor
    bool get(RoJoFloatMatrix *res,uint16_t samples,float radius,float noise);
};

#endif

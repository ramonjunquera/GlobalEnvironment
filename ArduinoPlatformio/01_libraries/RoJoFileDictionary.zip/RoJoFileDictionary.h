/*
  Nombre de la librería: RoJoFileDictionary.h
  Versión: 20220808
  Autor: Ramón Junquera
  Descripción:
    Simulación de clase diccionario basado en sistema de archivos.
    Guarda pares de valores (registros) en un archivo de texto.
    Un registro consta de clave (key) y valor asociado (value).
    Las claves son únicas.
    Cada registro se almacena en una línea.
    La clave se separa de su valor por el carácter ;
    La información se guarda en un archivo. Nunca en memoria.
*/

#ifndef RoJoFileDictionary_h
#define RoJoFileDictionary_h

#include <Arduino.h>
#include <RoJoMultiFS.h> //Gestión de sistema de archivos

struct RoJoFileDictionaryItem {
  String key="";
  String value="";
};

class RoJoFileDictionary {
  private:
    String _filename; //Nombre del archivo que guarda el diccionario
    uint16_t _count=0; //Número de registros
  public:
    bool begin(String fileName); //Inicialización
    uint16_t count(); //Número de items en el diccionario
    bool containsKey(String key); //Contiene la clave indicada?
    bool remove(String key); //Elimina una clave
    bool clear(); //Borra el contenido del diccionario
    bool add(String key,String value); //Añade un item al diccionario
    bool add(RoJoFileDictionaryItem item); //Añade un item al diccionario
    String key(uint16_t index); //Obtiene la clave de una posición
    String value(uint16_t index); //Obtiene el valor de una posición
    String value(String key,String defaultValue=""); //Obtiene el valor de una clave
    RoJoFileDictionaryItem item(uint16_t index); //Obtiene el item de una posición
    void end(); //Finaliza el uso del diccionario
}; //Punto y coma obligatorio para que no de error

#include <RoJoFileDictionary.cpp>

#endif
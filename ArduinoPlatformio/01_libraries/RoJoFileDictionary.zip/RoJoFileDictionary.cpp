/*
  Nombre de la librería: RoJoFileDictionary.h
  Versión: 20220808
  Autor: Ramón Junquera
*/


#ifndef RoJoFileDictionary_cpp
#define RoJoFileDictionary_cpp

#include <RoJoFileDictionary.h>

//Inicialización
//Devuelve true si consigue inicializar sin errores
bool RoJoFileDictionary::begin(String filename) {
  //Si ya teníamos inicializado el diccionario...terminamos con error
  if(_filename.length()>0) return false;

  RoJoFS.begin(); //Inicializamos sistema de archivos
  if(!RoJoFS.exists(filename)) { //Si el archivo no existe...
    File f=RoJoFS.open(filename,"w"); //Creamos un archivo nuevo
    if(!f) return false; //Si no hemos podido...terminamos con error
    f.close(); //Cerramos el archivo de escritura
  }
  //Ahora seguro que el archivo existe
  File f=RoJoFS.open(filename,"r"); //Abrimos el archivo como lectura
  if(!f) return false; //Si no se pudo abrir...terminamos con error
  //Tenemos el archivo abierto en modo lectura

  //Mientras el archivo tenga algo que leer...
  while(f.available()>0) {
    //Leemos la línea completa y no la guardamos
    f.readStringUntil('\r');
    //Aumentamos el contador de registros
    _count++;
  }
  //Cerramos el archivo
  f.close();
  //Anotamos el nombre del archivo que guarda el diccionario
  _filename=filename;
  //Todo Ok
  return true;
}

//Devuelve el número de items en el diccionario
uint16_t RoJoFileDictionary::count() {
  return _count;
}

//Indica si existe la clave indicada
bool RoJoFileDictionary::containsKey(String key) {
  //Si el diccionario no se ha inicializado...la clave nunca existirá
  if(_filename.length()==0) return false;

  File f=RoJoFS.open(_filename,"r"); //Abrimos el archivo
  //Mientras el archivo tenga algo que leer...
  while(f.available()>0) {
    //...leemos la clave
    String keyRead=f.readStringUntil(';');
    //Si la clave coincide con la que buscamos...
    if(keyRead==key) {
      //...cerramos el archivo
      f.close();
      //Indicamos que la clave existe
      return true;
    }
    //Leemos el resto de línea
    keyRead=f.readStringUntil('\r');
  }
  //Hemos terminado de leer el archivo. Lo cerramos
  f.close();
  //No hemos encontrado la clave buscada
  return false;
}

//Elimina una clave
//Devuelve true si la clave existía
bool RoJoFileDictionary::remove(String key) {
  //Si el diccionario no se ha inicializado...la clave nunca ha existido
  if(_filename.length()==0) return false;

  //Hemos encontrado la clave buscada?. Inicialmente no
  bool keyFound=false;
  
  //Necesitamos crear un nombre para el archivo temporal
  //Serán 8 dígitos aleatorios con extensión tmp
  String tempFile="/";
  for(byte i=0;i<8;i++) tempFile+=(char)random('0','0'+10);
  tempFile+=".tmp";

  File f=RoJoFS.open(_filename,"r"); //Abrimos el archivo como lectura
  File t=RoJoFS.open(tempFile,"w"); //Abrimos el archivo temporal como escritura
  
  while(f.available()>0) { //Mientras el archivo tenga algo que leer...
    String keyRead=f.readStringUntil(';'); //...leemos la clave
    String valueRead=f.readStringUntil('\r'); //Leemos el valor
    //Si la clave coincide con la que buscamos...anotamos que hemos encontrado la clave
    if(keyRead==key) keyFound=true;
    //Si no es la clave que buscamos...escribimos el registro en el archivo temporal
    else t.print(keyRead+";"+valueRead+"\r");
  }
  //Hemos terminado de leer el archivo.
  //Cerramos tanto el archivo temporal como el de diccionario
  t.close();
  f.close();

  if(keyFound) { //Si hemos encontrado la clave buscada...
    RoJoFS.remove(_filename); //...borramos el archivo de diccionario
    RoJoFS.rename(tempFile,_filename); //Renombramos el temporal al de diccionario
    _count--; //Reducimos el número de registros
  }
  //Si no hemos encontrado la clave buscada...borramos el archivo temporal
  else RoJoFS.remove(tempFile);

  //Devolvemos si la clave existía
  return keyFound;
}

//Borra el contenido del diccionario
//Devuelve true si lo consigue
bool RoJoFileDictionary::clear() {
  //Si el diccionario no se ha inicializado...no se puede vaciar
  if(_filename.length()==0) return false;

  if(RoJoFS.remove(_filename)) { //Si podemos borrar el archivo de diccionario...
    File f=RoJoFS.open(_filename,"w"); //Lo creamos de nuevo
    if(!f) return false; //Si no se ha podido crear el archivo...devolvemos error
    f.close();
  }
  
  _count=0;
  return true; //Todo Ok
}

//Añade un item al diccionario
//Si ya existe lo actualiza
//Devuelve true si ya existía la clave
bool RoJoFileDictionary::add(String key,String value) {
  //Si el diccionario no se ha inicializado...clave no existía
  if(_filename.length()==0) return false;

  //Borramos la clave si es que existe
  //Y anotamos si ya existía
  bool alreadyExists=remove(key);
  //Añadimos la nueva
  File f=RoJoFS.open(_filename,"a"); //Abrimos el archivo en modo escritura/append
  f.print(key+";"+value+"\r"); //Escribimos el nuevo registro
  f.close(); //Cerramos archivo
  _count++; //Tenemos un nuevo registro
  return alreadyExists; //Respondemos si ya existía la clave
}

//Añade un item al diccionario
//Si ya existe lo actualiza
//Devuelve true si ya existía la clave
bool RoJoFileDictionary::add(RoJoFileDictionaryItem item) {
  return add(item.key,item.value);
}

//Obtiene el valor de una clave
//Si no existe devuelve el valor por defecto
String RoJoFileDictionary::value(String key,String defaultValue) {
  //Si el diccionario no se ha inicializado...el valor no existe
  if(_filename.length()==0) return defaultValue;

  String keyRead;
  String valueRead;
  File f=RoJoFS.open(_filename,"r");
  
  while(f.available()>0) {
    keyRead=f.readStringUntil(';');
    valueRead=f.readStringUntil('\r');
    if(keyRead==key) {
      f.close();
      return valueRead;
    }
  }
  f.close();
  return defaultValue;
}

//Obtiene el item de una posición
//Si el índice está fuera de rango devuelve un item con clave y valor vacíos
RoJoFileDictionaryItem RoJoFileDictionary::item(uint16_t index) {
  //Creamos el item a devolver
  RoJoFileDictionaryItem a;
  //Si el diccionario se ha inicializado y el índice es válido...
  if(_filename.length()>0 && index<_count) {
    File f=RoJoFS.open(_filename,"r");

    if(f) { //Si hemos podido abrir el archivo...
      for(uint16_t i=0;i<=index;i++) {
        a.key=f.readStringUntil(';');
        a.value=f.readStringUntil('\r');
      }
      f.close();
    }
  }
  return a;
}

//Obtiene la clave de una posición
//Si el índice está fuera de rango devuelve una clave vacía
String RoJoFileDictionary::key(uint16_t index) {
  return item(index).key;
}

//Obtiene el valor de una posición
//Si el índice está fuera de rango devuelve un valor vacío
String RoJoFileDictionary::value(uint16_t index) {
  return item(index).value;
}

//Finaliza el uso del diccionario
void RoJoFileDictionary::end() {
  //Ya no tenemos items
  _count=0;
  //Ni tenemos nombre de archivo
  _filename="";
}

#endif

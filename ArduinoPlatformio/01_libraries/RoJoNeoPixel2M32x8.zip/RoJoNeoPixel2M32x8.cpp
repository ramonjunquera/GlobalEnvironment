/*
  Nombre de la librería: RoJoNeoPixel2M32x8.h
  Versión: 20210826
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixel2M32x8_cpp
#define RoJoNeoPixel2M32x8_cpp

#include <RoJoNeoPixel2M32x8.h>

//Inicialización
//Devuelve true si lo consigue
bool RoJoNeoPixel2M32x8::begin(byte pin) {
  return RoJoNeoPixel2::begin(xMax*yMax,pin);
}

//Convierte coordenadas en índice
byte RoJoNeoPixel2M32x8::_XY2Index(byte x,byte y) {
  if(x%2) return x*8+7-y; //Fila impar
  return x*8+y; //Fila par
}


//Dibuja pixel en memoria de video
//Devuelve true si lo consigue
bool RoJoNeoPixel2M32x8::drawPixel(byte x,byte y,uint32_t color) {
  if(!_ledsCount) return false; //No inicializado
  if(x>xMax || y>yMax) return false; //Fuera de rango
  pixelGRB pixel;
  pixel.setColor(color);
  videoMem[_XY2Index(x,y)]=pixel;
  return true;
}

//Devolvemos color de un pixel
//Si seleccionamos unas coordenadas fuera de rango, devuelve 0
uint32_t RoJoNeoPixel2M32x8::getPixel(int16_t x,int16_t y) {
  if(x<0 || x>=xMax || y<0 || y>=yMax) return 0; //Si fuera de rango...color negro
  return videoMem[_XY2Index(x,y)].getColor();
}

//Borra el display
//Devuelve true si lo consigue
bool RoJoNeoPixel2M32x8::clear(uint32_t color) {
  if(!_ledsCount) return false; //No inicializado
  pixelGRB pixel;
  pixel.setColor(color);
  for(uint16_t i=0;i<_ledsCount;i++) videoMem[i]=pixel; //Llenamos la memoria de video
  return true;
}

//Dibuja un sprite en unas coordenadas
bool RoJoNeoPixel2M32x8::drawSprite(RoJoSprite2 *source,int16_t x,int16_t y) {
  if(!_ledsCount) return false; //No inicializado
  displayRange r=source->visibleRange(-x,-y,xMax,yMax); //Comprobamos si hay área visible
  if(!r.visible) return true; //Si no es visible...terminamos
  pixelGRB pixel;
  uint16_t ry2=r.y2,rx1=r.x1,rx2=r.x2;
  for(uint16_t y0=r.y1;y0<=ry2;y0++) {
    for(uint16_t x0=rx1;x0<=rx2;x0++) {
      pixel.setColor(source->getPixel(x0,y0));
      videoMem[_XY2Index(x0+x,y0+y)]=pixel;
    }
  }
  return true;
}

#endif

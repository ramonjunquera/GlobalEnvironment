/*
  Nombre de la librería: RoJoRTC.h
  Versión: 20191128
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC genérico
    Se incluye la definición de la estructura RoJoDateTime
    El reloj sólo es capaz de almacenar 2 dígitos para el año. Supondremos que el año del reloj corresponde con las
    dos últimas cifras de un año del siglo 21 (20xx).
*/

#ifndef RoJoRTC_cpp
#define RoJoRTC_cpp

#include <RoJoRTC.h>

//Convierte de Binary Coded Decimal a Decimal
byte RoJoRTC::_bcd2dec(byte n) {
  return ((n/16*10) + (n % 16));
}

//Convierte de Decimal a Binary Coded Decimal
byte RoJoRTC::_dec2bcd(byte n) {
  return ((n/10*16) + (n % 10));
}

//Fija la hora indicada en el reloj
//No tiene en cuenta el valor de día de la semana. Lo recalcula
void RoJoRTC::set(RoJoDateTime *t) {
  //Función dummy
  //Se debe definir en la clase heredada
}

//Indica si el parámetro es un año bisiesto
//'y' es el año completo con sus 4 dígitos
bool RoJoRTC::_leapYear(uint16_t y) {
  return !(y%4) && ( (y%100) || !(y%400) );
}

//Calcula el número de segundos transcurridos entre el 1-Ene-1900 hasta la fecha indicada
//No se tiene en cuenta el valor del día de la semana
uint32_t RoJoRTC::datetime2seconds(RoJoDateTime *t) {
  //Definimos la variable donde guardaremos el resultado
  uint32_t s;
  //Calculamos los segundos de todos los años entre el 1900 y el indicado
  //Un año tiene 265*24*60*60=31536000 segundos
  s=(t->year-1900L)*31536000L;
  //Recorreremos todos los años hasta el indicado...
  for(uint16_t yearIndex=1900;yearIndex<t->year;yearIndex+=4) {
    //Si es un año bisiesto...le sumamos los segundos que tiene un día
    //Un día tiene 24*60*60=86400 segundos
    if(_leapYear(yearIndex)) s+=86400L;
  }
  //Si el mes es superior a enero...sumaremos también el tiempo de los meses del año transcurridos
  if(t->month>1) s+=_secondsPerMonth[t->month-2];
  //Si el año es bisiesto y el mes es superior a febrero...le tenemos que sumar los segundos del 29 de febrero
  if(_leapYear(t->year) && t->month>2) s+=86400L;
  //Le sumamos los días transcurridos del mes
  s+=86400L*(t->day-1);
  //Le sumamos las horas trascurridas del día
  s+=3600L*t->hour;
  //Le sumamos los minutos transcurridos de la hora
  s+=60*t->minute;
  //Finalmente le sumamos los segundos
  s+=t->second;
  //Devolvemos el valor calculado
  return s;
}

//Calcula la fecha que corresponde a los segundos transcurridos desde el 1-Ene-1900
//También se calcula el día de la semana
void RoJoRTC::seconds2datetime(uint32_t s,RoJoDateTime *t) {
  t->second=s%60; //Calculamos los segundos
  s/=60; //Convertimos a minutos
  t->minute=s%60; //Calculamos los minutos
  s/=60; //Convertimos a horas
  t->hour=s%24; //Calculamos las horas
  s/=24; //Convertimos a días
  
  t->weekDay=s%7; //Calculamos el día de la semana. El lunes es el día 0
  //Recorreremos todos los años desde el 1900 e iremos acumulando los días que tiene cada uno
  //Cuando el acumulado sea superior al número de días que tenemos, paramos
  uint32_t totalDays=0;
  uint16_t currentYear=1900;
  while((totalDays+=(_leapYear(currentYear)?366:365)) <= s) {
    currentYear++;
  }
  //Nos hemos pasado del número de días que teníamos
  //Eso quiere decir que hemos anotado también los días del año en curso
  //Tomamos nota del año
  t->year=currentYear;
  //Tomamos nota de si el año calculado es bisiesto
  bool leapYear=_leapYear(currentYear);
  //Restamos al total de días, los días del año calculado (que se lo habíamos sumado)
  totalDays-=(leapYear?366:365);
  //Quitamos los días que han transcurrido para todos los años pasados
  s-=totalDays;
  //Nos falta calcular el mes y el día
  //Definimos variable para guardar el mes calculado
  byte monthIndex;
  //Utilizaremos de nuevo la variable totalDay para guardar el número acumulado de días de los meses del año
  totalDays=0;
  //Recorremos todos los meses
  for(monthIndex=0;monthIndex<11;monthIndex++) {
    //Calculamos los días que tiene el mes procesado
    totalDays=_secondsPerMonth[monthIndex]/86400L;
    //Si el mes es superior a febrero y el año es bisiesto...se debe tener en cuenta el día extra de febrero
    if(monthIndex>1 && leapYear) totalDays++;
    //Si los días que nos quedan son menos que los que tiene el acumulado de meses...hemos encontrado el mes!
    if(s<totalDays) break;
  }
  //El mes buscado es monthIndex+1
  //Tomamos nota del mes calculado
  t->month=monthIndex+1;
  //Si el mes es superior a enero...
  if(t->month>1) {
    //Restamos el número de días que tienen los meses acumulados
    s-=_secondsPerMonth[monthIndex-1]/86400L;
    //Si el mes es superior a febrero y el año es bisiesto...se debe tener en cuenta el día extra de febrero
    if(monthIndex>1 && leapYear) s--;
  }
  //Lo único que nos queda ahora en la variable s son los días del mes. Los anotamos
  t->day=s+1;
  //En al caso de que la fecha sea 29-feb quedaría como mes=marzo,día=0.Lo corregimos
  if(t->day==0) {
    t->day=29;
    t->month=2;
  }
}

//Fija la hora en el reloj teniendo en cuenta que se le pasa el número
//de segundos transcurridos desde el 1-Ene-1900.
//Esta función está especialmente pensada para cuando se obtiene la
//hora de internet (NTP), porque la devuelve en este formato.
void RoJoRTC::set1900(uint32_t seconds1900) {
  RoJoDateTime t;
  seconds2datetime(seconds1900,&t); //Convertimos los segundos desde 1-Ene-1900 a formato datetime
  set(&t); //Fijamos la fecha calculada en el RTC
}

//Fija la hora en el reloj teniendo en cuenta que se le pasa el número
//de segundos transcurridos desde el 1-Ene-1970.
//Esta función está especialmente pensada para cuando se obtiene la
//hora del reloj interno de un sistema Unix porque la devuelve en este
//formato.
void RoJoRTC::set1970(uint32_t seconds1970) {
  //Llamamos a la función set1900 añadiendo al tiempo de 1970 la
  //diferencia hasta 1900
  set1900(seconds1970+2208988800L);
}

#endif

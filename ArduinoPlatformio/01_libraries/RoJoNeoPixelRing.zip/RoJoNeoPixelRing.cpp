#ifndef RoJoNeoPixelRing_cpp
#define RoJoNeoPixelRing_cpp

#include <RoJoNeoPixelRing.h>

//Inicialización
//Devuelve true si lo consigue
//Parámetros:
//- *leds: puntero a objeto RoJoNeoPixel
//- indexBegin: posición correspondiente al primer led del anillo
//- ledRingCount: número de leds del anillo
void RoJoNeoPixelRing::begin(RoJoNeoPixel *leds,uint16_t indexBegin,uint16_t ledRingCount) {
  _leds=leds;
  _indexBegin=indexBegin;
  _ledRingCount=ledRingCount;
}

//Borra/pinta todo el anillo de un color
void RoJoNeoPixelRing::clear(pixelGRB color) {
  uint16_t pos=_indexBegin;
  for(uint16_t i=_ledRingCount;i>0;i--) (*_leds).videoMem[pos++]=color;
}

//Convierte ángulo a índice de led
uint16_t RoJoNeoPixelRing::_angle2led(int16_t angle) {
  angle-=int(angle/360)*360; //Normalización
  return angle*_ledRingCount/360+_indexBegin; //Conversión a índice de led
}

//Obtiene el índice del led
uint16_t RoJoNeoPixelRing::ledIndex(int16_t angle) {
  return _angle2led(angle);
}

//Pinta un arco
//Parámetros:
//- color
//- angleStart: ángulo inicial en grados
//- angleEnd: ángulo final en grados (excluido). Si es > 32000 se tomará igual que angleStart
void RoJoNeoPixelRing::set(pixelGRB color,int16_t angleStart,int16_t angleEnd) {
  if(angleEnd>32000) angleEnd=angleStart+1;
  uint16_t ledStart=_angle2led(angleStart);
  uint16_t ledEnd=_angle2led(--angleEnd);
  if(ledEnd<ledStart) { //Si pasa por el cero...
    for(uint16_t i=ledStart;i<_ledRingCount;i++) (*_leds).videoMem[i]=color;
    for(uint16_t i=0;i<=ledEnd;i++) (*_leds).videoMem[i]=color;
  } else { //No pasa por el cero...
    for(uint16_t i=ledStart;i<=ledEnd;i++) (*_leds).videoMem[i]=color;
  }
}

#endif

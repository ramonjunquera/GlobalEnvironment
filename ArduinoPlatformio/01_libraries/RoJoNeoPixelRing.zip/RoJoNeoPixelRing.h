/*
  Nombre de la librería: RoJoNeoPixelRing.h
  Versión: 20221103
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel en forma de anillo.
    El tamaño del anillo y el número de pixels que contiene puede variar.
    Los anillos estándar son los de 8, 16, 24, 35 y 45 leds.
    Tomaremos como led inicial el que se encuentra en la posición del conector y lo ubicaremos
    en el punto superior.
    La secuencia de leds sigue el sentido horario.
    La creación del objeto RoJoNeoPixel la tendrá que hacer el usuario antes de llamar al
    método de inicialización (begin). Esto es así porque podríamos utilizar más de un anillo en
    el mismo proyecto. Dimensionaremos RoJoNeoPixel con el total de leds y después indicaremos
    el rango en el que se encuentra cada anillo.
*/

#ifndef RoJoNeoPixelRing_h
#define RoJoNeoPixelRing_h

#include <Arduino.h>
#include <RoJoNeoPixel.h>

class RoJoNeoPixelRing {
  private:
    //byte _XY2Index(byte x,byte y);
    RoJoNeoPixel *_leds; //Objeto de gestión de NeoPixel
    uint16_t _indexBegin; //Posición de led inicial
    uint16_t _ledRingCount; //Número de leds del anillo
    uint16_t _angle2led(int16_t angle);
  public:
    void begin(RoJoNeoPixel *leds,uint16_t indexBegin=0,uint16_t ledRingCount=8); //Inicialización
    void clear(pixelGRB color={0,0,0});
    void set(pixelGRB color,int16_t angleStart=0,int16_t angleEnd=32767);
    uint16_t ledIndex(int16_t angle); //Obtiene el índice del led
}; //Punto y coma obligatorio para que no de error

#include <RoJoNeoPixelRing.cpp>

#endif


/*
  Nombre de la librería: RoJoLCD1602A.h
  Versión: 20220118
  Autor: Ramón Junquera
  Descripción:
    Gestión de display LCD de 16x2 por conexión directa
*/

#ifndef RoJoLCD1602A_cpp
#define RoJoLCD1602A_cpp

#include <RoJoLCD1602A.h>

//Envía el medio byte inferior
void RoJoLCD1602A::_sendHalf(byte value) {
  //Recorremos cada bit del medio byte y fijamos los estados de los pines de datos
  for(byte i=0;i<4;i++) digitalWrite(_pinData[i],(value >> i) & 1);
  //Activa un pulso en el pin de envío para que el display pueda leer la configuración
  //de los pines de datos
  digitalWrite(_pinE,HIGH); //Activamos el pulso
  delayMicroseconds(1); //El pulso debe durar un mínimo de 300ns. Esperaremos 1000ns
  digitalWrite(_pinE,LOW); //Terminamos el pulso
  delayMicroseconds(1); //Damos tiempo para que se pueda distinguir el siguiente pulso
}

//Envía un byte al display seleccionando el modo (comando=LOW o carácter=HIGH)
void RoJoLCD1602A::_send(byte value,bool mode) {
  _mode=mode;
  digitalWrite(_pinRS,_mode); //Fijamos el modo (comando o carácter)
  _sendHalf(value>>4); //Enviamos la mitad alta
  _sendHalf(value); //Enviamos la mitad baja
}

//Luz de fondo. LOW=off, HIGH=on
void RoJoLCD1602A::backlight(bool status) {
  _backlight=status;
  if(_pinBacklight<255) digitalWrite(_pinBacklight,_backlight);
}

//Inicialización
void RoJoLCD1602A::begin(byte pinD4,byte pinD5,byte pinD6,byte pinD7,byte pinRS,byte pinE,byte pinBacklight) {
  //Guardamos variables en la zona privada
  _pinRS=pinRS;
  _pinE=pinE;
  _pinBacklight=pinBacklight;
  _pinData[0]=pinD4;
  _pinData[1]=pinD5;
  _pinData[2]=pinD6;
  _pinData[3]=pinD7;

  //Configuramos el pin de selección de comando/carácter. Lo configuramos como comando
  pinMode(_pinRS,OUTPUT); digitalWrite(_pinRS,LOW);
  //Configuramos el pin de envío. Ahora mismo no se está enviando
  pinMode(_pinE,OUTPUT); digitalWrite(_pinE,LOW);
  //Configuramos los pines de datos como salidas
  for(byte i=0;i<4;i++) pinMode(_pinData[i],OUTPUT);
  if(_pinBacklight<255) { //Si existe el pin de luz de fondo...
    pinMode(_pinBacklight,OUTPUT);
    digitalWrite(_pinBacklight,_backlight);
  }

  delay(50); //El display necesita 40ms para su inicializacion según el manual. Le daremos 50ms
  
  //Fijamos el modo de envío de 4 bits
  //El procedimiento es bastante curioso. Para que funcione correctamente en todas las 
  //situaciones, debemos activar 3 veces el modo de envío de 8 bits y a continuación el de 4 bits
  digitalWrite(_pinRS,LOW); //Modo de envío de comandos
  _sendHalf(0x03); //Medio byte alto de comando de modo de envío de 8 bits (0x30)   
  delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
  _sendHalf(0x03); //Medio byte alto de comando de modo de envío de 8 bits (0x30)
  delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
  _sendHalf(0x03); //Medio byte alto de comando de modo de envío de 8 bits (0x30)
  delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
  _sendHalf(0x02); //Medio byte alto de comando de modo de envío de 4 bits (0x20)
  delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.

  //Enviamos el comando que fija el comportamiento del display
  _send(_displaycontrol,LOW);
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  //Comando para fijar el modo de entrada (0x04) + de izquierda a derecha (0x02)
  _send(0x06,LOW);
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  clear(); //Limpiamos la pantalla
}


#endif

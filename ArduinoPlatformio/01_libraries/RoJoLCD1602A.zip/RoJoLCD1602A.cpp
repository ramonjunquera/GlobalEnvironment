/*
  Nombre de la librería: RoJoLCD1602A.h
  Versión: 20190905
  Autor: Ramón Junquera
  Descripción:
    Gestión de display LCD de 16x2
  Notas:
    - La librería sólo contempla la conexión con 4 pines de datos. Los bytes se enviarán como dos
      medios bytes. Es más lento, pero se ahorran 4 pines en la placa. Además tampoco se transmite
      tanta información como para se note la diferencia.
    - No se tiene en cuenta el pin RW. Se supone que siempre estará conectado a GND (en modo write).
      No se podrá leer información del display.
*/

#ifndef RoJoLCD1602A_cpp
#define RoJoLCD1602A_cpp

#include <RoJoLCD1602A.h>

//Inicialización
void RoJoLCD1602A::begin(byte pinRS,byte pinE,byte pinD4,byte pinD5,byte pinD6,byte pinD7) {
  //Guardamos variables en la zona privada
  _pinRS = pinRS;
  _pinE = pinE;
  _pinData[0] = pinD4;
  _pinData[1] = pinD5;
  _pinData[2] = pinD6;
  _pinData[3] = pinD7;

  //Configuramos el pin de selección de comando/carácter. Lo configuramos como comando
  pinMode(_pinRS,OUTPUT); digitalWrite(_pinRS,LOW);
  //Configuramos el pin de envío. Ahora mismo no se está enviando
  pinMode(_pinE,OUTPUT); digitalWrite(_pinE,LOW);
  //Configuramos los pines de datos como salidas
  for(byte i=0;i<4;i++) pinMode(_pinData[i],OUTPUT);

  //El display necesita 40ms para su inicializacion según el manual. Le daremos 50ms
  delay(50);
  
  //Fijamos el modo de envío de 4 bits
  //El procedimiento es bastante curioso. Para que funcione correctamente en todas las 
  //situaciones: reset caliente y reset frio, debemos activar el modo de envío de 8
  //bits y a continuación el de 4 bits
  digitalWrite(_pinRS,LOW); //Modo de envío de comandos
  _sendHalf(0x03); //Medio byte alto de comando de modo de envío de 8 bits (0x30)
  delayMicroseconds(40);
  _sendHalf(0x00); //Medio byte bajo de comando de modo de envío de 8 bits (0x30) 
  delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.
  _sendHalf(0x02); //Modo de envío a 4bits
  delayMicroseconds(4000); //Esperamos 4ms. Según el manual con 3.9ms es suficiente.

  //Enviamos el comando que fija el comportamiento del display
  _send(_displaycontrol,LOW);
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  //Comando para fijar el modo de entrada (0x04) + de izquierda a derecha (0x02)
  _send(0x06,LOW);
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  //Limpiamos la pantalla
  clear();
}

//Borra el display y pone el cursor en home
void RoJoLCD1602A::clear() {
  _send(0x01,LOW); //Comando de borrado de pantalla
  delayMicroseconds(1540); //Según el manual tarda 1.53ms
}

//Pone el cursor en la posición 0,0
void RoJoLCD1602A::home() {
  _send(0x02,LOW); //Comando de cursor a home
  delayMicroseconds(1540); //Según el manual tarda 1.53ms
}

//Posiciona el cursor en unas coordenadas
void RoJoLCD1602A::pos(byte col,byte row) {
  //Nos aseguramos que las coordenadas no salgan de los rangos permitidos
  //Recordemos que una fila tiene 64 caracteres, aunque sólo visualicemos 16
  _send(0x80+(col & 0x0F)+64*(row & 0x01),LOW);
  delayMicroseconds(40); //Segun el manual debemos esperar 39us. Esperamos 40us
}

//Activa/desactiva el display
void RoJoLCD1602A::enable(bool status) {
  //Mantiene en memoria su contenido. Sólo deja de mostrarlo

  //Si se debe activar...
  if(status) _displaycontrol |= 0x04;
  //Si se debe desactivar...
  else _displaycontrol &= ~0x04;
  //Enviamos el comando
  _send(_displaycontrol,LOW);
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
}

//Activa/desactiva el parpadeo del cursor
void RoJoLCD1602A::blink(bool status) {
  //Si se debe activar...
  if(status) _displaycontrol |= 0x01;
  //Si se debe desactivar...
  else _displaycontrol &= ~0x01;
  //Enviamos el comando
  _send(_displaycontrol,LOW);
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
}

//Muestra/oculta el cursor
void RoJoLCD1602A::cursor(bool status) {
  //Si se debe mostrar...
  if(status) _displaycontrol |= 0x02;
  //Si se debe ocultar...
  else _displaycontrol &= ~0x02;
  //Enviamos el comando
  _send(_displaycontrol,LOW);
  delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
}

//Define una carácter personalizado
void RoJoLCD1602A::createChar(byte charNum, byte charMap[]) {
  //Sólo se pueden modificar los 8 primeros caracteres

  //Enviamos comando para definir caracter
  _send(0x40 | ((charNum & 0x07) << 3),LOW);
  delayMicroseconds(40);
  //Enviamos los 8 bytes (filas) que definen el gráfico
  //Puesto que la matriz tiene 5 columnas, sólo se tendrán en cuenta los 5 bits de
  //menor peso
  for (byte i=0;i<8;i++) {
    _send(charMap[i],HIGH); //Enviamos el byte de gráficos
    delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  }
}

//Envía un byte al display seleccionando el modo (comando=LOW o carácter=HIGH)
void RoJoLCD1602A::_send(byte value,bool mode) {
  digitalWrite(_pinRS,mode); //Fijamos el modo (comando o carácter)
  _sendHalf(value>>4); //Enviamos la mitad alta
  _sendHalf(value); //Enviamos la mitad baja
}

//Envía medio byte
void RoJoLCD1602A::_sendHalf(byte value) {
  //Recorremos cada bit del medio byte y fijamos los estados de los pines de datos
  for(byte i=0;i<4;i++) digitalWrite(_pinData[i],(value >> i) & 1);
  //Activa un pulso en el pin de envío para que el display pueda leer la configuración
  //de los pines de datos
  digitalWrite(_pinE,HIGH); //Activamos el pulso
  delayMicroseconds(1); //El pulso debe durar un mínimo de 300ns. Esperaremos 1000ns
  digitalWrite(_pinE,LOW); //Terminamos el pulso
  delayMicroseconds(1); //Damos tiempo para que se pueda distinguir el siguiente pulso
}

//Muestra el texto indicado en la posición del cursor
void RoJoLCD1602A::print(String txt) {
  //Recorremos todos los caracteres de la cadena
  for(byte i=0;i<txt.length();i++) {
    _send(txt[i],true); //Enviamos el carácter al display
    delayMicroseconds(40); //Según el manual debemos esperar 39us. Esperamos 40us
  }
}

//Muestra un carácter en la posición del cursor
void RoJoLCD1602A::printChar(char ch) {
  _send(ch,HIGH);
  delayMicroseconds(44); //Según el manual debemos esperar 43us. Esperamos 44us
}

#endif

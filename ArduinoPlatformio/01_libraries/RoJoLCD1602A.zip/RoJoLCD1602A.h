/*
  Nombre de la librería: RoJoLCD1602A.h
  Versión: 20190905
  Autor: Ramón Junquera
  Descripción:
    Gestión de display LCD de 16x2
  Notas:
    - La librería sólo contempla la conexión con 4 pines de datos. Los bytes se enviarán como dos
      medios bytes. Es más lento, pero se ahorran 4 pines en la placa. Además tampoco se transmite
      tanta información como para se note la diferencia.
    - No se tiene en cuenta el pin RW. Se supone que siempre estará conectado a GND (en modo write).
      No se podrá leer información del display.
*/

#ifndef RoJoLCD1602A_h
#define RoJoLCD1602A_h

#include <Arduino.h>

class RoJoLCD1602A {
  private:
    byte _pinRS; //Pin de envío de comandos o caracteres. LOW=command, HIGH: character.
    byte _pinRW; //Pin de lectura/escritura. LOW=write, HIGH=read
    byte _pinE; //Pin de envío. LOW=no, HIGH=sí
    byte _pinData[8]; //Pines de datos
    void _send(byte value,bool mode); //Envía un byte al display seleccionando el modo (comando o carácter)
    void _sendHalf(byte value); //Envía medio byte
    
    //Byte de control de pantalla:
    //bit7 : 0 : no utilizado
    //bit6 : 0 : no utilizado
    //bit5 : 0 : no utilizado
    //bit4 : 0 : no utilizado
    //bit3 : 1 : control de pantalla
    //bit2 : display on/off
    //bit1 : cursor parpadeante
    //bit0 : mostrar cursor 
    //Por defecto pantalla activada, sin parpadeo de cursor y sin mostrar el cursor
    byte _displaycontrol=0b00001100;
  
  public:
    void begin(byte pinRS,byte pinE,byte pinD4,byte pinD5,byte pinD6,byte pinD7); //Inicialización
    void clear(); //Borra la pantalla
    void home(); //Pone el cursor en la posición 0,0
    void enable(bool status); //Activa/Desactiva la pantalla
    void cursor(bool status); //Muestra/Oculta el cursor (underscore)
    void blink(bool status); //Activa/Desactiva el parpadeo del cursor del carácter en el que está el cursor
    void pos(byte col,byte row); //Posiciona el cursor en unas coordenadas
    void print(String txt); //Muestra el texto indicado en la posición del cursor
    void createChar(byte location, byte charmap[]);
    void printChar(char ch); //Muestra un carácter en la posición del cursor
};

#ifdef __arm__
  #include <RoJoLCD1602A.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

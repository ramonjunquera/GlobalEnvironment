/*
  Nombre de la librería: RoJoLCD1602A.h
  Versión: 20220118
  Autor: Ramón Junquera
  Descripción:
    Gestión de display LCD de 16x2 por conexión directa
  Notas:
    - La librería sólo contempla la conexión con 4 pines de datos. Los bytes se enviarán como dos
      medios bytes. Es más lento, pero se ahorran 4 pines en la placa. Además tampoco se transmite
      tanta información como para se note la diferencia.
    - No se tiene en cuenta el pin RW. Se supone que siempre estará conectado a GND (en modo write).
      No se podrá leer información del display.
    - Si nos quedamos cortos de pines, podemo liberar el pin de luz de fondo (A/LED+) y conectarlo
      directamente a 3.3V o 5V
*/

#ifndef RoJoLCD1602A_h
#define RoJoLCD1602A_h

#include <Arduino.h>
#include <_RoJoLCD1602A.h>

class RoJoLCD1602A:public _RoJoLCD1602A {
  private:
    byte _pinRS; //Pin de envío de comandos o caracteres. LOW=command, HIGH: character.
    byte _pinE; //Pin de envío. LOW=no, HIGH=sí
    byte _pinBacklight; //Pin de luz de fondo. LOW=apagado, HIGH=encendido
    byte _pinData[4]; //Pines de datos
    virtual void _send(byte value,bool mode); //Envía un byte al display seleccionando el modo (comando o carácter)
    virtual void _sendHalf(byte value); //Envía el medio byte inferior
  public:
    void begin(byte pinD4,byte pinD5,byte pinD6,byte pinD7,byte pinRS,byte pinE,byte pinBacklight=255); //Inicialización
    virtual void backlight(bool status); //Luz de fondo. LOW=off, HIGH=on
};

#ifdef __arm__
  #include <RoJoLCD1602A.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

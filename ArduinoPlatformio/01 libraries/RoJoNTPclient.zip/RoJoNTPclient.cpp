/*
  Nombre de la librería: RoJoNTPclient.h
  Versión: 20191128
  Autor: Ramón Junquera
  Descripción:
    Permite obtener la hora de un servidor NTP
*/

#ifndef RoJoNTPclient_cpp
#define RoJoNTPclient_cpp

#include <RoJoNTPclient.h>

//Inicialización
void RoJoNTPclient::begin(String ntpServer,int8_t timeZone,bool summerTime) {
  _ntpServer=ntpServer; //Guardamos el nombre del servidor NTP
  _secondsOffset=(timeZone+summerTime)*3600; //Calculamos el offset en segundos
}

//Devuelve el tiempo en segundos desde 1900
//Devuelve 0 si no lo consigue
uint32_t RoJoNTPclient::get() {
  #ifdef __arm__ //Si es una RPi
    //Para conectar con un servidor, necesitamos conocer su dirección ip.
    //Es posible que la dirección del servidor NTP nos la entreguen como
    //nombre (hostname) y no como dirección ip.
    //En ese caso, necesitamos convertir el hostname a ip
    //Un hostname puede tener asociadas más de una dirección ip
    //Obtendremos todas las ips del hostname y probaremos a conectar con
    //cada una de ellas hasta encontrar un servidor que nos devuelva una
    //respuesta válida.
    //Repetiremos este proceso cada vez que se necesite para aprovechar
    //el servicio de balanceo de carga.
    //Para comunicarnos (enviar y recibir) con el servidor NTP, utilizaremos
    //un socket.
    
    //Obtenemos las distintas direcciones ip del hostname entregado
      //Creamos objeto para pasar parámetros de filtro
      struct addrinfo hints;
      memset(&hints,0,sizeof hints); //Vaciamos el objeto
      hints.ai_family=AF_INET; //Definimos el dominio: IPv4 Internet
      hints.ai_socktype = SOCK_STREAM; //Definimos el tipo: datagrama
      //Creamos puntero a objeto que contendrá la colección de direcciones
      //ip asociadas al hostname
      struct addrinfo *ipAddresses;
      //Solicitamos las direcciones ip asociadas a un hostname
      //Guardamos el resultado en results
      //Si se produce algún error...terminamos con error
      if((getaddrinfo(_ntpServer.c_str(),NULL,&hints,&ipAddresses))!=0) return 0;
      //Hemos conseguido obtener las direcciones ip del hostname
    //Recorreremos secuencialmente todas las direcciones ip obtenidas...
    for(struct addrinfo *ipAddress=ipAddresses;ipAddress!=NULL;ipAddress=ipAddress->ai_next) {
      //Creamos objeto para guardar la dirección del servidor NTP
        struct sockaddr_in serverAddress;
        memset(&serverAddress,0,sizeof(serverAddress)); //Vaciamos el objeto
        serverAddress.sin_family=AF_INET; //Definimos el dominio: IPv4 Internet
        serverAddress.sin_addr=((struct sockaddr_in*)(ipAddress->ai_addr))->sin_addr; //Asociamos la ip al servidor
        serverAddress.sin_port=htons(123); //Definimos el puerto
      //Nota. Si queremos saber la dirección ip, necesitamos pasarla a string
      //El código sería el siguiente:
      /*
        //Reservamos 16 bytes para guardar el texto de la dirección ip
        //La sintaxis de la dirección ip más larga es: xxx.xxx.xxx.xxx
        //Son 15 caracteres. A los que hay que añadir un carácter cero que
        //indica que la cadena ha finalizado. Total 16 bytes.
        char ipstr[16];
        //Convertimos la ip de binario a string
        inet_ntop(AF_INET,&serverAddress.sin_addr,ipstr,16);
        cout << "ipstr=[" << ipstr << "]" << endl;
      */
      
      //Inicializamos el buffer del paquete llenándolo de ceros
      memset(_packetBuffer,0,48);
      //Rellenamos las posiciones con los valores correctos para hacer
      //la solicitud al servidor NTP
      _packetBuffer[0]=0b11100011; // LI, Version, Mode
      _packetBuffer[1]=0; // Stratum, or type of clock
      _packetBuffer[2]=6; // Polling Interval
      _packetBuffer[3]=0xEC; // Peer Clock Precision
      //Los 8 bytes intermedios (del 4 al 11) son ceros (fijados antes).
      //Corresponden a Root Delay & Root Dispersion
      _packetBuffer[12]=49;
      _packetBuffer[13]=0x4E;
      _packetBuffer[14]=49;
      _packetBuffer[15]=52;
      
      //Creamos un socket con dominio de Internet, tipo datagrama y protocolo UDP
      int s=socket(AF_INET,SOCK_DGRAM,getprotobyname("udp")->p_proto);
      
      //Creamos una variable de tiempo de un segundo que la asociaremos al
      //socket como tiempo limite de espera de respuesta (timeout)
      struct timeval socketTimeout;
      socketTimeout.tv_sec=1; //Un segundo
      socketTimeout.tv_usec=0;
      setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&socketTimeout,sizeof(socketTimeout));
      
      //Enviamos el paquete UDP por el socket
      sendto(s,_packetBuffer,48,0,(struct sockaddr *)&serverAddress,sizeof(serverAddress));
      
      //Creamos objeto que guarda la dirección local para recibir
      //respuesta del socket
      struct sockaddr localAddress;
      //Variable para guardar el tamaño de la dirección local
      socklen_t localAddressLen=sizeof(localAddress);
      //Esperamos recibir respuesta. 48 bytes que se almacenarán en _packetBuffer
      //Hemos definido un segundo de timeout
      //Si se han recibido los 48 bytes esperados...
      if(recvfrom(s,_packetBuffer,48,0,&localAddress,&localAddressLen)==48) {
        //Extraemos la hora de la respuesta
        //La marca del tiempo se encuentra a partir del byte 40 del paquete recibido
        //Indica los segundos transcurridos desde el 1 de enero de 1900
        //En forma de uint32_t (4 bytes)
        //Leemos 4 bytes a partir de la posición 40
        //El primero es el que más peso tiene (como siempre)
        uint32_t secsSince1900=0;
        for(byte i=0;i<4;i++) secsSince1900=(secsSince1900<<8)+_packetBuffer[40+i];      
        //Añadimos el offset de tiempo debido a timeZone & summerTime
        secsSince1900+=_secondsOffset;
        //Liberamos el objeto que contiene los resultados
        freeaddrinfo(ipAddresses);
        //Terminamos devolviendo la hora actual 
        return secsSince1900;      
      }
      //La respuesta obtenida no es correcta
      //Suponemos que la dirección ip no es válida
      //Probaremos con la siguiente
    }
    //Hemos recorrido todas las direcciones ip, pero ninguna ha sido válida
    //Liberamos el objeto que contiene los resultados
    freeaddrinfo(ipAddresses);
    //Terminamos con error
    return 0;
  #else //Si es una placa ESP
    WiFiUDP _udp; //Objeto para gestionar los paquetes UDP
    _udp.begin(2390); //Inicializamos socket UDP recibiendo por el puerto 2390

    //Preparamos el paquete udp para que sea una solicitud de envío de hora
    //Inicializamos el buffer que contendrá la respuesta, llenándolo de ceros
    memset(_packetBuffer,0,48);
    //Rellenamos las posiciones con los valores correctos para hacer la solicitud al servidor NTP
    _packetBuffer[0] = 0b11100011; // LI, Version, Mode
    _packetBuffer[1] = 0;          // Stratum, or type of clock
    _packetBuffer[2] = 6;          // Polling Interval
    _packetBuffer[3] = 0xEC;       // Peer Clock Precision
    //Los 8 bytes intermedios (del 4 al 11) son ceros (fijados antes). Corresponden a Root Delay & Root Dispersion
    _packetBuffer[12]  = 49;
    _packetBuffer[13]  = 0x4E;
    _packetBuffer[14]  = 49;
    _packetBuffer[15]  = 52;
    //Hemos terminado de asignar los valores a todos los bytes del paquete para la solicitud NTP
    //Enviamos el paquete de solicitud siempre al puerto 123/udp
    _udp.beginPacket(_ntpServer.c_str(),123); //Indicamos la dirección de destino y el puerto
    _udp.write(_packetBuffer,48); //Escribimos (enviamos) el paquete de 48 bytes
    _udp.endPacket(); //Finalizamos el envío del paquete
    //Paquete de solicitud enviado!

    //Definimos la variable que contendrá el número de segundos transcurridos desde 01-01-1900
    //Inicialmente su valor es 0
    //Es el valor que devolveremso si no hemos podido obtener el tiempo de internet
    uint32_t secsSince1900=0;

    //Comprobamos cada décima de segundo si ha llegado un paquete con la longitud esperada
    //Lo repetimos un máximo de 10 veces (tiempo máximo = 1 segundo)
    for(byte t=0;t<10;t++) {
      //Esperamos un décima de segundo
      delay(100);
      //Si hemos recibido, al menos, un paquete completo...
      if(_udp.parsePacket()>=48) {
        //Leemos el paquete recibido y lo guardamos en el buffer
        _udp.read(_packetBuffer,48);
        //La marca del tiempo se encuentra a partir del byte 40 del paquete recibido
        //Indica los segundos transcurridos desde el 1 de enero de 1900
        //En forma de uint32_t (4 bytes)
        //Leemos 4 bytes a partir de la posición 40
        //El primero es el que más peso tiene (como siempre)
        for(byte i=0;i<4;i++) secsSince1900=(secsSince1900<<8)+_packetBuffer[40+i];
        //Hemos conseguido tener en secsSince1900 el número de segundos transcurridos desde
        //el 1 de enero de 1900 en la zona del meridiano de Greenwich
        secsSince1900+=_secondsOffset; //Añadimos la diferencia por timeZone & summerTime
        break; //Salimos del bucle (for)
      }
    }
    //Hemos esperado suficiente para recibir el paquete con el tiempo, y no ha llegado.
    //O sí lo tenemos y hemos obligado a terminar el bucle
    //De cualquier manera, podemos informar del resultado
    _udp.stop(); //Terminamos de utilizar la clase que gestiona los paquetes udp
    return secsSince1900; //Devolvemos el resultado
  #endif
}

#endif

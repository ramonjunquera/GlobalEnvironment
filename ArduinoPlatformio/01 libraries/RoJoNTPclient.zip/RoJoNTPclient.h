/*
  Nombre de la librería: RoJoNTPclient.h
  Versión: 20191128
  Autor: Ramón Junquera
  Descripción:
    Permite obtener la hora de un servidor NTP
*/

#ifndef RoJoNTPclient_h
#define RoJoNTPclient_h

#include <Arduino.h>
#ifdef __arm__ //Si es una RPi
  #include <netdb.h>
  #include <string.h>
#else //Si es una placa ESP
  #include <WiFiUdp.h>
#endif

class RoJoNTPclient {
  private:
    String _ntpServer; //Nombre del servidor NTP
    int32_t _secondsOffset; //Diferencia por timeZone y summerTime en segundos
    byte _packetBuffer[48]; //Buffer de paquetes
  public:
    void begin(String ntpServer,int8_t timeZone,bool summerTime); //Inicialización
    uint32_t get(); //Devuelve el tiempo en segundos desde 1900
};

#ifdef __arm__
  #include <RoJoNTPclient.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

/*
  Nombre de la librería: RoJoIP5306.h
  Versión: 20190920
  Autor: Ramón Junquera
  Descripción:
    Funciones de control de IP5306 para gestión de carga de batería
*/

#ifndef RoJoIP5306_h
#define RoJoIP5306_h

#include <Arduino.h>
#include <Wire.h>

class RoJoIP5306 {
  private:
    const byte _id=0x75; //Identificador I2C
    byte _read(byte reg); //Lee un registro por I2C
    void _write(byte reg,byte value); //Escribe un registro por I2C
  public:
    bool setVinMaxCurrent(uint16_t i=650); //Fija la intensidad máxima
    bool setChargeVolt(byte volt=0); //Fija voltaje de carga
    bool begin(byte pinSDA=255,byte pinSCL=255); //Inicialización
    bool isCharging(); //Está cargando?
    bool isChargeFull(); //Está cargado a tope?
    byte getBatteryLevel(); //Obtiene el nivel de batería
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoIP5306.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

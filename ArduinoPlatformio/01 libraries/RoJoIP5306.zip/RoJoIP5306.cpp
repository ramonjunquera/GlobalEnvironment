/*
  Nombre de la librería: RoJoIP5306.h
  Versión: 20190920
  Autor: Ramón Junquera
  Descripción:
    Funciones de control de IP5306 para gestión de carga de batería
*/

#ifndef RoJoIP5306_cpp
#define RoJoIP5306_cpp

#include <RoJoIP5306.h>

//Lee un registro por I2C
byte RoJoIP5306::_read(byte reg) {
  Wire.beginTransmission(_id);
    Wire.write(reg); //Solicitamos registro
  Wire.endTransmission(false); //Enviamos la solicitud, pero no cerramos la conexión
  Wire.requestFrom(_id,(byte)1); //Esperamos recibir 1 byte
  return Wire.read(); //Devolvemos el valor recibido
}

//Escribe un registro por I2C
void RoJoIP5306::_write(byte reg,byte value) {
  Wire.beginTransmission(_id);
    Wire.write(reg);
    Wire.write(value);
  Wire.endTransmission();
}

//Fija la intensidad máxima
//Devuelve true si lo consigue
bool RoJoIP5306::setVinMaxCurrent(uint16_t i) {
  //El parámetro i representa la intensidad en miliamperios
  //El límite máximo es de 3100 mA
  if(i>3100) return false; //Si está fuera de rango...terminamos con error
  _write(0x24,(_read(0x24) & 0xe0) | i/10); //Actualizamos registro 0x24=IP5306_REG_CHG_DIG
  return true; //Todo Ok
}

//Fija voltaje de carga
//Devuelve true si lo consigue
bool RoJoIP5306::setChargeVolt(byte volt) {
  //El parámetro volt representa el código de voltaje de la siguiente tabla:
  //  0 -> 4.2V (valor por defecto)
  //  1 -> 4.3V
  //  2 -> 4.35V
  //  3 -> 4.4V
  if(volt>3) return false;
  _write(0x20,(_read(0x20) & 0xfc) | volt); //Actualizamos registro 0x20=IP5306_REG_CHG_CTL0
  return true;
}

//Inicialización
//Devuelve true si todo es correcto
bool RoJoIP5306::begin(byte pinSDA,byte pinSCL) {
  bool answer;
  //Los dispositivos ESP permiten crear la comunicación I2C en cualquier pin
  //Por eso diferenciamos por tipo de despositivo...
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino
    //No hay posibilidad de seleccionar los pines I2C. Obviamos los parámetros
    answer=Wire.begin();
  #else //Si es un ESP o RPi
    //Si debemos utilizar los parámetros por defecto...
    if(pinSCL==255) answer=Wire.begin();
    else answer=Wire.begin(pinSDA,pinSCL);
  #endif
  //Si hemos podido inicializar I2C...
  if(answer) {
    setVinMaxCurrent(650); //Fijamos el límite de intensidad a 650mA
    setChargeVolt(0); //Fijamos el límite de voltaje de carga a 4.2V
    _write(0x21,_read(0x21) & 0x3F); //End charge current 200mA
    _write(0x22,(_read(0x22) & 0xFC) | 0x02); //Add volt 28mv
    _write(0x23,(_read(0x23) & 0xDF) | 0x20); //Vin charge CC
  }
  return answer;
}

//Está cargando?
bool RoJoIP5306::isCharging() {
  return (_read(0x70) & 0x08) > 0; //Leemos bit CHARGE_ENABLE_BIT del registro 0x70=IP5306_REG_READ0
}

//Está cargado a tope?
bool RoJoIP5306::isChargeFull() {
  return (_read(0x71) & 0x08) > 0; //Leemos bit CHARGE_FULL_BIT del registro 0x71=IP5306_REG_READ1
}

//Obtiene el nivel de batería entre 0=vacía y 4=llena
byte RoJoIP5306::getBatteryLevel() {
  switch (_read(0x78) & 0xF0) {
    case 0x00:
      return 4;
    case 0x80:
      return 3;
    case 0xC0:
      return 2;
    case 0xE0:
      return 1;
    default:
      return 0;
  }
}

#endif
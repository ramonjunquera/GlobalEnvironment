/*
  Nombre de la librería: RoJoWiFiSensor.h
  Versión: 20190929
  Autor: Ramón Junquera
  Descripción:
    Detección de movimiento por wifi
  Teoría y objetivo
    Una de la multitud de rediofrecuencias de las que estamos rodeados contínuamente es WiFi.
    Habitualmente no tenemos una visión directa entre el punto de acceso y el cliente.
    Lo normal es que las ondas chonquen, reboten y se distorsionen por el camino, perdiendo
    intensidad a cada paso.
    Uno de los obstáculos que deben sortear son las personas, que también absorben parte de la
    energía que tiene la onda.
    Por lo tanto, el movimiento de una persona en un entorno WiFi, produce alteración en la
    intensidad de la señal de los distintos puntos de acceso disponibles.
    El objetivo de esta librería es intentar detectar estas alteraciones para determinar si
    hay algún objeto en movimiento.
  Intensidad de señal
    La intensidad de señal de un punto de acceso se denomina RSSI. Es un número entero negativo.
    Cuanto mayor es el valor, mayor es la intensidad.
    Un punto de acceso con una buena señal tiene una RSSI > -80.
    Para valores por debajo de -90 consideramos que la señal comienza a debilitarse.
    Por lo tanto, tabajaremos con un rango de valores enteros entre [-255,0].
    Para simplificar su gestión, cambiaremos el signo a la RSSI y lo guardaremos en un byte
  Dispersión
    La señales más próximas tienen de tener una menor dispersión de valores que las alejadas,
    puesto que tienen menos obstáculos y probabilidades de que se muevan o provoquen interferencias.
  Requisitos
    Puesto que cada posición tiene un número de puntos de acceso distinto y distintas intensidades
    de señal, debemos crear un sistema que aprenda a reconocerlo de manera automática para que
    se adapte sin necesidad de una configuración previa.
  Almacenamiento
    Utilizaremos un diccionario en memoria que almacene los datos de cada uno de los puntos de
    acceso que gestionamos.
    Como clave utilizaremos la dirección MAC (BSSID). No usamos el nombre del punto de acceso porque
    no es un identificador único (varios puntos de acceso con el mismo nombre).
    Como valor del diccionario almacenaremos el histórico de medidas (RSSI) obtenidas.
    Las acompañaremos con los valores mínimo y máximo de las medidas guadadas.
    Antes de guardar una nueva medida, desplazaremos todas las medidas una posición en el array y
    la guardaremos en la primera.
    Esto obliga a recalcular el mínimo y máximo en cada nueva medida.
  Intensidades bajas
    Puesto que las señales con baja intensidad tiene gran dispersión, marcaremos un mínimo de señal.
    A partir de él, no tendremos en cuenta ese punto de acceso.
    Podría ser que a lo largo del tiempo una señal descienda por debajo del mínimo permitido.
    En estos casos eliminaremos la referencia del punto de acceso del diccionario.
  Desviación
    Un objeto en movimiento puede provocar el cambio de intensidad de varios puntos de acceso al
    mismo tiempo.
    Para tener en cuenta todas las variaciones, creamos una variable para la desviación acumulada.
    Cada vez que se solicite una comprobación, la desciación comenzará siendo nula.
    Se incrementará con los valores absolutos de las diferencias entre la intensidad actual y lo
    que salga de los límites de guardado.
  Método
    Inicialmente nuestro diccionario está vacío.
    Solicitamos un nuevo scaneo de puntos de acceso.
    Recorremos cada una de las entradas.
    Si reconocemos una MAC, comprobamos si su RSSI está dentro de los rangos actuales.
    Si no es así, incrementamos la desviación acumulada y añadiremos al histórico el RSSI actual.
    Si no reconocemos la MAC y tiene suficiente intensidad como para tenerla en cuenta, creamos
    una nueva entrada en el diccionario.
    Finalmente comprobamos si la desviación acumulada supera el límite establecido.
  Autoconfiguración
    Inicialmente tomamos medidas hasta que nos encontramos con un número fijado de medidas positivas
    (si que la desciación acumulada haya superado el máximo fijado).
    El método de inicialización (begin), permite indicar dos funciones. La roja que se llamará cuando
    se detecta una desviación, y la amarilla cuando no.
  Fiabilidad
    Se deben ajustar muy bien los valores de los parámetros definidos como constantes en el archivo
    de cabecera de la clase.
    Cuando se detecta movimiento, la medida se guarda en el histórico. Por lo tanto, no volverá a
    saltar la alarma por la misma razón hasta que no se regenere totalmente el histórico.
    Por esta razón, es conveniente que cuando se detecte movimento, se continúe tomando medidas
    pero no se haga saltar la alarma de nuevo en un tiempo, aproximadamente el que tarda el 
    hostórico en regenerarse.
  Debug
    En el archivo .cpp se puede definir la constante de entorno DEBUGGING que permitirá enviar por
    el puerto serie información detallada del funcionamiento interno.
*/

#ifndef RoJoWiFiSensor_h
#define RoJoWiFiSensor_h

#include <Arduino.h>
#include <WiFi.h>
#include <RoJoDictionary.h> //Gestión de diccionarios en memoria

const byte _maxDataRSSI=20; //Máximo número de medidas de intensidades que almacenaremos

//Estructura de datos de intensidades
struct RSSI {
  byte min;
  byte max;
  byte data[_maxDataRSSI];
};

class RoJoWiFiSensor {
  private:
    RoJoDictionary<String,RSSI> _savedMACs; //Diccionario de MACs guardadas
    const byte _maxStableChecks=_maxDataRSSI; //Máximo número de comprobaciones estables
    const byte _maxRSSI=90; //Máximo valor de intensidad de señal (menor cuanto más intensidad)
    const int _scanWait=8; //Tiempo de espera máximo para analizar una red
    const uint16_t _maxDev=_maxRSSI/30; //Máxima desviación acumulada = sensibilidad. A mayor valor, menos sensibilidad.
    uint16_t _update(); //Actualización de estado. Devuelve desviación acumulada
  public:
    bool begin(void (*functionRed)(),void (*functionYellow)()); //Inicialización
    bool check(); //Comprueba movimento

}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoWiFiSensor.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


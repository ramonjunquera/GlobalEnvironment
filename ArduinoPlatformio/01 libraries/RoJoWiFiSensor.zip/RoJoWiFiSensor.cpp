/*
  Nombre de la librería: RoJoWiFiSensor.h
  Versión: 20190929
  Autor: Ramón Junquera
  Descripción:
    Detección de movimiento por wifi
*/

#ifndef RoJoWiFiSensor_cpp
#define RoJoWiFiSensor_cpp

#define DEBUGGING //Activar para recibir mensajes de estado

#include <RoJoWiFiSensor.h>

//Inicialización
//Devuelve true si lo consigue
bool RoJoWiFiSensor::begin(void (*functionRed)(),void (*functionYellow)()) {
  //Como parámetros pasamos las funciones a las que se llama cuando se detectan cambios (red)
  //o no se detectan cambios (yellow). Las funciones no tienen parámetros ni devuelve nada.

  byte currentStableChecks=0; //Actual número de comprobaciones estables
  functionRed(); //Comenzamos llamando a la función roja
  bool lastWasRed=true; //La última llamada ha sido a la función roja
  uint16_t dev; //Desviación acumulada

  WiFi.begin(); //Activamos wifi
  _savedMACs.clear(); //Vaciamos el diccionario de MACs por si se quere reiniciar más de una vez

  while(currentStableChecks<_maxStableChecks) { //Mientras no tengamos suficientes comprobaciones estables...
    currentStableChecks++; //Suponemos que todo saldrá bien (inocente mientras no se demuestre lo contrario)
    dev=_update(); //Actualizamos el estado y obtenemos la desviación acumulada
    if(dev>_maxDev) { //Si se ha superado el máximo de desviación permitida...
      currentStableChecks=0; //Reiniciamos el contador de comprobaciones estables
      if(lastWasRed==false) { //Si la última llamada no fue rojo...
        functionRed(); //La llamamos ahora
        lastWasRed=true; //Anotamos que la última llamada ha sido roja
      } 
    }
    else { //Si no se contemplan modificaciones...
      if(lastWasRed==true) { //Si la última llamada fue roja...
        functionYellow(); //Hacemos la llamada amarilla
        lastWasRed=false; //Anotamos que la última llamada ha sido amarilla
      } 
    }
    #ifdef DEBUGGING
      Serial.println("  currentStableChecks="+String(currentStableChecks)); //DEBUG
    #endif
  }
  return true; //Fin de inicialización. Todo estable. Ok
}

//Comprueba movimiento
bool RoJoWiFiSensor::check() {
  uint16_t dev=_update(); //Actualizamos el estado y obtenemos la desviación acumulada
  #ifdef DEBUGGING
    Serial.println("  dev="+String(dev)); //DEBUG
  #endif
  return dev>_maxDev; //Devuelve si la desviación acumulada es mayor que el máximo esperado

}

//Actualización de estado. Devuelve desviación acumulada
uint16_t RoJoWiFiSensor::_update() {
  RSSI *dataRSSI=nullptr; //Puntero a estructura de datos de intensidades
  uint16_t dev=0; //Desviación acumulada

  byte SSIDcount=WiFi.scanNetworks(false,true,false,_scanWait); //Solicitamos un nuevo scanner y obtenemos el número de puntos de acceso disponibles
  for (byte SSIDindex=0;SSIDindex<SSIDcount;SSIDindex++) { //Recorremos todos los puntos de acceso
    String currentMAC=WiFi.BSSIDstr(SSIDindex); //Obtenemos la MAC address
    //Obtenemos la intensidad. Recordemos que la intensidad tiene signo negativo.
    //Cuanto mayor sea la intensidad mayor será el valor (más próximo a cero)
    //Para hacerlo más cómodo, cambiaremos el signo y trabajaremos sólo con valores positivos,
    //aunque estarán invertidos. A mayor valor -> menor intensidad. (No es un problema).
    int32_t currentRSSI=-WiFi.RSSI(SSIDindex);
    if(_savedMACs.value(currentMAC,&dataRSSI)) { //Si hemos podido obtener los datos de intensidad de la MAC actual (porque existe)...
      if(currentRSSI<dataRSSI->min) { //Si es menor que el mínimo
        #ifdef DEBUGGING
          Serial.println("New min. MAC:"+currentMAC+", "+String(dataRSSI->min)+"->"+String(currentRSSI)); //DEBUG
        #endif
        dev+=dataRSSI->min-currentRSSI; //Incrementamos la desviación
      }
      if(currentRSSI>dataRSSI->max) { //Si es mayor que el máximo
        #ifdef DEBUGGING
          Serial.println("New max. MAC:"+currentMAC+", "+String(dataRSSI->max)+"->"+String(currentRSSI)); //DEBUG
        #endif
        dev+=currentRSSI-dataRSSI->max; //Incrementamos la desviación
      }
      for(byte i=_maxDataRSSI-1;i>0;i--) dataRSSI->data[i]=dataRSSI->data[i-1]; //Movemos todos los valores una posición
        dataRSSI->data[0]=currentRSSI; //Añadimos el valor de la intensidad actual al histórico de datos
        //Recalculamos máximos y mínimos
        dataRSSI->min=255;
        dataRSSI->max=0;
        for(byte i=0;i<_maxDataRSSI;i++) {
          if(dataRSSI->data[i]>dataRSSI->max) dataRSSI->max=dataRSSI->data[i];
          if(dataRSSI->data[i]<dataRSSI->min) dataRSSI->min=dataRSSI->data[i];
        }
        if(dataRSSI->min>=_maxRSSI) { //Si la señal tiene tan poca intensidad que no vale la pena considerarla...
          #ifdef DEBUGGING
            Serial.println("MAC removed by low signal. MAC:"+currentMAC+", min="+String(dataRSSI->min)); //DEBUG
          #endif
          _savedMACs.remove(currentMAC); //La borramos
        } 
    } else { //Si esta MAC no la tenemos guardada...
      if(currentRSSI<_maxRSSI) { //Si tiene la suficiente intensidad la tendremos en cuenta...
        dataRSSI=new RSSI; //Creamos una nueva estructura de datos de intensidades
        //Todos los datos de histórico, máximo y mínimo serán iguales
        dataRSSI->min=dataRSSI->max=currentRSSI;
        for(byte i=0;i<_maxDataRSSI;i++) dataRSSI->data[i]=currentRSSI;
        #ifdef DEBUGGING
          Serial.println("MAC new: MAC:"+currentMAC+", currentRSSI="+String(currentRSSI)); //DEBUG
        #endif
        _savedMACs.add(currentMAC,dataRSSI); //Añadimos la MAC al diccionario
        dev++; //Por añadir una nueva MAC, incrementamos en una unidad la desviación
      }
    }
  }
  return dev; //Devuelve la desviación acumulada
}


#endif

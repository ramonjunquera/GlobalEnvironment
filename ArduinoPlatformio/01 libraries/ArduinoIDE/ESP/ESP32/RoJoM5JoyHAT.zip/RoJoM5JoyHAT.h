/*
  Nombre de la librería: RoJoM5JoyHAT.h
  Versión: 20200128
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del HAT de Joystick para M5Stick C
*/

#ifndef RoJoM5JoyHAT_h
#define RoJoM5JoyHAT_h

#include <Arduino.h>
#include <Wire.h>

class RoJoM5JoyHAT {
  private:
    const byte _idI2C=0x38; //Identificador del dispositivo en bus I2C
    bool _init=false; //Ha sido inicializado?
  public:
    bool begin(); //Inicialización
    bool get(int8_t *x,int8_t *y,bool *button); //Obtener datos
};

#endif

/*
  Nombre de la librería: RoJoESP32PWMS.h
  Versión: 20191001
  Autor: Ramón Junquera
  Descripción:
    Gestión de PWM para placas ESP32 usando el método SigmaDelta

    A fecha actual el paquete de instrucciones para compatibilizar las placas ESP32 con el IDE
    de Arduino no está totalmente desarrollado.
    Concretamente la instrucción analogWrite para gestionar PWM no existe.
    Se ha creado la función con el mismo nombre y parámetros que la original.
    La única diferencia es que devolverá false si no ha podido completarse.

    Con el método SigmaDelta disponemos de 8 canales (timers) con una resolución de 8 bits.
    Cada canal puede ser programado con su propia amplitud de onda.
    Una vez configurado un canal se asocia a un pin, que tendrá el estado de la onda.
    Por lo tanto, con esta librería podremos tener un máximo de 8 pines PWM con valores distintos.

    La frecuencia de la onda puede variar entre 1220 y 312500 Hz.
    Nosotros utilizamos la máxima.

    Los canales podrían ser utilizados por otras funciones.
    Esta clase no lo tiene en cuenta porque no hay manera de distinguir si un canal está o no
    en uso. Por lo tanto, si se hace uso de las funciones SigmaDelta desde algún otro punto
    del programa, debemos tener en cuenta que se corromperá por no respetarlas.
    En este caso, se sugiere utilizar la librería RoJoESP32PWML.h que hace uso de la funciones
    ledc que sí permiten compartir canales y tener un resultado similar.

    La función encarga de:
    - Comprobar si ya existe un canal que tenga asignado el pin solicitado para reutilizarlo.
    - Desactivar canales cuyo nivel es 0
    - Buscar canales libres para nuevas peticiones.
*/

#include <RoJoAnalogWriteESP32S.h>

//Asigna un nivel PWM a un pin
//Devuelve true si lo consigue
bool analogWrite(byte pin,byte level) {
  //Array con los pines asignados a cada canal. Inicialmente todos desasignados
  //Utilizamos 255 porque nunca hay tantos pines.
  static byte _pinsPWM[8]={255,255,255,255,255,255,255,255};

  //Último canal vacío
  byte lastEmpty=0xFF; 

  //El pin indicado tiene ya abierto un canal?
  //Recorremos todos los canales
  for(byte ch=0;ch<8;ch++) {
    if(_pinsPWM[ch]==pin) { //Si hemos encontrado un canal asignado a este pin...
      if(level) sigmaDeltaWrite(ch,level); //Si el nivel es distinto de cero...cambiamos el nivel PWM del canal
      else { //Si el nivel es cero...
        sigmaDeltaDetachPin(pin); //...desasignamos el pin del canal
        digitalWrite(pin,LOW); //Ponemos el pin a low. Forzamos que quede apagado
        _pinsPWM[ch]=255; //Anotamos que está desasignado
      }
      return true; //Hemos terminado correctamente
    }
    else { //Este canal no está asignado al pin indicado
      if(_pinsPWM[ch]==255) lastEmpty=ch; //Si el canal está sin asignar...anotamos que está vacío
    }
  }
  //Hemos recorrido todos los canales y ninguno está asignado al pin indicado
  //Si tenemos algún canal desasignado...
  if(lastEmpty!=0xFF) {
    //...lo utilizaremos
    _pinsPWM[lastEmpty]=pin; //Lo anotamos
    sigmaDeltaSetup(lastEmpty,312500); //Fijamos el canal a la máxima frecuencia
    sigmaDeltaWrite(lastEmpty,level); //Fijamos el nivel al solicitado
    sigmaDeltaAttachPin(pin,lastEmpty); //Asociamos el pin al canal
    return true; //Hemos terminado correctamente
  }
  //No tenemos canales desasignado para la petición
  return false; //Devolvemos error
}


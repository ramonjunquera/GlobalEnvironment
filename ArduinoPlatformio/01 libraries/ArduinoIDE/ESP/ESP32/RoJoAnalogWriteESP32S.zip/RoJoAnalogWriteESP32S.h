/*
  Nombre de la librería: RoJoESP32PWMS.h
  Versión: 20191001
  Autor: Ramón Junquera
  Descripción:
    Gestión de PWM para placas ESP32 usando el método SigmaDelta
*/

//Comprobamos que la placa es compatible
#if !defined(ESP32)
  #error Library RoJoAnalogWriteESP32S is only compatible with ESP32 family devices
#endif  

#pragma once //Evita el uso clásico de la comparativa de etiqueta para evitar cargas múltiples

#include <Arduino.h>

bool analogWrite(byte pin,byte level); //Asigna un nivel PWM a un pin

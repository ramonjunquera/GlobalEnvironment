/*
  Nombre de la librería: RoJo74HC595N8d.h
  Versión: 20200926
  Autor: Ramón Junquera
  Descripción:
  Como sabemos, 74HC595 nos permite aumentar el número de pines digitales.
  2 chips 74HC595 encadenados nos permiten controlar 16 pines digitales.
  La teoría nos dice que en el caso de una matriz de leds monocromos de 8x8,
  o un display led numérico de 8 dígitos, no podemos utilizarlo porque están
  preparados para multiplexación.
  Afortunadamente, el tiempo necesario para transferir la información es tan
  reducido que también podemos utilizarlo con multimplezación.
  Centrándonos en la solución aplicada en esta librería, tenemos dos módulos
  de leds numéricos de 4 dígitos. 8 dígitos en total.
  Si utilizados 2 chips de 74HC595 encadenados, podríamos conectar las salidas
  de uno a la posición del dígito a encender y el la salidas del otro a los
  pines de los segmentos a encender para dibujar el dígito.
  Esto sólo encendería un dígito. Pero si recorremos todos los dígitos
  secuencialmente y a la suficiente velocidad como para mantener persistencia
  visual, conseguiremos controlar el display completo.
  La misma teoría se podría aplicar a una matriz de leds monocromos de 8x8.
  La clase mantiene una memoria interna de 8 bytes. Uno por dígito.
  Viene con un pequeño diccionario de caracteres predefinidos, pero deja abierta
  la posibilidad de definición de caracteres customizados.
  Incluye un método para representar todos los dígitos de un número entero con
  signo.
  El método show está implementado de la manera más sencilla posible: síncrono.
  Sólo hay que indicarte el tiempo en milisegundos que queremos mantener el
  refresco del display.
  Se podrían utilizar interrupciones, timers, o Threads si nustro microcontrolador
  tiene más de un núcleo o un sistema que nos lo permita (RTOS).

  Ensamblado:
  El conjunto puede ensamblarse manualmente con 2 74HC595 en cascada y 2 displays
  led numéricos de 4 dígitos de ánodo común, pero también se vende ya montado.
  Se puede encontrar en Aliexpress: https://es.aliexpress.com/item/4001294161072.html
  Pinout:
  - DIO = pinData
  - SCK = pinClock
  - RCK = pinLatch
*/

#ifndef RoJo74HC595N8d_h
#define RoJo74HC595N8d_h

#include <Arduino.h>

class RoJo74HC595N8d {
  protected:
    byte _pinData,_pinLatch,_pinClock;
    byte _videoMem[8];
    //Definición de los caracteres que se pueden mostrar en una posición
    const byte _chars[19]={ 
      0b11000000 // 0 = 0
     ,0b11111001 // 1 = 1
     ,0b10100100 // 2 = 2
     ,0b10110000 // 3 = 3
     ,0b10011001 // 4 = 4
     ,0b10010010 // 5 = 5
     ,0b10000010 // 6 = 6
     ,0b11011000 // 7 = 7
     ,0b10000000 // 8 = 8
     ,0b10010000 // 9 = 9
     ,0b10001000 //10 = A
     ,0b10000011 //11 = b
     ,0b11000110 //12 = C
     ,0b10100001 //13 = d
     ,0b10000110 //14 = E
     ,0b10001110 //15 = F
     ,0b11111111 //16 = space
     ,0b10111111 //17 = -
     ,0b10011100 //18 = º
   };
   //Configuración de cada una de las posiciones de izquierda a derecha
   const byte _posId[8]={0b00010000,0b00100000,0b01000000,0b10000000,0b00000001,0b00000010,0b00000100,0b00001000};
  public:
    RoJo74HC595N8d(byte pinData,byte pinLatch,byte pinClock); //Constructor
    void set(byte pos,byte charIndex,bool dot); //Escribe un caracter del alfabeto en la memoria de vídeo
    void set(byte pos,byte value); //Escribe un valor en la memoria de vídeo de un chip
    void show(uint32_t ms=0); //Muestra memoria de video durante un tiempo
    void write(int64_t value); //Muestra un número entero con signo en el display
    void clear(byte chaIndex=16); //Borra memoria de video
};

#endif

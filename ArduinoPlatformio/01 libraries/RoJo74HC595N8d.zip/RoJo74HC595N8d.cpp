/*
  Nombre de la librería: RoJo74HC595N8d.h
  Versión: 20200926
  Autor: Ramón Junquera
  Descripción:
*/

#ifndef RoJo74HC595N8d_cpp
#define RoJo74HC595N8d_cpp

#include <Arduino.h>
#include <RoJo74HC595N8d.h>

//Constructor
RoJo74HC595N8d::RoJo74HC595N8d(byte pinData,byte pinLatch,byte pinClock) {
  //Guardamos los parámetros en variables privadas
  _pinData=pinData;
  _pinLatch=pinLatch;
  _pinClock=pinClock;
  //Configuramos los pines como salidas
  pinMode(_pinData,OUTPUT);
  pinMode(_pinLatch,OUTPUT);
  pinMode(_pinClock,OUTPUT);
}

//Escribe un caracter del alfabeto en la memoria de vídeo
//  pos es la posición del carácter [0,7]
//  charIndex es el índice del caracter a mostrar en el diccionario
//  dot es el punto decimal
void RoJo74HC595N8d::set(byte pos,byte charIndex,bool dot) {
  //Guardamos el valor que corresponde al índice del carácter en la memoria de vídeo
  //Tenemos en cuenta el punto decimal
  _videoMem[pos]=_chars[charIndex] & (dot?0b01111111:0b11111111);
}

//Escribe un valor en la memoria de vídeo
//  pos es la posición del carácter [0,7]
//  value es el estado de los segmentos del dígito
void RoJo74HC595N8d::set(byte pos,byte value) {
  _videoMem[pos]=~value; //Guardamos el valor en su posición de la memoria de vídeo
}

//Muestra memoria de vídeo durante un tiempo
void RoJo74HC595N8d::show(uint32_t ms) {
  uint32_t maxTime=millis()+ms;
  while(millis()<maxTime) {
    for(byte pos=0;pos<8;pos++) {
      digitalWrite(_pinLatch,LOW);
      shiftOut(_pinData,_pinClock,MSBFIRST,_videoMem[pos]); //Not segments
      shiftOut(_pinData,_pinClock,MSBFIRST,_posId[pos]); //Pos
      digitalWrite(_pinLatch,HIGH);
      delay(1);
    }
  }
}

//Escribe un valor entero en la memoria de video
void RoJo74HC595N8d::write(int64_t value) {
  if(!value) { //Si es 0...
    for(int8_t pos=6;pos>=0;pos--) _videoMem[pos]=_chars[16];
    _videoMem[7]=_chars[0];
  } else { //Si no es 0...
    int64_t valueAbs=abs(value);
    for(int8_t pos=7;pos>=0;pos--) {
      if(valueAbs) _videoMem[pos]=_chars[valueAbs%10];
      else _videoMem[pos]=_chars[16];
      valueAbs/=10;
    }
    //Si es negativo ponemos el signo
    if(value<0) _videoMem[0]=_chars[17];
  }
}

//Borra la memoria de video
void RoJo74HC595N8d::clear(byte charIndex) {
  for(int8_t i=7;i>=0;i--) _videoMem[i]=_chars[charIndex];
}

#endif
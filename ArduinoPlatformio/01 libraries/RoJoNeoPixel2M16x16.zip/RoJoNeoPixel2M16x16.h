/*
  Nombre de la librería: RoJoNeoPixel2M16x16.h
  Versión: 20210826
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixel2M16x16_h
#define RoJoNeoPixel2M16x16_h

#include <Arduino.h>
#include <RoJoSprite2.h> //Gestión de sprites
#include <RoJoNeoPixel2.h>

class RoJoNeoPixel2M16x16:public RoJoNeoPixel2 {
  private:
    byte _XY2Index(byte x,byte y);
  public:
    const uint16_t xMax=16; //Anchura de display
    const uint16_t yMax=16; //Altura de display
    bool begin(byte pin); //Inicialización
    bool drawPixel(byte x,byte y,uint32_t color);
    uint32_t getPixel(int16_t x,int16_t y); //Devolvemos color de pixel
    bool clear(uint32_t color=0);
    bool drawSprite(RoJoSprite2 *source,int16_t x=0,int16_t y=0); //Dibuja un sprite en unas coordenadas
}; //Punto y coma obligatorio para que no de error

#endif


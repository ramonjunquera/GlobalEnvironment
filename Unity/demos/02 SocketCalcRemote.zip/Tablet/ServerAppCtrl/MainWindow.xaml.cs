﻿/*
 * Autor: Ramón Junquera
 * Tema: Servidor de control de Calculadora por puerto serie
 * Fecha: 20211013
 * 
 * Notas:
 * - Cuando el device-in-the-middle arranca o reinicia, envía por el puerto serie
 *   información por defecto. No se puede evitar este envío. El contenido son caracteres
 *   de texto ASCII, excepto el último carácter que es 255.
 *   Por esta razón utilizaremos códigos binarios de valor bajo (<65). Así evitaremos
 *   confundirlos con estos mensajes.
 *   Los códigos deconocidos no los tendremos en cuenta.
 * - La comprobación de conexión de dispositivo y obtención de su puerto serie (llamada a 
 *   GetPortName) consume mucho tiempo.
 *   Aunque la frecuencia de envío y recepción es muy baja, no lo haremos en cada ciclo.
 *   Creamos un par de variable para controlar cada cuántos ciclos lo comprobamos.
 *   Esto acelera mucho el proceso de comandos.
 */

using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Media;

namespace ServerAppCtrl {
  /// <summary>
  /// Lógica de interacción para MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window {
    //Constantes globales
    private const string deviceId = "FTDIBUS\\VID_0403+PID_6001+6952BB03B4A\\0000"; //M5Stack Atom Lite
    //Variables globales
    private bool requestExit = false;
    private string appName = "Calculator";
    private byte systemVer = 0; //Versión de sistema operativo (columna de tabla automationIds
    private readonly string[,] automationIds = new string[17, 2]{
      { "num0Button", "130" } //0
      , {"num1Button", "131"} //1
      , {"num2Button", "132"} //2
      , {"num3Button", "133"} //3
      , {"num4Button", "134"} //4
      , {"num5Button", "135"} //5
      , {"num6Button", "136"} //6
      , {"num7Button", "137"} //7
      , {"num8Button", "138"} //8
      , {"num9Button", "139"} //9
      , {"multiplyButton", "92"} //*
      , {"minusButton", "94"} //-
      , {"plusButton", "93"} //+
      , {"equalButton", "121"} //=
      , {"decimalSeparatorButton", "84"} //,
      , {"backSpaceButton", "83"} //<-
      , {"CalculatorResults", "150"} //display
    };

    private AutomationElement GetElementObj(AutomationElement appObj, String automationId) {
      //Creamos una nueva condición para buscar por la propiedad AutomationId
      System.Windows.Automation.Condition condition = new PropertyCondition(AutomationElement.AutomationIdProperty, automationId);
      //Aplicamos las condiciones de búsqueda a los elementos de la aplicación y devolvemos la primera referencia encontrada
      return appObj.FindFirst(TreeScope.Descendants, condition);
    }

    /// <summary>
    /// Genera el mensaje de Click en el botón de la aplicación indicada
    /// </summary>
    /// <param name="appObj"></param>
    /// <param name="automationId"></param>
    private void ClickRemoteButton(AutomationElement appObj, String automationId) {
      if (appObj != null) { //Si la aplicación está en ejecución...
        //Obtenemos el objeto del ejemento
        AutomationElement myButton = GetElementObj(appObj, automationId);
        if (myButton != null) { //Si se ha encontrado el elemento que buscamos...
          //Creamos el objeto que generará el mensage de pulsación del botón
          InvokePattern btnPattern = myButton.GetCurrentPattern(InvokePattern.Pattern) as InvokePattern;
          btnPattern.Invoke(); //Lanzamos el mensaje de pulsación del bótón
        }
      }
    }

    /// <summary>
    /// Obtiene el objeto de la primera instancia en ejecución de la aplicación
    /// </summary>
    /// <returns>Puede devolver null</returns>
    private AutomationElement GetAppObj() {
      //Creamos elemento raíz del árbol de aplicaciones en ejecución
      AutomationElement root = AutomationElement.RootElement;
      //Creamos condición que filtra por nombre de aplicación
      System.Windows.Automation.Condition condition = new PropertyCondition(AutomationElement.NameProperty, appName);
      //Filtramos el árbol de aplicaciones en ejecución por nombre y guardamos el primer resultado obtenido
      return root.FindFirst(TreeScope.Children, condition);
    }

    //Devuelve el nombre del puerto serie en formato COM19. Si no lo encuenta devuelve una cadena vacía.
    //device ID es el identificador del dispositivo.
    private string GetPortName(string deviceId) {
      deviceId = deviceId.Replace("\\", "\\\\"); //Duplicamos el carácter \ porque lo utilizaremos para una consulta!
      string portName = ""; //Inicialmente no tenemos nombre de puerto
      //Creamos una consulta a los dispositivos del sistema que en su Caption
      //contengan la palabra COM (puertos de comunicación) y su DeviceID sea
      //el que buscamos
      ManagementObjectSearcher deviceSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%' AND DeviceID = '" + deviceId + "'");
      //Creamos una lista con todos los dispositivos
      List<ManagementBaseObject> devices = deviceSearcher.Get().Cast<ManagementBaseObject>().ToList();
      if(devices.Count>0) { //Si tenemos algún resultado...
        //Obtenemos el Caption del primer dispositivo en formato: "USB Serial Port (COM19)"
        string caption = devices[0].GetPropertyValue("Caption").ToString();
        //Para evitar problemas con idiomas, sólo buscaremos el texto que comienza por COM y llega hasta el siguiente )
        int indexCOM = caption.IndexOf("COM"); //Localizamos el texto "COM"
        //Devolvemos el puerto que comienza en indexCOM y llega hasta el siguiente )
        portName = caption.Substring(indexCOM, caption.IndexOf(")", indexCOM + 3) - indexCOM);
      }
      return portName; //Devolvemos el nombre del puerto
    }

    private void ThreadMain() {
      string portNameUsed = ""; //Inicialmente no estamos utilizando ningún puuerto seria
      string portNameReal = ""; //Puerto serie real
      SerialPort serialPort = null;
      const int epochGetPortName = 100; //Cada cuántos ciclos comprobamos la conexión del dispositivo?
      int epochGetPortNameCounter = 0; //Contador de ciclos para comprobar conexión de dispositivo

      while (!requestExit) {
        if(--epochGetPortNameCounter < 0) { //Hemos terminado los ciclos para comprobar conexión de dispositivo?
          epochGetPortNameCounter = epochGetPortName; //Reseteamos el contador de ciclos
          portNameReal = GetPortName(deviceId); //Obtenemos el puerto asignado al dispositivo
        }
        if(portNameReal.Length == 0) { //Si no hay dispositivo conectado...
          if(portNameUsed.Length > 0) { //Si se está utilizando un puerto serie...
            serialPort.Close();
            serialPort.Dispose();
            portNameUsed = ""; //El dispositivo se ha desconectado
            Dispatcher.Invoke(() => {
              RectangleSemaphore.Fill = new SolidColorBrush(System.Windows.Media.Colors.Red); //Semáforo en rojo
            });
          }
        } else { //Hay un dispositivo conectado...
          if(portNameUsed.Length == 0) { //Si no se está utilizando un puerto serie (se acaba de conectar un dispositivo)...
            portNameUsed = portNameReal; //Ahora utilizaremos el puerto detectado
            serialPort = new SerialPort(portNameUsed, 115200); //Creamos su puerto serie
            serialPort.Open();
            Dispatcher.Invoke(() => {
              RectangleSemaphore.Fill = new SolidColorBrush(System.Windows.Media.Colors.Green); //Semáforo en verde
            });
          } else { //Ya se está utilizando un puerto serie
            if(portNameReal != portNameUsed) { //Si el dispositivo ha cambiado de puerto...
              serialPort.Close();
              serialPort.Dispose();
              portNameUsed = ""; //El dispositivo se ha desconectado
              //Ya se conectará al puerto correcto en el próximo ciclo
            } else { //El dispositivo sigue conectado y no ha cambiado de puerto
              try { //Por si acaso se ha desconectado...
                if (serialPort.BytesToRead > 0) { //Si hay algo pendiente de recibir...
                  int rxByte = serialPort.ReadByte(); //Leemos el siguiente byte
                  switch(rxByte) {
                    case 0: //0
                    case 1: //1
                    case 2: //2
                    case 3: //3
                    case 4: //4
                    case 5: //5
                    case 6: //6
                    case 7: //7
                    case 8: //8
                    case 9: //9
                    case 10: //*
                    case 11: //-
                    case 12: //+
                    case 13: //=
                    case 14: //,
                    case 15: //BackSpace
                      ClickRemoteButton(GetAppObj(), automationIds[rxByte, systemVer]);
                      break;
                    case 16: //Open
                             //Abrimos una nueva instancia de la aplicación y esperamos un máximo de 5
                             //segundos para que termine de abrirse
                      System.Diagnostics.Process.Start("calc").WaitForInputIdle(5000);
                      break;
                    case 17: //Close
                      ClickRemoteButton(GetAppObj(), "Close");
                      break;
                    case 18: //Get result
                      AutomationElement appObj = GetAppObj(); //Obtenemos el objeto de la aplicación
                      if (appObj != null) { //Si tenemos la aplicación en ejecución
                                            //Obtenemos el objeto del elemento que muestra el resultado (display)
                        AutomationElement elementObj = GetElementObj(appObj, automationIds[16, systemVer]);
                        if (elementObj != null) { //Se ha encontrado el elemento del display
                                                  //Obtenemos el contenido del objeto...
                                                  //La propiedad Name contiene el resultado actual de la operación, pero tiene un
                                                  //prefijo añadido:
                                                  //-Español: "La pantalla muestra "
                                                  //-Inglés: "Display is "
                                                  //Para que la eliminación del prefijo no dependa del idioma, buscaremos la posición
                                                  //del último espacio y tomaremos sólo el resto.
                          string res = elementObj.Current.Name; //Obtenemos el texto del elemento (contiene prefijo).
                                                                //El texto que nos interesa está después del úlñtimo espacio
                          int lastSpaceIndex = res.LastIndexOf(" ") + 1;
                          res = res.Substring(lastSpaceIndex); //Tomamos sólo la última palabra
                                                               //Codificamos el texto a enviar con UTF8 en un array de bytes para poder enviarlo por stream
                          byte[] textByteArray = Encoding.UTF8.GetBytes(res);
                          serialPort.Write(textByteArray, 0, textByteArray.Length);
                          serialPort.Write("\n"); //Fin de línea "\n"
                        }
                      }
                      break;
                  }
                }
              } catch { //Se ha producido un error...se ha desconectado!
                //En el siguiente ciclo se detectará que no hay dispositivo
              }
            }
          }
        }
      } //While END
      if(portNameUsed.Length > 0) { //Si estamos conectados...
        serialPort.Close();
        serialPort.Dispose();
      }
    }

    public MainWindow() { //Constructor
      InitializeComponent();
      new Thread(ThreadMain).Start(); //Creamos el Thread principal y lo lanzamos
    }

    private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
      requestExit = true;
    }

    private void RadioButtonENG_Checked(object sender, RoutedEventArgs e) {
      appName = "Calculator"; systemVer = 0;
    }
    private void RadioButtonESP_Checked(object sender, RoutedEventArgs e) {
      appName = "Calculadora"; systemVer = 0;
    }
    private void RadioButtonTablet_Checked(object sender, RoutedEventArgs e) {
      appName = "Calculadora"; systemVer = 1;
    }
  }
}


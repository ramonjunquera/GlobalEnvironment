/*
  Autor: Ramón Junquera
  Fecha: 20211014
  Tema: Sockets
  Objetivo: Man in the middle socket <-> serial

  Descripción:
  Se comporta como una simple pasarela bidireccional entre el socket ip y el puerto serie.
  Crea un punto de acceso wifi y un socket en la dirección por defecto (192.168.4.1).

  Notas:
  - Cuando se resetea, por defecto se envía por el puerto serie un mensaje de texto que no
    se puede evitar.
    Puesto que el API sólo utiliza códigos bajos (<65), los caracteres ASCII del mensaje no se
    tendrán en cuenta.
*/

#include <Arduino.h>
#include <WiFi.h>
#include <RoJoNeoPixel2.h> //Gestión de led NeoPixel

//Definición de constantes globales
const char* wifiSSID = "WifiAtom";
const char* wifiPassword = "WifiAtom";
const uint16_t port=54433;
const uint32_t red=10<<16;
const uint32_t green=10<<8;
const uint32_t yellow=red+green;

//Variables globales
WiFiServer server(port); //Creamos un servidor wifi
RoJoNeoPixel2 led; //Objeto de gestión de led NeoPixel
WiFiClient client;
bool isConnected=false;
byte buffer[1];

void setup() {
  led.begin(1,27); //Sólo un led en el pin 27
  led.videoMem[0].setColor(red); led.show(); //Led rojo
  Serial.begin(115200);
  WiFi.mode(WIFI_AP); //Modo: punto de acceso
  WiFi.softAP(wifiSSID,wifiPassword); //Nombre y contraseña
  server.begin(); //Arrancamos el servidor
  led.videoMem[0].setColor(yellow); led.show(); led.show();//Led amarillo
}

void loop() {
  if(!isConnected) { //Si no tenemos una conexión...
    client=server.available(); //Comprobamos si tenemos pendiente alguna solicitud de conexión
    if(client) { //Si hemos conseguido un cliente...
      led.videoMem[0].setColor(green); led.show(); led.show(); //Led verde
      isConnected=true; //Estamos conectados!
    }
  } else { //Si tenemos una conexión...
    if(!client.connected()) { //Si el cliente se ha desconectado...
      led.videoMem[0].setColor(yellow); led.show(); led.show(); //Led amarillo
      isConnected=false; //Ya no tenemos conexión
    } else { //Si el cliente mantiene la conexión...
      //Si hemos conseguido leer el siguiente byte del cliente...lo enviamos por el puerto serie
      if(client.readBytes(buffer,1)) Serial.write(buffer[0]);

      int bytesAvailable=Serial.available(); //Anotamos cuantos bytes están pendientes de recibir por el puerto serie
      if(bytesAvailable) { //Si hay algop pendiente por recibir por el puerto serie...
        while(bytesAvailable--) client.write(Serial.read()); //Lo leemos del peurto serie y lo enviamos al cliente
        client.flush();
      }
    }
  }
}

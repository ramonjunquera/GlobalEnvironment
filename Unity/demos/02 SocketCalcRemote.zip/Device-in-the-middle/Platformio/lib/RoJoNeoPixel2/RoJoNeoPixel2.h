/*
  Nombre de la librería: RoJoNeoPixel2.h
  Versión: 20210826
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixel2_h
#define RoJoNeoPixel2_h

#include <Arduino.h>

struct pixelGRB {
  byte channel[3];
  uint32_t getColor() {
    return ((uint32_t)channel[1])<<16 | ((uint32_t)channel[0])<<8 | channel[2];
  }
  void setColor(uint32_t color) {
    //El color lo tenemos en formato RGB (00000000RRRRRRRRGGGGGGGGBBBBBBBB)
    //Lo descomponemos en canales en orden GRB, propio de NeoPixel
    channel[2]=color & 0xFF; //B
    color>>=8;
    channel[0]=color & 0xFF; //G
    channel[1]=color>>8; //R
  }
};

class RoJoNeoPixel2 {
  protected:
    //Las placas Arduino (Mega, UNO, Nano) tienen un direccionamiento de 16 bits.
    //Pero ESP32 utiliza registros de 32 bits.
    #ifdef ARDUINO_ARCH_AVR //Placas Arduino: Mega, Uno, Nano
      uint16_t _pinCommPort; //Puerto del pin de comunicaciones
      byte _pinCommMask; //Máscara del bit en el puerto del pin de comunicaciones
    #else //Pacas ESP32 & ESP8266
      uint32_t _pinCommPort; //Puerto del pin de comunicaciones
      uint32_t _pinCommMask; //Máscara del bit en el puerto del pin de comunicaciones
    #endif
    uint16_t _ledsCount=0; //Número de leds
    uint64_t _lastComm=0; //Tiempo en microsegundos de última comunicación
  public:
    pixelGRB *videoMem; //Puntero a memoria de video
    void end();
    ~RoJoNeoPixel2(); //Destructor
    bool begin(uint16_t ledsCount,byte pinComm); //Inicialización
    void show(); //Envía memoria de video actual
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoNeoPixel2.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


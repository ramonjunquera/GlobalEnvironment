/*
 * Pendiente:
 * - Recepci�n de texto con \n al final para mostrar en resultado m�s r�pido
 * Autor: Ram�n Junquera
 * Fecha: 20211014
 * Tema: Comunicaciones ip en Unity
 * 
 * Descripci�n:
 * Se utiliza un Canvas para mostrar la UI.
 * Puesto que trataremos con comunicaciones, se aisla su gesti�n del hilo principal para que no interfiera en el UI.
 * La comunicaci�n con el Thread de gesti�n de comunicaciones la realizamos con una ConcurrentQueue.
 * La interacci�n con los objetos UI a�aden comandos a la cola.
 * Desde el Thread de comunicaciones tambi�n es necesario interactuar con el UI. Para ello creamos otra ConcurrentQueue
 * de acciones que se gestionar� en el m�todo Update() que siempre se ejecuta en primer plano.
 */

using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;
using UnityEngine.UI; //Necesario para acceder a los elementos UI desde scripts
using System.Text;
using System;

public class CanvasScript : MonoBehaviour {
  //Variables globales
  private Button buttonDisconnect, buttonConnect;
  private Button buttonOpen, buttonClose, buttonGetResult;
  private Button button0, button1, button2, button3, button4;
  private Button button5, button6, button7, button8, button9;
  private Button buttonBackspace, buttonDecimal, buttonEqual, buttonPlus, buttonMinus, buttonMultiply;
  private Text textResult;
  private readonly ConcurrentQueue<byte> canvasAPI = new ConcurrentQueue<byte>(); //Cola de comandos a ejecutar/enviar
  private readonly ConcurrentQueue<Action> refreshUI = new ConcurrentQueue<Action>(); //Cola acciones para refrescar UI (primer plano)
  private byte[] rxBuffer = new byte[1024]; //El buffer de entrada (1Kb)
  private int rxBufferLength = 0; //Bytes utilizados en el buffer de entrada

  //Activamos botones de desconectar y calculadora?
  private void EnableButtons(bool status) {
    refreshUI.Enqueue(() => { //A�adimos acciones a cola de refresco UI
      buttonDisconnect.interactable = status;
      buttonOpen.interactable = status;
      buttonClose.interactable = status;
      button0.interactable = status;
      button1.interactable = status;
      button2.interactable = status;
      button3.interactable = status;
      button4.interactable = status;
      button5.interactable = status;
      button6.interactable = status;
      button7.interactable = status;
      button8.interactable = status;
      button9.interactable = status;
      buttonGetResult.interactable = status;
      buttonBackspace.interactable = status;
      buttonDecimal.interactable = status;
      buttonEqual.interactable = status;
      buttonPlus.interactable = status;
      buttonMinus.interactable = status;
      buttonMultiply.interactable = status;
    });
  }

  private void ThreadSend() {
    TcpClient client = null;
    NetworkStream stream = null;
    byte actionRequest;

    while(true) { //Bucle infinito
      if (canvasAPI.TryDequeue(out actionRequest)) { //Si conseguimos obtener un nuevo elemento...
        if (actionRequest <= 18) { //Si se trata se una pulsaci�n directa...
          stream.WriteByte(actionRequest); //...enviamos su c�digo
          stream.Flush();
        } else {
          switch(actionRequest) {
            case 19: //Solicitud de conexi�n
              string errorMessage = "";
              try {
                client = new TcpClient("192.168.4.1", 54433); //Intentamos conectar con el servidor
              } catch (SocketException ex) {
                switch (ex.ErrorCode) {
                  case 10061: //El servidor no tiene la aplicaci�n en ejecuci�n
                    errorMessage = "No server app";
                    break;
                  case 10053:
                  case 10060:
                  case 10065:
                  case 11001: //Servidor desconocido
                    errorMessage = "IP unknown";
                    break;
                  default: //Error de comunicaci�n desconocido
                    errorMessage = "[" + ex.ErrorCode.ToString() + "]";
                    break;
                }
              }
              if (errorMessage.Length == 0) { //Si hemos podido conectar con el servidor (si no hay mensaje de error)...
                refreshUI.Enqueue(() => { //A�adimos acciones a cola de refresco UI
                  textResult.text = "0";
                });
                stream = client.GetStream(); //Obtenemos el stream
                EnableButtons(true); //Activamos botones de desconectar y calculadora
              } else { //No hemos podido conectar con el servidor
                client = null;
                refreshUI.Enqueue(() => { //A�adimos acciones a cola de refresco UI
                  textResult.text = errorMessage;
                  buttonConnect.interactable = true;
                });
              }
              break;
            case 20: //Solicitud de desconexi�n
              stream.Close();
              client.Close();
              client = null; //Ya no tenemos conexi�n
              refreshUI.Enqueue(() => { //A�adimos acciones a cola de refresco UI
                buttonConnect.interactable = true;
              });
              break;
          }
        }
      }
      if (client != null) { //Si estamos conectamos...
        if (stream.DataAvailable) { //Si hay datos pendientes por recibir...
          int rxByte = stream.ReadByte(); //Leemos el siguiente byte
          switch (rxByte) {
            case 10: //Fin de l�nea "\n"
              //Detectado el caracter de fin de l�nea
              //Convertiremos el buffer de entrada en un string con codificaci�n UTF8
              //Y lo mostramos como texto recibido
              string txt = Encoding.UTF8.GetString(rxBuffer, 0, rxBufferLength);
              refreshUI.Enqueue(() => { //A�adimos acciones a cola de refresco UI
                textResult.text = txt;
              });
              rxBufferLength = 0; //Reseteamos el buffer de recepci�n
              break;
            default: //Cualquier otro car�cter
              rxBuffer[rxBufferLength++] = (byte)rxByte; //A�adimos el byte recibido al buffer de entrada
              break;
          }
        }
      }
    } //while end
  } //ThreadSend end

  //Constructor
  private void Awake() {
    //Indentificamos objetos. S�lo se puede hacer en primer plano.
    buttonConnect = GameObject.FindGameObjectWithTag("ButtonConnect").GetComponent<Button>();
    buttonDisconnect = GameObject.FindGameObjectWithTag("ButtonDisconnect").GetComponent<Button>();
    buttonOpen = GameObject.FindGameObjectWithTag("ButtonOpen").GetComponent<Button>();
    buttonClose = GameObject.FindGameObjectWithTag("ButtonClose").GetComponent<Button>();
    textResult = GameObject.FindGameObjectWithTag("TextResult").GetComponent<Text>();
    button0 = GameObject.FindGameObjectWithTag("Button0").GetComponent<Button>();
    button1 = GameObject.FindGameObjectWithTag("Button1").GetComponent<Button>();
    button2 = GameObject.FindGameObjectWithTag("Button2").GetComponent<Button>();
    button3 = GameObject.FindGameObjectWithTag("Button3").GetComponent<Button>();
    button4 = GameObject.FindGameObjectWithTag("Button4").GetComponent<Button>();
    button5 = GameObject.FindGameObjectWithTag("Button5").GetComponent<Button>();
    button6 = GameObject.FindGameObjectWithTag("Button6").GetComponent<Button>();
    button7 = GameObject.FindGameObjectWithTag("Button7").GetComponent<Button>();
    button8 = GameObject.FindGameObjectWithTag("Button8").GetComponent<Button>();
    button9 = GameObject.FindGameObjectWithTag("Button9").GetComponent<Button>();
    buttonGetResult = GameObject.FindGameObjectWithTag("ButtonGetResult").GetComponent<Button>();
    buttonBackspace = GameObject.FindGameObjectWithTag("ButtonBackspace").GetComponent<Button>();
    buttonDecimal = GameObject.FindGameObjectWithTag("ButtonDecimal").GetComponent<Button>();
    buttonEqual = GameObject.FindGameObjectWithTag("ButtonEqual").GetComponent<Button>();
    buttonPlus = GameObject.FindGameObjectWithTag("ButtonPlus").GetComponent<Button>();
    buttonMinus = GameObject.FindGameObjectWithTag("ButtonMinus").GetComponent<Button>();
    buttonMultiply = GameObject.FindGameObjectWithTag("ButtonMultiply").GetComponent<Button>();
    new Thread(ThreadSend).Start(); //Creamos y ejecutamos Thread de comunicaciones
  }

  // Start is called before the first frame update
  void Start() {
  }

  void Update() { //Se ejecuta en cada refresco de fotograma
    //Puesto que se ejecuta en primer plano, lo utilizaremos para actualizar objetos gr�ficos
    //con las acciones de la cola refreshUI
    while(!refreshUI.IsEmpty) { //Mientras la cola de refrescos UI no est� vac�a...
      refreshUI.TryDequeue(out Action action); //Creamos una variable para guarda la acci�n y la recuperamos de la cola
      action(); //La ejecutamos
    }
  }

  public void Button0Click() {
    canvasAPI.Enqueue(0);
  }
  public void Button1Click() {
    canvasAPI.Enqueue(1);
  }
  public void Button2Click() {
    canvasAPI.Enqueue(2);
  }
  public void Button3Click() {
    canvasAPI.Enqueue(3);
  }
  public void Button4Click() {
    canvasAPI.Enqueue(4);
  }
  public void Button5Click() {
    canvasAPI.Enqueue(5);
  }
  public void Button6Click() {
    canvasAPI.Enqueue(6);
  }
  public void Button7Click() {
    canvasAPI.Enqueue(7);
  }
  public void Button8Click() {
    canvasAPI.Enqueue(8);
  }
  public void Button9Click() {
    canvasAPI.Enqueue(9);
  }
  public void ButtonMultiplyClick() {
    canvasAPI.Enqueue(10);
  }
  public void ButtonMinusClick() {
    canvasAPI.Enqueue(11);
  }
  public void ButtonPlusClick() {
    canvasAPI.Enqueue(12);
  }
  public void ButtonEqualClick() {
    canvasAPI.Enqueue(13);
  }
  public void ButtonDecimalClick() {
    canvasAPI.Enqueue(14);
  }
  public void ButtonBackSpaceClick() {
    canvasAPI.Enqueue(15);
  }
  public void ButtonOpenClick() {
    canvasAPI.Enqueue(16);
  }
  public void ButtonCloseClick() {
    canvasAPI.Enqueue(17);
  }
  public void ButtonGetResultClick() {
    canvasAPI.Enqueue(18);
  }
  public void ButtonConnectClick() {
    buttonConnect.interactable = false;
    canvasAPI.Enqueue(19);
  }
  public void ButtonDisconnectClick() {
    EnableButtons(false);
    canvasAPI.Enqueue(20);
  }
}

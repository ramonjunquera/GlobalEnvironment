using UnityEngine;

public class Cube1Script : MonoBehaviour {
  //Variables globales
  private float vel = 0; //Velocidad vertical
  System.Random rnd = new System.Random(); //Variable random para cálculo de altura de salto

  // Start is called before the first frame update
  void Start() {
  }

  // Update is called once per frame
  void Update() {
    gameObject.transform.Rotate(0,1,0); //Rota un grado sobre el eje y (vertical)
    float y0 = gameObject.transform.position.y; //Obtenemos altura actual
    vel -= 0.01f; //Reducimos la velocidad con el valor de la aceleración
    float y1 = y0 + vel; //Calculamos la nueva altura
    if (y1 < 0) vel = y1 = 0; //Si la nueva altura está por debajo del suelo...la velocidad y la altura serán nulas
    gameObject.transform.Translate(0, y1-y0, 0); //Aplicamos vector de desplazamiento en altura
  }

  //El cubo debe saltar!
  public void Jump() {
    //Obtenemos un valor aleatorio entre 20 y 30
    //Lo convertimos en flotante
    //Lo dividimos por 100 para obtener valores en [0.2,0.3]
    //Incrementamos la velocidad vertical del cubo en este valor
    vel += ((float)rnd.Next(20, 30)) / 100;
  }
}

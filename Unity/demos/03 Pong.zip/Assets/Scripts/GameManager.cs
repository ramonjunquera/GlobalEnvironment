using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
  int score1, score2;
  public GameObject ball;
  public Text textScore1, textScore2;
  public void Goal(int playerId)
  {
    if (playerId == 1) score1++;
    else score2++;
    textScore1.text = score1.ToString();
    textScore2.text = score2.ToString();
    //Debug.Log($"Player 1: {score1}, Player 2 {score2}");
    if (score1 == 3 || score2 == 3)
    {
      SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    ball.GetComponent<BallController>().LaunchBall();
  }
}

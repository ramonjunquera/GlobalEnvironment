using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PadController : MonoBehaviour
{
  int playerId;
  public bool isIA = false;
  GameObject ball;
  void Start()
  {
    playerId = (gameObject.name == "Pad1" ? 1 : 2);
    ball = GameObject.Find("Ball");
  }

  void Update()
  {
    float vel;
    if (!isIA) vel = (playerId == 1 ? Input.GetAxisRaw("VerticalPlayer1") : Input.GetAxisRaw("VerticalPlayer2"));
    else
    {
      vel = (gameObject.transform.position.y > ball.transform.position.y ? -1:1);
    }
    vel *= 3;
    gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, vel);
  }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour
{
  Vector2 initialPos;
  public int speed = 6;
  public void LaunchBall()
  {
    gameObject.transform.position = initialPos;
    gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(speed * (Random.Range(0, 2) * 2 - 1), speed * (Random.Range(0, 2) * 2 - 1));
  }
  void Start()
  {
    initialPos = gameObject.transform.position;
    LaunchBall();
  }
}

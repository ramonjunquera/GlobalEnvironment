using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalController : MonoBehaviour
{
  public GameObject gameManager;
  private void OnTriggerEnter2D(Collider2D collision)
  {
    if(collision.name=="Ball")
    {
      int playerWinId = (gameObject.name == "Goal1" ? 2:1);
      gameManager.GetComponent<GameManager>().Goal(playerWinId);
    }
  }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinnerCanvasController : MonoBehaviour {
  public void ButtonRestartClick() {
    SceneManager.LoadScene(SceneManager.GetActiveScene().name);
  }
}

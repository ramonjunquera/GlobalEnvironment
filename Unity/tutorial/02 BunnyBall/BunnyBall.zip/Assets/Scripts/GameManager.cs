﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class GameManager : MonoBehaviour {
  public GameObject winnerUI;
  public GameObject player;
  public GameObject camCM;
  public GameObject levelsFolder;
  int level = 0;
  GameObject grassPath; //Prefab de GrassPath
  Vector3[] grassPositions = { //Posiciones del suelo en los distintos niveles
    new Vector3(0,0,4), //Level 1
    new Vector3(0,0,7), //Level 2
    new Vector3(3,0,7), //Level 3
    new Vector3(6,0,7), //Level 4
    new Vector3(6,0,10), //Level 5
    new Vector3(6,0,13), //Level 6
    new Vector3(3,0,13), //Level 7
    new Vector3(3,0,16), //Level 8
    new Vector3(0,0,16), //Level 9
    new Vector3(-3,0,16), //Level 10
    new Vector3(-3,0,13), //Level 11
    new Vector3(-6,0,13), //Level 12
    new Vector3(-6,0,10) //Level 13
  };
  private void Awake() {
    grassPath = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/GrassPath.prefab");
  }
  public void NextLevel() {
    if (level == 13) GameOver(); //Si ya es el último nivel...terminamos
    else { //No es el último nivel...
      GameObject newGrassPath = Instantiate(grassPath,levelsFolder.transform);
      newGrassPath.transform.position = grassPositions[level++];
      newGrassPath.name = $"Level {level}"; //Para diferenciarlos
      player.GetComponent<Rigidbody>().velocity = Vector3.zero; //Sin velocidad lineal
      player.GetComponent<Rigidbody>().angularVelocity = Vector3.zero; //Sin velocidad angular
      camCM.SetActive(false); //Desactivamos la cámara inteligente
      player.transform.position = new Vector3(0, 2, 0); //Movemos el jugador al inicio
      camCM.transform.position = new Vector3(0, 3, -10); //Movemos la cámara al inicio
      camCM.SetActive(true); //Activamos la cámara inteligente
    }
  }
  private void Start() {
    NextLevel();
  }
  public void GameOver() {
    player.GetComponent<Player>().enabled = false;
    Destroy(player.GetComponent<Rigidbody>());
    winnerUI.SetActive(true);
    gameObject.SetActive(false);
  }
}

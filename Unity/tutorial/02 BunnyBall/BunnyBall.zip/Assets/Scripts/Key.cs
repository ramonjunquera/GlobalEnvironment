﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Key : MonoBehaviour {
  [SerializeField] GameObject shockwavePrefab;
  [SerializeField] GameManager gameManager;

  private void Start() {
    gameManager = FindObjectOfType<GameManager>();
  }
  private void OnTriggerEnter(Collider other) {
    if (other.CompareTag("Player")) {
      GameObject shockWave=Instantiate(shockwavePrefab, transform.position, Quaternion.identity,gameManager.levelsFolder.transform);
      Destroy(gameObject, 0.1f); //Destruimos la llave
      Destroy(shockWave, 2); //Destruimos la explosión tras 2 segundos
      gameManager.NextLevel();
    }
  }
}

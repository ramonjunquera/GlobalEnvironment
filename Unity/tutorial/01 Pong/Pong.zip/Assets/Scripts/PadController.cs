using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PadController : MonoBehaviour {
  public float verticalSpeed = 3;
  public bool autoPlay = false;
  GameObject ball;
  void Start() {
    ball = GameObject.Find("Ball");
  }
  void Update() {
    float vel=verticalSpeed;
    if(autoPlay) {
      vel*=(gameObject.transform.position.y > ball.transform.position.y)? -1 : 1;
    } else {
      vel*=(gameObject.name == "Pad1") ? Input.GetAxisRaw("VerticalPad1") : Input.GetAxisRaw("VerticalPad2");
    }
    gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0, vel);
  }
  
}

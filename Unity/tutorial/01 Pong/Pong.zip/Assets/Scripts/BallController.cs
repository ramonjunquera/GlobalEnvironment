using UnityEngine;

public class BallController : MonoBehaviour {
  public int speed = 6;
  public void LaunchBall() {
    gameObject.transform.position = Vector3.zero;
    gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(speed * (Random.Range(0, 2) * 2 - 1), speed * (Random.Range(0, 2) * 2 - 1));
  }
  void Start() {
    LaunchBall();
  }
}

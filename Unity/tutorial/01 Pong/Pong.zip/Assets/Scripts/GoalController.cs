using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoalController : MonoBehaviour
{
  GameObject gameManager;
  void Start() {
    gameManager = GameObject.Find("GameManager");
  }
  void OnTriggerEnter2D(Collider2D collision) {
    int playerWinId = gameObject.name == "WallLeft" ? 2 : 1;
    gameManager.GetComponent<GameManager>().Goal(playerWinId);
  }
}

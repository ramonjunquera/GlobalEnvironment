using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
  int score1=0, score2=0;
  Text counter1, counter2;
  public int scoreMax=3;
  private void Start() {
    GameObject canvas = GameObject.Find("ScoreBoard");
    counter1 = canvas.GetComponentsInChildren<Text>().First(go => go.name == "Counter1");
    counter2 = canvas.GetComponentsInChildren<Text>().First(go => go.name == "Counter2");
  }
  public void Goal(int playerId) {
    Debug.Log($"Jugador {playerId} ha marcado gol");
    if (playerId == 1) score1++;
    else score2++;
    counter1.text = score1.ToString();
    counter2.text = score2.ToString();
    if(score1==scoreMax || score2==scoreMax) {
      SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    GameObject.Find("Ball").GetComponent<BallController>().LaunchBall();
  }
}

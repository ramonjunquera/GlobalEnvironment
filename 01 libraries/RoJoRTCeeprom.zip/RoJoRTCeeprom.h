/*
  Nombre de la librería: RoJoRTCeeprom.h
  Versión: 20170927
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión de la memoria EEPROM del módulo Tiny RTC I2C Real Time
*/

#ifndef RoJoRTCeeprom_h
#define RoJoRTCeeprom_h

#include <Arduino.h> 

class RoJoRTCeeprom
{
  private:
    const byte _eepromID=0x50; //Identificador de la memoria en el bus I2C
  public:
    RoJoRTCeeprom(); //Constructor
    bool check(); //Comprueba si el la memoria está conectada
    byte peek(uint16_t address); //Obtiene el valor de una posición de memoria
    void poke(uint16_t address,byte value); //Escribe en una posición de memoria
};

#endif

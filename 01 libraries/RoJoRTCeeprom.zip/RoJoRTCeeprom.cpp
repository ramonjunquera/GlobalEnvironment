/*
  Nombre de la librería: RoJoRTCeeprom.h
  Versión: 20170927
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión de la memoria EEPROM del módulo Tiny RTC I2C Real Time
*/

#include <Arduino.h>
#include <Wire.h>
#include "RoJoRTCeeprom.h"

RoJoRTCeeprom::RoJoRTCeeprom()
{
  //Comenzamos inicializando la conexión I2C
  Wire.begin();
  //Habitualmente el bus I2C transmite con una frecuencia de 100KHz.
  //Con el siguiente comando lo incrementamos hasta 400KHz, si la placa lo permite.
  Wire.setClock(400000L);
}

bool RoJoRTCeeprom::check()
{
  //Comprueba si la memoria está conectada
  //Devuelve true si se ha encontrado

  //Abrimos comunicación con la memoria EEPROM
  Wire.beginTransmission(_eepromID);
  //Se solicita finalizar la comunicación. Si ocurre algún error es que no se pudo encontrar
  return !Wire.endTransmission();
}

byte RoJoRTCeeprom::peek(uint16_t address)
{
  //Obtiene el valor de una posición de memoria

  //Comenzamos la transmisión al dispositivo de la memoria EEPROM
  Wire.beginTransmission(_eepromID);
  
  //Creamos un buffer para en el que intercambiamos los bytes de la dirección
  byte buf[2]={(byte)(address>>8),(byte)(address & 0xFF)};
  //Enviamos el buffer con la dirección
  Wire.write(buf,2);

  //Hemos terminado la transmisión
  Wire.endTransmission();
  
  //Solicitamos la lectura de un byte de ese dispositivo
  Wire.requestFrom(_eepromID,(byte)1);
  //Obtenemos el byte
  byte value=Wire.read();
  
  //Devolvemos el byte leido
  return value;
}

void RoJoRTCeeprom::poke(uint16_t address,byte value)
{
  //Escribe un byte en la EEPROM en la dirección indicada
  
  //Comenzamos la transmisión al dispositivo de la memoria EEPROM
  Wire.beginTransmission(_eepromID);
  //Creamos un buffer donde guardamos la dirección de memoria
  //con los bytes alto y bajo intercambiados, y el valor a escribir
  byte buf[3]={(byte)(address >> 8),(byte)(address & 0xFF),value};
  //Enviamos el buffer al dispositivo
  Wire.write(buf,3);
  //Hemos terminado la transmisión
  Wire.endTransmission();
  //Obligatorio esperar 5 ms para que no se ofusque el buffer
  delay(5);
}




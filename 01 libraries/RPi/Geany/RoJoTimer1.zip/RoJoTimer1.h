/*
  Nombre de la librería: RoJoTimer1.h
  Versión: 20170926
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas RPi para la gestión del timer 1
*/

#ifndef RoJoTimer1_h
#define RoJoTimer1_h

#include <Arduino.h>
#include <sys/time.h> //para itimerval
#include <signal.h> //para signal

class RoJoTimer1
{
  private:  //Definición de métodos/variables privadas
    struct itimerval _timerConfig; //Configuración
  public: //Definición de métodos/variables públicas
    //Inicialización de timer
    void begin(void (*f)(int),uint32_t period); 
    void end(); //Deshabilita la interrupción
}; //Punto y coma obligatorio para que no de error

//En el .cpp se ha definido timer1 como variable global, que también
//queremos utilizar aquí, por eso la referenciamos con extern
extern RoJoTimer1 timer1;

#endif

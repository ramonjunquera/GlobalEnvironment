/*
  Nombre de la librería: RoJoTimer1.h
  Versión: 20170926
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas RPi para la gestión del timer 1

    Sólo con incluir la librería se crea el objeto timer1, que tiene dos
    métodos públicos:
    - void begin(void (*f)(int),uint32_t period)
    - void end()
    El método begin inicializa el timer para que se llame a la función
    del primer parámetro cada cierto tiempo definido en el segundo
    parámetro.
    La función tiene un parámetro entero y no devuelve nada.
    El tiempo del periodo se mide en microsegundos.

    El método end deshabilita la interrupción.

    Se puede llamar repetidas veces al método begin sin llamar a end.
    Esto hará que se inicialice el timer con la nueva configuración.
*/

#ifndef RoJoTimer1_cpp
#define RoJoTimer1_cpp

#include <Arduino.h>
#include <sys/time.h> //para itimerval
#include <signal.h> //para signal
#include "RoJoTimer1.h"

void RoJoTimer1::begin(void (*f)(int),uint32_t period)
{
	//Inicialización de timer. Parámetros: función de llamada, periodo
	//en microsegundos.
	//La función a la que se llamará cuando salte la interrupción debe
	//tener un parámetro entero y no puede devolver nada.
	//Formato: void func(int signalType)

	//Definimos el tiempo que hay entre dos eventos
	//Tiempo en segundos
	_timerConfig.it_interval.tv_sec = period/1000000; 
	//Tiempo de microsegundos. No puede ser mayor de 1000000
	_timerConfig.it_interval.tv_usec = period%1000000; 
	
	//Definimos el tiempo que debe transcurrir para el primer evento
	//Tiempo en segundos
	_timerConfig.it_value.tv_sec = 0; 
	//Tiempo en microsegundos. Comienza ya
	//No podemos poner 0 porque entenderá que no comienza nunca
	_timerConfig.it_value.tv_usec = 1; 
	
    //Asignamos la función al tipo de señal
    signal(SIGALRM,f);
    //Aplicamos la configuración al timer
    setitimer(ITIMER_REAL,&_timerConfig,NULL);
	//Hemos podido crear el timer correctamente
}

void RoJoTimer1::end()
{
  //Deshabilita la interrupción
  
	//Paramos el timer
	_timerConfig.it_value.tv_sec=_timerConfig.it_value.tv_usec=0;
	setitimer(ITIMER_REAL,&_timerConfig,NULL);
}

//Aquí finaliza la definición de métodos de la clase
//Pero incluimos en el mismo archivo código que nos ayuda con la gestión

//Definimos timerClass como variable global de la clase
RoJoTimer1 timer1;

#endif

/*
  Nombre de la librería: RoJoSwitch.h
  Versión: 20170920
  Autor: Ramón Junquera
  Descripción:
    Gestión de un interruptor.
    Utiliza las resistencias PULL_UP internas.
    El interruptor debe ir conectado a tierra y al pin que lee su estado.
*/

#ifndef RoJoSwitch_cpp
#define RoJoSwitch_cpp

#include <Arduino.h>
#include "RoJoSwitch.h"

RoJoSwitch::RoJoSwitch(byte pin)
{ 
  //Constructor
  //Se pasa el pin al que está conectado el pulsador. La otra pata del pulsador debe ir a GND
      
  //Guardamos el pin al que está conectado el interruptor
  _pinSwitch=pin;
  //Configuramos el pin de entrada con resistencia de PULLUP
  pinMode(_pinSwitch,INPUT_PULLUP);
}

void RoJoSwitch::_check()
{
  //Comprueba el estado del interruptor

  //Tomamos nota de la hora actual
  uint32_t now=millis();
  //Si el estado actual del pulsador es distinto al de la última vez...
  if(digitalRead(_pinSwitch)!=_lastStatus)
  {
    //Si podemos aceptar una nueva pulsación...
    if(now-_lastTime>delayTime)
    {
      //Cambiamos el estado de la última vez
      _lastStatus=!_lastStatus;
      //Si se acaba de soltar...indicamos que se ha soltado
      if(_lastStatus) _buttonReleased = true;
      //Si se acaba de pulsar...indicamos que se ha pulsado
      else _buttonPressed = true;
    }
    //El Tomamos nota del momento del cambio para esperar el tiempo indicado y evitar el efecto rebote
    _lastTime=now;
  }
}

bool RoJoSwitch::pressed()
{
  //Indica si el interruptor ha sido pulsado
  
  //Llamamos a la función que refresca el estado actual del interruptor
  _check();
  //Si ha sido pulsado...
  if(_buttonPressed)
  {
    //...limpiamos el flag, porque ya ha sido consultado
    _buttonPressed = false;
    //Devolvemos la respuesta
    return true;
  }
  //No ha sido pulsado
  return false;
}

bool RoJoSwitch::released()
{
  //Indica si el interruptor ha sido soltado
  
  //Llamamos a la función que refresca el estado actual del interruptor
  _check();
  //Si ha sido soltado...
  if(_buttonReleased)
  {
    //...limpiamos el flag, porque ya ha sido consultado
    _buttonReleased = false;
    //Devolvemos la respuesta
    return true;
  }
  //No ha sido soltado
  return false;
}

bool RoJoSwitch::pressing()
{
  //Indica si el interruptor está siendo pulsado
  
  //Llamamos a la función que refresca el estado actual del interruptor
  _check();
  //Devolvemos el estado en el que se encontraba el interruptor hace un instante
  return !_lastStatus;
}

#endif

/*
  Nombre de la librería: RoJo74HC595N.h
  Versión: 20170916
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del chip de extensión de pines digitales 74HC595N
*/

#ifndef RoJo74HC595N_h
#define RoJo74HC595N_h

#include <Arduino.h>

class RoJo74HC595N
{
  private:
    byte _pinData,_pinLatch,_pinClock,_cascadeChips;
    //Definición de los caracteres que se pueden mostrar en una posición
    const byte _chars[19]={ 
      0b00111111 // 0 = 0
     ,0b00000110 // 1 = 1
     ,0b01011011 // 2 = 2
     ,0b01001111 // 3 = 3
     ,0b01100110 // 4 = 4
     ,0b01101101 // 5 = 5
     ,0b01111101 // 6 = 6
     ,0b00100111 // 7 = 7
     ,0b01111111 // 8 = 8
     ,0b01101111 // 9 = 9
     ,0b01110111 //10 = A
     ,0b01111100 //11 = b
     ,0b00111001 //12 = C
     ,0b01011110 //13 = d
     ,0b01111001 //14 = E
     ,0b01110001 //15 = F
     ,0b00000000 //16 = space
     ,0b01000000 //17 = -
     ,0b01100011 //18 = º
   };
   byte *_videoMem; //Memoria de vídeo
  public:
    RoJo74HC595N(byte pinData,byte pinLatch,byte pinClock,byte cascadeChips); //Constructor
    ~RoJo74HC595N(); //Destructor
    void set(byte pos,byte charIndex,bool dot); //Escribe un caracter del alfabeto en la memoria de vídeo
    void set(byte pos,byte value); //Escribe un valor en la memoria de vídeo de un chip
    void show(); //Envía la memoria de vídeo al 74HC595N
    void show(uint64_t value); //Escribe el valor indicado en la memoria de vídeo y lo muestra
    void showInt(int64_t i); //Muestra en los displays un entero con signo
    
};

#endif

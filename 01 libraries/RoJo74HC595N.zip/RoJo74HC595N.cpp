/*
  Nombre de la librería: RoJo74HC595N.h
  Versión: 20170916
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del chip de extensión de pines digitales 74HC595N
*/

#ifndef RoJo74HC595N_cpp
#define RoJo74HC595N_cpp

#include <Arduino.h>
#include "RoJo74HC595N.h"

RoJo74HC595N::RoJo74HC595N(byte pinData,byte pinLatch,byte pinClock,byte cascadeChips)
{
  //Constructor

  //Guardamos los parámetros en variables privadas
  _pinData=pinData;
  _pinLatch=pinLatch;
  _pinClock=pinClock;
  _cascadeChips=cascadeChips;
  //Creamos un array para la memoria de vídeo con tantos bytes como chips
  //El array se llenará de ceros (debido a los paréntesis finales)
  _videoMem = new byte[_cascadeChips]();
  //Configuramos los pines como salidas
  pinMode(_pinData,OUTPUT);
  pinMode(_pinLatch,OUTPUT);
  pinMode(_pinClock,OUTPUT);
}

RoJo74HC595N::~RoJo74HC595N()
{
  //Destructor

  //Liberamos la memoria de vídeo
  delete[] _videoMem;
}

void RoJo74HC595N::set(byte pos,byte charIndex,bool dot)
{
  //Escribe un caracter del alfabeto en la memoria de vídeo
  //  pos es la posición del carácter (número de chip en la cadena)
  //  charIndex es el índice del caracter a mostrar en el diccionario
  //  dot es el punto decimal

  //Guardamos el valor que corresponde al índice del carácter en la memoria de vídeo
  //Tenemos en cuenta el punto decimal
  _videoMem[pos]=_chars[charIndex] | (dot?0b10000000:0x00);
}

void RoJo74HC595N::set(byte pos,byte value)
{
  //Escribe un valor en la memoria de vídeo
  //  pos es la posición del carácter (número de chip en la cadena)
  //  value es el estado de los pines del chip

  //Guardamos el valor en su posición de la memoria de vídeo
  _videoMem[pos]=value;
}

void RoJo74HC595N::show()
{
  //Envía la memoria de vídeo al 74HC595N

  //Los leds no deben cambiar mientras se envía la información
  digitalWrite(_pinLatch,LOW);
  //Recorremos todos los chips enviando la memoria de vídeo
  //Tenemos en cuenta que el primer byte enviado será para el último chip de la cadena
  for(byte c=0;c<_cascadeChips;c++) shiftOut(_pinData,_pinClock,MSBFIRST,_videoMem[_cascadeChips-1-c]);
  //Ya podemos aplicar la configuración enviada
  digitalWrite(_pinLatch,HIGH);
}

void RoJo74HC595N::showInt(int64_t i)
{
  //Muestra en los displays un entero con signo
  //Suponemos todos los displays ordenados en cascada

  //Copiamos el valor absoluto en otra variable para descomponerlo en dígitos
  int64_t descomp=abs(i);
  //Recorremos todos los chips
  for(byte c=0;c<_cascadeChips;c++)
  {
    //Comenzando por las unidades, vamos descomponiendo el valor original en dígitos
    _videoMem[_cascadeChips-1-c]=_chars[descomp%10];
    //Despreciamos las unidades actuales
    descomp/=10;
  }
  //Si es negativo ponemos el signo
  if(i<0) _videoMem[0]=_chars[17];
  //Directamente mostramos el resultado
  show();
}

void RoJo74HC595N::show(uint64_t value)
{
  //Escribe el valor indicado en la memoria de vídeo y lo muestra

  //Recorremos todos los chips
  for(byte c=0;c<_cascadeChips;c++)
  {
    //Comenzando por el byte más bajo y vamos descomponiendo el valor original en bytes
    _videoMem[c]=value & 0xFF;
    //Despreciamos el byte más bajo
    value >>= 8;
  }
  //Directamente mostramos el resultado
  show();
}

#endif

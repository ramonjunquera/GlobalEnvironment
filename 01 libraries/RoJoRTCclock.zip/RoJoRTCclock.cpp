/*
  Nombre de la librería: RoJoRTCclock.h
  Versión: 20170928
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del reloj del módulo Tiny RTC I2C Real Time

  Para poder gestionar con un poco de agilidad el tema de fechas y horas, se incluye en la librería la clase datetime

  El reloj sólo es capaz de almacenar 2 dígitos para el año. Supondremos que el año del reloj corresponde con las
  dos últimas cifras de un año del siglo 21 (20xx).
  
  El método getCompilerTime() no está disponible para plataformas ARM (RPi)
*/

#ifndef RoJoRTCclock_cpp
#define RoJoRTCclock_cpp

#include <Arduino.h>
#include <Wire.h>
#include "RoJoRTCclock.h"

RoJoRTCclock::RoJoRTCclock()
{
  //Comenzamos inicializando la conexión I2C
  Wire.begin();
  //Habitualmente el bus I2C transmite con una frecuencia de 100KHz.
  //Con el siguiente comando lo incrementamos hasta 400KHz, si la placa lo permite.
  Wire.setClock(400000L);
}

bool RoJoRTCclock::check()
{
  //Comprueba si el reloj está conectado
  //Devuelve true si se ha encontrado

  //Abrimos comunicación con el reloj
  Wire.beginTransmission(_clockID);
  //Se devuelve el resultado inverso al de fin de transmisión
  //Cuando una transmisión finaliza correctamente, devuelve false
  return !Wire.endTransmission();
}

byte RoJoRTCclock::_bcd2dec(byte n)
{
  //Convierte de Binary Coded Decimal a Decimal
  return ((n/16*10) + (n % 16));
}

byte RoJoRTCclock::_dec2bcd(byte n)
{
  //Convierte de Decimal a Binary Coded Decimal
  return ((n/10*16) + (n % 10));
}

datetime RoJoRTCclock::get()
{
  //Obtiene la hora

  //Creamos una variable para guardar la hora que nos devuelva el reloj
  datetime timeNow;

  //Abrimos comunicación con el reloj (identificador 0x68)
  Wire.beginTransmission(_clockID);
  //Escribimos un byte con valor cero (reset pointer)
  byte zero=0;
  Wire.write(&zero,1);
  //Cerramos la comunicación (no tenemos más información que enviar)
  Wire.endTransmission();
  //Solicitamos 7 bytes del reloj: segundos, minutos, horas, día de la semana, día del mes, mes y año
  Wire.requestFrom(_clockID,(byte)7);
  //Anotamos cada uno de los valores en la estructura timeNow
  timeNow.second=_bcd2dec(Wire.read()); //Leemos el byte de segundos
  //Nota: si los segundos > 128 quiere decir que el reloj está parado porque nunca se ha puesto en hora
  timeNow.minute=_bcd2dec(Wire.read()); //Leemos el byte de minutos
  timeNow.hour=_bcd2dec(Wire.read()); //Leemos el byte de horas
  timeNow.weekDay=Wire.read(); //Leemos el byte de día de la semana. lun=1,dom=7
  timeNow.day=_bcd2dec(Wire.read()); //Leemos el byte de día del mes
  timeNow.month=_bcd2dec(Wire.read()); //Leemos el byte del mes
  timeNow.year=2000+_bcd2dec(Wire.read()); //Leemos el byte del año (20xx)
  //Devolvemos la hora recien leida
  return timeNow;
}

void RoJoRTCclock::set(datetime t,int32_t secondsDelay)
{
  //Fija la hora indicada en el reloj con una demora en segundos
  //No tiene en cuenta el valor de día de la semana. Lo recalcula
  //Para calcular el día de la semana, convertimos el datetime en segundos
  //sumándole la demora indicada
  uint32_t s=datetime2seconds(t)+secondsDelay;
  //...y lo volvemos a convertir en datetime
  t=seconds2datetime(s);
  
  //Abrimos comunicación con el reloj (identificador 0x68)
  Wire.beginTransmission(_clockID);
  
  //Creamos un buffer para la escritura
  byte buf[8]=
  {
	  0, //reset pointer
	  _dec2bcd(t.second), //segundos en bcd
	  _dec2bcd(t.minute), //minutos en bcd
	  _dec2bcd(t.hour), //horas en bcd
	  t.weekDay, //día de la semana
	  _dec2bcd(t.day), //día de mes en bcd
	  _dec2bcd(t.month), //número de mes en bcd
	  _dec2bcd(t.year%100) //dos últimos dígitos del año 20xx
  };
  //Enviamos la fecha y hora para que se tenga en cuenta
  Wire.write(buf,8);
  //Cerramos la comunicación
  Wire.endTransmission();  
}

bool RoJoRTCclock::_leapYear(int y)
{
  //Indica si el parámetro es un año bisiesto
  //y es el año completo con sus 4 dígitos

  return !(y%4) && ( (y%100) || !(y%400) );
}

uint32_t RoJoRTCclock::datetime2seconds(datetime t)
{
  //Calcula el número de segundos transcurridos entre el 1-Ene-1900 hasta la fecha indicada
  //No se tiene en cuenta el valor del día de la semana

  //Definimos la variable donde guardaremos el resultado
  uint32_t s;
  //Calculamos los segundos de todos los años entre el 1900 y el indicado
  //Un año tiene 265*24*60*60=31536000 segundos
  s=(t.year-1900L)*31536000L;
  //Recorreremos todos los años hasta el indicado...
  for(int yearIndex=1900;yearIndex<t.year;yearIndex+=4)
  {
    //Si es un año bisiesto...le sumamos los segundos que tiene un día
    //Un día tiene 24*60*60=86400 segundos
    if(_leapYear(yearIndex)) s+=86400L;
  }
  //Si el mes es superior a enero...sumaremos también el tiempo de los meses del año transcurridos
  if(t.month>1) s+=_secondsPerMonth[t.month-2];
  //Si el año es bisiesto y el mes es superior a febrero...le tenemos que sumar los segundos del 29 de febrero
  if(_leapYear(t.year) && t.month>2) s+=86400L;
  //Le sumamos los días transcurridos del mes
  s+=86400L*(t.day-1);
  //Le sumamos las horas trascurridas del día
  s+=3600L*t.hour;
  //Le sumamos los minutos transcurridos de la hora
  s+=60*t.minute;
  //Finalmente le sumamos los segundos
  s+=t.second;
  //Devolvemos el valor calculado
  return s;
}

datetime RoJoRTCclock::seconds2datetime(uint32_t s)
{
  //Calcula la fecha que corresponde a los segundos transcurridos desde el 1-Ene-1900
  //También se calcula el día de la semana

  //Definimos la variable donde guardaremos el resultado
  datetime t;
  //Calculamos los segundos
  t.second=s%60;
  //Convertimos a minutos
  s/=60;
  //Calculamos los minutos
  t.minute=s%60;
  //Convertimos a horas
  s/=60;
  //Calculamos las horas
  t.hour=s%24;
  //Convertimos a días
  s/=24;
  //Calculamos el día de la semana
  t.weekDay=1+s%7; //El lunes es el día 1
  //Recorreremos todos los años desde el 1900 e iremos acumulando los días que tiene cada uno
  //Cuando el acumulado sea superior al número de días que tenemos, paramos
  uint32_t totalDays=0;
  int currentYear=1900;
  while((totalDays+=(_leapYear(currentYear)?366:365)) <= s)
  {
    currentYear++;
  }
  //Nos hemos pasado del número de días que teníamos
  //Eso quiere decir que hemos anotado también los días del año en curso
  //Tomamos nota del año
  t.year=currentYear;
  //Tomamos nota de si el año calculado es bisiesto
  bool leapYear=_leapYear(currentYear);
  //Restamos al total de días, los días del año calculado (que se lo habíamos sumado)
  totalDays-=(leapYear?366:365);
  //Quitamos los días que han transcurrido para todos los años pasados
  s-=totalDays;
  //Nos falta calcular el mes y el día
  //Definimos variable para guardar el mes calculado
  byte monthIndex;
  //Utilizaremos de nuevo la variable totalDay para guardar el número acumulado de días de los meses del año
  totalDays=0;
  //Recorremos todos los meses
  for(monthIndex=0;monthIndex<11;monthIndex++)
  {
    //Calculamos los días que tiene el mes procesado
    totalDays=_secondsPerMonth[monthIndex]/86400L;
    //Si el mes es superior a febrero y el año es bisiesto...se debe tener en cuenta el día extra de febrero
    if(monthIndex>1 && leapYear) totalDays++;
    //Si los días que nos quedan son menos que los que tiene el acumulado de meses...hemos encontrado el mes!
    if(s<totalDays) break;
  }
  //El mes buscado es monthIndex+1
  //Tomamos nota del mes calculado
  t.month=monthIndex+1;
  //Si el mes es superior a enero...
  if(t.month>1)
  {
    //Restamos el número de días que tienen los meses acumulados
    s-=_secondsPerMonth[monthIndex-1]/86400L;
    //Si el mes es superior a febrero y el año es bisiesto...se debe tener en cuenta el día extra de febrero
    if(monthIndex>1 && leapYear) s--;
  }
  //Lo único que nos queda ahora en la variable s son los días del mes. Los anotamos
  t.day=s+1;
  //En al caso de que la fecha sea 29-feb quedaría como mes=marzo,día=0.Lo corregimos
  if(t.day==0)
  {
    t.day=29;
    t.month=2;
  }
  //Devolvemos la fecha calculada
  return t;
}

#if !defined(__arm__)
datetime RoJoRTCclock::getCompilerTime()
{
  //Devuelve la fecha y hora del momento de la compilación
  //Se obtiene de las cadenas __DATE__ & __TIME__
  //La cadena de __DATE__ tiene el formato "MMM DD YYYY"
  //La cadena de __TIME__ tiene el formato "HH:MM:SS"
  
  //Nota: Utilizaremos substrings para extraer los valores de las cadenas
  //porque en ESP no exite la función sscanf

  //Creamos la variable que devolveremos
  datetime t;
  //Extraemos los valores de __TIME__
  t.hour=String(__TIME__).substring(0,2).toInt();
  t.minute=String(__TIME__).substring(3,5).toInt();
  t.second=String(__TIME__).substring(6,8).toInt();
  //Variable para guardar el nombre del mes (3 caracteres + 1 de fin de cadena = 4)
  char monthName[4];
  //Extraemos los valores de __DATE__
  String(__DATE__).substring(0,3).toCharArray(monthName,4); //Extraemos el nombre del mes
  t.day=String(__DATE__).substring(4,6).toInt();
  t.year=String(__DATE__).substring(7,11).toInt();
  //Necesitamos saber a qué mes corresponde la cadena...
  //Recorremos todos los meses...
  for(byte monthIndex=0;monthIndex<12;monthIndex++)
  {
    //...si el mes que buscamos coincide con el mes de la posición actual...
    if(strcmp(monthName,_monthNames[monthIndex])==0)
    {
      //...anotamos el mes...
      t.month=monthIndex+1;
      //...y salimos del bucle
      break;
    }
  }
  //Devolvemos la fecha calculada
  return t;
}
#endif

void RoJoRTCclock::set1900(int32_t seconds1900)
{
  //Fija la hora en el reloj teniendo en cuenta que se le pasa el número
  //de segundos transcurridos desde el 1-Ene-1900.
  //Esta función está especialmente pensada para cuando se obtiene la
  //hora de internet (NTP), porque la devuelve en este formato.

  //Convertimos los segundos desde 1-Ene-1900 a formato datetime
  datetime t=seconds2datetime(seconds1900);
  //Fijamos la fecha calculada en el reloj sin demoras asicionales
  set(t,0);
}

void RoJoRTCclock::set1970(int32_t seconds1970)
{
  //Fija la hora en el reloj teniendo en cuenta que se le pasa el número
  //de segundos transcurridos desde el 1-Ene-1970.
  //Esta función está especialmente pensada para cuando se obtiene la
  //hora del reloj interno de un sistema Unix porque la devuelve en este
  //formato.

  //Llamamos a la función set1900 añadiendo al tiempo de 1970 la
  //diferencia hasta 1900
  set1900(seconds1970+2208988800L);
}

#endif


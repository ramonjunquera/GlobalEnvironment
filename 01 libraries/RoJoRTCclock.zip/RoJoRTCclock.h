/*
  Nombre de la librería: RoJoRTCclock.h
  Versión: 20170928
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del reloj del módulo Tiny RTC I2C Real Time

  Para poder gestionar con un poco de agilidad el tema de fechas y horas, se incluye en la librería la clase datetime

  El reloj sólo es capaz de almacenar 2 dígitos para el año. Supondremos que el año del reloj corresponde con las
  dos últimas cifras de un año del siglo 21 (20xx)
  
  El método getCompilerTime() no está disponible para plataformas ARM (RPi)
*/

#ifndef RoJoRTCclock_h
#define RoJoRTCclock_h

#include <Arduino.h>
#include <Wire.h>

class datetime
{
  public:
  byte second=0; 
  byte minute=0;
  byte hour=0; //En formato 24 horas
  byte weekDay=0; //lun=1,dom=7
  byte day=0;
  byte month=0; //enero=1, diciembre=12
  int year=0; //Completo. Con sus 4 dígitos
};

class RoJoRTCclock
{
  private:
    const byte _clockID=0x68; //Identificador I2C del módulo
    byte _bcd2dec(byte n); //Convierte de Binary Coded Decimal a Decimal
    byte _dec2bcd(byte n); //Convierte de Decimal a Binary Coded Decimal
    const char *_monthNames[12] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"}; //Nombre de los meses tal y como aparecen en la variable __DATE__
    //Creamos un array con los segundos que contienen los meses del año acumulados.
    //Sólo llegamos hasta noviembre
    //Mes - días - segundos - acumulado
    //Ene     31    2678400     2678400
    //Feb     28    2419200     5097600
    //Mar     31    2678400     7776000
    //Abr     30    2592000    10368000
    //May     31    2678400    13046400
    //Jun     30    2592000    15638400
    //Jul     31    2678400    18316800
    //Ago     31    2678400    20995200
    //Sep     30    2592000    23587200
    //Oct     31    2678400    26265600
    //Nov     30    2592000    28857600
    const uint32_t _secondsPerMonth[11]={2678400,5097600,7776000,10368000,13046400,15638400,18316800,20995200,23587200,26265600,28857600};
    bool _leapYear(int y); //Indica si el año indicado es bisiesto
  public:
    uint32_t datetime2seconds(datetime t); //Calcula el número se segundos transcurridos entre el 1-Ene-1900 hasta la fecha indicada
    datetime seconds2datetime(uint32_t s); //Calcula la fecha correspondiente a los segundos trascurridos desde el 1-Ene-1900
    RoJoRTCclock(); //Constructor
    bool check(); //Comprueba si el reloj está conectado
    datetime get(); //Obtiene la hora
    void set(datetime t,int32_t secondsDelay); //Fijar fecha y hora con una demora en segundos
    void set1900(int32_t seconds1900); //Fijar fecha y hora teniendo en cuenta que se le pasa el número de segundos transcurridos desde el 1-Ene-1900
    void set1970(int32_t seconds1970); //Fijar fecha y hora teniendo en cuenta que se le pasa el número de segundos transcurridos desde el 1-Ene-1970
    #if !defined(__arm__)
		datetime getCompilerTime(); //Obtiene la fecha y hora del momento de la compilación
    #endif
};

#endif

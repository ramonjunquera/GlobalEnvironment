﻿/*
  Nombre de la librería: RoJoTelegramBot.h
  Versión: 20171202
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión de bots de Telegram para ESP8266
*/

#ifndef RoJoTelegramBot_h
#define RoJoTelegramBot_h

#include <Arduino.h>
#include <WiFiClientSecure.h> //Librería para gestión de conexiones https
#include <FS.h> //Librería para gestión de archivos

struct TelegramMessage
{
  uint32_t update_id;
  uint32_t message_id;
  uint32_t from_id;
  String from_name;
  uint64_t chat_id;
  uint32_t date;
  String text;
};

class RoJoTelegramBot
{
  private:
    String _botToken; //Token del bot
    const String _telegramHost="api.telegram.org"; //Host de Telegram
    const uint16_t _telegramPort=443; //Puerto de Telegram (https)
    uint32_t _lastUpdateId=0; //Identificador del último mensaje recibido
    String _actionCodes[9]={"typing","upload_photo","record_video","record_audio","upload_audio","upload_document","find_location","record_video_note","upload_video_note"};
    uint64_t _clienParseInt(WiFiClientSecure *client,uint16_t timeOut);
    bool _clientFindString(WiFiClientSecure *client,uint16_t timeOut,String findText,String endText="");
    String _clientReadString(WiFiClientSecure *client,uint16_t timeOut,String border);
    uint64_t _clientFieldInt(WiFiClientSecure *client,uint16_t timeOut,String fieldName,String endText="");
    String _clientFieldString(WiFiClientSecure *client,uint16_t timeOut,String fieldName,String endText="");
  public:
    String uint64String(uint64_t a); //Convierte un uint64_t en String
    RoJoTelegramBot(String botToken); //Constructor
    TelegramMessage getNextMessage(); //Obtiene el siguiente mensaje
    bool sendMessage(uint64_t chat_id,String text,String keyboard="",bool resize=false,bool oneTime=false); //Envía un mensaje a un chat
    String sendPhotoRemote(uint64_t chat_id,String photo,String caption = "",bool disable_notification = false,uint32_t reply_to_message_id = 0);
    String sendPhotoLocal(uint64_t chat_id,String fileName); //Envía una imagen local
    bool sendChatAction(uint64_t chat_id,byte actionCode); //Envía un mensaje de acción
};

#endif

/*
  Nombre de la librería: RoJoLosPowerWDT.h
  Versión: 20170921
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino.
    Gestiona la permanencia temporal en el modo de bajo consumo.

    Una vez incluida la librería se crear automáticamente el objeto lowPowerWDT que
    sólo tiene dos métodos:
    - void sleep(uint32_t period)
    - void wakeup()

    El primero permite indicar un tiempo aproximado en milisegundo en el que la placa 
    se mantendrá en modo de bajo consumo. Tras ese tiempo, volverá a despertar.
    El segundo método fuerza a la salida del modo de bajo consumo.

    Las interrupciones por hardware se siguen teniendo en cuenta y pueden ser utilizadas
    para salir del modo de bajo consumo.
*/

//Los valores de tiempos son aproximados

#include <Arduino.h>
#include <avr/wdt.h>
#include <avr/sleep.h>
#include "RoJoLowPowerWDT.h"

SIGNAL(WDT_vect)
{
  //Función a la que se llama cuando el timer WatchDog genera un evento

  //Desactivamos el timer WatchDog
  wdt_disable();
  WDTCSR &= ~_BV(WDIE);
}

void RoJoLowPowerWDT::_sleep(byte periodCode)
{
  //Duerme durante un tiempo determinado por el código

  //Configuramos el timer del WatchDog para que salte pasado el tiempo indicado por el código
  wdt_enable(periodCode);
  //Reseteamos el timer WatchDog
  wdt_reset();
  WDTCSR |= _BV(WDIE);
  //Definimos el modo de bajo consumo utilizaremos (SLEEP_MODE_PWR_DOWN)
  set_sleep_mode(SLEEP_MODE_PWR_DOWN);
  //Entramos en modo de bajo consumo
  sleep_mode();

  //A partir de este punto ya no se ejecuta el programa puesto que estamos "durmiendo"
  //En el momento que despertemos, continuaremos en este punto
}

void RoJoLowPowerWDT::sleep(uint32_t period)
{
  //Duerme durante un tiempo dado en milisegundos

  //Código de periodo válido
  byte validPeriodCode;
  //Comenzamos a dormir
  _sleeping=true;
  //Mientras estemos dormidos y tengamos que dormir más que la siesta más corta...
  while(_sleeping && period>_periodCodes[0])
  {
    //Reseteamos el código de periodo válido
    validPeriodCode=0;
    //Tenemos que saber cuánto debemos dormir
    //Recorremos todos los periodos de siesta
    for(byte p=1;p<10;p++)
    {
      //Si la siesta debe durar más que el código actual...el código de periodo es válido
      if(period>_periodCodes[p]) validPeriodCode=p;
      //La siesta es más corta que lo que dura el código actual...no buscamos más
      else break;
    }
    //Reducimos el tiempo de sueño pendiente con lo invertido en esta siesta
    period-=_periodCodes[validPeriodCode];
    //Tenemos el códido de periodo correcto para dormir. Dormimos
    _sleep(validPeriodCode);
  }
  //Deshabilitamos el timer de WatchDog
  wdt_disable();
  //Hemos terminado de dormir
  sleep_disable();
  //Hemos despertado!
  _sleeping=false;
}

void RoJoLowPowerWDT::wakeup()
{
  //Despertamos

  //Ya no estamos dormidos
  _sleeping=false;
  //Desactivamos el timer WatchDog
  wdt_disable();
}

RoJoLowPowerWDT lowPowerWDT;

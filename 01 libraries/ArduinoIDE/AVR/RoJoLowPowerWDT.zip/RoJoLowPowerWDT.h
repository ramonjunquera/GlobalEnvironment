/*
  Nombre de la librería: RoJoLosPowerWDT.h
  Versión: 20170921
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino.
    Gestiona la permanencia temporal en el modo de bajo consumo.
*/

#ifndef RoJoLowPowerWDT_h
#define RoJoLowPowerWDT_h

#include <Arduino.h>
#include <avr/wdt.h>
#include <avr/sleep.h>

class RoJoLowPowerWDT
{
  private:
    //Estoy durmiendo?. Inicialmente no.
    bool _sleeping=false;
    //Duerme durante un tiempo determinado por el código
    void _sleep(byte periodCode);
    //Array de códigos de duración de tiempo para el timer WatchDog
    const uint16_t _periodCodes[10]={135,151,182,243,374,625,1126,2127,4128,8129};
  public:
    //Duerme durante un tiempo dado en milisegundos
    void sleep(uint32_t period);
    //Despierta
    void wakeup();
};

extern RoJoLowPowerWDT lowPowerWDT;

#endif

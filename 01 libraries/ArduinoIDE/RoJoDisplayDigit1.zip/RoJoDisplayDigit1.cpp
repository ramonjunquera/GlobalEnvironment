/*
  Nombre de la librería: RoJoDisplayDigit1.cpp
  Versión: 20170915
  Autor: Ramón Junquera
  Descripción:
    Gestión de un display de 8 segmentos con conexión directa a la placa

  Recordemos la nomenclatura de los segmentos
        a
      ███
    █      █
  f █      █ b
    █  g   █
      ███
    █      █
  e █      █ c
    █      █
      ███     █ h
        d
    
*/

#ifndef RoJoDisplayDigit1_cpp
#define RoJoDisplayDigit1_cpp

#include <Arduino.h>
#include "RoJoDisplayDigit1.h"

RoJoDisplayDigit1::RoJoDisplayDigit1(byte psA,byte psB,byte psC,byte psD,byte psE,byte psF,byte psG,byte psH)
{ 
  //Constructor
  //Los parámetros son los pines de cada uno de los segmentos
      
  //Guardamos los pines de cada uno de los segmentos en el array privado
  _segmentPins[0]=psA;
  _segmentPins[1]=psB;
  _segmentPins[2]=psC;
  _segmentPins[3]=psD;
  _segmentPins[4]=psE;
  _segmentPins[5]=psF;
  _segmentPins[6]=psG;
  _segmentPins[7]=psH;
  //Configuramos todos los segmentos de salida
  for(byte s=0;s<8;s++) pinMode(_segmentPins[s],OUTPUT);
  //Borramos el display (mostramos un espacio sin punto)
  set(16,false);
}

void RoJoDisplayDigit1::set(byte digit,bool dot)
{
  //Muestra un carácter en el display
  //Permite activar el punto decimal

  //Calculamos el valor que se debe mostrar teniendo en cuenta el carácter y el punto decimal
  byte value=_chars[digit] | (dot?0b10000000:0x00);
  //Recorremos todos los segmentos...
  for(byte s=0;s<8;s++)
  {
    digitalWrite(_segmentPins[s],value & 0x01);
    value>>=1;
  }
}

#endif

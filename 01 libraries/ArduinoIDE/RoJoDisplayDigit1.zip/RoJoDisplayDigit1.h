/*
  Nombre de la librería: RoJoDisplayDigit1.h
  Versión: 20170915
  Autor: Ramón Junquera
  Descripción:
    Gestión de un display de 8 segmentos con conexión directa a la placa
*/

#ifndef RoJoDisplayDigit1_h
#define RoJoDisplayDigit1_h

#include <Arduino.h>

class RoJoDisplayDigit1
{
  private:
    byte _segmentPins[8]; //Guarda los pines de cada segmento
    const byte _chars[19]={ //Definición de los caracteres que se pueden mostrar
      0b00111111 // 0 = 0
     ,0b00000110 // 1 = 1
     ,0b01011011 // 2 = 2
     ,0b01001111 // 3 = 3
     ,0b01100110 // 4 = 4
     ,0b01101101 // 5 = 5
     ,0b01111101 // 6 = 6
     ,0b00100111 // 7 = 7
     ,0b01111111 // 8 = 8
     ,0b01101111 // 9 = 9
     ,0b01110111 //10 = A
     ,0b01111100 //11 = b
     ,0b00111001 //12 = C
     ,0b01011110 //13 = d
     ,0b01111001 //14 = E
     ,0b01110001 //15 = F
     ,0b00000000 //16 = space
     ,0b01000000 //17 = -
     ,0b01100011 //18 = º
   };
  public:
    RoJoDisplayDigit1(byte psA,byte psB,byte psC,byte psD,byte psE,byte psF,byte psG,byte psH); //Constructor
    void set(byte digit,bool dot); //Muestra un carácter en el display
}; //Punto y coma obligatorio para que no de error

#endif

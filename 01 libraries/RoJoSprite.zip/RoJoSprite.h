/*
  Nombre de la librería: RoJoSprite.h
  Versión: 20171103
  Autor: Ramón Junquera
  Descripción:
    Gestión de sprites color blanco y negro
    Sólo compatible con las familias de placas ESP32 y ESP8266 y
    Raspberry Pi 3
*/

#ifndef RoJoSprite_h
#define RoJoSprite_h

//Si declaramos la siguiente línea se entiende que queremos utilizar la
//versión completa. Si no, se utilizará una versión con menos
//funcionalidades que ocupa menos
#define RoJoSpriteFull

//Comprobamos que la placa es compatible
#if !defined(ESP32) && !defined(ESP8266) && !defined(__arm__)
  #error Library RoJoSprite is only compatible with ESP32 & ESP8266 family devices or Raspberry Pi 3
#endif  

#include <Arduino.h>

class RoJoSprite
{
  private:
    byte *_bitmap; //Array de gráficos
    uint16_t _xMax; //Anchura en pixels
    uint16_t _pagesMax; //Altura en páginas (bytes)
    //Aplica una máscara al byte de una página (de la memoria de vídeo)
    void _mask(uint16_t page,uint16_t x,byte mask,byte color);
  public:
    RoJoSprite(); //Constructor
    ~RoJoSprite(); //Destructor
    uint16_t width();
    uint16_t heightPages(); //Altura en páginas
    void clean(); //Libera memoria ocupada por el array de gráficos
    void setSize(uint16_t x,uint16_t pages); //Fija un nuevo tamaño para el sprite
    byte getPage(uint16_t x,uint16_t page); //Devolvemos el contenido de una columnas de una página
    void setPage(int16_t x,int16_t page,byte mask,byte color); //Guarda el byte de una columna de una página
    void setPixel(int16_t x,int16_t y,byte color); //Dibuja pixel
    bool getPixel(int16_t x,int16_t y); //Obtiene el estado del pixel
    bool load(String fileName); //Carga la información del sprite desde un archivo
//Funciones excluidas de la versión completa    
#if defined(RoJoSpriteFull)
    void clear(); //Borra el sprite pintando el fondo de negro
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color); //Dibuja una línea recta
    void save(String fileName); //Guarda la información del sprite en un archivo
    void resize(uint16_t width,uint16_t height,RoJoSprite *source);
#endif
}; //Punto y coma obligatorio para que no de error

#endif


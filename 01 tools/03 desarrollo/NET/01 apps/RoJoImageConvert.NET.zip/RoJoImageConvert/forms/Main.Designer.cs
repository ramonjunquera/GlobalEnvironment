﻿namespace RoJoImageConvert
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonLoad = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonBW = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSave1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSave16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSave24 = new System.Windows.Forms.ToolStripButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripButtonSave8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonGrey = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonLoad,
            this.toolStripButtonBW,
            this.toolStripButtonGrey,
            this.toolStripButtonSave1,
            this.toolStripButtonSave8,
            this.toolStripButtonSave16,
            this.toolStripButtonSave24});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(536, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonLoad
            // 
            this.toolStripButtonLoad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonLoad.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLoad.Image")));
            this.toolStripButtonLoad.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonLoad.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLoad.Name = "toolStripButtonLoad";
            this.toolStripButtonLoad.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonLoad.Text = "toolStripButton1";
            this.toolStripButtonLoad.ToolTipText = "Load";
            this.toolStripButtonLoad.Click += new System.EventHandler(this.toolStripButtonLoad_Click);
            // 
            // toolStripButtonBW
            // 
            this.toolStripButtonBW.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonBW.Enabled = false;
            this.toolStripButtonBW.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonBW.Image")));
            this.toolStripButtonBW.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonBW.Name = "toolStripButtonBW";
            this.toolStripButtonBW.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonBW.Text = "toolStripButton1";
            this.toolStripButtonBW.ToolTipText = "Convert to black & white";
            this.toolStripButtonBW.Click += new System.EventHandler(this.toolStripButtonBW_Click);
            // 
            // toolStripButtonSave1
            // 
            this.toolStripButtonSave1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSave1.Enabled = false;
            this.toolStripButtonSave1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSave1.Image")));
            this.toolStripButtonSave1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSave1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSave1.Name = "toolStripButtonSave1";
            this.toolStripButtonSave1.Size = new System.Drawing.Size(26, 22);
            this.toolStripButtonSave1.Text = "toolStripButton1";
            this.toolStripButtonSave1.ToolTipText = "Save SPR1";
            this.toolStripButtonSave1.Click += new System.EventHandler(this.toolStripButtonSave1_Click);
            // 
            // toolStripButtonSave16
            // 
            this.toolStripButtonSave16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSave16.Enabled = false;
            this.toolStripButtonSave16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSave16.Image")));
            this.toolStripButtonSave16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSave16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSave16.Name = "toolStripButtonSave16";
            this.toolStripButtonSave16.Size = new System.Drawing.Size(36, 22);
            this.toolStripButtonSave16.Text = "toolStripButton1";
            this.toolStripButtonSave16.ToolTipText = "Save SPR16";
            this.toolStripButtonSave16.Click += new System.EventHandler(this.toolStripButtonSave16_Click);
            // 
            // toolStripButtonSave24
            // 
            this.toolStripButtonSave24.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSave24.Enabled = false;
            this.toolStripButtonSave24.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSave24.Image")));
            this.toolStripButtonSave24.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSave24.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSave24.Name = "toolStripButtonSave24";
            this.toolStripButtonSave24.Size = new System.Drawing.Size(36, 22);
            this.toolStripButtonSave24.Text = "toolStripButton1";
            this.toolStripButtonSave24.ToolTipText = "Save SPR24";
            this.toolStripButtonSave24.Click += new System.EventHandler(this.toolStripButtonSave24_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(164, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(536, 219);
            this.panel1.TabIndex = 2;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 244);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(536, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(521, 17);
            this.toolStripStatusLabel1.Spring = true;
            this.toolStripStatusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripButtonSave8
            // 
            this.toolStripButtonSave8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSave8.Enabled = false;
            this.toolStripButtonSave8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSave8.Image")));
            this.toolStripButtonSave8.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonSave8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSave8.Name = "toolStripButtonSave8";
            this.toolStripButtonSave8.Size = new System.Drawing.Size(31, 22);
            this.toolStripButtonSave8.Text = "toolStripButton1";
            this.toolStripButtonSave8.ToolTipText = "Save SPR8";
            this.toolStripButtonSave8.Click += new System.EventHandler(this.toolStripButtonSave8_Click);
            // 
            // toolStripButtonGrey
            // 
            this.toolStripButtonGrey.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonGrey.Enabled = false;
            this.toolStripButtonGrey.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonGrey.Image")));
            this.toolStripButtonGrey.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonGrey.Name = "toolStripButtonGrey";
            this.toolStripButtonGrey.Size = new System.Drawing.Size(23, 22);
            this.toolStripButtonGrey.Text = "toolStripButton1";
            this.toolStripButtonGrey.ToolTipText = "Convert to grey";
            this.toolStripButtonGrey.Click += new System.EventHandler(this.toolStripButtonGrey_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 266);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Main";
            this.Text = "Image Convert v1.10";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonLoad;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButtonBW;
        private System.Windows.Forms.ToolStripButton toolStripButtonSave1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSave16;
        private System.Windows.Forms.ToolStripButton toolStripButtonSave24;
        private System.Windows.Forms.ToolStripButton toolStripButtonSave8;
        private System.Windows.Forms.ToolStripButton toolStripButtonGrey;
    }
}


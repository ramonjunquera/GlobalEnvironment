﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace RoJoImageConvert
{
    public partial class Main : Form
    {
        string originalFileName = "";
        public Main() {
            InitializeComponent();
        }

        //Pulsado el botón de cargar imagen
        private void toolStripButtonLoad_Click(object sender, EventArgs e) {
            OpenFileDialog oFile = new OpenFileDialog();
            oFile.Filter = "Image file (*.bmp,*.jpg)|*.bmp;*.jpg";
            //Si se acepta la selección de archivo...
            if(DialogResult.OK==oFile.ShowDialog()) {
                //Anotamos el nombre original del archivo que contiene la imagen
                originalFileName = oFile.FileName;
                //Cargamos la imagen desde el archivo
                pictureBox1.Image = Image.FromFile(oFile.FileName);
                //Informamos de detalles en barra de estado
                toolStripStatusLabel1.Text = "(" + pictureBox1.Image.Width.ToString() + " x " + pictureBox1.Image.Height.ToString() + ") " + originalFileName;
                //Activamos botones
                toolStripButtonBW.Enabled = true; //Convertir a blanco y negro
                toolStripButtonGrey.Enabled = true; //Convertir a grises
                //Activamos botones de exportación a color
                toolStripButtonSave8.Enabled = true; //Exportación a color 8
                toolStripButtonSave16.Enabled = true; //Exportación a color 16
                toolStripButtonSave24.Enabled = true; //Exportación a color 24
                //Desactivamos exportación en blanco y negro
                toolStripButtonSave1.Enabled = false; //Exportación a color 1
            }
        }

        //Pulsado el botón para convertir a blanco y negro
        private void toolStripButtonBW_Click(object sender, EventArgs e) {
            Cursor.Current = Cursors.WaitCursor;
            //Es posible que el formato de la imagen sea por índice
            //En estos casos no se puede cambiar el color de un pixel directamente con la función SetPixel
            //Para evitarlo, creamos un nuevo Bitmap en el que escribiremos la imagen en blanco y negro
            //y finalmente sustituiremos la imagen que se muestra por la nueva
            Bitmap newBitmap = new Bitmap(pictureBox1.Image.Width,pictureBox1.Image.Height);

            for (int y = 0; y < pictureBox1.Image.Height; y++) {
                for (int x = 0; x < pictureBox1.Image.Width; x++) {
                    //Tomamos nota del color 
                    Color c = ((Bitmap)pictureBox1.Image).GetPixel(x, y);
                    //Decidimos si el pixel se debe convertir a blanco o a negro
                    //y lo guardamos en el nuevo bitmap
                    newBitmap.SetPixel(x, y, (c.R + c.G + c.B > 382) ? Color.White : Color.Black);
                }
            }
            //Aplicamos el nuevo bitmap a la imagen de pantalla
            pictureBox1.Image = newBitmap;
            //Refrescamos el objeto gráfico para que se muestre en pantalla
            pictureBox1.Refresh();
            //Desactivamos el botón de convertir a blanco y negro
            toolStripButtonBW.Enabled = false;
            //Activamos los botón de exportar en blanco y negro
            toolStripButtonSave1.Enabled = true;
            //Desactivamos botónes de exportar en modos no monocromáticos
            toolStripButtonSave8.Enabled = false;
            toolStripButtonSave16.Enabled = false;
            toolStripButtonSave24.Enabled = false;
            Cursor.Current = Cursors.Default;
        }

        //Pulsado el botón para convertir a grises
        private void toolStripButtonGrey_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            //Es posible que el formato de la imagen sea por índice
            //En estos casos no se puede cambiar el color de un pixel directamente con la función SetPixel
            //Para evitarlo, creamos un nuevo Bitmap en el que escribiremos la imagen en tonos de gris
            //y finalmente sustituiremos la imagen que se muestra por la nueva
            Bitmap newBitmap = new Bitmap(pictureBox1.Image.Width, pictureBox1.Image.Height);

            for (int y = 0; y < pictureBox1.Image.Height; y++)
            {
                for (int x = 0; x < pictureBox1.Image.Width; x++)
                {
                    //Tomamos nota del color 
                    Color c = ((Bitmap)pictureBox1.Image).GetPixel(x, y);
                    int t = (c.R + c.G + c.B) / 3; //Calculamos su tono medio
                    c = Color.FromArgb(t, t, t); //Aplicamos el tono a los tres canales
                    newBitmap.SetPixel(x, y, c); //Y lo guardamos en el nuevo bitmap
                }
            }
            //Aplicamos el nuevo bitmap a la imagen de pantalla
            pictureBox1.Image = newBitmap;
            //Refrescamos el objeto gráfico para que se muestre en pantalla
            pictureBox1.Refresh();
            Cursor.Current = Cursors.Default;
        }

        //Pulsado el botón de exportación en blanco y negro
        private void toolStripButtonSave1_Click(object sender, EventArgs e) {
            SaveFileDialog sFile = new SaveFileDialog();
            //Cambiamos la extensión del archivo original
            sFile.FileName = System.IO.Path.GetDirectoryName(originalFileName) + "\\" + System.IO.Path.GetFileNameWithoutExtension(originalFileName) + ".spr";
            //Si se acepta el cuadro de diálogo...
            if (DialogResult.OK == sFile.ShowDialog()) {
                Cursor.Current = Cursors.WaitCursor;
                byte HB, LB; //Variables HiByte & LowByte
                //Abrimos el archivo para escritura binaria
                System.IO.FileStream swFile = System.IO.File.OpenWrite(sFile.FileName);

                //Escribimos la profundidad de color
                swFile.WriteByte(1);

                //Escribimos la anchura de la imagen
                LB = (byte)(pictureBox1.Image.Width & 0xFF);
                HB = (byte)((pictureBox1.Image.Width & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);

                //Calculamos el número de páginas
                int pCount = pictureBox1.Image.Height / 8;
                if (pictureBox1.Image.Height % 8 > 0) pCount++;

                //Calculamos la altura real que tendrá el sprite en función de sus páginas
                int pixelHeight = pCount * 8;

                //Esribimos la altura de la imagen en pixels
                LB = (byte)(pixelHeight & 0xFF);
                HB = (byte)((pixelHeight & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);

                //Recorremos todas las páginas
                for (int p = 0; p < pCount; p++) {
                    //Recorremos todas las columnas
                    for (int x = 0; x < pictureBox1.Image.Width; x++) {
                        //Inicializamos el valor del byte procesado
                        byte value = 0;
                        //Recorremos los bytes de la página
                        for (int y = 0; y < 8; y++) {
                            //Si la coordenada vertical está dentro del rango...
                            if (8 * p + y < pictureBox1.Image.Height) {
                                //Si el bit es negro...
                                if (((Bitmap)pictureBox1.Image).GetPixel(x, 8 * p + y).R == 0) {
                                    value += (byte)(1 << y);
                                }
                            }
                        }
                        //Escribimos el byte calculado
                        swFile.WriteByte(value);
                    }
                }
                //Cerramos el archivo
                swFile.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        //Pulsado el botón de exportación en color 8
        private void toolStripButtonSave8_Click(object sender, EventArgs e)
        {
            SaveFileDialog sFile = new SaveFileDialog();
            //Cambiamos la extensión del archivo original
            sFile.FileName = System.IO.Path.GetDirectoryName(originalFileName) + "\\" + System.IO.Path.GetFileNameWithoutExtension(originalFileName) + ".spr";
            //Si se acepta el cuadro de diálogo...
            if (DialogResult.OK == sFile.ShowDialog())
            {
                Cursor.Current = Cursors.WaitCursor;

                byte HB, LB;

                //Abrimos el archivo para escritura binaria
                System.IO.FileStream swFile = System.IO.File.OpenWrite(sFile.FileName);

                //Escribimos la profundidad de color
                swFile.WriteByte(8);

                //Escribimos la anchura de la imagen en pixels
                LB = (byte)(pictureBox1.Image.Width & 0xFF);
                HB = (byte)((pictureBox1.Image.Width & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);
                //Esribimos la altura de la imagen en pixels
                LB = (byte)(pictureBox1.Image.Height & 0xFF);
                HB = (byte)((pictureBox1.Image.Height & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);
                //Recorremos todas las filas
                for (int y = 0; y < pictureBox1.Image.Height; y++)
                {
                    //Recorremos todas las columnas
                    for (int x = 0; x < pictureBox1.Image.Width; x++)
                    {
                        //Obtenemos sólo el primer canal, porque los 3 son iguales
                        LB = ((Bitmap)pictureBox1.Image).GetPixel(x, y).R;
                        //Guardamos el color
                        swFile.WriteByte(LB);
                    }
                }
                //Cerramos el archivo
                swFile.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        //Pulsado el botón de exportación en color 16
        private void toolStripButtonSave16_Click(object sender, EventArgs e)
        {
            SaveFileDialog sFile = new SaveFileDialog();
            //Cambiamos la extensión del archivo original
            sFile.FileName = System.IO.Path.GetDirectoryName(originalFileName) + "\\" + System.IO.Path.GetFileNameWithoutExtension(originalFileName) + ".spr";
            //Si se acepta el cuadro de diálogo...
            if (DialogResult.OK == sFile.ShowDialog())
            {
                Cursor.Current = Cursors.WaitCursor;

                //Variables HiByte & LowByte
                byte HB, LB;

                //Abrimos el archivo para escritura binaria
                System.IO.FileStream swFile = System.IO.File.OpenWrite(sFile.FileName);

                //Escribimos la profundidad de color
                swFile.WriteByte(16);

                //Escribimos la anchura de la imagen
                LB = (byte)(pictureBox1.Image.Width & 0xFF);
                HB = (byte)((pictureBox1.Image.Width & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);
                //Esribimos la altura de la imagen en pixels
                LB = (byte)(pictureBox1.Image.Height & 0xFF);
                HB = (byte)((pictureBox1.Image.Height & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);
                //Recorremos todas las filas
                for (int y = 0; y < pictureBox1.Image.Height; y++) {
                    //Recorremos todas las columnas
                    for (int x = 0; x < pictureBox1.Image.Width; x++) {
                        //Obtenemos los distintos canales del color
                        byte R = ((Bitmap)pictureBox1.Image).GetPixel(x, y).R;
                        byte G = ((Bitmap)pictureBox1.Image).GetPixel(x, y).G;
                        byte B = ((Bitmap)pictureBox1.Image).GetPixel(x, y).B;
                        //Convertimos a formato 16 bits: RRRRRGGG GGGBBBBB
                        HB = (byte)((R & 0b11111000) | (G >> 5));
                        LB = (byte)(((G & 0b00011100) << 3) | (B >> 3));
                        //Guardamos los 2 bytes
                        swFile.WriteByte(LB);
                        swFile.WriteByte(HB);
                    }
                }
                //Cerramos el archivo
                swFile.Close();
                Cursor.Current = Cursors.Default;
            }
        }

        //Pulsado el botón de exportación en color 24
        private void toolStripButtonSave24_Click(object sender, EventArgs e)
        {
            SaveFileDialog sFile = new SaveFileDialog();
            //Cambiamos la extensión del archivo original
            sFile.FileName = System.IO.Path.GetDirectoryName(originalFileName) + "\\" + System.IO.Path.GetFileNameWithoutExtension(originalFileName) + ".spr";
            //Si se acepta el cuadro de diálogo...
            if (DialogResult.OK == sFile.ShowDialog()) {
                Cursor.Current = Cursors.WaitCursor;

                //Variables HiByte & LowByte
                byte HB, LB;

                //Abrimos el archivo para escritura binaria
                System.IO.FileStream swFile = System.IO.File.OpenWrite(sFile.FileName);

                //Escribimos la profundidad de color
                swFile.WriteByte(24);

                //Escribimos la anchura de la imagen
                LB = (byte)(pictureBox1.Image.Width & 0xFF);
                HB = (byte)((pictureBox1.Image.Width & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);
                //Esribimos la altura de la imagen en pixels
                LB = (byte)(pictureBox1.Image.Height & 0xFF);
                HB = (byte)((pictureBox1.Image.Height & 0xFF00) >> 8);
                swFile.WriteByte(LB);
                swFile.WriteByte(HB);
                //Recorremos todas las filas
                for (int y = 0; y < pictureBox1.Image.Height; y++) {
                    //Recorremos todas las columnas
                    for (int x = 0; x < pictureBox1.Image.Width; x++) {
                        //Guardamos los distintos canales de color
                        swFile.WriteByte(((Bitmap)pictureBox1.Image).GetPixel(x, y).R); //Red
                        swFile.WriteByte(((Bitmap)pictureBox1.Image).GetPixel(x, y).G); //Green
                        swFile.WriteByte(((Bitmap)pictureBox1.Image).GetPixel(x, y).B); //Blue
                    }
                }
                //Cerramos el archivo
                swFile.Close();
                Cursor.Current = Cursors.Default;
            }
        }

     
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoJoFontEdit
{
    public class DataFont
    {
        public byte charMin;
        public byte charMax;
        public byte pages;
        public DataChar[] dataChar;
        public byte charCount()
        {
            //Devuelve el número de caracteres que tiene la fuente
            return (byte)(charMax - charMin + 1);
        }
        public void redimPages(byte newPages)
        {
            //Redimensiona las páginas de todos los caracteres de una fuente
            //Suponemos que el número de páginas ha cambiado

            //Anotamos el número de caracteres de la fuente
            byte charCount = this.charCount();
            //Recorremos todos los caracteres de la fuente
            for (byte c = 0; c < charCount; c++)
            {
                //Redimensionamos el carácter la nuevo número de páginas
                this.dataChar[c].redimPages(pages, newPages);
            }
            //Asignamos el nuevo número de páginas a la fuente
            pages = newPages;
        }
        public void redimCharMax(byte newCharMax)
        {
            //Redimensiona la fuente ajustando el último carácter
            //Suponemos que el último carácter ha cambiado

            //Calculamos el nuevo número de caracteres
            byte newCharCount = (byte)(newCharMax - charMin + 1);
            //Creamos un nuevo array de caracteres
            DataChar[] newDataChar = new DataChar[newCharCount];
            //Si el nuevo último carácter es mayor que el anterior (si se amplia el núemro de caracteres)...
            if(newCharMax>charMax)
            {
                //Anotamos el número de caracteres actuales
                byte charCount=this.charCount();
                //Copiaremos los carácteres actuales
                for (byte c = 0; c < charCount; c++)
                    newDataChar[c]= dataChar[c];
                //Crearemos el resto
                for (byte c=charCount;c<newCharCount;c++)
                    newDataChar[c] = new DataChar(pages);
            }
            else //Se reduce el número de caracteres
            {
                //Copiaremos los carácteres que correspondan
                for (byte c = 0; c < newCharCount; c++)
                    newDataChar[c] = dataChar[c];
            }
            //Asignamos el nuevo array de caracteres a la fuente
            dataChar = newDataChar;
            //Anotamos cuál es ahora el último carácter
            charMax = newCharMax;
        }
        public void redimCharMin(byte newCharMin)
        {
            //Redimensiona la fuente ajustando el primer carácter
            //Suponemos que el primer carácter ha cambiado

            //Calculamos el nuevo número de caracteres
            byte newCharCount = (byte)(charMax - newCharMin + 1);
            //Creamos un nuevo array de caracteres
            DataChar[] newDataChar = new DataChar[newCharCount];
            //Si el nuevo primer carácter es menor que el anterior (si se amplia el núemro de caracteres)...
            if (newCharMin < charMin)
            {
                //Anotamos el número de caracteres nuevos
                byte diff = (byte)(charMin-newCharMin);
                //Crearemos los caracteres iniciales nuevos
                for (byte c = 0; c < diff; c++)
                    newDataChar[c] = new DataChar(pages);
                //Copiaremos los carácteres actuales
                for (byte c = diff; c < newCharCount; c++)
                    newDataChar[c] = dataChar[c-diff];
            }
            else //Se reduce el número de caracteres
            {
                //Copiaremos los carácteres que correspondan
                for (byte c = 0; c < newCharCount; c++)
                    newDataChar[c] = dataChar[c];
            }
            //Asignamos el nuevo array de caracteres a la fuente
            dataChar = newDataChar;
            //Anotamos cuál es ahora el primer carácter
            charMin = newCharMin;
        }
        public DataFont()
        {
            //Constructor

            //Cuando se crea una fuente sólo tiene un carácter. El cero
            charMin = charMax = 48;
            //Sólo tiene una página
            pages = 1;
            //Creamos el array de caracteres, con un sólo carácter
            dataChar = new DataChar[1];
            dataChar[0] = new DataChar(pages);
        }
    }
}

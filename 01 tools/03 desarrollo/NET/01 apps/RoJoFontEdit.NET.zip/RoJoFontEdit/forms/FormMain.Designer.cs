﻿namespace RoJoFontEdit
{
    partial class FormMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.trackBarChar = new System.Windows.Forms.TrackBar();
            this.panelSeparator3 = new System.Windows.Forms.Panel();
            this.panelChar = new System.Windows.Forms.Panel();
            this.labelChar = new System.Windows.Forms.Label();
            this.labelCharNumber = new System.Windows.Forms.Label();
            this.panelSeparator4 = new System.Windows.Forms.Panel();
            this.numericUpDownWidth = new System.Windows.Forms.NumericUpDown();
            this.panelSeparator5 = new System.Windows.Forms.Panel();
            this.buttonZoomIn = new System.Windows.Forms.Button();
            this.buttonZoomOut = new System.Windows.Forms.Button();
            this.panelSeparator2 = new System.Windows.Forms.Panel();
            this.buttonConfig = new System.Windows.Forms.Button();
            this.panelSeparator1 = new System.Windows.Forms.Panel();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBoxMain = new System.Windows.Forms.PictureBox();
            this.panelConfig = new System.Windows.Forms.Panel();
            this.labelPages = new System.Windows.Forms.Label();
            this.numericUpDownPages = new System.Windows.Forms.NumericUpDown();
            this.trackBarCharMax = new System.Windows.Forms.TrackBar();
            this.panelCharMin = new System.Windows.Forms.Panel();
            this.labelCharMinChar = new System.Windows.Forms.Label();
            this.labelCharMinNumber = new System.Windows.Forms.Label();
            this.labelCharMax = new System.Windows.Forms.Label();
            this.labelCharMin = new System.Windows.Forms.Label();
            this.panelCharMax = new System.Windows.Forms.Panel();
            this.labelCharMaxChar = new System.Windows.Forms.Label();
            this.labelCharMaxNumber = new System.Windows.Forms.Label();
            this.trackBarCharMin = new System.Windows.Forms.TrackBar();
            this.panelPicture = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarChar)).BeginInit();
            this.panelChar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).BeginInit();
            this.panelConfig.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCharMax)).BeginInit();
            this.panelCharMin.SuspendLayout();
            this.panelCharMax.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCharMin)).BeginInit();
            this.panelPicture.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMenu.Controls.Add(this.trackBarChar);
            this.panelMenu.Controls.Add(this.panelSeparator3);
            this.panelMenu.Controls.Add(this.panelChar);
            this.panelMenu.Controls.Add(this.panelSeparator4);
            this.panelMenu.Controls.Add(this.numericUpDownWidth);
            this.panelMenu.Controls.Add(this.panelSeparator5);
            this.panelMenu.Controls.Add(this.buttonZoomIn);
            this.panelMenu.Controls.Add(this.buttonZoomOut);
            this.panelMenu.Controls.Add(this.panelSeparator2);
            this.panelMenu.Controls.Add(this.buttonConfig);
            this.panelMenu.Controls.Add(this.panelSeparator1);
            this.panelMenu.Controls.Add(this.buttonSave);
            this.panelMenu.Controls.Add(this.buttonOpen);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(600, 42);
            this.panelMenu.TabIndex = 1;
            // 
            // trackBarChar
            // 
            this.trackBarChar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trackBarChar.Location = new System.Drawing.Point(120, 0);
            this.trackBarChar.Maximum = 48;
            this.trackBarChar.Minimum = 48;
            this.trackBarChar.Name = "trackBarChar";
            this.trackBarChar.Size = new System.Drawing.Size(275, 40);
            this.trackBarChar.TabIndex = 5;
            this.trackBarChar.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBarChar.Value = 48;
            this.trackBarChar.ValueChanged += new System.EventHandler(this.trackBarChar_ValueChanged);
            // 
            // panelSeparator3
            // 
            this.panelSeparator3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelSeparator3.Enabled = false;
            this.panelSeparator3.Location = new System.Drawing.Point(395, 0);
            this.panelSeparator3.Name = "panelSeparator3";
            this.panelSeparator3.Size = new System.Drawing.Size(9, 40);
            this.panelSeparator3.TabIndex = 12;
            // 
            // panelChar
            // 
            this.panelChar.Controls.Add(this.labelChar);
            this.panelChar.Controls.Add(this.labelCharNumber);
            this.panelChar.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelChar.Location = new System.Drawing.Point(404, 0);
            this.panelChar.Name = "panelChar";
            this.panelChar.Size = new System.Drawing.Size(32, 40);
            this.panelChar.TabIndex = 11;
            // 
            // labelChar
            // 
            this.labelChar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelChar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelChar.Location = new System.Drawing.Point(0, 15);
            this.labelChar.Name = "labelChar";
            this.labelChar.Size = new System.Drawing.Size(32, 25);
            this.labelChar.TabIndex = 9;
            this.labelChar.Text = "0";
            this.labelChar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // labelCharNumber
            // 
            this.labelCharNumber.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelCharNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCharNumber.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelCharNumber.Location = new System.Drawing.Point(0, 0);
            this.labelCharNumber.Name = "labelCharNumber";
            this.labelCharNumber.Size = new System.Drawing.Size(32, 15);
            this.labelCharNumber.TabIndex = 12;
            this.labelCharNumber.Text = "48";
            this.labelCharNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panelSeparator4
            // 
            this.panelSeparator4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelSeparator4.Enabled = false;
            this.panelSeparator4.Location = new System.Drawing.Point(436, 0);
            this.panelSeparator4.Name = "panelSeparator4";
            this.panelSeparator4.Size = new System.Drawing.Size(9, 40);
            this.panelSeparator4.TabIndex = 10;
            // 
            // numericUpDownWidth
            // 
            this.numericUpDownWidth.Dock = System.Windows.Forms.DockStyle.Right;
            this.numericUpDownWidth.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownWidth.Location = new System.Drawing.Point(445, 0);
            this.numericUpDownWidth.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownWidth.Name = "numericUpDownWidth";
            this.numericUpDownWidth.Size = new System.Drawing.Size(72, 41);
            this.numericUpDownWidth.TabIndex = 2;
            this.numericUpDownWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownWidth.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownWidth.ValueChanged += new System.EventHandler(this.numericUpDownWidth_ValueChanged);
            // 
            // panelSeparator5
            // 
            this.panelSeparator5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelSeparator5.Enabled = false;
            this.panelSeparator5.Location = new System.Drawing.Point(517, 0);
            this.panelSeparator5.Name = "panelSeparator5";
            this.panelSeparator5.Size = new System.Drawing.Size(9, 40);
            this.panelSeparator5.TabIndex = 8;
            // 
            // buttonZoomIn
            // 
            this.buttonZoomIn.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("buttonZoomIn.Image")));
            this.buttonZoomIn.Location = new System.Drawing.Point(526, 0);
            this.buttonZoomIn.Name = "buttonZoomIn";
            this.buttonZoomIn.Size = new System.Drawing.Size(36, 40);
            this.buttonZoomIn.TabIndex = 7;
            this.buttonZoomIn.UseVisualStyleBackColor = true;
            this.buttonZoomIn.Click += new System.EventHandler(this.buttonZoomIn_Click);
            // 
            // buttonZoomOut
            // 
            this.buttonZoomOut.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("buttonZoomOut.Image")));
            this.buttonZoomOut.Location = new System.Drawing.Point(562, 0);
            this.buttonZoomOut.Name = "buttonZoomOut";
            this.buttonZoomOut.Size = new System.Drawing.Size(36, 40);
            this.buttonZoomOut.TabIndex = 6;
            this.buttonZoomOut.UseVisualStyleBackColor = true;
            this.buttonZoomOut.Click += new System.EventHandler(this.buttonZoomOut_Click);
            // 
            // panelSeparator2
            // 
            this.panelSeparator2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSeparator2.Enabled = false;
            this.panelSeparator2.Location = new System.Drawing.Point(111, 0);
            this.panelSeparator2.Name = "panelSeparator2";
            this.panelSeparator2.Size = new System.Drawing.Size(9, 40);
            this.panelSeparator2.TabIndex = 4;
            // 
            // buttonConfig
            // 
            this.buttonConfig.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonConfig.Image = ((System.Drawing.Image)(resources.GetObject("buttonConfig.Image")));
            this.buttonConfig.Location = new System.Drawing.Point(77, 0);
            this.buttonConfig.Name = "buttonConfig";
            this.buttonConfig.Size = new System.Drawing.Size(34, 40);
            this.buttonConfig.TabIndex = 3;
            this.buttonConfig.UseVisualStyleBackColor = true;
            this.buttonConfig.Click += new System.EventHandler(this.buttonConfig_Click);
            // 
            // panelSeparator1
            // 
            this.panelSeparator1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSeparator1.Enabled = false;
            this.panelSeparator1.Location = new System.Drawing.Point(68, 0);
            this.panelSeparator1.Name = "panelSeparator1";
            this.panelSeparator1.Size = new System.Drawing.Size(9, 40);
            this.panelSeparator1.TabIndex = 2;
            // 
            // buttonSave
            // 
            this.buttonSave.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonSave.Enabled = false;
            this.buttonSave.Image = ((System.Drawing.Image)(resources.GetObject("buttonSave.Image")));
            this.buttonSave.Location = new System.Drawing.Point(34, 0);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(34, 40);
            this.buttonSave.TabIndex = 1;
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonOpen
            // 
            this.buttonOpen.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonOpen.Image = ((System.Drawing.Image)(resources.GetObject("buttonOpen.Image")));
            this.buttonOpen.Location = new System.Drawing.Point(0, 0);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(34, 40);
            this.buttonOpen.TabIndex = 0;
            this.buttonOpen.UseVisualStyleBackColor = true;
            this.buttonOpen.Click += new System.EventHandler(this.buttonOpen_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "\"Font|*.fon|All files|*.*\"";
            // 
            // pictureBoxMain
            // 
            this.pictureBoxMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxMain.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxMain.Name = "pictureBoxMain";
            this.pictureBoxMain.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxMain.TabIndex = 2;
            this.pictureBoxMain.TabStop = false;
            this.pictureBoxMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBoxMain_MouseDown);
            this.pictureBoxMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxMain_MouseMove);
            // 
            // panelConfig
            // 
            this.panelConfig.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelConfig.Controls.Add(this.labelPages);
            this.panelConfig.Controls.Add(this.numericUpDownPages);
            this.panelConfig.Controls.Add(this.trackBarCharMax);
            this.panelConfig.Controls.Add(this.panelCharMin);
            this.panelConfig.Controls.Add(this.labelCharMax);
            this.panelConfig.Controls.Add(this.labelCharMin);
            this.panelConfig.Controls.Add(this.panelCharMax);
            this.panelConfig.Controls.Add(this.trackBarCharMin);
            this.panelConfig.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelConfig.Location = new System.Drawing.Point(0, 42);
            this.panelConfig.Name = "panelConfig";
            this.panelConfig.Size = new System.Drawing.Size(600, 140);
            this.panelConfig.TabIndex = 3;
            this.panelConfig.Visible = false;
            // 
            // labelPages
            // 
            this.labelPages.AutoSize = true;
            this.labelPages.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPages.Location = new System.Drawing.Point(11, 100);
            this.labelPages.Name = "labelPages";
            this.labelPages.Size = new System.Drawing.Size(54, 20);
            this.labelPages.TabIndex = 25;
            this.labelPages.Text = "Pages";
            // 
            // numericUpDownPages
            // 
            this.numericUpDownPages.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDownPages.Location = new System.Drawing.Point(99, 94);
            this.numericUpDownPages.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownPages.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownPages.Name = "numericUpDownPages";
            this.numericUpDownPages.Size = new System.Drawing.Size(72, 32);
            this.numericUpDownPages.TabIndex = 24;
            this.numericUpDownPages.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownPages.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownPages.ValueChanged += new System.EventHandler(this.numericUpDownPages_ValueChanged);
            // 
            // trackBarCharMax
            // 
            this.trackBarCharMax.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBarCharMax.Location = new System.Drawing.Point(137, 48);
            this.trackBarCharMax.Maximum = 255;
            this.trackBarCharMax.Name = "trackBarCharMax";
            this.trackBarCharMax.Size = new System.Drawing.Size(455, 45);
            this.trackBarCharMax.TabIndex = 23;
            this.trackBarCharMax.TickFrequency = 5;
            this.trackBarCharMax.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBarCharMax.Value = 48;
            this.trackBarCharMax.ValueChanged += new System.EventHandler(this.trackBarCharMax_ValueChanged);
            // 
            // panelCharMin
            // 
            this.panelCharMin.Controls.Add(this.labelCharMinChar);
            this.panelCharMin.Controls.Add(this.labelCharMinNumber);
            this.panelCharMin.Location = new System.Drawing.Point(99, 5);
            this.panelCharMin.Name = "panelCharMin";
            this.panelCharMin.Size = new System.Drawing.Size(32, 40);
            this.panelCharMin.TabIndex = 20;
            // 
            // labelCharMinChar
            // 
            this.labelCharMinChar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelCharMinChar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCharMinChar.Location = new System.Drawing.Point(0, 15);
            this.labelCharMinChar.Name = "labelCharMinChar";
            this.labelCharMinChar.Size = new System.Drawing.Size(32, 25);
            this.labelCharMinChar.TabIndex = 9;
            this.labelCharMinChar.Text = "0";
            this.labelCharMinChar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // labelCharMinNumber
            // 
            this.labelCharMinNumber.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelCharMinNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCharMinNumber.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelCharMinNumber.Location = new System.Drawing.Point(0, 0);
            this.labelCharMinNumber.Name = "labelCharMinNumber";
            this.labelCharMinNumber.Size = new System.Drawing.Size(32, 15);
            this.labelCharMinNumber.TabIndex = 12;
            this.labelCharMinNumber.Text = "48";
            this.labelCharMinNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelCharMax
            // 
            this.labelCharMax.AutoSize = true;
            this.labelCharMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCharMax.Location = new System.Drawing.Point(11, 63);
            this.labelCharMax.Name = "labelCharMax";
            this.labelCharMax.Size = new System.Drawing.Size(82, 20);
            this.labelCharMax.TabIndex = 22;
            this.labelCharMax.Text = "Char MAX";
            // 
            // labelCharMin
            // 
            this.labelCharMin.AutoSize = true;
            this.labelCharMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCharMin.Location = new System.Drawing.Point(11, 20);
            this.labelCharMin.Name = "labelCharMin";
            this.labelCharMin.Size = new System.Drawing.Size(76, 20);
            this.labelCharMin.TabIndex = 21;
            this.labelCharMin.Text = "Char MIN";
            // 
            // panelCharMax
            // 
            this.panelCharMax.Controls.Add(this.labelCharMaxChar);
            this.panelCharMax.Controls.Add(this.labelCharMaxNumber);
            this.panelCharMax.Location = new System.Drawing.Point(99, 48);
            this.panelCharMax.Name = "panelCharMax";
            this.panelCharMax.Size = new System.Drawing.Size(32, 40);
            this.panelCharMax.TabIndex = 19;
            // 
            // labelCharMaxChar
            // 
            this.labelCharMaxChar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelCharMaxChar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCharMaxChar.Location = new System.Drawing.Point(0, 15);
            this.labelCharMaxChar.Name = "labelCharMaxChar";
            this.labelCharMaxChar.Size = new System.Drawing.Size(32, 25);
            this.labelCharMaxChar.TabIndex = 9;
            this.labelCharMaxChar.Text = "0";
            this.labelCharMaxChar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // labelCharMaxNumber
            // 
            this.labelCharMaxNumber.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelCharMaxNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCharMaxNumber.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelCharMaxNumber.Location = new System.Drawing.Point(0, 0);
            this.labelCharMaxNumber.Name = "labelCharMaxNumber";
            this.labelCharMaxNumber.Size = new System.Drawing.Size(32, 15);
            this.labelCharMaxNumber.TabIndex = 12;
            this.labelCharMaxNumber.Text = "48";
            this.labelCharMaxNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // trackBarCharMin
            // 
            this.trackBarCharMin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBarCharMin.Location = new System.Drawing.Point(137, 5);
            this.trackBarCharMin.Maximum = 255;
            this.trackBarCharMin.Name = "trackBarCharMin";
            this.trackBarCharMin.Size = new System.Drawing.Size(455, 45);
            this.trackBarCharMin.TabIndex = 18;
            this.trackBarCharMin.TickFrequency = 5;
            this.trackBarCharMin.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBarCharMin.Value = 48;
            this.trackBarCharMin.ValueChanged += new System.EventHandler(this.trackBarCharMin_ValueChanged);
            // 
            // panelPicture
            // 
            this.panelPicture.AutoScroll = true;
            this.panelPicture.Controls.Add(this.pictureBoxMain);
            this.panelPicture.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPicture.Location = new System.Drawing.Point(0, 182);
            this.panelPicture.Name = "panelPicture";
            this.panelPicture.Size = new System.Drawing.Size(600, 173);
            this.panelPicture.TabIndex = 4;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 355);
            this.Controls.Add(this.panelPicture);
            this.Controls.Add(this.panelConfig);
            this.Controls.Add(this.panelMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(469, 172);
            this.Name = "FormMain";
            this.Text = "RoJo Edit Font v20180530";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarChar)).EndInit();
            this.panelChar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).EndInit();
            this.panelConfig.ResumeLayout(false);
            this.panelConfig.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCharMax)).EndInit();
            this.panelCharMin.ResumeLayout(false);
            this.panelCharMax.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCharMin)).EndInit();
            this.panelPicture.ResumeLayout(false);
            this.panelPicture.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.TrackBar trackBarChar;
        private System.Windows.Forms.Panel panelSeparator2;
        private System.Windows.Forms.Panel panelSeparator1;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonOpen;
        private System.Windows.Forms.Panel panelSeparator5;
        private System.Windows.Forms.Button buttonZoomIn;
        private System.Windows.Forms.Button buttonZoomOut;
        private System.Windows.Forms.Panel panelSeparator4;
        private System.Windows.Forms.Label labelChar;
        private System.Windows.Forms.Panel panelChar;
        private System.Windows.Forms.Label labelCharNumber;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.NumericUpDown numericUpDownWidth;
        private System.Windows.Forms.Panel panelSeparator3;
        private System.Windows.Forms.PictureBox pictureBoxMain;
        private System.Windows.Forms.Panel panelConfig;
        private System.Windows.Forms.Button buttonConfig;
        private System.Windows.Forms.Label labelPages;
        private System.Windows.Forms.NumericUpDown numericUpDownPages;
        private System.Windows.Forms.TrackBar trackBarCharMax;
        private System.Windows.Forms.Panel panelCharMin;
        private System.Windows.Forms.Label labelCharMinChar;
        private System.Windows.Forms.Label labelCharMinNumber;
        private System.Windows.Forms.Label labelCharMax;
        private System.Windows.Forms.Label labelCharMin;
        private System.Windows.Forms.Panel panelCharMax;
        private System.Windows.Forms.Label labelCharMaxChar;
        private System.Windows.Forms.Label labelCharMaxNumber;
        private System.Windows.Forms.TrackBar trackBarCharMin;
        private System.Windows.Forms.Panel panelPicture;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RoJoFontEdit
{
    public partial class FormMain : Form
    {
        //Definición de variables privadas para gestión de la aplicación
        private DataFont font; //Fuente en edición
        private bool modified = false; //Inicialmente no ha sido modificada
        private byte zoom = 20; //Nivel inicial de zoom
        private String filename = "newfont.fon"; //Nombre de archivo
        public FormMain()
        {
            //Inicialización del formulario
            InitializeComponent();

            //Creamos el objeto de la fuente
            font = new DataFont();
            //Llamar a función que crea una nueva imagen y muestra en ella el carácter actual
            drawPictureChar();
        }
        private string openFileFON(DataFont newFont,string filename)
        {
            //Abre un archivo .fon
            //Devuelve el mensaje de error (si existe)

            //Mensaje de error. Inicialmente ninguno
            string errorMessage = ""; 
            //Intentamos leer el contenido del archivo
            try
            {
                //Abrimos el archivo
                FileStream fs = File.Open(openFileDialog1.FileName, FileMode.Open);
                //Leemos el código del primer caracter de la fuente
                newFont.charMin = (byte)fs.ReadByte();
                //Leemos el código del último caracter de la fuente
                newFont.charMax = (byte)fs.ReadByte();
                //Leemos el número de páginas de altura
                newFont.pages = (byte)fs.ReadByte();
                //Calculamos el número de caracteres de la fuente
                byte charCount = newFont.charCount();
                //Creamos el array de caracteres
                newFont.dataChar = new DataChar[charCount];
                //Recorremos todos los caracteres
                for (byte c = 0; c < charCount; c++)
                {
                    //Creamos la clase carácter para esta posición
                    newFont.dataChar[c] = new DataChar(font.pages);
                    //Posicionamos la lectura del archivo en la anchura del carácter
                    fs.Seek(3 + 3*c, SeekOrigin.Begin);
                    //Leemos la anchura
                    newFont.dataChar[c].width = (byte)fs.ReadByte();
                    //Creamos el array de datos del carácter
                    newFont.dataChar[c].data = new byte[newFont.dataChar[c].width * newFont.pages];
                    //Leemos la posición de inicio de datos del carácter
                    UInt16 charIndex = (UInt16)(fs.ReadByte() + fs.ReadByte() * 256);
                    //Posicionamos la lectura del archivo al inicio de datos del carácter
                    fs.Seek(charIndex, SeekOrigin.Begin);
                    //Leemos los datos del carácter al array
                    fs.Read(newFont.dataChar[c].data, 0, newFont.dataChar[c].width * newFont.pages);
                }
                //Cerramos el archivo
                fs.Close();
            }
            catch (Exception ex)
            {
                //Algo ha salido mal leyendo el archivo
                //Anotamos el mensaje de error
                errorMessage = "Error reading font file: " + ex.Message;
            }
            //Hemos terminado de leer el archivo
            //Devolvemos el mensaje de error
            return errorMessage;
        }
        private void buttonOpen_Click(object sender, EventArgs e)
        {
            //Pulsado el botón Open

            //Si se cancela el formulario de selección de archivos...hemos terminado
            if (openFileDialog1.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
            //Creamos una nueva clase para cargar la fuente
            DataFont newFont= new DataFont();
            //Si el archivo es .fon...
            if(openFileDialog1.FileName.EndsWith(".fon"))
            {
                //Intentamos leer el archivo
                string errorMessage = openFileFON(newFont, openFileDialog1.FileName);
                //Si se ha leido correctamente....
                if (errorMessage.Length==0)
                {
                    //Si la fuente cargada actualmente ha sido modificada...
                    if (modified)
                    {
                        //...si no se acepta la carga de la nueva fuente...
                        if (MessageBox.Show("Current font will loose changes. Do you want to continue?", "Load confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK)
                        {
                            //...hemos terminado
                            return;
                        }
                    }
                    //Se acepta la carga de la nueva fuente
                    //Anotamos el nombre del archivo
                    filename = openFileDialog1.FileName;
                    //Sustituimos la fuente actual por la nueva
                    font = newFont;
                    //Por ahora no se ha modificado
                    modified = false;
                    buttonSave.Enabled = false;
                    //Aplicamos los límites del rango de caracteres de la fuente
                    trackBarChar.Minimum = font.charMin;
                    trackBarChar.Maximum = font.charMax;
                    //Y a los controles de configuración
                    trackBarCharMin.Value = font.charMin;
                    trackBarCharMax.Value = font.charMax;
                    //Actualizamos los caracteres mostrados en config
                    trackBarCharMin_ValueChanged(null, null);
                    trackBarCharMax_ValueChanged(null, null);
                    //Aplicamos el número de páginas al control de configuración
                    numericUpDownPages.Value = font.pages;
                    //Inicialmente comenzaremos editando el primer carácter del rango
                    trackBarChar.Value = font.charMin;
                    //Asignamos la anchura correcta
                    numericUpDownWidth.Value = font.dataChar[0].width;
                    //Se dibuja el carácter seleccionado
                    drawPictureChar();
                }
                else //ha ocurrido un error leyendo el archivo
                {
                    //Mostramos el mensaje de error
                    MessageBox.Show(errorMessage);
                }
            }
            else
            {
                //No reconocemos la extensión del archivo de entrada
                MessageBox.Show("Input filename extension unknown");
            }
        }
        private void trackBarChar_ValueChanged(object sender, EventArgs e)
        {
            //Se ha cambiado el carácter a editar

            //Actualizamos el código ASCII del carácter
            labelCharNumber.Text = trackBarChar.Value.ToString();
            //Actualizamos el carácter
            labelChar.Text = ((char)(trackBarChar.Value)).ToString();
            //Actualizamos la anchura correcta
            numericUpDownWidth.Value = font.dataChar[trackBarChar.Value-font.charMin].width;
            //Redibujamos el carácter actual
            drawPictureChar();
        }
        private void drawPictureChar()
        {
            //Crea una nueva images vacía del tamaño del carácter actual
            //Tiene en cuenta el zoom

            //Calculamos el tamaño del carácter
            byte charX = font.dataChar[trackBarChar.Value - font.charMin].width;
            byte charY = (byte)(font.pages * 8);
            //Calculamos el tamaño de la imagen
            int picX = zoom * charX;
            int picY = zoom * charY;
            //Creamos la imagen
            Bitmap newPicture = new Bitmap(picX, picY);
            //Dibujamos la rejilla en negro
            //Líneas horizontales
            for (int y = 0; y < charY;y ++)
                for(int x=0;x<picX;x++)
                {
                    newPicture.SetPixel(x, y * zoom, Color.Black);
                    newPicture.SetPixel(x, (y+1) * zoom-1, Color.Black);
                }
            //Líneas verticales
            for (int x = 0; x < charX; x++)
                for (int y = 0; y < picY; y++)
                {
                    newPicture.SetPixel(x * zoom, y, Color.Black);
                    newPicture.SetPixel((x+1)*zoom-1,y, Color.Black);
                }
            //Asignamos la imagen al control gráfico
            pictureBoxMain.Image = newPicture;
            //Dibujamos los pixels del carácter
            //Recorremos todos los pixels
            for (byte x = 0; x < charX; x++)
                for (byte y = 0; y < charY; y++)
                {
                    //Anotamos si el pixel está activo
                    bool status = (font.dataChar[trackBarChar.Value - font.charMin].data[x + (y / 8) * font.dataChar[trackBarChar.Value - font.charMin].width] & 1 << (y % 8)) > 0;
                    //Dibujamos el pixel
                    drawPicturePixel(x, y, status);
                }
        }
        private void drawPicturePixel(byte x, byte y, bool status)
        {
            //Dibuja un pixel del caracter en la imagen

            //Calculamos las posiciones iniciales
            int x0 = x * zoom + 1;
            int y0 = y * zoom + 1;
            //Calculamos la anchura del pixel
            int width = zoom - 2;
            //Calculamos el color
            Color c;
            //Si tiene el color activo...negro
            if (status) c = Color.Black;
            //Sino...blanco
            else c = Color.White;
            //Dibujamos el rectángulo que representa el pixel
            for (int xi = 0; xi < width; xi++)
                for (int yi = 0; yi < width; yi++)
                    ((Bitmap)(pictureBoxMain.Image)).SetPixel(x0 + xi, y0 + yi, c);
        }
        private void buttonZoomIn_Click(object sender, EventArgs e)
        {
            //Pulsado el botón para aumentar el zoom

            //Aumentamos el zoom
            zoom++;
            //Si hemos llegado al máximo zoom...desactivamos el botón
            if (zoom == 255) buttonZoomIn.Enabled = false;
            //Activamos el botón para reducir el zoom
            buttonZoomOut.Enabled = true;
            //Redibujamos el carácter
            drawPictureChar();
        }
        private void buttonZoomOut_Click(object sender, EventArgs e)
        {
            //Pulsado el botón para reducir el zoom

            //Reducimos el zoom
            zoom--;
            //Si hemos llegado al mínimo zoom...desactivamos el botón
            if (zoom == 5) buttonZoomOut.Enabled = false;
            //Activamos el botón para aumentar el zoom
            buttonZoomIn.Enabled = true;
            //Redibujamos el carácter
            drawPictureChar();
        }
        private void fontModified()
        {
            //La fuente se ha modificado

            modified = true;
            buttonSave.Enabled = true;
        }
        private void buttonSave_Click(object sender, EventArgs e)
        {
            //Se ha pulsado el botón de salvar fuente

            //Intentamos guardar el contenido del archivo
            try
            {
                //Abrimos el archivo para escritura
                FileStream fs = File.Open(filename, FileMode.Create);
                //Escribimos el código del primer carácter de la fuente
                fs.WriteByte(font.charMin);
                //Escribimos el código del último carácter de la fuente
                fs.WriteByte(font.charMax);
                //Escribimos el número de páginas de altura
                fs.WriteByte(font.pages);
                //Calculamos el número de caracteres de la fuente
                Byte charCount = (byte)(font.charMax - font.charMin + 1);
                //Definimos variable que guardará la posición de los datos gráficos
                //Inicialmente apuntará a la zona detrás de la tabla de anchura+offset
                UInt16 dataChar= (UInt16)(3+3*charCount);
                //Definimos variable con el sumatorio de anchuras
                UInt16 totalWidth = 0;
                //Escribimos la tabla de anchura+offset
                for (byte c = 0; c < charCount; c++)
                {
                    //Anchura del carácter
                    byte width = font.dataChar[c].width;
                    //La escribimos
                    fs.WriteByte(width);
                    //La añadimos al sumatorio de anchuras
                    totalWidth += width;
                    //Escribimos la dirección de datos
                    fs.WriteByte((byte)(dataChar & 255));
                    fs.WriteByte((byte)(dataChar >> 8));
                    //Incrementamos la dirección en tantos bytes como contenga el carácter
                    dataChar += (UInt16)(width * font.pages);
                }
                
                //El tamaño de los datos gráficos es el sumatorio de anchuras por el
                //número de páginas
                totalWidth *= font.pages;
                //Escribimos los datos gráficos de cada carácter
                for (byte c = 0; c < charCount; c++)
                {
                    //Anchura del carácter
                    byte width = font.dataChar[c].width;
                    //Recorremos todas las páginas y columnas
                    for (byte p=0;p<font.pages;p++)
                        for(byte x=0;x<width;x++)
                            fs.WriteByte(font.dataChar[c].data[x+p*width]);
                }
                //Cerramos el archivo
                fs.Close();
            }
            catch (Exception ex)
            {
                //Algo ha salido mal leyendo el archivo
                MessageBox.Show("Error writing font file: " + ex.Message);
                return;
            }
            //El archivo se ha guardado correctamente
            //Ya no hay modificaciones
            modified = false;
            //Desactivamos el botón de guardar
            buttonSave.Enabled = false;
        }
        private void numericUpDownWidth_ValueChanged(object sender, EventArgs e)
        {
            //Ha cambiado la anchura del carácter editado

            //Anotamos el índice del carácter editado
            byte charIndex = (byte)(trackBarChar.Value - font.charMin);
            //Anotamos la anchura antigua (la actual)
            byte oldWidth = font.dataChar[charIndex].width;
            //Anotamos la anchura nueva
            byte newWidth = (byte)numericUpDownWidth.Value;
            //Si las anchuras antigua y nueva son iguales...hemos terminado
            if (oldWidth == newWidth) return;
            //La anchura ha cambiado!!

            //Redimensionamos la anchura del carácter editado
            font.dataChar[charIndex].redimWidth(newWidth, font.pages);
            //Redibujamos el carácter completo
            drawPictureChar();
            //La fuente se ha modificado
            fontModified();
        }
        private void buttonConfig_Click(object sender, EventArgs e)
        {
            //Se ha pulsado el botón config

            //Si el botón de configuración es estándar...
            if(buttonConfig.FlatStyle==FlatStyle.Standard)
            {
                //...lo cambiamos a botón plano
                buttonConfig.FlatStyle = FlatStyle.Flat;
                //...y mostramos el panel de configuración
                panelConfig.Visible = true;
            }
            else //El botón está apretado
            {
                //Lo cambiamos a modo normal
                buttonConfig.FlatStyle = FlatStyle.Standard;
                //Ocultamos el panel de configuración
                panelConfig.Visible = false;
            }
        }
        private void numericUpDownPages_ValueChanged(object sender, EventArgs e)
        {
            //Ha cambiado el valor del número de páginas de la fuente

            //Nuevo número de páginas
            byte newPages = (byte)numericUpDownPages.Value;
            //Si el número de páginas ha cambiado...
            if (font.pages != newPages)
            {
                //Redimensionamos todos los caracteres de la fuente al nuevo número de páginas
                font.redimPages(newPages);
                //Asignamos el nuevo número de páginas a la fuente
                font.pages = newPages;
                //Redibujamos el carácter actual
                drawPictureChar();
                //La fuente se ha modificado
                fontModified();
            }
        }
        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Se ha solicitado cerrar el formulario

            //Si se ha modificado y no se ha salvado...
            if(modified)
            {
                //...si no se acepta la carga de la nueva fuente...
                if (MessageBox.Show("Current font will loose changes. Do you want to continue?", "Load confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK)
                {
                    //...calcelamos el cerrado
                    e.Cancel=true;
                }
            }
        }
        private void drawCharPixel(int x,int y,bool status)
        {
            //Dibuja un punto del carácter actual seleccionado en la fuente
            //dadas las coordenadas del puntero en el cuadro de imagen.
            //También actualiza la imagen mostrada
            //status es el estado en el que debe quedar el pixel

            //Calculamos la anchura del carácter
            byte charWidth = font.dataChar[trackBarChar.Value - font.charMin].width;
            //Calculamos el tamaño de la imagen del carácter
            int charPictureWidth = charWidth * zoom;
            int charPictureHeigth = font.pages * 8 * zoom;
            //Si el punto está fuera de rango...hemos terminado
            if (x >= charPictureWidth) return;
            if (y >= charPictureHeigth) return;
            if (x < 0) return;
            if (y < 0) return;
            //Calculamos las coordenadas del pixel
            byte xChar = (byte)(x / zoom); //Columna
            byte yChar = (byte)(y / zoom); //Fila
            byte page = (byte)(yChar / 8); //Página
            byte dy = (byte)(yChar % 8); //Fila de página
            //Posición del byte gráfico
            int dataIndex = xChar + page * charWidth;
            //Estado actual del pixel
            bool currentStatus = (font.dataChar[trackBarChar.Value - font.charMin].data[dataIndex] & (byte)(1 << dy)) > 0;
            //Si el pixel está apagado y se quiere encender
            //o si está encendido y se quiere apagar...
            if((!currentStatus && status) || (currentStatus && !status))
            {
                //Cambiamos el estado del pixel en la fuente
                font.dataChar[trackBarChar.Value - font.charMin].data[dataIndex] ^= (byte)(1 << dy);
                //Cambiamos el estado del pixel en la imagen
                currentStatus = !currentStatus;
                drawPicturePixel(xChar, yChar, currentStatus);
                //La fuente se ha modificado
                fontModified();
                //Refrescamos la imagen
                pictureBoxMain.Refresh();
            }
        }
        private void pictureBoxMain_MouseMove(object sender, MouseEventArgs e)
        {
            //El ratón de ha movido sobre la imagen

            //Haremos lo mismo que si se pulsado sobre la imagen
            pictureBoxMain_MouseDown(sender, e);
        }
        private void pictureBoxMain_MouseDown(object sender, MouseEventArgs e)
        {
            //Se ha hecho click sobre la imagen

            //Anotamos el estado de los botones del ratón
            MouseButtons mb = e.Button;
            //Si está pulsado el botón izquierdo...
            if (mb == MouseButtons.Left)
            {
                //...activaremos el pixel
                drawCharPixel(e.X, e.Y, true);
            }
            else if (mb == MouseButtons.Right)
            {
                //...desactivaremos el pixel
                drawCharPixel(e.X, e.Y, false);
            }
        }
        private void trackBarCharMax_ValueChanged(object sender, EventArgs e)
        {
            //Ha cambiado el carácter final de la fuente

            //Tomamos nota del nuevo valor
            byte newCharMax = (byte)trackBarCharMax.Value;
            //Tomamos nota del antiguo valor (el actual)
            byte oldCharMax = font.charMax;
            //Siempre actualizamos el cuadro que muestra el índice
            labelCharMaxChar.Text = ((char)(newCharMax)).ToString();
            labelCharMaxNumber.Text = newCharMax.ToString();
            //Siempre charMin<=charMax
            if (newCharMax < trackBarCharMin.Value)
            {
                //Actualizamos el valor de la barra de charMin
                trackBarCharMin.Value = newCharMax;
                trackBarCharMin_ValueChanged(null, null);
            }
            //Siempre charMax < carácter seleccionado
            if (newCharMax < trackBarChar.Value) trackBarChar.Value = newCharMax;
            //Si ha cambiado el valor del último carácter...
            if (newCharMax != oldCharMax)
            {
                //Redimensionamos la fuente cambiando el último carácter
                font.redimCharMax(newCharMax);
                //La fuente se ha modificado
                fontModified();
                //Cambiamos el límite del selector de caracteres
                trackBarChar.Maximum = newCharMax;
                //Asignamos la anchura correcta
                numericUpDownWidth.Value = font.dataChar[trackBarChar.Value - font.charMin].width;
                //Se dibuja el carácter seleccionado
                drawPictureChar();
            }
        }
        private void trackBarCharMin_ValueChanged(object sender, EventArgs e)
        {
            //Ha cambiado el carácter inicial de la fuente

            //Tomamos nota del nuevo valor
            byte newCharMin = (byte)trackBarCharMin.Value;
            //Tomamos nota del antiguo valor (el actual)
            byte oldCharMin = font.charMin;
            //Siempre actualizamos el cuadro que muestra el índice
            labelCharMinChar.Text = ((char)(newCharMin)).ToString();
            labelCharMinNumber.Text = newCharMin.ToString();
            //Siempre charMin<=charMax
            if (newCharMin > trackBarCharMax.Value)
            {
                //Actualizamos el valor de la barra de charMax
                trackBarCharMax.Value = newCharMin;
                trackBarCharMax_ValueChanged(null, null);
            }
            //Siempre charMin > carácter seleccionado
            if (newCharMin > trackBarChar.Value) trackBarChar.Value = newCharMin;
            //Si ha cambiado el valor del primer carácter...
            if (newCharMin != oldCharMin)
            {
                //Redimensionamos la fuente cambiando el primer carácter
                font.redimCharMin(newCharMin);
                //La fuente se ha modificado
                fontModified();
                //Cambiamos el límite del selector de caracteres
                trackBarChar.Minimum = newCharMin;
                //Asignamos la anchura correcta
                numericUpDownWidth.Value = font.dataChar[trackBarChar.Value - font.charMin].width;
                //Se dibuja el carácter seleccionado
                drawPictureChar();
            }
        }
    }
}

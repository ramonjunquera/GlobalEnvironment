﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace FontConvert.Forms
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        private void LogWrite(string text)
        {
            //Añade una nueva línea en el panel informativo y hace scroll para mostrarla

            //Añadimos el texto al log
            textBox_Log.Text += text + Environment.NewLine;
            //Seleccionamos 0 caracteres al final del texto = posicionamos el cursor al final
            textBox_Log.Select(textBox_Log.Text.Length, 0);
            //Obligamos al scroll a que muestre la línea que contiene el cursor
            textBox_Log.ScrollToCaret();
            //Actualizamos el objeto gráfico para que se vea la nueva actualización
            textBox_Log.Refresh();
            //Ejecutamos tareas de fondo para que la aplicación no se quede bloqueada
            Application.DoEvents();
        }
        private String GetFirstWord(ref String completeRow,string splitter)
        {
            //Devuelve la primera palabra y la quita de la cadena. El separador de palabras es splitter
            //Ej:
            //  completeRow = "12345;hola;adios"
            //  splitter = ";"
            //Devuelve: 12345
            //  y actualiza completeRow a "hola;adios"

            //Cadena temporal
            String tmp;

            //Localizamos la posición del siguiente separador
            int pos = completeRow.IndexOf(splitter);
            //Si no hay ninguno...
            if (pos < 0)
            {
                //Anotamos lo que contenga actualmente la cadena completa
                tmp = completeRow;
                //Ya no tendrá más texto porque ahora lo devolvemos todo
                completeRow = "";
                //Devolvemos lo que tenía antes la cadena completa
                return tmp;
            }
            //Hemos encontrado un separador
            //Si se encuentra en la primera posición...
            if (pos == 0)
            {
                //Quitamos tantos caracteres como longitud tenga el splitter
                completeRow = completeRow.Substring(splitter.Length);
                //Devolvemos una cadena vacía
                return "";
            }
            //El splitter no se encuentra en la primera posición
            //Copiamos el texto de la primera palabra (hasta la posición del primer splitter)
            tmp = completeRow.Substring(0, pos);
            //Le quitamos la palabra inicial y el splitter
            completeRow = completeRow.Substring(pos + splitter.Length);
            //Devolvemos el contenido de la primera palabra que habíamos anotado
            return tmp;
        }
        private void button_Open_Click(object sender, EventArgs e)
        {
            //Pulsado el botón para abrir un archivo

            //Variables de método
            //Nombre del archivo de entrada
            string fileNameIn;
            //Paso en el que se encuentra actualmente la lectura del archivo
            //  0 - Sin comenzar. Buscando cabecera de array de bitmap
            //  1 - Leyendo array de bitmap
            //  2 - Leido array bitmap. Buscando cabecera de propiedades de caracteres
            //  3 - Leyendo array de propiedades de caracteres
            //  4 - Leido array de propiedades de caracteres. Buscando cabecera de estructura de fuente
            //  5 - Leyendo estructura de fuente
            //  6 - Leida estructura de fuente. Buscando din de archivo
            byte currentStep = 0;
            //Cadena que contendrá el texto de la línea leida
            string rowText;
            //Cadena con la palabra procesada
            string word;
            //Lista de bytes bitmap de archivo de entrada
            List<byte> bitmapIn = new List<byte>();
            //Posición de los caracteres { y }
            int key1, key2;
            //Lista de estructuras de parámetros de caracteres de archivo de entrada
            List<int[]> charParamsIn = new List<int[]>();
            //Nombres de las estructuras
            string nameStructBitmap = "";
            string nameStructGFXglyph = "";
            string nameStructGFXfont="";
            //Valores de fuente de entrada
            byte firstCharFontIn = 0;
            byte lastCharFontIn = 0;
            byte yAdvanceFont = 0;
            //Lista de array booleanos con los pixels de los caracteres
            List<bool[,]> bitmapTmp = new List<bool[,]>();
            //Lista de bytes bitmap de archivo de salida
            List<byte> bitmapOut = new List<byte>();
            //Lista de estructuras de parámetros de caracteres de archivo de salida
            //Serán arrays de 2 valores: índice de inicio,anchura en pixels
            List<int[]> charParamsOut = new List<int[]>();

            //Si no se acepta la selección de archivo...hemos terminado
            if (openFileDialog1.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
            //Anotamos el nombre del archivo
            fileNameIn = openFileDialog1.FileName;
            LogWrite("Seleccionado archivo " + fileNameIn);

            //Abrimos el archivo usando una codificación estándard y con detección de codificación
            //para que no se pierdan los caracteres especiales: ºª
            System.IO.StreamReader inputFile = new System.IO.StreamReader(fileNameIn, System.Text.Encoding.Default, true);

            //Mientras no lleguemos al final del archivo...
            while (!inputFile.EndOfStream)
            {
                //Leemos una nueva línea del archivo de entrada
                rowText = inputFile.ReadLine();
                //Quitamos cualquier comentario
                rowText= GetFirstWord(ref rowText, "//");
                //Eliminamos los espacios iniciales y finales
                rowText = rowText.Trim();
                //Si la línea contiene algo...
                if(rowText.Length>0)
                {
                    //Si la línea no comienza por // (no es un comentario)
                    if(!rowText.StartsWith("//"))
                    {
                        //Dependiendo del paso en el que se encuentre la lectura...
                        switch (currentStep)
                        {
                            case 0: //Sin comenzar. Buscando cabecera de array de bitmap
                                //Obtenemos la primera palabra
                                word = GetFirstWord(ref rowText, " ");
                                //Si no es la definición de una constante...
                                if(word.ToUpper()!="CONST")
                                {
                                    LogWrite("Error. Falta 'const' en la declaración de estructura bitmap");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = rowText.Trim();
                                word = GetFirstWord(ref rowText, " ");
                                if (word.ToUpper() != "UINT8_T")
                                {
                                    LogWrite("Error. Falta 'uint8_t' en la declaración de estructura bitmap");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = rowText.Trim();
                                nameStructBitmap = GetFirstWord(ref rowText, "[]");
                                if(nameStructBitmap.Length==0)
                                {
                                    LogWrite("Error. Falta nombre en la declaración de la estructura bitmap");
                                    inputFile.Close();
                                    return;
                                }
                                //Si el último caracter no es {...
                                if(rowText.Substring(rowText.Length-1,1)!="{")
                                {
                                    LogWrite("Error. Falta '{' como último carácter de la declaración de la estructura bitmap");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = "";
                                LogWrite("Detectada correcta declaración de estructura bitmap con nombre: " + nameStructBitmap);
                                //Detección correcta. Siguiente paso
                                currentStep = 1;
                                break;
                            case 1: //Leyendo array de bitmap
                                while(rowText.Length>0)
                                {
                                    word = GetFirstWord(ref rowText, ",");
                                    if(word.Length>4)
                                    {
                                        //Es posible que este sea el último valor e incluya ' };'
                                        //Si la palabra incluye el caracter }...
                                        if(word.IndexOf('}')>0)
                                        {
                                            //...reducimos la palabra a sus 4 primeros caracteres
                                            word = word.Substring(0, 4);
                                            //Cambiamos al siguiente paso: buscando cabecera de propiedades de caracteres
                                            currentStep = 2;
                                        }
                                        else //No incluye el carácter }
                                        {
                                            LogWrite("Error. Longitud errónea en valor de bitmap: " + word);
                                            inputFile.Close();
                                            return;
                                        }
                                    }
                                    if (word.Substring(0, 2) != "0x")
                                    {
                                        LogWrite("Error. Valor de bitmap no comienza por '0x': " + word);
                                        inputFile.Close();
                                        return;
                                    }
                                    //Tomamos sólo los dos últimos caracteres, los convertimos a byte y lo guardamos en bitmap
                                    bitmapIn.Add(Convert.ToByte(word.Substring(2,2),16));
                                    //Recortamos el texto de la línea que queda
                                    rowText = rowText.Trim();
                                }
                                break;
                            case 2: //Leido array bitmap. Buscando cabecera de propiedades de caracteres
                                //Obtenemos la primera palabra
                                word = GetFirstWord(ref rowText, " ");
                                //Si no es la definición de una constante...
                                if (word.ToUpper() != "CONST")
                                {
                                    LogWrite("Error. Falta 'const' en la declaración de estructura de propiedades de caracteres");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = rowText.Trim();
                                word = GetFirstWord(ref rowText, " ");
                                if (word.ToUpper() != "GFXGLYPH")
                                {
                                    LogWrite("Error. Falta 'GFXglyph' en la declaración de propiedades de caracteres");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = rowText.Trim();
                                nameStructGFXglyph = GetFirstWord(ref rowText, "[]");
                                if (nameStructGFXglyph.Length == 0)
                                {
                                    LogWrite("Error. Falta nombre en la declaración de la estructura GFXglyph");
                                    inputFile.Close();
                                    return;
                                }
                                //Si el último caracter no es {...
                                if (rowText.Substring(rowText.Length - 1, 1) != "{")
                                {
                                    LogWrite("Error. Falta '{' como último carácter de la declaración de la estructura GFXglyph");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = "";
                                LogWrite("Detectada correcta declaración de estructura GFXglyph con nombre: " + nameStructGFXglyph);
                                //Detección correcta. Siguiente paso
                                currentStep = 3;
                                break;
                            case 3: //Leyendo array de propiedades de caracteres
                                //Anotamos la posición del primer {
                                key1 = rowText.IndexOf('{');
                                //Si no existe...
                                if(key1<0)
                                {
                                    LogWrite("Error. Falta '{' en línea de datos de estructura GFXglyph: " + rowText);
                                    inputFile.Close();
                                    return;
                                }
                                //Anotamos la posición del primer }
                                key2 = rowText.IndexOf('}');
                                //Si no existe...
                                if (key2 < 0)
                                {
                                    LogWrite("Error. Falta '}' en línea de datos de estructura GFXglyph: " + rowText);
                                    inputFile.Close();
                                    return;
                                }
                                //Si la posición de { es superior a la de }...
                                if(key1>key2)
                                {
                                    LogWrite("Error. Las llaves {} tienen posiciones intercambiadas: " + rowText);
                                    inputFile.Close();
                                    return;
                                }
                                //Anotamos el texto que hay detrás de }
                                word = rowText.Substring(key2 + 1);
                                //Si el texto sufijo contiene otro }...
                                if(word.IndexOf('}')>0)
                                {
                                    //...es que en esta línea también finaliza la definición de datos
                                    //Saltamos al siguiente paso: buscar cabecera de estructura de fuente
                                    currentStep = 4;
                                }
                                //Anotamos en rowText el contenido entre {}
                                rowText = rowText.Substring(key1 + 1, key2 - key1 - 1);
                                rowText = rowText.Trim();
                                //Procesamos el texto que contiene los parámetros del carácter separados por comas
                                //Tenemos 6 parámetros de tipo entero
                                //Creamos el array que los contendrá
                                int[] charParam = new int[6];

                                //Recorremos los 6 parámetros
                                for(int p=0;p<6;p++)
                                {
                                    //Anotamos cada uno de ellos
                                    charParam[p] = Convert.ToInt16(GetFirstWord(ref rowText, ","));
                                    rowText = rowText.Trim();
                                }

                                //Descripción de los parámetros de la estructura GFXglyph
                                //uint16_t bitmapOffset; //Pointer into GFXfont->bitmap
                                //uint8_t width;         // Bitmap dimensions in pixels
                                //uint8_t height;        // Bitmap dimensions in pixels
                                //uint8_t xAdvance;      // Distance to advance cursor (x axis)
                                //int8_t xOffset;        // Dist from cursor pos to UL corner
                                //int8_t yOffset;        // Dist from cursor pos to UL corner

                                //Tenemos los 6 parámetros en charParam
                                //Los añadimos a la lista
                                charParamsIn.Add(charParam);
                                break;
                            case 4: //Leido array de propiedades de caracteres. Buscando cabecera de estructura de fuente
                                //Obtenemos la primera palabra
                                word = GetFirstWord(ref rowText, " ");
                                //Si no es la definición de una constante...
                                if (word.ToUpper() != "CONST")
                                {
                                    LogWrite("Error. Falta 'const' en la declaración de estructura de fuente");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = rowText.Trim();
                                word = GetFirstWord(ref rowText, " ");
                                if (word.ToUpper() != "GFXFONT")
                                {
                                    LogWrite("Error. Falta 'GFXfont' en la declaración de estrutura de fuente");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = rowText.Trim();
                                nameStructGFXfont = GetFirstWord(ref rowText, " ");
                                if (nameStructGFXfont.Length == 0)
                                {
                                    LogWrite("Error. Falta nombre en la declaración de la estructura GFXfont");
                                    inputFile.Close();
                                    return;
                                }
                                //Si el último caracter no es {...
                                if (rowText.Substring(rowText.Length - 1, 1) != "{")
                                {
                                    LogWrite("Error. Falta '{' como último carácter de la declaración de la estructura GFXfont");
                                    inputFile.Close();
                                    return;
                                }
                                rowText = "";
                                LogWrite("Detectada correcta declaración de estructura GFXfont con nombre: " + nameStructGFXfont);
                                //Detección correcta. Siguiente paso
                                currentStep = 5;
                                break;
                            case 5: //Leyendo estructura de fuente. bitmap
                                //Componemos el texto esperado
                                word = "(uint8_t  *)" + nameStructBitmap + ",";
                                if (rowText != word)
                                {
                                    LogWrite("Error. Texto inesperado en definición de bitmap de estructura de fuente.");
                                    LogWrite("Se esperaba: " + word);
                                    LogWrite("Se ha encontrado: " + rowText);
                                    inputFile.Close();
                                    return;
                                }
                                //Definición correcta
                                //Saltamos de paso
                                currentStep = 6;
                                break;
                            case 6: //Leyendo estructura de fuente. GFXglyph
                                //Componemos el texto esperado
                                word = "(GFXglyph *)" + nameStructGFXglyph + ",";
                                if (rowText != word)
                                {
                                    LogWrite("Error. Texto inesperado en definición de GFXglyph de fuente.");
                                    LogWrite("Se esperaba: " + word);
                                    LogWrite("Se ha encontrado: " + rowText);
                                    inputFile.Close();
                                    return;
                                }
                                //Definición correcta
                                //Saltamos de paso
                                currentStep = 7;
                                break;
                            case 7: //Leyendo estructura de fuente. values
                                //Descripción de los parámetros de la estructura GFXfont
                                //uint8_t* bitmap;      // Glyph bitmaps, concatenated
                                //GFXglyph* glyph;      // Glyph array
                                //uint8_t first;        // ASCII extents
                                //uint8_t last;         // ASCII extents
                                //uint8_t yAdvance;     // Newline distance (y axis)

                                //Leemos firstChar
                                word = GetFirstWord(ref rowText, ",");
                                if (word.Length != 4)
                                {
                                    LogWrite("Error. Longitud errónea en valor first de fuente: " + word);
                                    inputFile.Close();
                                    return;
                                }
                                if (word.Substring(0, 2) != "0x")
                                {
                                    LogWrite("Error. Valor de first de fuente no comienza por '0x': " + word);
                                    inputFile.Close();
                                    return;
                                }
                                //Tomamos sólo los dos últimos caracteres, los convertimos a byte y lo guardamos
                                firstCharFontIn=Convert.ToByte(word.Substring(2, 2), 16);
                                //Recortamos el texto de la línea que queda
                                rowText = rowText.Trim();

                                //Leemos lastChar
                                word = GetFirstWord(ref rowText, ",");
                                if (word.Length != 4)
                                {
                                    LogWrite("Error. Longitud errónea en valor last de fuente: " + word);
                                    inputFile.Close();
                                    return;
                                }
                                if (word.Substring(0, 2) != "0x")
                                {
                                    LogWrite("Error. Valor de last de fuente no comienza por '0x': " + word);
                                    inputFile.Close();
                                    return;
                                }
                                //Tomamos sólo los dos últimos caracteres, los convertimos a byte y lo guardamos
                                lastCharFontIn = Convert.ToByte(word.Substring(2, 2), 16);
                                //Recortamos el texto de la línea que queda
                                rowText = rowText.Trim();

                                //Leemos yAdvanceFont
                                word = GetFirstWord(ref rowText, "}").Trim();
                                yAdvanceFont = Convert.ToByte(word);

                                LogWrite("Lectura finalizada correctamente");

                                //Saltamos de paso
                                currentStep = 8;
                                break;
                            case 8: //Leida estructura de fuente. Buscando fin de archivo
                                break;
                        }
                    }
                }
            }
            //Lectura finalizada correctamente. Cerramos el archivo de entrada
            inputFile.Close();

            //Procesamos datos recuperados

            //Calculamos el valor máximo de yOffset (en valor absoluto)
            LogWrite("Calculando max(yOffset)");
            int maxyOffset = 0;
            //Recorremos todos los caracteres definidos
            for (byte currentChar = firstCharFontIn; currentChar <= lastCharFontIn; currentChar++)
            {
                //Anotamos el array de los parámetros del carácter procesado en charParam
                int[] charParam = charParamsIn[currentChar - firstCharFontIn];

                //Formato de los parámetros de un carácter
                // 0 - bitmapOffset;  //Pointer into GFXfont->bitmap
                // 1 - width;         // Bitmap dimensions in pixels
                // 2 - height;        // Bitmap dimensions in pixels
                // 3 - xAdvance;      // Distance to advance cursor (x axis)
                // 4 - xOffset;       // Dist from cursor pos to UL corner
                // 5 - yOffset;       // Dist from cursor pos to UL corner

                //Si el valor absoluto de yOffset es mayor que maxyOffset...será el nuevo valor máximo
                if (-charParam[5] > maxyOffset) maxyOffset = -charParam[5];
            }

            //Calculamos el valor máximo del tamaño de la fuente
            LogWrite("Calculando maxSize");
            int maxSize = 0;
            //Recorremos todos los caracteres definidos
            for (byte currentChar = firstCharFontIn; currentChar <= lastCharFontIn; currentChar++)
            {
                //Anotamos el array de los parámetros del carácter procesado en charParam
                int[] charParam = charParamsIn[currentChar - firstCharFontIn];

                //Formato de los parámetros de un carácter
                // 0 - bitmapOffset;  //Pointer into GFXfont->bitmap
                // 1 - width;         // Bitmap dimensions in pixels
                // 2 - height;        // Bitmap dimensions in pixels
                // 3 - xAdvance;      // Distance to advance cursor (x axis)
                // 4 - xOffset;       // Dist from cursor pos to UL corner
                // 5 - yOffset;       // Dist from cursor pos to UL corner

                //inicialmente el tamaño del carácter lo da la máxima altura sobre la línea base
                int size = maxyOffset;
                //Si -yOffset <= height ... le sumamos yOffset + height;
                //Si la letra tiene parte bajo la línea base...le sumamos al tamaño la parte que queda bajo la línea base
                if (-charParam[5]<=charParam[2]) size += charParam[5] + charParam[2];

                //Si el tamaño del carácter es mayor que el máximo tamaño...este será el nuevo máximo
                if (size > maxSize) maxSize = size;
            }
            //Tenemos en maxSize la altura máxima de la fuente

            //Calculamos el número de bytes de altura que debe tener
            //Porque siempre utilizamos múltiplos de 8
            LogWrite("Calculando heightBytes");
            int heightBytes = maxSize / 8;
            //Si todavía falta algo más...usaremos un byte más de altura
            if ((maxSize % 8) > 0) heightBytes++;

            //Recorremos todos los caracteres definidos
            for (byte currentChar=firstCharFontIn;currentChar<=lastCharFontIn;currentChar++)
            {
                //Anotamos el array de los parámetros del carácter procesado en charParam
                int[] charParam = charParamsIn[currentChar - firstCharFontIn];

                //Formato de los parámetros de un carácter
                // 0 - bitmapOffset;  //Pointer into GFXfont->bitmap
                // 1 - width;         // Bitmap dimensions in pixels
                // 2 - height;        // Bitmap dimensions in pixels
                // 3 - xAdvance;      // Distance to advance cursor (x axis)
                // 4 - xOffset;       // Dist from cursor pos to UL corner
                // 5 - yOffset;       // Dist from cursor pos to UL corner

                //Obtenemos las dimensiones de la letra
                int width = charParam[1];
                int height = charParam[2];
                //Obtenemos el offset en bitmapIn
                int bitmapOffset = charParam[0]-1;

                //Crearemos un array bidimensional de booleanos que mantendrá la imagen
                //La anchura será la del carácter y la altura será la de la fuente
                //Si el carácter no tiene anchura, le pondremos al menos una columna
                bool[,] bitmapBool = new bool[(width>0?width:1), heightBytes * 8];

                //Si el carácter tiene anchura...
                if (width>0)
                {
                    //Bit procesado. Se barre de izquierda a derecha. De más peso a menos. Decreciente
                    int bitProcessed = 0;
                    //byte procesado
                    byte byteProcessed = 0;

                    //Recorremos todas las filas que definen el carácter
                    for (int y = 0; y < height; y++)
                    {
                        //Recorremos todas las filas
                        for (int x = 0; x < width; x++)
                        {
                            //Pasamos al siguiente bit
                            //Si tenemos que cambiar de byte...
                            if (--bitProcessed < 0)
                            {
                                //...volvemos a comenzar desde el bit más pesado
                                bitProcessed = 7;
                                //Leemos un nuevo byte, aumentando previamente el contador
                                byteProcessed = bitmapIn[++bitmapOffset];
                            }
                            //Tenemos el los datos a procesar en byteProcessed & bitProcessed

                            //Anotamos el estado del bit procesado
                            bitmapBool[x, y + maxyOffset + charParam[5]] = ((byteProcessed & (1 << bitProcessed)) > 0);
                        }
                    }
                }
                else //No tiene 
                {
                    //Cambiamos la anchura del carácter a 1
                    //Ya se ha creado un array de bool con anchura 1
                    //Por defecto los valores se completan con false
                    charParam[1] = 1;
                }

                //Tenemos en bitmapBool los pixels del carácter
                //Guardamos el array en la lista bitmapTmp
                bitmapTmp.Add(bitmapBool);
            }
            //Tenemos todos los gráficos codificados en bitmapTmp

            //Debemos rellenar el array con los parámetros de los caracteres para su exportación
            //Debemos llevar la cuenta de la posición en la que nos encontramos para escribir en
            //el array donde se guardan los bitmaps de los caracteres de salida
            LogWrite("Calculando array de parámetros de caracteres de salida");
            int currentBitmapIndex=0;
            //Recorremos todos los caracteres definidos
            for (byte currentChar = firstCharFontIn; currentChar <= lastCharFontIn; currentChar++)
            {
                //Creamos el array que guardaremos en la lista de parámetros de salida
                int[] charParamOut = new int[2];
                
                //Anotamos el array de los parámetros del carácter procesado en charParamIn
                int[] charParamIn = charParamsIn[currentChar - firstCharFontIn];

                //Formato de los parámetros de un carácter
                // 0 - bitmapOffset;  //Pointer into GFXfont->bitmap
                // 1 - width;         // Bitmap dimensions in pixels
                // 2 - height;        // Bitmap dimensions in pixels
                // 3 - xAdvance;      // Distance to advance cursor (x axis)
                // 4 - xOffset;       // Dist from cursor pos to UL corner
                // 5 - yOffset;       // Dist from cursor pos to UL corner

                //Extraemos la anchura
                int width = charParamIn[1];
                //Si la anchura original es nula...la sustituimos por 1
                if (width == 0) width++;

                //Llenamos los valores del array de parámetros de los caracteres de salida
                //El primer elemento contiene la posición del array de bitmaps
                //Anotamos la posición actual en la que nos encontramos
                charParamOut[0] = currentBitmapIndex;
                //El segundo elemento contiene la anchura del carácter
                charParamOut[1] = width;

                //Guardamos el array con los parámetros del carácter procesado en la lista charParamsOut
                charParamsOut.Add(charParamOut);

                //Debemos aumentar el indicador de posición de lectura de bytes de bitmaps de salida
                //Aumentará en tantos bytes como consuma el carácter actual
                //Será el producto de su anchura por el número de páginas que ocupe la fuente
                currentBitmapIndex += heightBytes * width;
            }

            //Extraemos el nombre de la fuente
            string fontName = System.IO.Path.GetFileNameWithoutExtension(fileNameIn);

            //Creamos el nombre del archivo de salida
            LogWrite("Exportando datos a archivo de salida");
            string fileNameOut = System.IO.Path.GetDirectoryName(fileNameIn) + "\\RoJoABC" + System.IO.Path.GetFileName(fileNameIn);
            //Abrimos el archivo de salida
            System.IO.StreamWriter outFile = new System.IO.StreamWriter(fileNameOut, false, System.Text.Encoding.Default);

            //Añadimos la línea al archivo de salida
            outFile.WriteLine("//Font based on " + fontName);
            outFile.WriteLine();

            //Sección de exportación del array de bitmaps

            outFile.WriteLine("const byte RoJoABC" + fontName + "Bitmap[] PROGMEM =");
            outFile.WriteLine("{");

            //Prefijo de cada línea de código. Será una coma, excepto en la primer fila que será un espacio
            string linePrefix = " "; 

            //Recorremos todos los caracteres definidos
            for (byte currentChar = firstCharFontIn; currentChar <= lastCharFontIn; currentChar++)
            {
                //Anotamos el array de los parámetros del carácter procesado en charParam
                int[] charParam = charParamsIn[currentChar - firstCharFontIn];

                //Formato de los parámetros de un carácter
                // 0 - bitmapOffset;  //Pointer into GFXfont->bitmap
                // 1 - width;         // Bitmap dimensions in pixels
                // 2 - height;        // Bitmap dimensions in pixels
                // 3 - xAdvance;      // Distance to advance cursor (x axis)
                // 4 - xOffset;       // Dist from cursor pos to UL corner
                // 5 - yOffset;       // Dist from cursor pos to UL corner

                //Mostramos la información
                outFile.WriteLine("//Char index=" + (currentChar - firstCharFontIn).ToString("000") + " code=0x" + currentChar.ToString("X2") + "=" + currentChar.ToString("000") + "='" + (char)currentChar + "'");
                outFile.WriteLine("//  bitmapOffset=" + charParam[0].ToString("0000") + " width=" + charParam[1].ToString("00") + " height=" + charParam[2].ToString("00"));
                outFile.WriteLine("//  xAdvance=" + charParam[3].ToString("00") + " xOffset=" + charParam[4].ToString("00") + " yOffset=" + charParam[5].ToString("00"));

                //Obtenemos las dimensiones de la letra
                int width = charParam[1];
                int height = charParam[2];
                //Obtenemos el offset en bitmapIn
                int bitmapOffset = charParam[0] - 1;

                //Dibujamos el carácter
                //Recorremos todas las filas que definen el carácter
                for (int y = 0; y < heightBytes * 8; y++)
                {
                    rowText = "//row " + y.ToString("00") + " ";
                    //Recorremos todas las columnas
                    for (int x = 0; x < width; x++)
                    {
                        rowText += (bitmapTmp[currentChar - firstCharFontIn][x, y]) ? '*' : '.';
                    }
                    outFile.WriteLine(rowText);
                }
                outFile.WriteLine("");

                //Recorremos todas las páginas
                for (int p = 0; p < heightBytes; p++)
                {
                    outFile.WriteLine("//page " + p.ToString());
                    //Recorremos todas las columnas
                    for (int c = 0; c < width;c++)
                    {
                        rowText = linePrefix;
                        linePrefix = ",";

                        rowText += "B";
                        //Recorremos todas las filas de la página
                        for(int r=0;r<8;r++)
                        {
                            rowText += (bitmapTmp[currentChar - firstCharFontIn][c, p * 8 + 7-r]) ? "1" : "0";
                        }
                        rowText += " //column " + c.ToString();

                        outFile.WriteLine(rowText);
                    }
                    outFile.WriteLine("");
                }
                outFile.WriteLine("");
            }
            outFile.WriteLine("};\n");


            //Sección de exportación de las propiedades de caracteres

            //Escribimos la cabecera
            outFile.WriteLine("const abcProperties RoJoABC" + fontName + "Props[] PROGMEM =");
            outFile.WriteLine("{");
            //Comenzamos con un prefijo de línea vacío
            linePrefix = " ";
            //Recorremos todos los caracteres definidos
            for (byte currentChar = firstCharFontIn; currentChar <= lastCharFontIn; currentChar++)
            {
                //Anotamos el array de los parámetros del carácter procesado en charParam
                int[] charParam = charParamsOut[currentChar - firstCharFontIn];
                //Escribimos los datos del parámetro con comentarios
                outFile.WriteLine(linePrefix + "{" + charParam[0].ToString() + "," + charParam[1] + "} //Char index=" + (currentChar - firstCharFontIn).ToString("000") + " code=0x" + currentChar.ToString("X2") + "=" + currentChar.ToString("000") + "='" + (char)currentChar + "'");
                //A partir de ahora el prefijo de línea será una coma
                linePrefix = ",";
            }
            //Escribimos el pie
            outFile.WriteLine("};\n");

            //Sección de exportación de las propiedades de la fuente

            //Escribimos la cabecera
            outFile.WriteLine("const abcFont RoJoABC" + fontName + " PROGMEM =");
            outFile.WriteLine("{");

            outFile.WriteLine("(byte *)RoJoABC" + fontName + "Bitmap //Bitmap");
            outFile.WriteLine(",(abcProperties *)RoJoABC" + fontName + "Props //Propiedades");
            outFile.WriteLine(",'" + (char)firstCharFontIn + "' //Primer carácter");
            outFile.WriteLine(",'" + (char)lastCharFontIn + "' //Último carácter");
            outFile.WriteLine("," + heightBytes.ToString() + " //Altura en páginas = 8 pixels");

            //Escribimos el pie
            outFile.WriteLine("};");

            //Cerramos el archivo de salida
            outFile.Close();

            //Hemos terminado con la exportación del archivo .h
            //Comenzaremos con la exportación del archivo .fon
            LogWrite("Exportando .fon");

            //El nombre del archivo de salida actual será el mismo que antes, excepto que 
            //cambiará la externsión. De .h  .fon
            fileNameOut = fileNameOut.Substring(0, fileNameOut.Length - 1) + "fon";
            //Abrimos el archivo para escritura
            FileStream fs = File.Open(fileNameOut, FileMode.Create);
            //Escribimos el código del primer carácter de la fuente
            fs.WriteByte(firstCharFontIn);
            //Escribimos el código del último carácter de la fuente
            fs.WriteByte(lastCharFontIn);
            //Escribimos el número de páginas de altura
            fs.WriteByte((byte)heightBytes);
            //Calculamos el número de caracteres de la fuente
            byte charCount = (byte)(lastCharFontIn - firstCharFontIn + 1);
            //Definimos variable que guardará la posición de los datos gráficos
            //Inicialmente apuntará a la zona detrás de la tabla de anchura+offset
            UInt16 dataChar = (UInt16)(3 + 3 * charCount);
            //Definimos variable con el sumatorio de anchuras
            UInt16 totalWidth = 0;
            //Escribimos la tabla de anchuras y direcciones/offset
            for (byte c = 0; c < charCount; c++)
            {
                //Escribimos anchura del carácter
                byte width = (byte)charParamsOut[c][1];
                fs.WriteByte(width);
                //La añadimos al sumatorio de anchuras
                totalWidth += width;
                //Escribimos la dirección de datos
                fs.WriteByte((byte)(dataChar & 255));
                fs.WriteByte((byte)(dataChar >> 8));
                //Incrementamos la dirección en tantos bytes como contenga el carácter
                dataChar += (UInt16)(width * heightBytes);
            }
            
            //El tamaño de los datos gráficos es el sumatorio de anchuras por el
            //número de páginas
            totalWidth *= (UInt16)heightBytes;
            //Escribimos los datos gráficos de cada carácter
            for (byte c = 0; c < charCount; c++)
            {
                //Anchura del carácter
                byte width = (byte)charParamsOut[c][1];
                //Recorremos todas las páginas y columnas
                for (byte p = 0; p < heightBytes; p++)
                    //Recorremos todas las columnas
                    for (byte x = 0; x < width; x++)
                    {
                        //Variable donde guardaremos el byte final
                        byte z = 0;
                        //Recorremos todas las filas
                        for (byte y = 0; y < 8; y++)
                            if(bitmapTmp[c][x, p * 8 + y])
                                z += (byte)(1 << y);
                        //Guardamos el byte calculado    
                        fs.WriteByte(z);
                    }
            }
            //Cerramos el archivo
            fs.Close();

            LogWrite("Exportanción finalizada");
        }
    }
}

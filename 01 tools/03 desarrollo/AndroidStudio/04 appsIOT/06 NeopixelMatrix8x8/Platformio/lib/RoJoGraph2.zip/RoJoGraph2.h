/*
  Nombre de la librería: RoJoGraph2.h
  Versión: 20210502
  Autor: Ramón Junquera
  Descripción:
    Funciones gráficas avanzadas
*/

#ifndef RoJoGraph2_h
#define RoJoGraph2_h

#include <Arduino.h>
#ifdef ROJO_PIN_CS_SD //Si debemos utilizar SD...
  #ifdef __arm__ //Si es una Raspberry...
    #error Raspberry has not SD
  #endif
  //No es una Raspberry
  //Puede tener SD. Lo cargamos
  #include <SD.h> //Librería de gestión de SD
#else //Si debemos utilizar SPIFFS...
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino...
    #error Arduino family has not SPIFFS
  #endif
  //No es una placa Arduino. Puede tener SPIFFS
  //Cargamos la librería en función del dispositivo
  #ifdef ESP32 //Si es un ESP32...
    #include <SPIFFS.h> //Librería de gestión SPIFFS para ESP32
  #else //Si cualquier otra cosa (ESP8266 o RPi)...
    #include <FS.h> //Librería de gestión SPIFFS para ESP8266
  #endif
#endif

//Estructura para guardar rangos de pantalla
struct displayRange {
  bool visible=false;
  uint16_t x1,x2,y1,y2;
};

class RoJoGraph2 {
  private:
    void _ellipse(int16_t x,int16_t y,uint16_t rx,uint16_t ry,uint32_t color,bool fill); //Dibuja una elipse
  protected:
    byte _bytesPerPixel; //Bytes por pixel 0=monocromo, 1=gris, 2=color, 3=color real
  public:
    void begin(); //Inicialización
    virtual uint16_t xMax(); //Anchura de display (dummy)
    virtual uint16_t yMax(); //Altura de display (dummy)
    static displayRange visibleRange(int16_t x,int16_t y,uint16_t width,uint16_t height,uint16_t displayWidth,uint16_t displayHeight); //Calcula el rango visible
    static displayRange visibleRange(int16_t *x,int16_t *y,int16_t *width,int16_t *height,uint16_t displayWidth,uint16_t displayHeight); //Calcula el rango visible
    displayRange visibleRange(int16_t x,int16_t y,uint16_t width=1,uint16_t height=1); //Calcula el rango visible
    displayRange visibleRange(int16_t *x,int16_t *y,int16_t *width,int16_t *height); //Calcula el rango visible
    virtual bool drawPixel(int16_t x,int16_t y,uint32_t color); //Dibuja un pixel (dummy)
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint32_t color); //Dibuja una línea
    virtual bool block(int16_t x,int16_t y,int16_t width=1,int16_t height=1,uint32_t color=0); //Dibuja un rectángulo relleno
    virtual void clear(uint32_t color=0); //Borra el área de dibujo
    byte infoSprite(String filename,uint16_t *width,uint16_t *height,byte *bytesPerPixel); //Información de archivo .spr
    virtual byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo .spr
    byte infoBMP(String filename,uint16_t *width,uint16_t *height,byte *bytesPerPixel); //Información de archivo BMP
    virtual byte drawBMP(String filename,int16_t x=0,int16_t y=0); //Dibuja un bmp directamente de un archivo
    virtual bool rect(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t borderColor); //Dibuja un rectángulo sin relleno
    void triangle(int16_t x1,int16_t y1,int16_t x2,int16_t y2,int16_t x3,int16_t y3,uint32_t borderColor); //Dibuja un triángulo sin relleno
    void triangleFill(int16_t x1,int16_t y1,int16_t x2,int16_t y2,int16_t x3,int16_t y3,uint32_t fillColor); //Dibuja un triángulo relleno
    void circle(int16_t x,int16_t y,int16_t r,uint32_t color); //Dibuja una circunferencia
    void disk(int16_t x,int16_t y,int16_t r,uint32_t color); //Dibuja un círculo
    void ellipse(int16_t x,int16_t y,uint16_t rx,uint16_t ry,uint32_t color); //Dibuja una elipse
    void ellipseFill(int16_t x,int16_t y,uint16_t rx,uint16_t ry,uint32_t color); //Dibuja una elipse rellena
    uint32_t getColor(byte R,byte G,byte B); //Compone el color
    void getColor(uint32_t color,byte *R,byte *G,byte *B,byte bytesPerPixel=255); //Descompone el color
    virtual bool printOver(String filenameFon,String text,uint32_t textColor,int16_t x=0,int16_t y=0); //Imprime texto
    byte bytesPerPixel(); //Devuelve el número de bytes por pixel
    bool infoPrint(String filenameFon,String text,uint16_t *width,uint16_t *heigth); //Información sobre un texto
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoGraph2.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


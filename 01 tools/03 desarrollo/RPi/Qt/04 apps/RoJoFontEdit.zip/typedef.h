#ifndef TYPEDEF_H
#define TYPEDEF_H

//Archivo de cabecera con la definición de tipos comunes en todas las clases

#define byte unsigned char //Para guardar compatibilidad con C#

#endif // TYPEDEF_H

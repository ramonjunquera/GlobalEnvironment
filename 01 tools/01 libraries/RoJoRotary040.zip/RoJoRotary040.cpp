/*
  Library name: RoJoRotary040.h
  Version: 20171004
  Author: Ramón Junquera
  Description: Rotatory encoder driver for Keyes KY-040
*/

#ifndef RoJoRotary040_cpp
#define RoJoRotary040_cpp

#include <Arduino.h>
#include "RoJoRotary040.h"

RoJoRotary040::RoJoRotary040(byte pinA, byte pinB)
{
  //Constructor. It is executed when the object is created
  //Parameters: encoder reading pins

  //Reading pins are saved in private class variables
  _pinA=pinA;
  _pinB=pinB;
  //Set reading pins as input. We don't use internal resistors for pullup because KY-040 has their own
  pinMode(_pinA, INPUT);
  pinMode(_pinB, INPUT);
}

void RoJoRotary040::update()
{
  //Update step counter

  //Read current pins values
  byte currentPinStatus = digitalRead(_pinA) * 2 + digitalRead(_pinB);
  //If status has been changed...
  if(_lastPinStatus != currentPinStatus)
  {
    //Last status now will be current one
    _lastPinStatus=currentPinStatus;
  
    //If current status is an starting status of a step...
    if ((currentPinStatus == 3) || (currentPinStatus == 0))
    {
      //if current status is equal than starting status...
      //...this is the starting status (again). Ending status is not valid. We'll delete it
      if(currentPinStatus == _status1) _status2=0;
      else //Current status is not equal than starting one
      {
        //It seems we have completed a step
        //We compose a single value of starting & ending status values. Comparisons will be easier
        byte pinStatusValue = _status1 * 4 + _status2;
        //if this value if a clockwise step [3,1]=3*4+1=12+1=13 or [0,2]=0*4+2=0+2=2...
        if((pinStatusValue==13) || (pinStatusValue==2))
        {
          //...if we didn't reach to maximum...
          //...steps counter will be increased
          if(stepsCounter<maxStepsCounter) stepsCounter++;
        }
        //if this value if a counterclockwise step [3,2]=3*4+2=12+2=14 or [0,1]=0*4+1=0+1=1...
        else if((pinStatusValue==14) || (pinStatusValue==1))
        {
          //...if we didn't reach to minimum...
          //...steps counter will be decreased
          if(stepsCounter>minStepsCounter) stepsCounter--;
        }
        //New starting status is current one
        _status1=currentPinStatus;
        //Ending status will be deleted
        _status2=0;
      }
    }
    else //Current status is not a starting one
    {
      //If current status is not the middle status...now it'll be
      if(currentPinStatus != _status2) _status2=currentPinStatus;
    }
  }
}

#endif



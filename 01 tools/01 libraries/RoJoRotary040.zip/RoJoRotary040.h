/*
  Library name: RoJoRotary040.h
  Version: 20171004
  Author: Ramón Junquera
  Description: Rotatory encoder driver for Keyes KY-040
*/

#ifndef RoJoRotary040_h
#define RoJoRotary040_h

#include <Arduino.h>

class RoJoRotary040
{
  private:  //Private methods & variables definition
    byte _pinA,_pinB; //Encoder reading pins
    volatile byte _status1=3; //Pin status for starting step
    volatile byte _status2=3; //Pin status for ending step
    byte _lastPinStatus=3;
  public: //Public methods & variables definition
    RoJoRotary040(byte pinA, byte pinB); //Constructor
    volatile int32_t stepsCounter=0;
    int16_t maxStepsCounter=32767; //2^15-1
    int16_t minStepsCounter=-maxStepsCounter;
    void update(); //Update step counter
}; //Mandatory to avoid error

#endif

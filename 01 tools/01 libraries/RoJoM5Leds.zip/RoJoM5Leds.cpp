/*
  Nombre de la librería: RoJoM5Leds.h
  Versión: 20190927
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds de M5Stack.
    M5Stack incluye una tira de 10 leds de NeoPixels que sólo utiliza un
    pin para su comunicación.
    La tira está dividida en dos segmentos de 5. Uno a cada lado.
    El orden de los leds sigue las agujas del reloj.
    El primer led se encuentra arriba a la derecha.
*/

#ifndef RoJoM5Leds_cpp
#define RoJoM5Leds_cpp

#include <RoJoM5Leds.h>

//Pone todos los leds del mismo color
void RoJoM5Leds::clear(byte r,byte g,byte b) {
   for(byte ledIndex=0;ledIndex<10;ledIndex++) {
     ledColor[ledIndex][0]=r;
     ledColor[ledIndex][1]=g;
     ledColor[ledIndex][2]=b;
   }
}

//Constructor / inicialización
RoJoM5Leds::RoJoM5Leds() {
  //Inicializamos el pin
  pinMode(_pinComm,OUTPUT);
  digitalWrite(_pinComm,LOW);
  clear();
  show();
  show();
}

//Devuelve el nÚmero de ciclos de reloj
inline uint32_t RoJoM5Leds::_clockCycles() {
  uint32_t ccount;
  __asm__ __volatile__("rsr %0,ccount":"=a" (ccount));
  return ccount;
}

//Muestra configuración actual
void RoJoM5Leds::show() {
  //La comunicación con el controlador de los leds (NeoPixel) se realiza por un
  //único pin y de manera unidireccional: desde el dispositivo a NeoPixel.
  //Por eso inicializamos el pin en modo salida (OUTPUT).
  //Cuando no se transmite, el pin se encuentra en estado LOW.
  //Para transmitir un bit, activaremos el estado HIGH durante un tiempo (pulso).
  //La duración del pulso dependerá del valor que queramos transmitir.
  //Según las especificaciones del fabricante, los tiempos de pulso son:
  // - 0.4us para valor 0
  // - 0.8us para valor 1
  //Además entre dos pulsos debe transcurrir un tiempo mínimo de 1.25us
  //Si no se transmite nada en 300us se supone que ha finalizado la comunicación
  //Para transmitir un byte enviaremos consecutívamente los bits en orden MSB
  //(big endian). Desde el bit más significativo al que menos.
  //Puesto que algunos de los tiempos utilizados están por debajo del microsegundo,
  //no podemos utilizar la función micros para calcular las esperas.
  //En vez de contar el tiempo en microsegundos, lo contaremos en ciclos de reloj.
  //El M5Stack tiene un ESP32 como microprocesador. Con un reloj de 240MHz.
  //Calculamos los ciclos de reloj correspondientes a cada tiempo de espera:
  //  waitLOW = 240MHz * 1.25us  = 300ciclos
  //  wait0   = 240MHz * 0.40us  =  96ciclos
  //  wait1   = 240MHz * 0.80us  = 192ciclos
  //En este driver no se han tenido en cuenta los tiempos especificados por el
  //fabricante. En base a pruebas, se han reducido para evitar errores y
  //acelerar la velocidad de transmisión
  //Los valores utilizados son:
  //  waitLOW = 130ciclos = 0.54us
  //  wait0   = 10ciclos  = 0.04us
  //  wait1   = 120ciclos = 0.50us

  //Tenemos que transmitir la configuración actual
  //Debemos asegurarnos que han transcurrido al menos 300us desde la última
  //comunicación para que NeoPixel entienda que es una transferencia nueva.
  while(micros()-_lastComm<300);

  //Definición de constantes de ciclos de espera
  const uint32_t waitLOW=130;
  const uint32_t wait0=10;
  const uint32_t wait1=120;
  //Definición de variables
  byte currentChannel; //Byte procesado
  byte mask; //Máscara para procesar cada bit
  uint32_t bitCycle; //Ciclos de espera por valor del bit
  uint32_t currentCycle; //Ciclo actual
  uint32_t lastCycle=0; //Ciclo anterior

  //Recorremos todos los leds y componentes de color
  for(byte ledIndex=0;ledIndex<10;ledIndex++) 
    for(byte colorChannel=0;colorChannel<3;colorChannel++) {
      //Obtenemos el byte a procesar
      //Hay que recordar que aunque el array de canales de color esté ordenado
      //correctamente (RGB), el orden de envío a NeoPixel es GRB.
      //Por eso utilizamos el array de offset
      currentChannel=ledColor[ledIndex][_offsetColor[colorChannel]];
      //Calculamos la máscara del bit de mayor peso
      mask=0b10000000; 
      //Recorremos los 8 bits del byte procesado
      for(byte currentBit=0;currentBit<8;currentBit++) {
        //Calculamos el tiempo de espera para estado HIGH en función del valor del bit
        bitCycle=(mask & currentChannel)?wait1:wait0;
        //Esperamos el tiempo de LOW
        while(((currentCycle=_clockCycles())-lastCycle)<waitLOW);
        //El último ciclo será el actual
        lastCycle=currentCycle;
        //Activamos el pulso
        digitalWrite(_pinComm,HIGH);
        //Esperamos el tiempo de pulso dependiente del valor del bit
        while(((currentCycle=_clockCycles())-lastCycle)<bitCycle);
        //Desactivamos el pulso
        digitalWrite(_pinComm,LOW);
        //El último ciclo será el actual
        lastCycle=currentCycle;
        //Pasamos al siguiente bit
        mask>>=1;
      }
    }
  //Hemos terminado de enviar todos los bytes
  //No esperaremos los ciclos LOW posteriores al último pulso, porque ya se tienen
  //en cuenta tiempo de espera al inicio del proceso

  //Hemos finalizado el envío. Anotamos la hora actual
  _lastComm=micros();
}

//Guarda un color
void RoJoM5Leds::setColor(byte colorIndex,byte r,byte g,byte b) {
  ledColor[colorIndex][0]=r;
  ledColor[colorIndex][1]=g;
  ledColor[colorIndex][2]=b;
}

#endif

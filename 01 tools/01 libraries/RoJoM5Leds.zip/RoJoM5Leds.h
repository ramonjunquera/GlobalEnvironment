/*
  Nombre de la librería: RoJoM5Leds.h
  Versión: 20190927
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds de M5Stack
*/

#ifndef RoJoM5Leds_h
#define RoJoM5Leds_h

#include <Arduino.h>

class RoJoM5Leds {
  private:
    const byte _pinComm=15; //Pin de comunicaciones
    uint64_t _lastComm=0; //Tiempo en microsegundos de última comunicación
    const byte _offsetColor[3]={1,0,2}; //Tabla de offsets de canales de color
    static uint32_t _clockCycles() __attribute__((always_inline)); //Devuelve el nÚmero de ciclos
  public:
    byte ledColor[10][3]; //Array de color de cada led: ledColor[led index][color channel (RGB)]
    void clear(byte r=0,byte g=0,byte b=0); //Pone el mismo color a todos los leds
    RoJoM5Leds(); //Constructor
    void show(); //Muesta configuración actual
    void setColor(byte colorIndex,byte r,byte g,byte b); //Guarda un color
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoM5Leds.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


/*
  Nombre de la librería: RoJoSSD1351.h
  Versión: 20210213
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 1.5" 128x128 SSD1351

  La siguiente librería permite la gestión del display a través de los
  pines del bus SPI controlados por hardware.

  Todas las funciones escriben directamente sobre el display.
  No se utiliza ninguna técnica de buffer (simple o doble) para reducir
  la tasa de transferencia por SPI.
  Los dispositivos con suficiente memoria podrán hacerlo gracias a
  la compatibilidad con RoJoSprite.
  
  Nota:
  La librería no tiene en cuenta los pines CS controlados por hardware.
  Se puede definir cualquier pin para CS porque se gestiona por software.
  En placas ESP estos pines se pueden desactivar.
  En Raspberry no. Esto quiere decir que RPi siempre seguirá gestionando
  el pin CS que tenga activo en ese momento.
  La ventaja de definir el pin CS por software es que podemos tener
  varios dispositivos SPI conectados a distintos pines de control y 
  no tendremos interferencias entre ellos.

  El sistema de archivos del cual se leen los sprites o fuentes
  es seleccionable mediante la constante global del preprocesador ROJO_PIN_CS_SD
  Estas constantes se definen en el archivo platformio.ini.

  Selección del sistema de archivos.
    Si se declara la constante ROJO_PIN_CS_SD y se le asigna un valor, se
    selecciona la SD como sistema de archivos.
    El valor de ROJO_PIN_CS_SD corresponde con el pin CS de la SD.
    Si no se declara esta constante, se utilizará SPIFFS.
    Ej.: build_flags = -D ROJO_PIN_CS_SD=15

  Tabla de compatibilidad de sistemas de archivos:

            SD SPIFFS
    Arduino SI NO
    ESP     SI SI
    RPi     NO SI

  Este display tiene dos profundidades de color distintas: 16 y 18 bits.
  Después de hacer varias pruebas, los resultados son indistinguibles
  a la vista. Hay que tener en cuenta que sólo aumenta un bit de
  profundidad en dos canales (de 16 a 18).
  Por lo tanto, no vale la pena añadir más código para poder gestionar
  el modo de 18 bits.
 */

#ifndef RoJoSSD1351_cpp
#define RoJoSSD1351_cpp

#include <RoJoSSD1351.h>

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoSSD1351::_writeCommand(byte command,...) {
  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos el comando
  //Todos los parámetros deben pasarse en modo datos
  //Lo activamos ahora y nos aseguramos que quedará así al finalizar
  digitalWrite(_pinDC,HIGH);
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0) {
    //...enviamos el parámetro
    SPI.transfer((byte)paramValue);
  }
  //Hemos terminado de trabajar con la lista
  va_end(paramList);
}

//Reset & inicialización
void RoJoSSD1351::reset() {
  digitalWrite(_pinRES,LOW);
  delay(10);
  digitalWrite(_pinRES,HIGH);
  delay(10);

  //Secuencia de inicialización
  _startCOMM(); //Iniciamos conexión SPI
    _writeCommand(0xFD,0x12,-1); //Set Command Lock. MCU protection status: reset
    _writeCommand(0xFD,0xB1,-1); //Set Command Lock. Commands accesibles 
    _writeCommand(0xB3,0xF1,-1); //Oscillator Frequency/Front Clock Divider
    _writeCommand(0xCA,127,-1); //Set MUX Ration. Reset
    _writeCommand(0xA1,0,-1); //Set Display Start Line to 0
    _writeCommand(0xA2,0,-1); //Set Display Offset to 0
    _writeCommand(0xB5,0,-1); //Set GPIO. Input disabled
    _writeCommand(0xB1,0x32,-1); //Pre-charge (Phase 2) period = 3 DLCKs / Set Reset (Phase 1) = 5 DCLKs
    _writeCommand(0xBE,0x05,-1); //Set VCOMH Voltage = 0.82 x VCC = reset
    _writeCommand(0xBB,0x17,-1); //Set Pre-charge voltage = 0,48387 x VCC = reset [pre-charge voltage level=code*0.4/31+0.2]
    _writeCommand(0xA6,-1); //Reset to normal display
    _writeCommand(0xC1,0xC8,0x80,0xC8,-1); //Set Constrast Current for RGB
    _writeCommand(0xC7,0x0F,-1); //Master Contrast Current Control
    _writeCommand(0xB4,0xA0,0xB5,0x55,-1); //Set Segment low Voltage (VSL). External VSL = reset.
    _writeCommand(0xB6,1,-1); //Set Second Pre-charge Period = 1 DCLKs
    //Set Re-map / Color Depth (Display RAM to Panel):
    //  Horizontal address increment = reset
    //  Column address 0 is mapped to SEG0 = reset
    //  Color sequence is swapped C->B->A
    //  Scan from COM[N-1] to COM0. Where N is the Multiplez ratio
    //  Enable COM Split Odd Even = reset
    //  Set Color Depth = 65k color = reset
    _writeCommand(0xA0,0B00110100,-1); 
  _endCOMM(); //Finalizamos conexión SPI
  //Borramos la pantalla
  clear();
  //Salimos del modo de bajo consumo
  sleep(false);
}

//Anchura de display
uint16_t RoJoSSD1351::xMax() {
  return _xMax;
}

//Altura de display
uint16_t RoJoSSD1351::yMax() {
  return _yMax;
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
void RoJoSSD1351::_setCursorRangeY(int16_t y1,int16_t y2) {
  _writeCommand(0x75,y1,y2,-1); //Set Row Address
}
void RoJoSSD1351::_setCursorRangeX(int16_t x1,int16_t x2) {
  _writeCommand(0x15,x1,x2,-1); //Set Column Address
  _writeCommand(0x5C,-1); //Write RAM Command. Modo de datos
}
void RoJoSSD1351::_setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2) {
  _setCursorRangeY(y1,y2);
  _setCursorRangeX(x1,x2);
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoSSD1351::block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color) {
   //Calculamos el área visible
  displayRange r=visibleRange(&x,&y,&width,&height);
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startCOMM();
    uint16_t ry2=r.y2,rx1=r.x1,rx2=r.x2;
    _setCursorRange(rx1,r.y1,rx2,ry2);
    for(uint16_t y=r.y1;y<=ry2;y++)
      for(uint16_t x=rx1;x<=rx2;x++)
        SPI.transfer16(color);
  _endCOMM();
  //Tiene parte visible
  return true;
}

//Dibuja un pixel
//Devuelve true si el pixel es visible
bool RoJoSSD1351::drawPixel(int16_t x,int16_t y,uint32_t color) {
  //Si el pixel está fuera de pantalla...hemos terminado;
  if(x<0 || x>=_xMax || y<0 || y>=_yMax) return false;

  _startCOMM();
    _setCursorRange(x,y,x,y);
    SPI.transfer16(color);
  _endCOMM();
  return true;
}

//Activa/Desactiva el modo hibernación
void RoJoSSD1351::sleep(bool mode) {
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startCOMM(); //Iniciamos conexión SPI
    if(mode) { //Si activamos el modo hibernación...
      _writeCommand(0xAE,-1); //Sleep ON
      _writeCommand(0xAB,0,-1); //Function Selection. Disable internal VDD regulator. Select 8-bit parallel interface
    } else { //Si desactivamos el modo hibernación...
      _writeCommand(0xAB,1,-1); //Function Selection. Enable internal VDD regulator. Select 8-bit parallel interface
      _writeCommand(0xAF,-1); //Sleep OFF
    }
  _endCOMM(); //Finalizamos conexión SPI
}

//Inicialización
void RoJoSSD1351::begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM) {
  //Este display tiene una profundidad de color de 16 bits (color)
  _bytesPerPixel=2;
  //Si no se ha indicado frecuencia...utilizaremos la máxima
  if(!freqCOMM) freqCOMM=4400000; //4.4 MHz
  //Definimos las caraterísticas de la conexión SPI
  _spiSetting=SPISettings(freqCOMM,MSBFIRST,SPI_MODE0);
  //Inicializamos las conexiones SPI
  SPI.begin();
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif

  //Guardamos los parámetros en variables internas
  _pinDC=pinDC;
  _pinRES=pinRES;
  _pinCS=pinCS;
  //Siempre escribiremos en los pines DC, RES y CS
  pinMode(_pinDC,OUTPUT);
  pinMode(_pinRES,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinRES,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip
  //Reseteamos el display
  reset();
  //Llamamos a la inicialización de la clase padre
  RoJoGraph2::begin(); //Principalmente inicializa SPIFFS
}

//Dibuja un archivo de sprite en unas coordenadas
//Sobreescribe la información existente
//Respuesta: true si lo consigue
byte RoJoSSD1351::drawSprite(String filename,int16_t x,int16_t y) {
  //Este método no es imprescindible, puesto que ya está definido en RoJoGraph
  //Lo hacemos para optimizarlo

  //Tabla de errores (los primeros son los de infoSprite):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida
  //  3 : La profundidad de color no coincide con la del display

  //Declaración de variables
  uint16_t width,height; //Anchura y altura
  byte bytesPerPixel; //Profundidad de color
  //Leemos los valores del archivo bmp
  byte errorCode=infoSprite(filename,&width,&height,&bytesPerPixel);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Si la profundidad de color no coincide con la del display...terminamos con error
  //La profundidad de color de este display siempre es de 16 bits
  //Sólo podremos leer sprites esta profundidad de color
  if(_bytesPerPixel!=bytesPerPixel) return 3;

  //Calculamos el área visible
  displayRange r=visibleRange(x,y,width,height);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;

  uint16_t color;
  uint32_t rowLength=width*2; //Número de bytes que contiene una línea
  uint32_t offsetBase=5+2*(r.x1-x); //Offset de datos gráficos. Se la columna inicial
  uint32_t ry2=r.y2,rx2=r.x2,y32=y;

  //Nota:
  //Diferenciaremos si el sistema de archivos es SPIFFS o SD
  //Podemos utilziar la conexión SPI con el display al mismo tiempo que trabajamos con SPIFFS sin interferencias
  //Con una SD no es posible, porque ambos dispositivos utilizan la conexión SPI. Por lo tanto, tendremos
  //que asegurarnos de mantener sólo una conexión SPI en cada momento.
  //Si definimos un rango de dibujo en el display, lo recordará aunque finalicemos la transacción.
  //Incluso recordará la posición del cursor para la escritura del siguiente dato gráfico

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    _endCOMM();
    //Recorremos las filas visibles del display
    for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
      //Posicionamos offset en archivo
      f.seek(offsetBase+rowLength*(yy-y32));
      //Recorremos las columnas visibles del display
      for(uint32_t xx=r.x1;xx<=rx2;xx++) {
        //Leemos el color
        f.read((byte *)&color,2);
        //Dibujamos el pixel
        _startCOMM();
          SPI.transfer16(color);
        _endCOMM();
      }
    }
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
      //Recorremos las filas visibles del display
      for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
        //Posicionamos offset en archivo
        f.seek(offsetBase+rowLength*(yy-y32));
        //Recorremos las columnas visibles del display
        for(uint32_t xx=r.x1;xx<=rx2;xx++) {
          //Leemos el color
          f.read((byte *)&color,2);
          //Dibujamos el pixel
          SPI.transfer16(color);
        }
      }
    _endCOMM();
  #endif
  f.close(); //Hemos terminado de utilizar el archivo
  return 0; //Todo Ok
}

//Dibuja un sprite en unas coordenadas
//Sobreescribe la información existente
//Devuelve true si lo consigue
bool RoJoSSD1351::drawSprite(RoJoSprite2 *sprite,int16_t x,int16_t y) {
  if(_bytesPerPixel!=sprite->bytesPerPixel()) return false;
  //Calculamos el área visible
  displayRange r=visibleRange(x,y,sprite->xMax(),sprite->yMax());
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startCOMM();
    //Definimos el rango del cursor
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    //Calculamos el rango visible del sprite origen
    int16_t dx1=r.x1-x,dx2=r.x2-x,dy1=r.y1-y,dy2=r.y2-y;
    //Recorremos todas las filas visibles del sprite origen
    for(int16_t dy=dy1;dy<=dy2;dy++) {
      //Recorremos todas las columnas visibles del sprite origen y enviamos el color del pixel
      for(int16_t dx=dx1;dx<=dx2;dx++) SPI.transfer16(sprite->getPixel(dx,dy));
      #ifdef ESP8266
        yield(); //Refrescamos WatchDog
      #endif
    }
  _endCOMM();
  return true;
}

//Sincroniza dos sprites y envía las diferencias al display.
//Los sprites deben tener el mismo tamaño.
//Respuesta: true si todo es correcto
bool RoJoSSD1351::drawSpriteSync(RoJoSprite2 *source,RoJoSprite2 *destination,int16_t x,int16_t y) {
  //Se detectan las diferencias entre los dos sprites y se escriben sobre el sprite destino
  //y se envían al display.
  //Finalmente el sprite destino queda igual que el origen.

  //Anotamos las medidas del sprite origen
  int16_t xMaxSprite=source->xMax(),yMaxSprite=source->yMax();
  //Si los sprites tienen distinto tamaño...terminamos con error
  if(xMaxSprite!=(int16_t)destination->xMax() || yMaxSprite!=(int16_t)destination->yMax()) return false;
  //Comprobamos si tiene parte visible
  displayRange r=visibleRange(x,y,xMaxSprite,yMaxSprite);
  //Si no es visible...terminamos correctamente
  if(!r.visible) return true;
  //El sprite es total o parcialmente visible
  //En el display se dibujará el sprite en el rango: r.x1,r.y1,r.x2,r.y2
  //Se mostrará el siguiente rango del sprite: r.x1-x,r.y1-y,r.x2-x,r.y2-y
  //Es más sencillo recorrer las filas y columnas del sprite y si se detectan
  //diferencias, hacer la conversión a coordenadas de display
  
  //Calculamos la última fila y columna a procesar en el sprite
  //Reaprovechamos variables
  xMaxSprite=r.x2-x;
  yMaxSprite=r.y2-y;

  bool selectedRangeY; //Se ha seleccionado el rango vertical con la fila procesada?
  int16_t xSprite; //Columna procesada. Coordenada x del sprite
  _startCOMM();
    //Recorremos todas las filas visibles del sprite
    for(int16_t ySprite=r.y1-y;ySprite<=yMaxSprite;ySprite++) {
      //Por ahora no se ha inicializado el rango vertical para la fila actual
      selectedRangeY=false;
      //Comenzamos por la primera columna
      xSprite=r.x1-x;
      //Mientras no hayamos procesado todas las columnas...
      while(xSprite<=xMaxSprite) {
        //Si el pixel actual no se ha modificado...
        if(source->getPixel(xSprite,ySprite)==destination->getPixel(xSprite,ySprite)) {
          //...no tenemos en cuenta este pixel. Pasaremos al siguiente
          xSprite++;
        } else { //El pixel actual ha sido modificado...
          //Si no se ha seleccionado la fila actual...
          if(!selectedRangeY) {
		        //...lo hacemos ahora. Coinvertimos a coordenadas de display
		        _setCursorRangeY(y+ySprite,y+ySprite);
		        //y lo anotamos
		        selectedRangeY=true;
		      }
          //Consideramos este pixel como procesado
          //Actualizamos su valor en el sprite destino
          destination->drawPixel(xSprite,ySprite,source->getPixel(xSprite,ySprite));
          //Por ahora la última columna modificada es la primera
          int16_t lastChangedColumn=xSprite;
          //Columna procesada = la siguiente a la primera
          int16_t processedColumn=xSprite+1;
          //Mientras llevemos menos de 5 pixels sin modificar...
          while(processedColumn-lastChangedColumn<=5) {
            //Si el pixel de la columna procesada ha cambiado...
            if(source->getPixel(processedColumn,ySprite)!=destination->getPixel(processedColumn,ySprite)) {
              //...anotamos que la última columna con cambios es la actual
              lastChangedColumn=processedColumn;
              //Consideramos este pixel como procesado
              //Actualizamos su valor en el sprite destino
              destination->drawPixel(processedColumn,ySprite,source->getPixel(processedColumn,ySprite));
            }
            //Aumentamos la posición de la columna procesada
            processedColumn++;
          } //end while
          //Seleccionamos como rango horizontal desde la columna actual hasta la última modificada
          //Convertimos a coordenadas de display
          _setCursorRangeX(x+xSprite,x+lastChangedColumn);
          //Enviamos los datos gráficos
          for(int16_t x0=xSprite;x0<=lastChangedColumn;x0++) SPI.transfer16(source->getPixel(x0,ySprite));
          //La primera columna pasará a ser la actual
          xSprite=processedColumn;
        }
      }
      #ifdef ESP8266
        yield(); //Refrescamos WatchDog
      #endif
    }
  _endCOMM();
  //Todo Ok
  return true;
}

//Inicia una transacción SPI
void RoJoSSD1351::_startCOMM() {
  SPI.beginTransaction(_spiSetting);
  digitalWrite(_pinCS,LOW);
}

// Finaliza una transacción SPI
void RoJoSSD1351::_endCOMM() {
  digitalWrite(_pinCS,HIGH);
  SPI.endTransaction();
}

#endif

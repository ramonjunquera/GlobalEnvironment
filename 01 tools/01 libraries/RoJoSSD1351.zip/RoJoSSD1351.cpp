/*
  Nombre de la librería: RoJoSSD1351.h
  Versión: 20190627
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 1.5" 128x128 SSD1351

  La siguiente librería permite la gestión del display a través de los
  pines del bus SPI controlados por hardware.

  Todas las funciones escriben directamente sobre el display.
  No se utiliza ninguna técnica de buffer (simple o doble) para reducir
  la tasa de transferencia por SPI.
  Los dispositivos con suficiente memoria podrán hacerlo gracias a
  la compatibilidad con RoJoSprite16.
  
  Nota:
  La librería no tiene en cuenta los pines CS controlados por hardware.
  Se puede definir cualquier pin para CS porque se gestiona por software.
  En placas ESP estos pines se pueden desactivar.
  En Raspberry no. Esto quiere decir que RPi siempre seguirá gestionando
  el pin CS que tenga activo en ese momento.
  La ventaja de definir el pin CS por software es que podemos tener
  varios dispositivos SPI conectados a distintos pines de control y 
  no tendremos interferencias entre ellos.

  El sistema de archivos del cual se leen los sprites o fuentes
  es seleccionable mediante la constante global del preprocesador ROJO_PIN_CS_SD
  Estas constantes se definen en el archivo platformio.ini.

  Selección del sistema de archivos.
    Si se declara la constante ROJO_PIN_CS_SD y se le asigna un valor, se
    selecciona la SD como sistema de archivos.
    El valor de ROJO_PIN_CS_SD corresponde con el pin CS de la SD.
    Si no se declara esta constante, se utilizará SPIFFS.
    Ej.: build_flags = -D ROJO_PIN_CS_SD=15

  Tabla de compatibilidad de sistemas de archivos:

            SD SPIFFS
    Arduino SI NO
    ESP     SI SI
    RPi     NO SI
 */

#ifndef RoJoSSD1351_cpp
#define RoJoSSD1351_cpp

#include <RoJoSSD1351.h>

//Máxima frecuencia SPI soportada por el display
uint32_t RoJoSSD1351::_maxFreqSPI()
{
  return 4400000;
}

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoSSD1351::_writeCommand(byte command,...)
{
  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos el comando
  //Todos los parámetros deben pasarse en modo datos
  //Lo activamos ahora y nos aseguramos que quedará así al finalizar
  digitalWrite(_pinDC,HIGH);
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0)
  {
    //...enviamos el parámetro
    SPI.transfer((byte)paramValue);
  }
  //Hemos terminado de trabajar con la lista
  va_end(paramList);
}

//Reset & inicialización
void RoJoSSD1351::reset()
{
  digitalWrite(_pinRES,LOW);
  delay(10);
  digitalWrite(_pinRES,HIGH);
  delay(10);

  //Secuencia de inicialización
  _startSPI(); //Iniciamos conexión SPI
    _writeCommand(0xFD,0x12,-1); //Set Command Lock. MCU protection status: reset
    _writeCommand(0xFD,0xB1,-1); //Set Command Lock. Commands accesibles 
    _writeCommand(0xB3,0xF1,-1); //Oscillator Frequency/Front Clock Divider
    _writeCommand(0xCA,127,-1); //Set MUX Ration. Reset
    _writeCommand(0xA1,0,-1); //Set Display Start Line to 0
    _writeCommand(0xA2,0,-1); //Set Display Offset to 0
    _writeCommand(0xB5,0,-1); //Set GPIO. Input disabled
    _writeCommand(0xAB,1,-1); //Function Selection. Enable internal VDD regulator. Select 8-bit parallel interface
    _writeCommand(0xB1,0x32,-1); //Pre-charge (Phase 2) period = 3 DLCKs / Set Reset (Phase 1) = 5 DCLKs
    _writeCommand(0xBE,0x05,-1); //Set VCOMH Voltage = 0.82 x VCC = reset
    _writeCommand(0xBB,0x17,-1); //Set Pre-charge voltage = 0,48387 x VCC = reset [pre-charge voltage level=code*0.4/31+0.2]
    _writeCommand(0xA6,-1); //Reset to normal display
    _writeCommand(0xC1,0xC8,0x80,0xC8,-1); //Set Constrast Current for RGB
    _writeCommand(0xC7,0x0F,-1); //Master Contrast Current Control
    _writeCommand(0xB4,0xA0,0xB5,0x55,-1); //Set Segment low Voltage (VSL). External VSL = reset.
    _writeCommand(0xB6,1,-1); //Set Second Pre-charge Period = 1 DCLKs
    _writeCommand(0xAF,-1); //Sleep mode OFF (Display ON)
    //Set Re-map / Color Depth (Display RAM to Panel):
    //  Horizontal address increment = reset
    //  Column address 0 is mapped to SEG0 = reset
    //  Color sequence is swapped C->B->A
    //  Scan from COM[N-1] to COM0. Where N is the Multiplez ratio
    //  Enable COM Split Odd Even = reset
    //  Set Color Depth = 65k color = reset
    _writeCommand(0xA0,0B00110100,-1); 
  _endSPI(); //Finalizamos conexión SPI

  //Borramos la pantalla
  clear();
}

//Anchura de display
uint16_t RoJoSSD1351::xMax()
{
  return _xMax;
}

//Altura de display
uint16_t RoJoSSD1351::yMax()
{
  return _yMax;
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
void RoJoSSD1351::_setCursorRangeY(int16_t y1,int16_t y2)
{
  _writeCommand(0x75,y1,y2,-1); //Set Row Address
}
void RoJoSSD1351::_setCursorRangeX(int16_t x1,int16_t x2)
{
  _writeCommand(0x15,x1,x2,-1); //Set Column Address
  _writeCommand(0x5C,-1); //Write RAM Command. Modo de datos
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoSSD1351::block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color)
{
  //Intercambiamos coordenadas erróneas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
   //Calculamos el área visible
  displayRange r=visibleRange(x1,y1,x2-x1+1,y2-y1+1);
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startSPI();
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    for(byte y=r.y1;y<=r.y2;y++)
      for(byte x=r.x1;x<=r.x2;x++)
        SPI.transfer16(color);
  _endSPI();
  
  //Tiene parte visible
  return true;
}

//Dibuja un pixel
//Devuelve true si lo consigue si el pixel es visible
bool RoJoSSD1351::drawPixel(int16_t x,int16_t y,uint16_t color)
{
  //Si las coordenadas están fuera de rango...terminamos
  if(x<0 || x>=_xMax || y<0 || y>=_yMax) return false;

  _startSPI();
    _setCursorRange(x,y,x,y);
    SPI.transfer16(color);
  _endSPI();
  return true;
}

//Activa/Desactiva el modo hibernación
void RoJoSSD1351::sleep(bool mode)
{
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startSPI(); //Iniciamos conexión SPI
    if(mode) //Si activamos el modo hibernación...
    {
      _writeCommand(0xAE,-1); //Sleep ON
      _writeCommand(0xAB,0,-1); //Function Selection. Disable internal VDD regulator. Select 8-bit parallel interface
    }
    else //Si desactivamos el modo hibernación...
    {
      _writeCommand(0xAB,1,-1); //Function Selection. Enable internal VDD regulator. Select 8-bit parallel interface
      _writeCommand(0xAF,-1); //Sleep OFF
    }
  _endSPI(); //Finalizamos conexión SPI
}

#endif

/*
  Nombre de la librería: RoJoSSD1351.h
  Versión: 20190627
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 1.5" 128x128 SSD1351
*/

#ifndef RoJoSSD1351_h
#define RoJoSSD1351_h

#include <Arduino.h>
#include <RoJoDisplayDriver.h>

class RoJoSSD1351:public RoJoDisplayDriver
{
  private:
    uint32_t _maxFreqSPI(); //Máxima frecuencia SPI soportada por el display
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _setCursorRangeX(int16_t x1,int16_t x2); //Define rango X
    void _setCursorRangeY(int16_t y1,int16_t y2); //Define rango Y
    const byte _xMax=128; //Anchura de display
    const byte _yMax=128; //Altura de display
  public:
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void reset(); //Reset & inicialización
    bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color=0); //Dibuja un rectángulo relleno de un color
    bool drawPixel(int16_t x,int16_t y,uint16_t color); //Dibuja un pixel
    void sleep(bool mode); //Activa/Desactiva modo hibernación
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoSSD1351.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

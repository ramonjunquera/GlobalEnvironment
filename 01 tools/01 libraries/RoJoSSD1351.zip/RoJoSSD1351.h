/*
  Nombre de la librería: RoJoSSD1351.h
  Versión: 20210213
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 1.5" 128x128 SSD1351
*/

#ifndef RoJoSSD1351_h
#define RoJoSSD1351_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite2.h> //Gestión de sprites
#include <RoJoGraph2.h> //Gestión de gráficos avanzados

class RoJoSSD1351:public RoJoGraph2
{
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    SPISettings _spiSetting; //Características de la conexión SPI
    void _setCursorRangeX(int16_t x1,int16_t x2); //Define rango X
    void _setCursorRangeY(int16_t y1,int16_t y2); //Define rango Y
    void _setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2);
    const byte _xMax=128; //Anchura de display
    const byte _yMax=128; //Altura de display
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _startCOMM(); //Inicia una transacción SPI
    void _endCOMM(); //Finaliza una transacción SPI
  public:
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void reset(); //Reset & inicialización
    bool block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color=0); //Dibuja un rectángulo relleno de un color
    bool drawPixel(int16_t x,int16_t y,uint32_t color); //Dibuja un pixel
    void sleep(bool mode); //Activa/Desactiva modo hibernación
    void begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM=0); //Inicialización
    byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo
    bool drawSprite(RoJoSprite2 *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    bool drawSpriteSync(RoJoSprite2 *source,RoJoSprite2 *destination,int16_t x=0,int16_t y=0); //Sincroniza dos sprites
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoSSD1351.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

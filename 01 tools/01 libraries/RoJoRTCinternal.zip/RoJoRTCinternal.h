/*
  Nombre de la librería: RoJoRTCinternal.h
  Versión: 20191128
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC interno
    Clase derivada de RoJoRTC
  Notas:
    ESP
      Las placas ESP ofrecen la posibilidad de utilizar la función time() para obtener
      el número de segundos que lleva encendida la placa desde el último reset.
      El valor que devuelve es un uint32_t. El máximo valor será:
        2^32-1 = 4294967295 s = 71582788 m = 1193046 h = 49710 días = 136 años
      Es tiempo suficiente como para no preocuparmos.
      Por esa razón el desarrollo para ESP es simple.
    Arduino
      En las placas Arduino, no existe esta función. La más parecida es millis()
      que devuelve en un uint32_t los milisegundos desde el último reset.
      Esto es:
        2^32-1 = 4294967295 ms = 4294967 s = 71582 m = 1193 h = 49,7 días
      Cada 49,7 días se llegará al valar máximo que puede devolver millis() y se
      comenzará de nuevo.
      Si no ajustamos la hora del reloj en menos de 49 días, el método get devolverá
      un valor incorrecto del reloj.
      Para evitarlo, creamos un método capaz de detectar si se ha producido el
      desbordamiento y corregir automáticamente el valor.
    Raspberry Pi
      En RPi podemos utilizar el mismo reloj interno que en las placas ESP.
      Hay que tener en cuenta que guardan los segundos desde 01-01-1970 y no
      desde 01-01-1900.
      El reloj interno es el que se utiliza para dar la hora a todo el sistema.
      A tener en cuenta que si tenemos configurado que la hora se actualice
      desde un servidor NTP de Internet, tenemos conexión a ese servidor
      y cambiamos la hora con el método set, tardará muy poco en volver
      a recuperar la hora correcta. 
*/

#ifndef RoJoRTCinternal_h
#define RoJoRTCinternal_h

#include <Arduino.h>
#include <RoJoRTC.h> //Gestión de RTC genérico

class RoJoRTCinternal:public RoJoRTC {
  private:
    uint32_t _secOffset=0; //Segundos a sumar al reloj interno para hora actual
  public:
    void get(RoJoDateTime *t); //Obtiene la hora
    void set(RoJoDateTime *t); //Fijar fecha y hora
};

#ifdef __arm__
  #include <RoJoRTCinternal.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

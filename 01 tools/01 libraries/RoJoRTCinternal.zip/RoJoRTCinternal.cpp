/*
  Nombre de la librería: RoJoRTCinternal.h
  Versión: 20191128
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC interno
    Clase derivada de RoJoRTC
  Notas:
    ESP
      Las placas ESP ofrecen la posibilidad de utilizar la función time() para obtener
      el número de segundos que lleva encendida la placa desde el último reset.
      El valor que devuelve es un uint32_t. El máximo valor será:
        2^32-1 = 4294967295 s = 71582788 m = 1193046 h = 49710 días = 136 años
      Es tiempo suficiente como para no preocuparmos.
      Por esa razón el desarrollo para ESP es simple.
    Arduino
      En las placas Arduino, no existe esta función. La más parecida es millis()
      que devuelve en un uint32_t los milisegundos desde el último reset.
      Esto es:
        2^32-1 = 4294967295 ms = 4294967 s = 71582 m = 1193 h = 49,7 días
      Cada 49,7 días se llegará al valar máximo que puede devolver millis() y se
      comenzará de nuevo.
      Si no ajustamos la hora del reloj en menos de 49 días, el método get devolverá
      un valor incorrecto del reloj.
      Para evitarlo, creamos un método capaz de detectar si se ha producido el
      desbordamiento y corregir automáticamente el valor.
    Raspberry Pi
      En RPi podemos utilizar el mismo reloj interno que en las placas ESP.
      Hay que tener en cuenta que guardan los segundos desde 01-01-1970 y no
      desde 01-01-1900.
      Por defecto, la hora es la de GMT. Se necesita hacer la corrección
      de timezone.
      El reloj interno es el que se utiliza para dar la hora a todo el sistema.
      Si tenemos configurado que la hora se actualice desde un servidor
      NTP de Internet, tenemos conexión a ese servidor y cambiamos la
      hora con el método set, tardará muy poco en volver a recuperar la
      hora correcta. 
*/

#ifndef RoJoRTCinternal_cpp
#define RoJoRTCinternal_cpp

#include <RoJoRTCinternal.h>

//Obtiene la hora
void RoJoRTCinternal::get(RoJoDateTime *t) {
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino
    static uint32_t lastSeconds=0; //Segundos transcurridos en el ciclo anterior
    uint32_t s=millis()/1000; //Segundos transcurridos desde el último reset
    if(s<lastSeconds) { //Si se ha desbordado el valor de millis...
      //Sumamos al valor de segundos de offset, el número de segundos que tarda ee
      //desbordarse el valor de millis()
      //La función millis devuelve un uint32_t con las milésismas de segundo
      //transcurridas desde el último reset
      //El valor máquina que puede contener un uint32_t es 2^32-1=4294967295
      //Dividiendo por 1000 tendremos los segundos = 4294967
      //Este es el valor en ql que incrementaremos los segundos de offset
      _secOffset+=4294967;
    }
    lastSeconds=s; //Guadamos el valor actual para el próximo ciclo
    //Le sumamos los segundos de offset para obtener los segundos de la hora actual
    //Convertimos los segundos en fecha/hora
    seconds2datetime(s+_secOffset,t); 
  #else //Si es una placa ESP o RPi
    uint32_t s=time(nullptr); //Obtenemos hora de reloj interno
    //Le sumamos los segundos de offset para obtener los segundos de la hora actual
    //Convertimos los segundos en fecha/hora
    seconds2datetime(s+_secOffset,t);
  #endif
}

//Fija la hora indicada en el reloj
//No tiene en cuenta el valor de día de la semana. Lo recalcula
void RoJoRTCinternal::set(RoJoDateTime *t) {
  uint32_t s=datetime2seconds(t); //Lo pasamos a segundos transcurridos desde 1900
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino
    _secOffset=s-millis()/1000; //Calculamos los segundos de offSet con la hora actual
  #elif defined(__arm__) //Si es una RPi
    //El reloj interno tiene como fecha base 01-01-1970, pero el método
    //get asume que el reloj usar como base 01-01-1900.
    //Para corregirlo definiremos los segundos de offset como fijos
    //Con la diferencia de segundos entre las fechas base.
    //Por otra parte, el reloj interno devuelve la hora de GMT y no
    //tiene en cuenta el timezone.
    //Calcularemos la diferencia de timezone y la añadiremos a los
    //segundos de offset. 

    //Necesitamos conocer el ajuste por timezone
    time_t now=time(nullptr); //Obtenemos la hora actual
    struct tm tz={0}; //Creamos estructura para guardar info de timezone
    localtime_r(&now,&tz); //Obtenemos info de timezone
    //Definimos el offset con la diferencia de segundos entre fechas base
    //y la diferencia de segundos por timezone
    _secOffset=2208988800L+tz.tm_gmtoff;
    
    //Fijaremos la hora indicada en el reloj interno
    struct timeval linuxTime; //Creamos estructura para guardar fecha
    linuxTime.tv_sec=s-_secOffset; //Segundos desde 01-01-1970 y sin info timezone
    linuxTime.tv_usec=0; //No hay microsegundos
    settimeofday(&linuxTime,NULL); //Asignamos la fecha a reloj interno
  #else //Si es una placa ESP
    _secOffset=s-time(nullptr); //Calculamos los segundos de offSet con la hora actual
  #endif
}

#endif

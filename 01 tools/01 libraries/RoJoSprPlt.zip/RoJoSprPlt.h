/*
 * Autor: Ramón Junquera
 * Fecha: 20200824
 * Tema: Simulador de plt. Representación gráfica
 */

#ifndef RoJoSprPlt_h
#define RoJoSrPlt_h

#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoFloatMatrix.h> //Gestión de matrices

//Función que determina el color de un pixel del mapa de background
void meshRWB(float valueMin,float valueMax,float value,RoJoColor *c);

class RoJoSprPlt {
  private:
    float _xMin,_yMin,_xK,_yK; //Para cálculo de coordenadas
    void _displayXY(float *x,float *y); //Calcula coordenadas de pantalla
  public:
    RoJoSprite *spr=nullptr; //Sprite
    void end();
    bool begin(uint16_t xMax=200,uint16_t yMax=200); //Inicialización con dimensiones
    ~RoJoSprPlt(); //Destructor
    float meshMin,meshMax;
    bool axis(float xMin=-1,float xMax=1,float yMin=-1,float yMax=1);
    bool axis(bool scaled,RoJoFloatMatrix *X);
    bool scatter(RoJoFloatMatrix *X,RoJoColor c={0,0,255});
    void getLimitsX(float *xMin,float *xMax);
    void getLimitsY(float *yMin,float *yMax);
    bool mesh(RoJoFloatMatrix *X,RoJoFloatMatrix *Y,RoJoFloatMatrix *V,void (*meshColor)(float,float,float,RoJoColor*),bool autoLimit=true); //Muestra mapa de color
    bool plot(RoJoFloatMatrix *X,RoJoColor c={0,0,255});
};

#endif

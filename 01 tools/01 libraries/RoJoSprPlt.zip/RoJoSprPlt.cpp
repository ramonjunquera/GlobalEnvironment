/*
 * Autor: Ramón Junquera
 * Fecha: 20200824
 * Tema: Simulador de plt. Representación gráfica
 */

#include <RoJoSprPlt.h>

//Función que determina el color de un pixel del mapa de background
//La secuencia de colores es Red->White->Blue
//Esta función no pertenece a la clase para que el usuario pueda definir
//las suyas propias.
//Parámetros:
//- valueMin, valueMax : valores mínimo y máximo del rango
//- value: valor a analizar
//- c: color correspondiente al valor con la escala de colores
//Nota:
//Si el valor está fuera de rango, devolverá el color negro
void meshRWB(float valueMin,float valueMax,float value,RoJoColor *c) {
  //Si está fuera de rango...el pixel es negro
  if(value<valueMin || value>valueMax) c->set16(0);
  else { //La coordenadas están dentro de rango...
    float valueMean=(valueMax+valueMin)/2;
    float delta=valueMean-valueMin;
    if(value<valueMean) { //Tramo RW
      uint8_t level=(value-valueMin)/delta*255;
      *c={255,level,level};
    } else { //Tramo WB
      uint8_t level=(valueMax-value)/delta*255;
      *c={level,level,255};
    }
  }
}

//class RoJoQtPlt--------------------------------------------------------------

//Libera memoria
void RoJoSprPlt::end() {
  if(spr!=nullptr) { //Si hay algún sprite...
    delete spr; //Libera objeto sprite
    spr=nullptr; //Resetea puntero
  }
}

//Inicialización con dimensiones en pixels
//Devuelve true si lo consigue
bool RoJoSprPlt::begin(uint16_t xMax,uint16_t yMax) {
  if(xMax==0 || yMax==0) return false;
  //Si nunca se ha inicializado el sprite...lo creamos ahora
  if(spr==nullptr) spr=new RoJoSprite(16);
  if(!spr->setSize(xMax,yMax)) return false; //Intenta dimensionar el sprite
  //Fijamos valores de escalas para representar de [-1,1]
  _xMin=_yMin=-1;
  _xK=xMax/2;
  _yK=yMax/2;
  //Damos valores por defecto al min y max de mesh
  //Utilizamos [0,1] porque son los límites de la función sigmoide
  meshMin=0;
  meshMax=1;
  return true; //Todo Ok
}

//Destructor
RoJoSprPlt::~RoJoSprPlt() {
  end();
}

//Calcula coordenadas de pantalla
//Parámetros
//- input: coordenada espaciales
//- output: coordenadas de pantalla
void RoJoSprPlt::_displayXY(float *x,float *y) {
  *x=(*x-_xMin)*_xK;
  *y=spr->yMax()-(*y-_yMin)*_yK;
}

//Fija escalas y dibuja ejes
//Devuelve true si lo consigue
bool RoJoSprPlt::axis(float xMin,float xMax,float yMin,float yMax) {
  if(xMin>=xMax || yMin>=yMax) return false;
  spr->clear({255,255,255}); //Borramos imágen (pantalla blanca)
  _xMin=xMin;
  _yMin=yMin;
  _xK=(float)spr->xMax()/(xMax-xMin);
  _yK=(float)spr->yMax()/(yMax-yMin);
  //Dibujamos los ejes (si son visibles)
  float x,y;
  x=y=0; //Centro de coordenadas
  _displayXY(&x,&y);
  if(x>=0 && x<spr->xMax()) spr->line(x,0,x,spr->yMax(),{0,0,0}); //Eje vertical
  if(y>=0 && y<spr->yMax()) spr->line(0,y,spr->xMax(),y,{0,0,0}); //Eje horizontal
  return true; //Todo Ok
}

//Fija escalas y dibuja ejes en base a coordenadas a mostrar
//Parámetros:
//- scaled: false=ejes con la misma proporción
//- X: matrix con tamaño (samples,2)
//Devuelve true si lo consigue
bool RoJoSprPlt::axis(bool scaled,RoJoFloatMatrix *X) {
  if(X->cols()!=2) return false;
  spr->clear({255,255,255}); //Borramos imágen
  float xMax,yMax;
  //Detectamos valores máximos y mínimos de cada eje
  X->maxminCol(&_xMin,&xMax,0); //maxmin de x
  X->maxminCol(&_yMin,&yMax,1); //maxmin de y
  //Si la amplitud del intervalo es nulo en algún caso...
  //...marcamos nosotros los límites
  if(_xMin==xMax) {
    _xMin-=1;
    xMax+=1;
  }
  if(_yMin==yMax) {
    _yMin-=1;
    yMax+=1;
  }
  //Calculamos amplitud de intervalo y tomamos el 10% para dar márgen
  float xDelta=0.1*(xMax-_xMin);
  float yDelta=0.1*(yMax-_yMin);
  //Recalculamos los límites del intervalo
  _xMin-=xDelta;
  xMax+=xDelta;
  _yMin-=yDelta;
  yMax+=yDelta;
  if(scaled) { //Si los ejes pueden tener distinta escala...
    //Calculamos la K para el cálculo de coordenadas de pantalla
    _xK=(float)spr->xMax()/(xMax-_xMin);
    _yK=(float)spr->yMax()/(yMax-_yMin);
  } else { //Los ejes no pueden tener distinta escala
    float delta=(xMax-_xMin-yMax+_yMin)/2;
    if(xDelta>yDelta) {
      _yMin-=delta;
      yMax+=delta;
    } else {
      _xMin+=delta;
      xMax-=delta;
    }
    delta=xMax-_xMin;
    _xK=(float)spr->xMax()/delta;
    _yK=(float)spr->yMax()/delta;
  }
  //Dibujamos los ejes (si son visibles)
  float x,y;
  x=y=0; //Centro de coordenadas
  _displayXY(&x,&y);
  if(x>=0 && x<spr->xMax()) spr->line(x,0,x,spr->yMax(),{0,0,0}); //Eje vertical
  if(y>=0 && y<spr->yMax()) spr->line(0,y,spr->xMax(),y,{0,0,0}); //Eje horizontal
  return true; //Todo Ok
}

//Representación gráfica de puntos
//Parámetros:
//- X : RoJoFloatMatrix con coordenadas de tamaño (samples,2)
//- c : color. Por defecto azul
//Respuesta: true si todo es correcto
bool RoJoSprPlt::scatter(RoJoFloatMatrix *X,RoJoColor c) {
  if(X->cols()!=2) return false;
  uint16_t rows=X->rows();
  float x,y;
  //Dibujamos todos los puntos
  for(uint16_t row=0;row<rows;row++) {
    x=X->m[row][0];
    y=X->m[row][1];
    _displayXY(&x,&y);
    spr->block(x-1,y-1,x+1,y+1,c); //Relleno
    spr->rect(x-2,y-2,x+2,y+2,{0,0,0}); //Borde
  }
  return true; //Todo Ok
}

//Obtiene los límites de visualización del eje X
void RoJoSprPlt::getLimitsX(float *xMin,float *xMax) {
  *xMin=_xMin;
  *xMax=_xMin+spr->xMax()/_xK;
}

//Obtiene los límites de visualización del eje Y
void RoJoSprPlt::getLimitsY(float *yMin,float *yMax) {
  *yMin=_yMin;
  *yMax=_yMin+spr->yMax()/_yK;
}

//Representación de mapa de color
//Parámetros:
//- X: Matriz de coordenadas X (cols,1)
//- Y: Matriz de coordenadas Y (rows,1)
//- V: Matriz de valores (rows,cols);
//- void (*meshColor)(float,float,float,RoJoColor*): función de cálculo de color
//- autoLimit: cálculo automático de límites?
//Nota:
//- Suponemos que las coordenadas están ordenadas de menor a mayor
bool RoJoSprPlt::mesh(RoJoFloatMatrix *X,RoJoFloatMatrix *Y,RoJoFloatMatrix *V,void (*meshColor)(float,float,float,RoJoColor*),bool autoLimit) {
  uint16_t rows=Y->rows();
  uint16_t cols=X->rows();
  if(rows==0 || cols==0 || X->cols()!=1 || Y->cols()!=1 || V->rows()!=rows || V->cols()!=cols) return false;
  if(autoLimit) V->maxmin(&meshMin,&meshMax); //Si hay que calcular los límites...lo hacemos
  //Definimos arrays de enteros para guardar la conversión a coordenadas de pantalla
  //Esto evitará que tengamos que convertirlas cada vez que queramos usarlas
  //El primer elemento es el límite inferior visible
  //El último elemento es el límite superior visible
  //Los elementos intermedios contienen el promedio de dos valores contiguos
  //El resultado final serán las coordenadas de pantalla de las separaciones de pixels
  uint16_t *Xp=new uint16_t[cols+1];
  uint16_t *Yp=new uint16_t[rows+1];
  Xp[0]=0; Xp[cols]=spr->xMax();
  Yp[0]=spr->yMax(); Yp[rows]=0; //El eje y está invertido
  float meanValue;
  RoJoColor c; //Color del pixel
  for(uint16_t i=0;i<cols-1;i++) {
    meanValue=(X->m[i][0]+X->m[i+1][0])/2;
    Xp[i+1]=(meanValue-_xMin)*_xK;
  }
  for(uint16_t i=0;i<rows-1;i++) {
    meanValue=(Y->m[i][0]+Y->m[i+1][0])/2;
    Yp[i+1]=spr->yMax()-(meanValue-_yMin)*_yK;
  }
  for(uint32_t row=0;row<rows;row++) {
    for(uint32_t col=0;col<cols;col++) {
      meshColor(meshMin,meshMax,V->m[row][col],&c); //Calculamos color de pixel
      //Tenemos las coordenadas de pantalla de los límites de los pixels
      //en Xp & Yp.
      //Las coordenadas de Yp están invertidas (de mayor a menor) para que
      //se muestra en pantalla con el sentido de coordenadas cartesianas.
      //Tomamos como vértice inicial el superior izquierdo
      spr->block(Xp[col],Yp[row+1],Xp[col+1],Yp[row],c);
    }
  }
  //Ya no necesitamos los arrays de coordenadas de pantalla
  delete[] Xp;
  delete[] Yp;
  return true; //Todo Ok
}

//Representación gráfica de líneas
//Parámetros:
//- X : RoJoFloatMatrix con coordenadas de tamaño (samples,2)
//- c : color. Por defecto azul
//Respuesta: true si todo es correcto
bool RoJoSprPlt::plot(RoJoFloatMatrix *X,RoJoColor c) {
  uint16_t rows=X->rows();
  if(X->cols()!=2) return false;
  float x0,y0,x1,y1;
  //Primer punto
  x1=X->m[0][0];
  y1=X->m[0][1];
  _displayXY(&x1,&y1);
  //Dibujamos las líneas que unen los puntos
  for(uint16_t row=1;row<rows;row++) {
    x0=x1;
    y0=y1;
    x1=X->m[row][0];
    y1=X->m[row][1];
    _displayXY(&x1,&y1);
    spr->line(x0,y0,x1,y1,c);
  }
  return true; //Todo Ok
}

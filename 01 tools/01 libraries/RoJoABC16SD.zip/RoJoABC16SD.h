/*
  Nombre de la librería: RoJoABC16.h
  Versión: 20180225
  Autor: Ramón Junquera
  Descripción:
    Gestión de fuentes de color (16bits)
*/

#ifndef RoJoABC16_h
#define RoJoABC16_h

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
#define UseSD

#include <Arduino.h>
#ifdef UseSD //Si debemos utilizar una terjeta SD...
  #define SPIFFS SD //Cuando referenciemos a SPIFFS se redireccionará a SD
  #include <SD.h> //Librería de gestión SD
  #include "RoJoSprite16SD.h"
#else //Si debemos utilizar SPIFFS
  #ifdef ARDUINO_ARCH_AVR //Si es un Arduino...
    #error Arduino family has not SPIFFS
  #elif defined(ESP32) //Si es un ESP32...
    #include <SPIFFS.h> 
  #else //Si cualquier otra cosa (ESP8266 o RPi)...
    #include <FS.h>
  #endif
  #include "RoJoSprite16.h"
#endif

class RoJoABC16
{
  private:
    File _f; //Archivo de fuentes
    byte _charMin; //Primer carácter ASCII incluido en librería
    byte _charMax; //Último carácter ASCII incluido en librería
    byte _pages=0; //Altura en páginas
    byte _charCount; //Número de caracteres de la fuente
    bool _charInFont(byte c); //El carácter pertenece a la fuente?
    byte _charWidth(byte c); //Devuelve la anchura de un carácter
    uint16_t _charIndex(byte c); //Devuelve el índice de inicio de los datos gráficos de un carácter
    void _seek(uint32_t pos); //Cambia la posición de lectura del archivo _f
    const uint32_t _freq_SD=25000000; //Frecuencia SPI de la SD = 25MHz
  public:
    RoJoABC16(); //Constructor
    bool print(String fileNameFon,String text,RoJoSprite16 *sprite,uint16_t textColor,uint16_t backColor=0); //Crea un sprite con el texto indicado. Fondo por defecto = negro
    bool print(String fileNameFon,String text,RoJoSprite16 *sprite,uint16_t textColor,uint16_t backColor,uint16_t borderColor); //Crea un sprite de texto con borde
}; //Punto y coma obligatorio para que no de error

#endif


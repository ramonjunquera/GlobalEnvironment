/*
  Nombre de la librería: RoJoSprite16.h
  Versión: 20180521
  Autor: Ramón Junquera
  Descripción:
    Gestión de sprites color 16bits
*/

#ifndef RoJoSprite16_cpp
#define RoJoSprite16_cpp

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
#define UseSD

#include <Arduino.h>
#ifdef UseSD //Si debemos utilizar una tarjeta SD...
  #define SPIFFS SD //Cuando referenciemos a SPIFFS se redireccionará a SD
  #include <SD.h> //Librería de gestión SD
  #include "RoJoSprite16SD.h"
#else //Si debemos utilizar SPIFFS
  #ifdef ARDUINO_ARCH_AVR //Si es un Arduino...
    #error Arduino family has not SPIFFS
  #elif defined(ESP32) //Si es un ESP32...
    #include <SPIFFS.h> 
  #else //Si cualquier otra cosa (ESP8266 o RPi)...
    #include <FS.h>
  #endif
  #include "RoJoSprite16.h"
#endif

RoJoSprite16::RoJoSprite16(byte pinCS_SD)
{
	//Constructor

  _pinCS_SD=pinCS_SD;
	
	_xMax=_yMax=0;
	_bitmap=NULL;
}

RoJoSprite16::~RoJoSprite16()
{
	//Destructor
	
	//Liberamos memoria de array gráfico
	clean();
}

uint16_t RoJoSprite16::width()
{
	return _xMax;
}
	
uint16_t RoJoSprite16::height()
{
	return _yMax;
}

void RoJoSprite16::clean()
{
  //Libera memoria ocupada por el array de gráficos
  
  //Si el puntero del array de gráficos está apuntando a una
  //posición de memoria dintinta de cero...
  //Si tenemos array gráfico...
  if(_bitmap)
  {
    //Liberamos su memoria
    delete[] _bitmap;
    //Al liberar la memoria a la que apunta un puntero no cambia
    //el puntero. Lo cambiaremos manualmente
    _bitmap=NULL;
    //Ya no tiene dimensión
    _xMax=_yMax=0;
  } 
}

void RoJoSprite16::setSize(uint16_t x,uint16_t y)
{
  //Fija un nuevo tamaño para el sprite

  #ifndef UseSD //Si no utilizamos una tarjeta SD...
    //Inicializamos el acceso a archivos
    //Puesto que SPIFFS no se puede desconectar, lo inicializamos y no nos preocupamos más de él
    //Si utilizamos un tarjeta SD, ya la inicializaremos cuando vayamos a utilizarla
    //en los métodos load & save
    //No lo inicializamos en el constructor porque en placas DOIT falla por no tener
    //la memoria reservada para ello. Lo hacemos aquí, que es el primer
    //método que se utiliza tras la creación de un sprite.
    SPIFFS.begin();
  #endif

  //Borramos el array gráfico
  clean();
  //Guardamos los valores de los parámetros
  _xMax=x;
  _yMax=y;
  //Creamos un nuevo array gráfico lleno de ceros
  _bitmap = new uint16_t[x*y]();
}

bool RoJoSprite16::load(String fileName)
{
	//Carga la información del sprite desde un archivo
	//Devuelve false ante cualquier error

	uint16_t width,height;

  #ifdef UseSD //Si debemos utilizar una SD...
    //Inicializamos el uso de archivos
    //Indicamos la frecuencia y pin CS
    #ifdef ESP32
      //Puesto que ESP32 tiene su propia librería SD, los parámetros de begin
      //son distintos
      SPIFFS.begin(_pinCS_SD,SPI,_freq_SD);
    #elif defined(ESP8266)
      //Puesto que ESP8266 también tiene su propia librería SD, los parámetros de 
      //begin también son distintos
      SPIFFS.begin(_pinCS_SD,_freq_SD);
    #else
      //Si no es un ESP, es un Arduino. Usamos los parámetros de la librería SD.h estándar
      //Lo intentamos hasta conseguirlo
      while(!SPIFFS.begin(_freq_SD,_pinCS_SD));
    #endif
    //Abrimos el archivo indicado como sólo lectura
    File f=SPIFFS.open(fileName);
  #else //Si es SPIFFS...
    //Abrimos el archivo indicado como sólo lectura
    File f=SPIFFS.open(fileName,"r");
  #endif
  //Si hubo algún problema...devolvemos error
  if(!f) return false;
  //Leemos la anchura (2 bytes)
  f.readBytes((char *)&width,2);
  //Leemos la altura (2 bytes)
  f.readBytes((char *)&height,2);
  //Fijamos el tamaño del sprite
  setSize(width,height);
  //Leemos el resto del archivo y lo guardamos en el array bitmap
  f.readBytes((char *)_bitmap,width*height*2);
  //Cerramos el archivo
  f.close();

	//Todo ok
	return true;
}

uint16_t RoJoSprite16::getPixel(uint16_t x,uint16_t y)
{
  //Devolvemos color
  
  //Si no hay sprite...devolvemos 0
  if(!_bitmap) return 0;
  //Y si existe, devolvemos el color
  return _bitmap[x+y*_xMax];
}

void RoJoSprite16::_copy(int16_t x,int16_t y,RoJoSprite16 *source,uint16_t invisibleColor,bool invisible)
{
  //Copia un sprite sobre otro en unas coordenadas
  //Se indica qué color se debe tomar como invisible y si se debe tener en cuenta
  //Método privado

  //Tomanos nota del tamaño del sprite a dibujar
  uint16_t sourceSizeX=(*source).width();
  uint16_t sourceSizeY=(*source).height();

  int16_t destinationX; //Columna a escribir
  int16_t destinationY; //Fila a escribir
  uint16_t pixelColor; //Color del pixel procesado
  
  //Recorremos todas las filas del sprite a dibujar
  for(uint16_t sourceY=0;sourceY<sourceSizeY;sourceY++)
  {
    //Calculamos la fila en la que se copiará
    destinationY=y+sourceY;
    //Si la fila está dentro de rango...
    if(destinationY>=0 && destinationY<_yMax)
    {
      //...la dibujamos
      
      //Recorremos todas las columnas del sprite a dibujar
      for(uint16_t sourceX=0;sourceX<sourceSizeX;sourceX++)
      {
        //Calculamos la columna en la que se copiará
        destinationX=x+sourceX;
        //Si la columna está dentro de rango...
        if(destinationX>=0 && destinationX<_xMax)
        {
          //Obtenemos el color del pixel del sprite origen
          pixelColor=(*source).getPixel(sourceX,sourceY);
          //Si no hay que tener en cuenta un color invisible o el color del pixel
          //es distinto al del invisible...
          if(!invisible || pixelColor!=invisibleColor)
          {
            //...podemos copiar el pixel
            drawPixel(destinationX,destinationY,pixelColor);
          }
        }
      }
    }
  }  
}

void RoJoSprite16::drawSprite(int16_t x,int16_t y,RoJoSprite16 *source,uint16_t invisibleColor)
{
  //Copia un sprite sobre otro en unas coordenadas
  //Se indica qué color se debe tomar como invisible
  _copy(x,y,source,invisibleColor,true);
}

void RoJoSprite16::drawSprite(int16_t x,int16_t y,RoJoSprite16 *source)
{
  //Dibuja un sprite en unas coordenadas
  _copy(x,y,source,0,false);
}

void RoJoSprite16::drawPixel(int16_t x,int16_t y,uint16_t color)
{
  //Si las coordenadas están fuera de rango...terminamos
  if(x<0 || x>=_xMax || y<0 || y>=_yMax) return;
  //Guardamos color
  _bitmap[x+y*_xMax]=color;
}

void RoJoSprite16::save(String fileName)
{
	//Guarda la información del sprite en un archivo

	uint16_t width,height;
	width=_xMax;
	height=_yMax;

	//Si hay algo que escribir...
	if(_bitmap)
	{
    #ifdef UseSD //Si debemos utilizar una SD...
      //Inicializamos el uso de archivos
      //Indicamos la frecuencia y pin CS
      #ifdef ESP32
        //Puesto que ESP32 tiene su propia librería SD, los parámetros de begin
        //son distintos
        SPIFFS.begin(_pinCS_SD,SPI,_freq_SD);
      #elif defined(ESP8266)
        //Puesto que ESP8266 también tiene su propia librería SD, los parámetros de 
        //begin también son distintos
        SPIFFS.begin(_pinCS_SD,_freq_SD);
      #else
        //Si no es un ESP, es un Arduino. Usamos los parámetros de la librería SD.h estándar
        //Lo intentamos hasta conseguirlo
        while(!SPIFFS.begin(_freq_SD,_pinCS_SD));
      #endif
      //Abrimos el archivo indicado como escritura
      File f=SPIFFS.open(fileName,FILE_WRITE);
    #else //Si es SPIFFS...
      //Abrimos el archivo indicado como escritura
      File f=SPIFFS.open(fileName,"w");
    #endif
    //Escribimos la anchura
    f.write((byte *)&width,2);
    //Escribimos la altura
    f.write((byte *)&height,2);
    //Escribimos el array de bitmap
    f.write((byte *)_bitmap,_xMax*_yMax*2);
    //Cerramos el archivo
    f.close();
	}
}

void RoJoSprite16::clear(uint16_t color)
{
  //Borra el sprite llenando el fondo de un color

  //Calculamos el tamaño del array gráfico
  uint32_t bitmapSize = _xMax*_yMax;
  //Recorremos todos los bytes del array gráfico...escribiendo el color en todos los pixels
  for(uint32_t i=0;i<bitmapSize;i++) _bitmap[i]=color;
}

void RoJoSprite16::clear()
{
  //Borra el sprite pintando el fondo de negro
  clear(0);
}

void RoJoSprite16::replaceColor(uint16_t source,uint16_t destination)
{
  //Cambia los pixels de un color por otro

  //Calculamos el tamaño del array gráfico
  uint32_t bitmapSize = _xMax*_yMax;
  //Recorremos todos los bytes del array gráfico...
  for(uint32_t i=0;i<bitmapSize;i++)
  {
    //Si el color del pixel es el que buscamos...lo reemplazamos
    if(_bitmap[i]==source) _bitmap[i]=destination;
  }
}

void RoJoSprite16::resize(uint16_t width,uint16_t height,RoJoSprite16 *source)
{
  //Redimensiona un sprite
 
  //Borramos el sprite actual y creamos una nuevo con el tamaño indicado
  setSize(width,height);
  //Anotamos las dimensiones del sprite origen para facilitar la nomenclatura
  uint32_t sourceSizeX=(*source).width();
  uint32_t sourceSizeY=(*source).height();

  //Recorremos todas las filas
  for(uint32_t y=0;y<height;y++)
  {
    //Recorremos todas las columnas
    for(uint32_t x=0;x<width;x++)
    {
      //Calculamos la posición del pixel a tomar desde el origen y lo escribimos en el destino
      _bitmap[y*width+x]=(*source).getPixel((x*sourceSizeX)/_xMax,(y*sourceSizeY)/_yMax);
    }
  }
}

void RoJoSprite16::line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color)
{
  //Dibuja una línea utilizando el algoritmo de Bresenham

  const bool steep=abs(y2-y1)>abs(x2-x1);
  
  if(steep)
  {
    _swap(&x1,&y1);
    _swap(&x2,&y2);
  }
 
  if(x1>x2)
  {
    _swap(&x1,&x2);
    _swap(&y1,&y2);
  }
 
  int16_t dx=x2-x1;
  int16_t dy=abs(y2-y1);
 
  int16_t err=dx/2;
  const int16_t ystep=y1<y2?1:-1;
 
  for(;x1<x2;x1++)
  {
    if(steep) drawPixel(y1,x1,color);
    else drawPixel(x1,y1,color);
 
    err-=dy;
    if(err<0)
    {
      y1+=ystep;
      err+=dx;
    }
  }
}

void RoJoSprite16::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t borderColor)
{
  //Dibuja un rectángulo sin relleno
  line(x1,y1,x2,y1,borderColor);
  line(x1,y2,x2,y2,borderColor);
  line(x1,y1,x1,y2,borderColor);
  line(x2,y1,x2,y2,borderColor);
}

void RoJoSprite16::clear(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color)
{
  //Dibuja un rectángulo relleno de un color

  //Recorremos todas las filas y columnas pintando del color indicado
  for(int16_t x=x1;x<=x2;x++)
    for(int16_t y=y1;y<=y2;y++)
      drawPixel(x,y,color);
}

void RoJoSprite16::clear(int16_t x1,int16_t y1,int16_t x2,int16_t y2)
{
  //Dibuja un rectángulo relleno de color negro
  clear(x1,y1,x2,y2,0);
}

byte RoJoSprite16::pinCS_SD()
{
  //Devuelve el pin CS de la SD
  return _pinCS_SD;
}

void RoJoSprite16::triangle(int16_t x1,int16_t y1,int16_t x2,int16_t y2,int16_t x3,int16_t y3,uint16_t borderColor)
{
  //Dibuja un triángulo sin relleno
  line(x1,y1,x2,y2,borderColor);
  line(x1,y1,x3,y3,borderColor);
  line(x2,y2,x3,y3,borderColor);
}

void RoJoSprite16::triangleFill(int16_t x0,int16_t y0,int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t fillColor)
{
  //Dibuja un triángulo relleno

  //Ordenamos en vertical: y0 <= y1 <= y2
  if(y0>y1)
  {
    _swap(&x0,&x1);
    _swap(&y0,&y1);
  }
  if(y1>y2)
  {
    _swap(&x1,&x2);
    _swap(&y1,&y2);
  }
  if(y0>y1)
  {
    _swap(&x0,&x1);
    _swap(&y0,&y1);
  }

  //Inicio y final de segmento horizontal
  int16_t a,b;

  //Si la primera y última coordenada vertical coinciden...
  if(y0==y2)
  {
    //Sólo tendremos que dibujar una línea horizontal
    //Calcularemos sus coordenadas horizontales con el mínimo (a) y el máximo (b)
    a=b=x0;
    if(x1<a) a=x1; else if(x1>b) b=x1;
    if(x2<a) a=x2; else if(x2>b) b=x2;
    //Dibujamos una línea horizontal
    line(a,y1,b,y1,fillColor);
    //Hemos terminado
    return;
  }
  //El triángulo no forma una línea horizontal

  //Definición de variables
  int16_t dx01=x1-x0;
  int16_t dy01=y1-y0;
  int16_t dx02=x2-x0;
  int16_t dy02=y2-y0;
  int16_t dx12=x2-x1;
  int16_t dy12=y2-y1;
  int16_t sa=0;
  int16_t sb=0;
  int16_t last; //Última coordenada vertical a dibujar/rellenar
  int16_t y; //Coordenada vertical procesada

  //Calculamos la coordenada vertical hasta la que tenemos que dibujar/rellenar
  //Si la parte inferior del triángulo es horizontal...esa será la última
  if(y1==y2) last=y1;
  //Y si no...dibujaremos hasta una antes de llegar a la coordenada vertical intermedia
  else last=y1-1;
  
  //Dibujamos la parte superior del triángulo. Desde y0 a y1
  for (y=y0;y<=last;y++)
  {
    //Calculamos los extremos
    a=x0+sa/dy01;
    b=x0+sb/dy02;
    
    sa+=dx01;
    sb+=dx02;

    line(a,y,b,y,fillColor);
  }

  //Dibujamos la parte inferior del triángulo. Desde y1 a y2
  //Si y1==y2 no se dibuja nada
  sa=dx12*(y-y1);
  sb=dx02*(y-y0);
  for(;y<=y2;y++)
  {
    //Calculamos los extremos
    a=x1+sa/dy12;
    b=x0+sb/dy02;
    
    sa+=dx12;
    sb+=dx02;

    line(a,y,b,y,fillColor);
  }
}

void RoJoSprite16::_swap(int16_t *a,int16_t *b)
{
  //Intercambia los valores de las variables
  int16_t tmp;
  tmp=*a;*a=*b;*b=tmp;
}

#endif

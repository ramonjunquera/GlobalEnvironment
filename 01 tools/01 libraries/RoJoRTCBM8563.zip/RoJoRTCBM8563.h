/*
  Nombre de la librería: RoJoRTCBM8563.h
  Versión: 20191120
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC BM8563
    Es el modelo que contiene el M5Stick-C
    Clase derivada de RoJoRTC
*/

#ifndef RoJoRTCBM8563_h
#define RoJoRTCBM8563_h

#include <Arduino.h>
#include <RoJoRTC.h> //Gestión de RTC genérico

class RoJoRTCBM8563:public RoJoRTC {
  public:
    bool begin(int8_t pinSDA=-1,int8_t pinSCL=-1); //Inicializa el RTC
    void get(RoJoDateTime *t); //Obtiene la hora
    void set(RoJoDateTime *t); //Fijar fecha y hora
};

#ifdef __arm__
  #include <RoJoRTCBM8563.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

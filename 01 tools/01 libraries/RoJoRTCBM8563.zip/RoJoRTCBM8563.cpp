/*
  Nombre de la librería: RoJoRTCBM8563.h
  Versión: 20191128
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC BM8563
    Es el modelo que contiene el M5Stick-C
    Clase derivada de RoJoRTC
*/

#ifndef RoJoRTCBM8563_cpp
#define RoJoRTCBM8563_cpp

#include <RoJoRTCBM8563.h>

//Inicializa el RTC
bool RoJoRTCBM8563::begin(int8_t pinSDA,int8_t pinSCL){
  _clockID=0x51; //Guardamos el identificador I2C
  #if defined(ARDUINO_ARCH_AVR) || defined(__arm__) //Si es una placa Arduino o RPi
    Wire.begin(); //No se pueden seleccionar los pines I2C
  #else //No es una placa Arduino
    if(pinSDA<0) Wire.begin(); //No hay pines seleccionados
    else Wire.begin(pinSDA,pinSCL); //Las placas ESP pueden seleccionar los pines I2C
  #endif
  //Habitualmente el bus I2C transmite con una frecuencia de 100KHz.
  //Con el siguiente comando lo incrementamos hasta 400KHz, si la placa lo permite.
  Wire.setClock(400000L);
  //Abrimos comunicación con el RTC
  Wire.beginTransmission(_clockID);
  //Se devuelve el resultado inverso al de fin de transmisión
  //Cuando una transmisión finaliza correctamente, devuelve false
  return !Wire.endTransmission();
}

//Obtiene la hora
void RoJoRTCBM8563::get(RoJoDateTime *t) {
  Wire.beginTransmission(_clockID); //Abrimos comunicación con el RTC
  Wire.write(2); //Escribimos un byte con valor 0x02 (reset pointer)
  Wire.endTransmission(); //Cerramos la comunicación (no tenemos más información que enviar)
  //Solicitamos 7 bytes del reloj: segundos, minutos, horas, día de la semana, día del mes, mes y año
  Wire.requestFrom(_clockID,(byte)7);
  //Anotamos cada uno de los valores en la estructura timeNow
  t->second=_bcd2dec(Wire.read()); //Leemos el byte de segundos
  //Nota: si los segundos > 128 quiere decir que el reloj está parado porque nunca se ha puesto en hora
  t->minute=_bcd2dec(Wire.read()); //Leemos el byte de minutos
  t->hour=_bcd2dec(Wire.read()); //Leemos el byte de horas
  t->day=_bcd2dec(Wire.read()); //Leemos el byte de día del mes
  t->weekDay=Wire.read(); //Leemos el byte de día de la semana. lun=0,dom=6
  t->month=_bcd2dec(Wire.read()); //Leemos el byte del mes
  t->year=2000+_bcd2dec(Wire.read()); //Leemos el byte del año (20xx)
}

//Fija la hora indicada en el reloj
//No tiene en cuenta el valor de día de la semana. Lo recalcula
void RoJoRTCBM8563::set(RoJoDateTime *t) {
  uint32_t s=datetime2seconds(t); //Lo pasamos a segundos transcurridos desde 1900
  seconds2datetime(s,t); //...y lo volvemos a convertir en datetime
  //Ahora tenemos calculado también el día de la semana
  
  Wire.beginTransmission(_clockID); //Abrimos comunicación con el RTC
    Wire.write(0x02); //Reset pointer
    Wire.write(_dec2bcd(t->second)); //segundos en bcd
    Wire.write(_dec2bcd(t->minute)); //minutos en bcd
    Wire.write(_dec2bcd(t->hour)); //horas en bcd
    Wire.write(_dec2bcd(t->day)); //día de mes en bcd
    Wire.write(t->weekDay); //día de la semana
    Wire.write(_dec2bcd(t->month)); //número de mes en bcd
    Wire.write(_dec2bcd(t->year%100)); //dos últimos dígitos del año 20xx
  Wire.endTransmission(); //Cerramos la comunicación
}

#endif

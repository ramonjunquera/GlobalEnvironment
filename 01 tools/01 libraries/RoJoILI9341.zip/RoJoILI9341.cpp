/*
  Nombre de la librería: RoJoILI9341.h
  Versión: 20190830
  Autor: Ramón Junquera
  Descripción:
    Gestión de display ILI9341 SPI 240x320

  Notas:
    En este display, todos los datos que se le envían son de 16 bits.
    Si hay datos de un byte (como los comandos o sus parámetros), aún así
    se deben enviar como valor de 16 bits.
*/

#ifndef RoJoILI9341_cpp
#define RoJoILI9341_cpp

#include <RoJoILI9341.h>

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoILI9341::_writeCommand(byte command,...) {
  //ILI9341 envía la información (comando y parámetros) en paquetes de 8bits (bytes)
  //El comando se envía en modo comando y sus parámetros en modo datos

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos el comando
  //Todos los parámetros deben pasarse en modo datos
  //Lo activamos ahora y nos aseguramos que quedará así al finalizar
  digitalWrite(_pinDC,HIGH);
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0) {
    //...enviamos el parámetro
    SPI.transfer(paramValue);
  }
  //Hemos terminado de trabajar con la lista
  va_end(paramList);
}

// Configura la rotación
void RoJoILI9341::rotation(byte r) {
  //     cualquier display                   M5Stack Fire
  // r : posición conectores : orientación : posición botones
  //---  -------------------   -----------   ----------------
  // 0 : abajo                 vertical      izquierda (*)
  // 1 : derecha               apaisado      abajo
  // 2 : arriba                vertical      derecha
  // 3 : izquierda             apaisado      arriba
  
  //Nos aseguramos que es un valor permitido
  r%=4;
  
  _startCOMM();
    //Memory access control
    //Código correspondiente a la rotación
    _writeCommand(0x36,_rotationCodes[r],-1);
    //Si la rotación es impar
    if(r%2) {
      //El formato será apaisado
      _xMax=_yMaxDefault;
      _yMax=_xMaxDefault;
    }
    else {
      //El formato será vertical
      _xMax=_xMaxDefault;
      _yMax=_yMaxDefault;
    }
  _endCOMM();
}

// Activa/Desactiva el modo hibernación
void RoJoILI9341::sleep(bool mode)
{
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startCOMM();
    if(mode) {
      _writeCommand(0x10,-1); //Sleep IN
      _writeCommand(0x28,-1); //Display OFF
      delay(5);
    }
    else {
      _writeCommand(0x29,-1); //Display ON
      _writeCommand(0x11,-1); //Sleep OUT
      delay(120);
    }
  _endCOMM();
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
void RoJoILI9341::_setCursorRangeY(int16_t y1,int16_t y2) {
  //0x2B=Page Address Set
  _writeCommand(0x2B,(byte)(y1>>8),(byte)(y1 & 0xFF),(byte)(y2>>8),(byte)(y2 & 0xFF),-1);
}
void RoJoILI9341::_setCursorRangeX(int16_t x1,int16_t x2) {
  //0x2A=Column Address Set
  _writeCommand(0x2A,(byte)(x1>>8),(byte)(x1 & 0xFF),(byte)(x2>>8),(byte)(x2 & 0xFF),-1);
  //Write memory
  _writeCommand(0x2C,-1);
}
void RoJoILI9341::_setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2) {
  _setCursorRangeY(y1,y2);
  _setCursorRangeX(x1,x2);
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoILI9341::block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color) {
  //Intercambiamos coordenadas erróneas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
  //Calculamos el área visible
  displayRange r=visibleRange(x1,y1,x2-x1+1,y2-y1+1);
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startCOMM();
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    for(uint16_t y=r.y1;y<=r.y2;y++)
      for(uint16_t x=r.x1;x<=r.x2;x++)
        SPI.transfer16(color);
  _endCOMM();
  
  //Tiene parte visible
  return true;
}

//Anchura de display (dummy)
uint16_t RoJoILI9341::xMax() {
  return _xMax;
}

//Altura de display (dummy)
uint16_t RoJoILI9341::yMax() {
  return _yMax;
}

//Reset & inicialización
void RoJoILI9341::reset() {
  //Hard reset
  digitalWrite(_pinRES,LOW);
  delay(20);
  digitalWrite(_pinRES,HIGH);
  delay(120);
  //En ILI9486 tras un hard reset se debe hacer un soft reset
  _startCOMM();
    _writeCommand(0x01,-1); //Comando soft reset
    delay(5);
  _endCOMM();

  //Comandos de inicialización
  //Comenzamos una transacción
  _startCOMM();
    //Power Control B
    //  Power Control: disabled
    //  Discharge path: enabled
    _writeCommand(0xCF,0x00,0x81,0x30,-1);
    //Power on sequence control.
    //  CP1 soft start: disabled
    //  En_vlc: 1st frame enabled
    //  En_ddvdh: 4th frame enabled
    //  En_vgh: 2nd frame enabled
    //  En_vgl: 3rd frame enabled
    //  DDVDH enhanced mode: enabled
    _writeCommand(0xED,0x64,0x03,0x12,0x81,-1);
    //Driver timing control A
    //  Gate driver non-overlap timing control: default + 1 unit
    //  EQ timing control: default - 1 unit
    //  CR timing control: default - 1 unit
    //  Pre-charge timing control: default - 2 unit
    _writeCommand(0xE8,0x85,0x00,0x78,-1);
    //Power Control A
    //  vcore control: 1.6V
    //  ddvdh control: 5.6V
    _writeCommand(0xCB,0x39,0x2C,0x00,0x34,0x02,-1);
    //Pump ratio control
    //  DDVDH: 2xVCI
    _writeCommand(0xF7,0x20,-1);
    //Driver timing control B
    //  VG_SW_T1. EQ to GND :0 unit
    //  VG_SW_T2. EQ to DDVDH: 0 unit
    //  VG_SW_T3. EQ to DDVDH: 0 unit
    //  VG_SW_T4. EQ to GND: 0 unit
    _writeCommand(0xEA,0x00,0x00,-1);
    //Power control 1
    //  GVDD level: 4.60V
    _writeCommand(0xC0,0x23,-1);
    //Power control 2
    //  Factor used in the step-up circuits: DDVDH=VCI x 2, VHG=VCI x 7, VGL=-VCI x 4
    _writeCommand(0xC1,0x10,-1);
    //VCOM control 1
    //  VCOMH: 4.250V
    //  VCOML: -1.500V
    _writeCommand(0xC5,0x3E,0x28,-1);
    //VCOM control 2
    //  nVM: 0
    //  VCOMH: VMH - 58, VCOML: VMH - 58
    _writeCommand(0xC7,0x86,-1);
    //Vertical Scrolling Start Address: 0
    _writeCommand(0x37,0x00,0x00,-1);
    //COLMOD. Pixel Format Set
    //  RGB interface format: 16 bits/pixel
    //  MCU interface format: 16 bits/pixel
    _writeCommand(0x3A,0x55,-1);
    //Frame Control (In Normal Mode/Full Colors)
    //  DIVA. Division ratio for internal clocks when Normal Mode: fosc
    //  RTNA. Frame Rate: 79 Hz = 24 clocks per line
    _writeCommand(0xB1,0x00,0x18,-1);
    //Display Function Control
    //  Gate outputs in non-display area: Interval scan
    //  Source outputs on non-display area. Positive polarity: V63
    //  Source outputs on non-display area. Negative polarity: V0
    //  VCOM output on non-display area. Positive polarity: VCOML
    //  VCOM output on non-display area. Negative polarity: VCOMH
    //  Scan Cycle: 5 frames
    //  Frequency FLM: 85ms
    //  Liquid crystal type: Normally white
    //  Gate Output Scan Direction & Sequence: G1 -> G320
    //  Source Output Scan Direction: S1 -> S720
    //  LCD Driver Line: 320 lines
    //  External fosc: undefined
    _writeCommand(0xB6,0x08,0x82,0x27,0x00,-1);
    //3 gamma control: disabled
    _writeCommand(0xF2,0x00,-1);
    //Gamma set: gamma curve 1
    _writeCommand(0x26,0x01,-1);
    //Positive Gamma Correction
    _writeCommand(0xE0,0x0F,0x32,0x2B,0x0C,0x0E,0x08,0x4E,0xF1,0x37,0x07,0x10,0x03,0x0E,0x09,0x00,-1);
    //Negative Gamma Correction
    _writeCommand(0xE1,0x00,0x0E,0x14,0x03,0x11,0x07,0x31,0xC1,0x48,0x08,0x0F,0x0C,0x31,0x36,0x0F,-1);
  _endCOMM();

  //Rotación 0: 240x320. Vertical. Conector abajo. En M5Stack Fire los botones a la izquierda
  rotation(0);
  //Borramos el display
  clear();
  //Salimos del modo de bajo consumo
  sleep(false);
}

//Dibuja un pixel
//Devuelve true si lo consigue si el pixel es visible
bool RoJoILI9341::drawPixel(int16_t x,int16_t y,uint16_t color) {
  //Si las coordenadas están fuera de rango...terminamos
  if(x<0 || x>=(int16_t)_xMax || y<0 || y>=(int16_t)_yMax) return false;

  _startCOMM();
    _setCursorRange(x,y,x,y);
    SPI.transfer16(color);
  _endCOMM();
  return true;
}

//Inicialización
void RoJoILI9341::begin(byte pinRES,byte pinDC,byte pinCS,byte pinBackLight,uint32_t freqCOMM) {
  //Este display tiene una profundidad de color de 16 bits (color)
  _colorDepth=16;
  //Si no se ha indicado frecuencia...utilizaremos la máxima
  if(!freqCOMM) freqCOMM=79999999; //<80 MHz
  //Definimos las caraterísticas de la conexión SPI
  _spiSetting=SPISettings(freqCOMM,MSBFIRST,SPI_MODE0);
  //Inicializamos las conexiones SPI
  SPI.begin();
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif

  //Guardamos los parámetros en variables internas
  _pinDC=pinDC;
  _pinRES=pinRES;
  _pinCS=pinCS;
  _pinBackLight=pinBackLight;
  //Siempre escribiremos en los pines DC, RES y CS
  pinMode(_pinDC,OUTPUT);
  pinMode(_pinRES,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinRES,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip
  //No hemos inicializado el pin de BackLight a propósito
  //Lo haremos cuando se utilice
  //Si se ha definido pin de backlight...la encendemos
  if(_pinBackLight<255) backLight(true);
  //Reseteamos el display
  reset();
  //Llamamos a la inicialización de la clase padre
  RoJoGraph::begin(); //Principalmente inicializa SPIFFS
}

// Inicia comunicación
void RoJoILI9341::_startCOMM() {
  SPI.beginTransaction(_spiSetting);
  digitalWrite(_pinCS,LOW);
}

// Finaliza comunicación
void RoJoILI9341::_endCOMM() {
  digitalWrite(_pinCS,HIGH);
  SPI.endTransaction();
}

//Dibuja un sprite en unas coordenadas
//Sobreescribe la información existente
bool RoJoILI9341::drawSprite(RoJoSprite *sprite,int16_t x,int16_t y) {
  //Calculamos el área visible
  displayRange r=visibleRange(x,y,sprite->xMax(),sprite->yMax());
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startCOMM();
    //Definimos el rango del cursor
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    //Calculamos el rango visible del sprite origen
    int16_t dx1=r.x1-x,dx2=r.x2-x,dy1=r.y1-y,dy2=r.y2-y;
    //Recorremos todas las filas visibles del sprite origen
    for(int16_t dy=dy1;dy<=dy2;dy++) {
      //Recorremos todas las columnas visibles del sprite origen y enviamos el color del pixel
      for(int16_t dx=dx1;dx<=dx2;dx++) SPI.transfer16(sprite->getPixel(dx,dy));
      #ifdef ESP8266
        yield(); //Refrescamos WatchDog
      #endif
    }
  _endCOMM();
  return true;
}

//Dibuja un sprite directamente de un archivo
byte RoJoILI9341::drawSprite(String filename,int16_t x,int16_t y) {
  //Este método no es imprescindible, puesto que ya está definido en RoJoGraph
  //Lo hacemos para optimizarlo

  //Tabla de errores (los primeros son los de infoSprite):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida
  //  3 : La profundidad de color no coincide con la del display

  //Declaración de variables
  uint16_t width,height; //Anchura y altura
  byte colorDepth; //Profundidad de color
  //Leemos los valores del archivo bmp
  byte errorCode=infoSprite(filename,&width,&height,&colorDepth);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Si la profundidad de color no coincide con la del display...terminamos con error
  if(_colorDepth!=colorDepth) return 3;

  //Calculamos el área visible
  displayRange r=visibleRange(x,y,width,height);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;

  uint16_t color;
  uint32_t rowLength=width*2; //Número de bytes que contiene una línea
  uint32_t offsetBase=5+2*(r.x1-x); //Offset de datos gráficos. Se la columna inicial
  uint32_t ry2=r.y2,rx2=r.x2,y32=y;

  //Nota:
  //Diferenciaremos si el sistema de archivos es SPIFFS o SD
  //Podemos utilziar la conexión SPI con el display al mismo tiempo que trabajamos con SPIFFS sin interferencias
  //Con una SD no es posible, porque ambos dispositivos utilizan la conexión SPI. Por lo tanto, tendremos
  //que asegurarnos de mantener sólo una conexión SPI en cada momento.
  //Si definimos un rango de dibujo en el display, lo recordará aunque finalicemos la transacción.
  //Incluso recordará la posición del cursor para la escritura del siguiente dato gráfico

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    _endCOMM();
    //Recorremos las filas visibles del display
    for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
      //Posicionamos offset en archivo
      f.seek(offsetBase+rowLength*(yy-y32));
      //Recorremos las columnas visibles del display
      for(uint32_t xx=r.x1;xx<=rx2;xx++) {
        //Leemos el color
        f.read((byte *)&color,2);
        //Dibujamos el pixel
        _startCOMM();
          SPI.transfer16(color);
        _endCOMM();
      }
    }
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
      //Recorremos las filas visibles del display
      for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
        //Posicionamos offset en archivo
        f.seek(offsetBase+rowLength*(yy-y32));
        //Recorremos las columnas visibles del display
        for(uint32_t xx=r.x1;xx<=rx2;xx++) {
          //Leemos el color
          f.read((byte *)&color,2);
          //Dibujamos el pixel
          SPI.transfer16(color);
        }
      }
    _endCOMM();
  #endif

  
  //hemos terminado de utilizar el archivo
  f.close();
  //Todo Ok
  return 0;
}

//Sincroniza dos sprites y envía las diferencias al display.
//Los sprites deben tener el mismo tamaño.
//Respuesta: true si todo es correcto
bool RoJoILI9341::drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x,int16_t y) {
  //Se detectan las diferencias entre los dos sprites y se escriben sobre el sprite destino
  //y se envían al display.
  //Finalmente el sprite destino queda igual que el origen.

  //Anotamos las medidas del sprite origen
  int16_t xMaxSprite=source->xMax();
  int16_t yMaxSprite=source->yMax();
  //Si los sprites tienen distinto tamaño...terminamos con error
  if(xMaxSprite!=(int16_t)destination->xMax() || yMaxSprite!=(int16_t)destination->yMax()) return false;
  //Comprobamos si tiene parte visible
  displayRange r=visibleRange(x,y,xMaxSprite,yMaxSprite);
  //Si no es visible...terminamos correctamente
  if(!r.visible) return true;
  //El sprite es total o parcialmente visible
  //En el display se dibujará el sprite en el rango: r.x1,r.y1,r.x2,r.y2
  //Se mostrará el siguiente rango del sprite: r.x1-x,r.y1-y,r.x2-x,r.y2-y
  //Es más sencillo recorrer las filas y columnas del sprite y si se detectan
  //diferencias, hacer la conversión a coordenadas de display
  
  //Calculamos la última fila y columna a procesar en el sprite
  //Reaprovechamos variables
  xMaxSprite=r.x2-x;
  yMaxSprite=r.y2-y;

  bool selectedRangeY; //Se ha seleccionado el rango vertical con la fila procesada?
  int16_t xSprite; //Columna procesada. Coordenada x del sprite
  _startCOMM();
    //Recorremos todas las filas visibles del sprite
    for(int16_t ySprite=r.y1-y;ySprite<=yMaxSprite;ySprite++) {
      //Por ahora no se ha inicializado el rango vertical para la fila actual
      selectedRangeY=false;
      //Comenzamos por la primera columna
      xSprite=r.x1-x;
      //Mientras no hayamos procesado todas las columnas...
      while(xSprite<=xMaxSprite) {
        //Si el pixel actual no se ha modificado...
        if(source->getPixel(xSprite,ySprite)==destination->getPixel(xSprite,ySprite)) {
          //...no tenemos en cuenta este pixel. Pasaremos al siguiente
          xSprite++;
        }
        else { //El pixel actual ha sido modificado...
          //Si no se ha seleccionado la fila actual...
          if(!selectedRangeY) {
		        //...lo hacemos ahora. Coinvertimos a coordenadas de display
		        _setCursorRangeY(y+ySprite,y+ySprite);
		        //y lo anotamos
		        selectedRangeY=true;
		      }
          //Consideramos este pixel como procesado
          //Actualizamos su valor en el sprite destino
          destination->drawPixel(xSprite,ySprite,source->getPixel(xSprite,ySprite));
          //Por ahora la última columna modificada es la primera
          int16_t lastChangedColumn=xSprite;
          //Columna procesada = la siguiente a la primera
          int16_t processedColumn=xSprite+1;
          //Mientras llevemos menos de 5 pixels sin modificar...
          while(processedColumn-lastChangedColumn<=5) {
            //Si el pixel de la columna procesada ha cambiado...
            if(source->getPixel(processedColumn,ySprite)!=destination->getPixel(processedColumn,ySprite)) {
              //...anotamos que la última columna con cambios es la actual
              lastChangedColumn=processedColumn;
              //Consideramos este pixel como procesado
              //Actualizamos su valor en el sprite destino
              destination->drawPixel(processedColumn,ySprite,source->getPixel(processedColumn,ySprite));
            }
            //Aumentamos la posición de la columna procesada
            processedColumn++;
          } //end while
          //Seleccionamos como rango horizontal desde la columna actual hasta la última modificada
          //Convertimos a coordenadas de display
          _setCursorRangeX(x+xSprite,x+lastChangedColumn);
          //Enviamos los datos gráficos
          for(int16_t x0=xSprite;x0<=lastChangedColumn;x0++) SPI.transfer16(source->getPixel(x0,ySprite));
          //La primera columna pasará a ser la actual
          xSprite=processedColumn;
        }
      }
      #ifdef ESP8266
        yield(); //Refrescamos WatchDog
      #endif
    }
  _endCOMM();
  //Todo Ok
  return true;
}

//Gestiona la luz de fondo
void RoJoILI9341::backLight(bool status) {
  //Suponemos que el pin está sin configurar. Lo hacemos ahora
  pinMode(_pinBackLight,OUTPUT);
  //Aplicamos el estado
  digitalWrite(_pinBackLight,status);
}

#endif

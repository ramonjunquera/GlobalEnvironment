/*
  Nombre de la librería: RoJoNeoPixel.h
  Versión: 20210524
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
*/

#ifndef RoJoNeoPixel_h
#define RoJoNeoPixel_h

#include <Arduino.h>
#include <RoJoSprite2.h> //Gestión de sprites

class RoJoNeoPixel {
  private:
    //Las placas Arduino (Mega, UNO, Nano) tienen un direccionamiento de 16 bits.
    //Pero ESP32 utiliza registros de 32 bits.
    #ifdef ARDUINO_ARCH_AVR //Placas Arduino: Mega, Uno, Nano
      uint16_t _pinCommPort; //Puerto del pin de comunicaciones
      byte _pinCommMask; //Máscara del bit en el puerto del pin de comunicaciones
    #else //Pacas ESP32 & ESP8266
      uint32_t _pinCommPort; //Puerto del pin de comunicaciones
      uint32_t _pinCommMask; //Máscara del bit en el puerto del pin de comunicaciones
    #endif
    uint16_t _xMax=0; //Tamaño horizontal
    uint16_t _yMax=0; //Tamaño vertical
    uint64_t _lastComm=0; //Tiempo en microsegundos de última comunicación
  public:
    RoJoSprite2 *v; //Puntero a sprite con la memoria de vídeo
    bool begin(uint16_t sizeX,uint16_t sizeY,byte pinComm); //Inicialización
    ~RoJoNeoPixel(); //Destructor
    void draw(); //Dibuja memoria actual
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoNeoPixel.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


/*
  Nombre de la librería: RoJoNeoPixel.h
  Versión: 20201226
  Autor: Ramón Junquera
  Descripción:
    Gestión de leds NeoPixel.
    Esta librería no está preparada para multitarea.
*/

#ifndef RoJoNeoPixel_cpp
#define RoJoNeoPixel_cpp

#include <RoJoNeoPixel.h>

//Inicialización
//Devuelve true si lo consigue
bool RoJoNeoPixel::begin(uint16_t sizeX,uint16_t sizeY,byte pinComm) {
  //Creamos y dimensionamos el sprite de la memoria de vídeo
  v=new RoJoSprite(24); //Sprite de color real
  if(!v) return false;
  if(!v->setSize(sizeX,sizeY)) return false;
  //El sprite de la memoria de vídeo se ha creado correctamente
  //Anotamos la dimensión en variables internas para no tener que hacerlo
  //en cada bucle
  _xMax=sizeX;
  _yMax=sizeY;

  //Definimos el puerto y el bit del pin de comunicaciones
  #ifdef ARDUINO_AVR_MEGA2560 //Si es una Mega
    //Tenemos 70 pines disponibles
    //Codificamos el puerto y el bit en un solo valor y lo guardamos en un array
    //Ya se ha tenido en cuenta el offset de algunos puertos (A,B,C,D,E,F,G)
    //de 32 bytes (0x20).
    //Utilizamos los 3 bits más bajos para guardar el bit del puerto
    //y el resto para guardar la dirección de memoria del puerto
    const uint16_t ports[] PROGMEM={368,369,372,373,421,371,2067,2068,2069,2070,300,301,302,303,2345,2344,2065,2064,347,346,345,344,272,273,274,275,276,277,278,279,327,326,325,324,323,322,321,320,351,418,417,416,2143,2142,2141,2140,2139,2138,2137,2136,299,298,297,296,392,393,394,395,396,397,398,399,2112,2113,2114,2115,2116,2117,2118,2119};
    _pinCommPort=ports[pinComm]>>3; //Calculamos la dirección del puerto
    _pinCommMask=1<<(ports[pinComm]&7); //Calculamos la máscara del pin en el puerto
  #elif defined(ARDUINO_AVR_NANO) || defined(ARDUINO_AVR_UNO) //Si es una Nano o UNO
    //Tenemos 20 pines disponibles
    //Codificamos el puerto y el bit en un solo valor y lo guardamos en un array
    //Ya se ha tenido en cuenta el offset de los puertos (B,C,D)
    //de 32 bytes (0x20).
    //Utilizamos los 3 bits más bajos para guardar el bit del puerto
    //y el resto para guardar la dirección de memoria del puerto
    const uint16_t ports[] PROGMEM={344,345,346,347,348,349,350,351,296,297,298,299,300,301,320,321,322,323,324,325};
    _pinCommPort=ports[pinComm]>>3; //Calculamos la dirección del puerto
    _pinCommMask=1<<(ports[pinComm]&7); //Calculamos la máscara del pin en el puerto
  #elif defined(ESP32)
    //Sólo utilizamos dos registros de 32 bits para controlar todos los
    //posibles pines.
    _pinCommPort=(pinComm<32)?0x3FF44004:0x3FF44010; //Calculamos la dirección del puerto
    _pinCommMask=(pinComm<32)?(1<<pinComm):(1<<(pinComm-32)); //Calculamos la máscara del pin en el puerto

    //Curioso!. Si no inicializamos el puerto serie, al llamar al método draw()
    //se activará el primer pixel en verde!!!!. No se porqué.
    Serial.begin(115200);
  #elif defined(ESP8266)
    //Para los 16 primeros pines [0,15] utilizamos un registro.
    //El pin 16 se gestiona en un registro independiente
    _pinCommPort=(pinComm<16)?0x60000300:0x60000768; //Calculamos la dirección del puerto
    _pinCommMask=(pinComm<16)?(1<<pinComm):1; //Calculamos la máscara del pin en el puerto
  #endif

  //Inicializamos pin de conexión con display
  pinMode(pinComm,OUTPUT);
  digitalWrite(pinComm,LOW);
  draw(); //Mostramos sprite (borramos display)
  return true; //Todo Ok
}

//Destructor
RoJoNeoPixel::~RoJoNeoPixel() {
  v->end(); //Liberamos la memoria ocupada por la memoria de vídeo
  _xMax=_yMax=0; //No tiene dimensión
}

//Muestra el sprite de momoria de vídeo
void RoJoNeoPixel::draw() {
  if(_xMax==0) return; //Si no se ha inicializado...hemos terminado
  //La comunicación con el controlador de los leds (NeoPixel) se realiza por un
  //único pin y de manera unidireccional: desde el dispositivo a NeoPixel.
  //Por eso inicializamos el pin en modo salida (OUTPUT).
  //Cuando no se transmite, el pin se encuentra en estado LOW.
  //Para transmitir un bit, activaremos el estado HIGH durante un tiempo (pulso).
  //La duración del pulso dependerá del valor que queramos transmitir.
  //Según las especificaciones del fabricante, los tiempos de pulso son:
  // - 0.4us para valor 0
  // - 0.8us para valor 1
  //Además entre dos pulsos debe transcurrir un tiempo mínimo de 1.25us
  //Si no se transmite nada en 300us se supone que ha finalizado la comunicación
  //Para transmitir un byte enviaremos consecutívamente los bits en orden MSB
  //(big endian). Desde el bit más significativo al que menos.
  //Puesto que algunos de los tiempos utilizados están por debajo del microsegundo,
  //no podemos utilizar la función micros para calcular las esperas.
  //En procesadores lentos tampoco podemos utilizar la función digitalWrite
  //porque es muy poco eficiente y pierde mucho tiempo. No se podría enviar
  //el pulso de 0 (0.4us).
  //Gestionamos el estado de los pines escribiendo directamente en los puertos.

  //Tenemos que transmitir la configuración actual
  //Debemos asegurarnos que han transcurrido al menos 300us desde la última
  //comunicación para que NeoPixel entienda que es una transferencia nueva.
  while(micros()-_lastComm<300);

  //Definición de variables
  byte currentChannel; //Byte de canal procesado
  byte maskChannel; //Máscara para procesar cada bit de cada canal
  RoJoColor color; //Color del pixel
  //La duración de los pulsos en muy corta y las rutinas de gestión de pulsos
  //deben estar muy optimizadas.
  //Recuperar el valor de una variable de clase es más lento que hacerlo de
  //una variable local. Por eso hacemos una copia de los datos necesarios
  //en variables locales.
  #ifdef ARDUINO_ARCH_AVR //Placas Arduino: Mega, Uno, Nano
    byte pinCommMask=_pinCommMask; //Máscara del pin en variable local
    volatile byte *pinCommPort=(byte*)_pinCommPort; //Puerto en variable local
  #else //Pacas ESP32 & ESP8266
    uint32_t pinCommMask=_pinCommMask; //Máscara del pin en variable local
    volatile uint32_t *pinCommPort=(uint32_t*)_pinCommPort; //Puerto en variable local
  #endif
  //Evitamos interrupciones durante el envío
  #ifndef ESP32 //Procesadores ESP8266 y Arduino: UNO, Nano, Mega
    noInterrupts();
  #else //ESP32
    portDISABLE_INTERRUPTS();
  #endif

  for(uint16_t y=0;y<_yMax;y++) { //Recorremos todas las filas
    for(uint16_t x=0;x<_xMax;x++) { //Recorremos todas las columnas
      color=v->getPixel(x,y); //Obtenemos el color del pixel
      //Intercambiamos los canales R y G porque la secuencia de envío de canales es GRB
      maskChannel=color.channels[0]; color.channels[0]=color.channels[1]; color.channels[1]=maskChannel;
      for(byte indexChannel=0;indexChannel<3;indexChannel++) {//Recorremos todos los canales
        currentChannel=color.channels[indexChannel]; //Obtenemos el byte a procesar
        maskChannel=0b10000000; //Calculamos la máscara del bit de mayor peso
        for(byte currentBit=0;currentBit<8;currentBit++) { //Recorremos los 8 bits del byte procesado
          //Debemos esperar 1.25us en pulso bajo antes de enviar un nuevo bit
          #ifdef ESP32
            //Nota:
            //Modelo   loops
            //CJMCU-64  19 
            //Atom      27
            //Resultado: tomamos el mayor = 27
            for(byte i=0;i<27;i++) {
              __asm__ __volatile__(
                "nop \n" // ciclo 1
              );
            }
          #elif defined(ESP8266)
            for(byte i=0;i<5;i++) {
              __asm__ __volatile__(
                "nop \n" // ciclo 1
              );
            }
          #endif
          if((maskChannel & currentChannel) > 0) { //Si debemos enviar un 1...
            //Necesitamos un pulso de 0.8us
            *pinCommPort |= pinCommMask; // digitalWrite(_pinComm,HIGH);
            #if defined(ARDUINO_AVR_MEGA2560) || defined(ARDUINO_AVR_UNO) //Mega o UNO
              __asm__ __volatile__(
                "nop \n" // ciclo 1
                "nop \n" // ciclo 2
              );
            #elif defined(ARDUINO_AVR_NANO) //Nano
              __asm__ __volatile__(
                "nop \n" // ciclo 1
                "nop \n" // ciclo 2
                "nop \n" // ciclo 3
              );
            #elif defined(ESP32) //ESP32
              //Nota:
              //Modelo   loops
              //CJMCU-64  19 
              //Atom      18
              //Resultado: tomamos el mayor = 19
              for(byte i=0;i<19;i++) {
                __asm__ __volatile__(
                  "nop \n" // ciclo 1
                );
              }
            #elif defined(ESP8266) //ESP8266
              for(byte i=0;i<5;i++) {
                __asm__ __volatile__(
                  "nop \n" // ciclo 1
                );
              }
            #endif
            *pinCommPort &= ~pinCommMask; // digitalWrite(_pinComm,LOW);
          } else { //Si debemos enviar un 0...
            //Necesitamos un pulso de 0.4us. En la práctica no es necesario
            *pinCommPort |= pinCommMask; // digitalWrite(_pinComm,HIGH);
            *pinCommPort &= ~pinCommMask; // digitalWrite(_pinComm,LOW);
          }
          maskChannel>>=1;
        }
      }
    }
  }
  //Reactivamos interrupciones
  #ifndef ESP32 //Procesadores ESP8266 y Arduino: UNO, Nano, Mega
    interrupts();
  #else //ESP32
    portENABLE_INTERRUPTS();
  #endif
  //Hemos terminado de enviar todos los bytes
  //No esperaremos los ciclos LOW posteriores al último pulso, porque ya se tienen
  //en cuenta tiempo de espera al inicio del proceso

  _lastComm=micros(); //Hemos finalizado el envío. Anotamos la hora actual
}

#endif

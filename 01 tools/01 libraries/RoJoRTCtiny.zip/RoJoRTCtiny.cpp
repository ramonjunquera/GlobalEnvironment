/*
  Nombre de la librería: RoJoRTCtiny.h
  Versión: 20191128
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC Tiny
    Clase derivada de RoJoRTC
*/

#ifndef RoJoRTCtiny_cpp
#define RoJoRTCtiny_cpp

#include <RoJoRTCtiny.h>

//Inicializa el RTC
bool RoJoRTCtiny::begin(int8_t pinSDA,int8_t pinSCL){
  _clockID=0x68; //Guardamos el identificador I2C
  #if defined(ARDUINO_ARCH_AVR) || defined(__arm__) //Si es una placa Arduino o RPi
    Wire.begin(); //No se pueden seleccionar los pines I2C
  #else //No es una placa Arduino
    if(pinSDA<0) Wire.begin(); //No hay pines seleccionados
    else Wire.begin(pinSDA,pinSCL); //Las placas ESP pueden seleccionar los pines I2C
  #endif
  //Habitualmente el bus I2C transmite con una frecuencia de 100KHz.
  //Con el siguiente comando lo incrementamos hasta 400KHz, si la placa lo permite.
  Wire.setClock(400000L);
  //Abrimos comunicación con el RTC
  Wire.beginTransmission(_clockID);
  //Se devuelve el resultado inverso al de fin de transmisión
  //Cuando una transmisión finaliza correctamente, devuelve false
  return !Wire.endTransmission();
}

//Obtiene la hora
void RoJoRTCtiny::get(RoJoDateTime *t) {
  Wire.beginTransmission(_clockID); //Abrimos comunicación con el RTC
    byte buffer=0;
    Wire.write(&buffer,1); //Escribimos un byte con valor 0x00 (reset pointer)
  Wire.endTransmission(); //Cerramos la comunicación (no tenemos más información que enviar)
  //Solicitamos 7 bytes del reloj: segundos, minutos, horas, día de la semana, día del mes, mes y año
  Wire.requestFrom(_clockID,(byte)7);
  //Anotamos cada uno de los valores en la estructura timeNow
  t->second=_bcd2dec(Wire.read()); //Leemos el byte de segundos
  //Nota: si los segundos > 128 quiere decir que el reloj está parado porque nunca se ha puesto en hora
  t->minute=_bcd2dec(Wire.read()); //Leemos el byte de minutos
  t->hour=_bcd2dec(Wire.read()); //Leemos el byte de horas
  t->weekDay=Wire.read(); //Leemos el byte de día de la semana. lun=0,dom=6
  t->day=_bcd2dec(Wire.read()); //Leemos el byte de día del mes
  t->month=_bcd2dec(Wire.read()); //Leemos el byte del mes
  t->year=2000+_bcd2dec(Wire.read()); //Leemos el byte del año (20xx)
}

//Fija la hora indicada en el reloj
//No tiene en cuenta el valor de día de la semana. Lo recalcula
void RoJoRTCtiny::set(RoJoDateTime *t) {
  uint32_t s=datetime2seconds(t); //Lo pasamos a segundos transcurridos desde 1900
  seconds2datetime(s,t); //...y lo volvemos a convertir en datetime
  //Ahora tenemos calculado también el día de la semana
  
  byte buffer[8]={
    0x00, //Reset pointer
    _dec2bcd(t->second), //segundos en bcd
    _dec2bcd(t->minute), //minutos en bcd
    _dec2bcd(t->hour), //horas en bcd
    t->weekDay, //día de la semana
    _dec2bcd(t->day), //día de mes en bcd
    _dec2bcd(t->month), //número de mes en bcd
    _dec2bcd(t->year%100) //dos últimos dígitos del año 20xx
  };
  Wire.beginTransmission(_clockID); //Abrimos comunicación con el RTC
    Wire.write(buffer,8);
  Wire.endTransmission(); //Cerramos la comunicación
  
}

#endif

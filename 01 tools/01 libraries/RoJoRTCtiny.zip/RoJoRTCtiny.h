/*
  Nombre de la librería: RoJoRTCtiny.h
  Versión: 20191120
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC Tiny
    Clase derivada de RoJoRTC
*/

#ifndef RoJoRTCtiny_h
#define RoJoRTCtiny_h

#include <Arduino.h>
#include <RoJoRTC.h> //Gestión de RTC genérico

class RoJoRTCtiny:public RoJoRTC {
  public:
    bool begin(int8_t pinSDA=-1,int8_t pinSCL=-1); //Inicializa el RTC
    void get(RoJoDateTime *t); //Obtiene la hora
    void set(RoJoDateTime *t); //Fijar fecha y hora
};

#ifdef __arm__
  #include <RoJoRTCtiny.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

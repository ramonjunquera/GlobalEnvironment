/*
  Nombre de la librería: RoJoSprite16.h
  Versión: 20180225
  Autor: Ramón Junquera
  Descripción:
    Gestión de sprites color 16bits
*/

#ifndef RoJoSprite16_h
#define RoJoSprite16_h

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
//#define UseSD

#include <Arduino.h>
#ifdef UseSD //Si debemos utilizar una terjeta SD...
  #define SPIFFS SD //Cuando referenciemos a SPIFFS se redireccionará a SD
  #include <SD.h> //Librería de gestión SD
#endif

class RoJoSprite16
{
  private:
    uint16_t *_bitmap; //Array de gráficos
    uint16_t _xMax,_yMax; //Anchura y altura en pixels
    void _copy(int16_t x,int16_t y,RoJoSprite16 *source,uint16_t invisibleColor,bool invisible); //Copia un sprite sobre otro
    byte _pinCS_SD; //Pin CS de SPI cuando utilizamos una SD
    const uint32_t _freq_SD=25000000; //Frecuencia de SPI de la SD = 25MHz
  public:
    RoJoSprite16(byte pinCS_SD=SS); //Constructor
    ~RoJoSprite16(); //Destructor
    uint16_t width();
    uint16_t height();
    void clean(); //Libera memoria ocupada por el array de gráficos
    void setSize(uint16_t x,uint16_t y); //Fija un nuevo tamaño para el sprite
    bool load(String fileName); //Carga la información del sprite desde un archivo
    uint16_t getPixel(uint16_t x,uint16_t y); //Devolvemos color
    void drawSprite(int16_t x,int16_t y,RoJoSprite16 *source,uint16_t invisibleColor); //Dibuja un sprite en unas coordenadas
    void drawSprite(int16_t x,int16_t y,RoJoSprite16 *source); //Dibuja un sprite en unas coordenadas
    void drawPixel(int16_t x,int16_t y,uint16_t color); //Guardamos color
    void save(String fileName); //Guarda la información del sprite en un archivo
	  void clear(uint16_t color); //Borra el sprite llenando el fondo de un color
    void clear(); //Borra el sprite pintando el fondo de negro
    void clear(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color); //Dibuja un rectángulo relleno de un color
    void clear(int16_t x1,int16_t y1,int16_t x2,int16_t y2); //Dibuja un rectángulo relleno negro
    void replaceColor(uint16_t source,uint16_t destination); //Cambia los pixels de un color por otro
    void resize(uint16_t width,uint16_t height,RoJoSprite16 *source); //Redimensiona un sprite
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color); //Dibuja una línea recta
    void rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t borderColor); //Dibuja un rectángulo
    byte pinCS_SD(); //Devuelve el pin CS de la SD
}; //Punto y coma obligatorio para que no de error

#endif


/*
  Nombre de la librería: RoJoSprite.h
  Versión: 20210211
  Autor: Ramón Junquera
  Descripción:
    Gestión de sprites
*/

#ifndef RoJoSprite2_cpp
#define RoJoSprite2_cpp

#include <RoJoSprite2.h>

//Libera el array de gráficos
void RoJoSprite2::end() {
  if(_yMax>0) { //Si contiene filas...
    for(int16_t row=_pageMax-1;row>=0;row--) free(_videoMem[row]); //Las borramos
    free(_videoMem); //Borramos array de punteros de filas
    _xMax=_yMax=0; //Ya no hay datos
  }
}

//Constructor
//Parámetros:
//- bytesPerPixel : 0=monocromo, 1=gris, 2=color, 3=color real
RoJoSprite2::RoJoSprite2(byte bytesPerPixel) {
  _bytesPerPixel=bytesPerPixel; //Anotamos los bytes por pixel
  _xMax=_yMax=0; //No contiene datos
}

//Fija un nuevo tamaño en pixels y profundidad de color para el sprite
//Devuelve true si lo consigue
bool RoJoSprite2::setSize(uint16_t x,uint16_t y) {
  if(x==0 || y==0) return false; //Si no tiene dimensión...terminamos con error
  begin(); //Llamamos a la inicialización de la clase padre
  end(); //Eliminamos cualquier sprite anterior

  uint32_t bytesPerRow;
  uint16_t pages=y; //Número de filas
  if(_bytesPerPixel) { //Si es un sprite color...
    bytesPerRow=x*_bytesPerPixel;
    pages=y;
  } else { //Si es un sprite monocromo...
    bytesPerRow=x;
    pages=y/8;
    if(y%8) pages++;
    y=8*pages;
  }

  byte *videoMemRow;
  _videoMem=(byte**)malloc(pages*sizeof(byte*));
  if(!_videoMem) return false; //Si no hay memoria...error
  for(int16_t row=pages-1;row>=0;row--) { //Reservaremos memoria para cada fila
    videoMemRow=(byte*)malloc(bytesPerRow); //Reservamos memoria para una fila
    if(!videoMemRow) { //Si no hay memoria...
      for(uint16_t i=row;i<pages;i++) free(_videoMem[i]); //Liberamos filas reservadas
      free(_videoMem); //Liberamos array de punteros de filas
      return false; //Error
    }
    memset((void*)videoMemRow,0,bytesPerRow); //Limpiamos la memoria reservada
    _videoMem[row]=videoMemRow; //La guardamos
  }
  //Guardamos los valores de dimensión
  _xMax=x;
  _yMax=y;
  _pageMax=pages;
  return true; //Todo Ok
}

//Destructor
RoJoSprite2::~RoJoSprite2() {
	end(); //Liberamos array de gráfico
}

//Anchura en pixels
uint16_t RoJoSprite2::xMax() {
  return _xMax;
}

//Altura en pixels
uint16_t RoJoSprite2::yMax() {
  return _yMax;
}

//Dibuja un pixel color. Función interna
//No se comprueba visibilidad y profundidad de color
void RoJoSprite2::_drawPixelColor(uint16_t x,uint16_t y,uint32_t color) {
  memcpy(&_videoMem[y][x*_bytesPerPixel],&color,_bytesPerPixel);
}

//Dibuja un pixel monocromo. Función interna
//No se comprueba visibilidad y profundidad de color
void RoJoSprite2::_drawPixelMono(uint16_t x,uint16_t y,bool color) {
  if(color) _videoMem[y/8][x]|=1<<(y%8); //Enciende pixel
  else _videoMem[y/8][x]&=~(1<<(y%8)); //Apaga pixel
}

//Dibuja un pixel. Función interna
//No se comprueba visibilidad
void RoJoSprite2::_drawPixel(uint16_t x,uint16_t y,uint32_t color) {
  if(_bytesPerPixel) _drawPixelColor(x,y,color);
  else _drawPixelMono(x,y,color);
}

//Dibuja un pixel
//Devuelve true si es visible
bool RoJoSprite2::drawPixel(int16_t x,int16_t y,uint32_t color) {
  displayRange r=visibleRange(x,y); //Comprobamos si es visible
  if(!r.visible) return false; //Si no es visible...terminamos
  //El punto tiene coordenadas dentro de los límites del sprite
  _drawPixel(x,y,color);
  //Todo ok
  return true;
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoSprite2::block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color) {
  //Mejora de la rutina de RoJoGraph en sprites color

  //Comprobamos si hay área visible
  displayRange r=visibleRange(&x,&y,&width,&height);
  //Si no es visible...terminamos
  if(!r.visible) return false;
  //El bloque tiene parte visible

  //Variables para acelerar los bucles
  uint16_t rx1=r.x1,rx2=r.x2,ry2=r.y2;

  if(_bytesPerPixel) { //Sprite color...
    byte *videoMemRow;
    //Recorremos todas las filas y columnas y dibujamos el pixel
    for(uint16_t row=r.y1;row<=ry2;row++) {
      videoMemRow=&_videoMem[row][rx1*_bytesPerPixel];
      for(uint16_t col=rx1;col<=rx2;col++) {
        memcpy(videoMemRow,&color,_bytesPerPixel);
        videoMemRow+=_bytesPerPixel;
      } 
    }
  } else { //Sprite monocromo...
    //Recorremos todas las filas y columnas y dibujamos el pixel
    for(uint16_t row=r.y1;row<=ry2;row++) {
      for(uint16_t col=rx1;col<=rx2;col++) {
        _drawPixelMono(col,row,color);
      } 
    }
  }
  return true; //Todo Ok
}

//Devolvemos color de un pixel
//Función privada. No comprueba visibilidad
uint32_t RoJoSprite2::_getPixel(uint16_t x,uint16_t y) {
  uint32_t color=0;
  if(_bytesPerPixel) memcpy(&color,&_videoMem[y][x*_bytesPerPixel],_bytesPerPixel); //Color
  else color=(_videoMem[y/8][x] & (1<<(y%8)))>0; //Monocromo
  return color;
}

//Devolvemos color de un pixel
//Si seleccionamos unas coordenadas fuera de rango, devuelve 0
uint32_t RoJoSprite2::getPixel(int16_t x,int16_t y) {
  //No comprobamos si el sprite está inicializado, porque en el constructor
  //se asigna un tamaño inicial de 0x0

  uint32_t color=0;
  //Comprobamos si es visible
  displayRange r=visibleRange(x,y);
  //Si el pixel es visible...copiamos su contenido a color
  if(r.visible) color=_getPixel(x,y);
  return color;
}

//Carga la información del sprite desde un archivo
//Devuelve error
byte RoJoSprite2::loadSprite(String filename) {
  //Tabla de errores (primeros errores como RoJoGraph2::drawSprite)
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida
  //  3 : No hay memoria suficiente para cargar el archivo

  uint16_t width,height;
  byte bytesPerPixel;
  byte errorCode=infoSprite(filename,&width,&height,&bytesPerPixel);
  if(errorCode) return errorCode;
  if(!setSize(width,height)) return 3;
  drawSprite(filename);
  return 0; //Todo Ok
}

//Carga un archivo bmp en el sprite
byte RoJoSprite2::loadBMP(String filename) {
  //Tabla de errores (los 8 primeros como RoJoGraph2::drawBMP)
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe.
  //  2 : La firma del tipo de archivo no coincide
  //  3 : Anchura demasiado grande
  //  4 : Altura demasiado grande
  //  5 : El número de planos no es 1
  //  6 : No tiene 24 bits por pixel (no es a color)
  //  7 : Está comprimido
  //  8 : La profundidad de color no coincide con la del display
  //  9 : No hay memoria suficiente para cargar el archivo

  //Nota, permitiremos cargar cualquier bmp sin importar su profundidad de color

  uint16_t width,height;
  byte bytesPerPixel;
  byte errorCode=infoBMP(filename,&width,&height,&bytesPerPixel);
  if(errorCode) return errorCode;
  if(!setSize(width,height)) return 9;
  drawBMP(filename);
  return 0; //Todo Ok
}

//Copia un sprite sobre el actual, en unas coordenadas.
//Suponemos que todo el área indicada es visible
//Suponemos que la profundidad de color coincide
void RoJoSprite2::_drawSprite2(RoJoSprite2 *source,int16_t x,int16_t y,displayRange *r,uint32_t invisibleColor,bool invisible) {
  //Ya suponemos que que ambos sprites tienen la misma profundidad de color
  #ifdef ESP8266
    //Desactivamos WatchDog porque vamos trabajar en memoria con bucles
    //sin refrescar interrupciones de WatchDog. Así evitaremos que falle
    ESP.wdtDisable();
  #endif

  uint32_t color=0;
  uint16_t ry2=r->y2,rx1=r->x1,rx2=r->x2;
  byte *offsetSource,*offsetDestination;
  uint32_t bytesPerRow;

  if(_bytesPerPixel) { //Si es color...
    bytesPerRow=(rx2-rx1+1)*_bytesPerPixel;
    for(uint16_t dy=r->y1;dy<=ry2;dy++) { //Recorremos las filas visibles del sprite destino
      offsetSource=&source->_videoMem[dy-y][(rx1-x)*_bytesPerPixel];
      offsetDestination=&_videoMem[dy][rx1*_bytesPerPixel];
      for(uint16_t dx=rx1;dx<=rx2;dx++) { //Recorremos las columnas visibles del sprite destino
        if(invisible) { //Si hay color invisible...
          //Obtenemos el color del pixel procesado del sprite origen
          memcpy(&color,offsetSource,_bytesPerPixel);
          //Si el color no es el invisible...lo copiamos
          if(color!=invisibleColor) memcpy(offsetDestination,offsetSource,_bytesPerPixel);
          offsetSource+=_bytesPerPixel;
          offsetDestination+=_bytesPerPixel;
        } else { //Si no hay un color invisible...
          memcpy(offsetDestination,offsetSource,bytesPerRow); //Copia directa
        }
      }
    }
  } else { //Si es monocromo...
    if(y%8) { //Si no se puede copiar por páginas...
      for(uint16_t row=r->y1;row<=ry2;row++) { //Recorremos las filas visibles del sprite destino
        for(uint16_t col=rx1;col<=rx2;col++) { //Recorremos las columnas visibles del sprite destino
          color=source->_getPixel(col-x,row-y);
          if(!invisible || color!=invisibleColor) _drawPixelMono(col,row,color);
        }
      }
    } else { //Si se puede copiar por páginas..
      uint16_t page0=y/8;
      uint16_t page1=r->y1>>3,page2=ry2>>3; //Calculamos página inicial y final visibles
      bytesPerRow=rx2-rx1+1;
      for(uint16_t page=page1;page<=page2;page++) {
        offsetDestination=&_videoMem[page][rx1];
        offsetSource=&source->_videoMem[page-page0][rx1-x];
        if(invisible) { //Si hay color invisible...
          if(invisibleColor) { //Si el color invisible es el 1...
            //El bucle se repite tantas veces como pixels visibles en una fila
            for(uint16_t i=bytesPerRow;i>0;i--) *(offsetDestination++)&=*(offsetSource++);
          } else {  //Si el color invisible es el 0...
            //El bucle se repite tantas veces como pixels visibles en una fila
            //Incrementamos los punteros de origen y destino en cada ejecución
            for(uint16_t i=bytesPerRow;i>0;i--) {
              *offsetDestination=(*offsetDestination & ~(*offsetSource)) | *offsetSource;
              offsetSource++; offsetDestination++;
            }
          }
        }
        //Si no hay color invisible...copiamos directamente
        else memcpy(offsetDestination,offsetSource,bytesPerRow);
      }
    }
  }
  
  #ifdef ESP8266
    //Reactivamos las interrupciones de WatchDog
    ESP.wdtEnable(1000);
  #endif
}

//Copia un sprite sobre el actual, en unas coordenadas.
//Se puede indicar un color como invisible
//Devuelve true si tiene parte visible
//Método privado
bool RoJoSprite2::_drawSprite1(RoJoSprite2 *source,int16_t x,int16_t y,uint32_t invisibleColor,bool invisible) {
  //Si la profundidad de color es distinta en el sprite actual y origen...terminamos con error
  if(_bytesPerPixel!=source->_bytesPerPixel) return false;
  displayRange r=visibleRange(x,y,source->_xMax,source->_yMax); //Comprobamos si hay área visible
  if(!r.visible) return false; //Si no es visible...terminamos con error
  _drawSprite2(source,x,y,&r,invisibleColor,invisible); //El sprite tiene área visible
  return true; //Todo Ok
}

//Copia un sprite sobre otro en unas coordenadas
//Devuelve true si escribe algo
bool RoJoSprite2::drawSprite(RoJoSprite2 *source,int16_t x,int16_t y) {
  return _drawSprite1(source,x,y);
}

//Copia un sprite sobre otro en unas coordenadas tomando un color como invisible
//Devuelve true si escribe algo
bool RoJoSprite2::drawSprite(RoJoSprite2 *source,int16_t x,int16_t y,uint32_t invisibleColor) {
  return _drawSprite1(source,x,y,invisibleColor,true);
}

//Dibuja un archivo .spr en unas coordenadas. No importa la profundidad de color.
//Sobreescribe la información existente
//Respuesta: código de error
byte RoJoSprite2::drawSprite(String filename,int16_t x,int16_t y) {
  //Tabla de errores (los primeros son los de infoSprite):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida

  //Declaración de variables
  uint16_t width,height; //Anchura y altura
  byte bytesPerPixel;
  //Leemos los valores del archivo bmp
  byte errorCode=infoSprite(filename,&width,&height,&bytesPerPixel);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Si la profundidad de color del archivo no coincide con la de la clase actual...
  //...utilizamos el método de RoJoGraph2, que es compatible con todo, aunque lento
  if(_bytesPerPixel!=bytesPerPixel) return RoJoGraph2::drawSprite(filename,x,y);
  //Seguro que la profundidad de color coincide
  //Escribiremos rutinas optimizadas

  //Calculamos el área visible
  displayRange r=visibleRange(x,y,width,height);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
  #endif
  //Suponemos que no hay errores de apertura en el archivo, porque lo hemos
  //probado hace un momento con infoSprite

  uint32_t bytesPerRow;
  uint16_t ry2=r.y2; //Optimización de bucles
  uint32_t offsetFile=5+r.x1-x; //Offset de archivo .spr incluido rx1
  uint32_t offsetX=r.x1*_bytesPerPixel;

  #ifdef ESP8266
    ESP.wdtDisable(); //Desactivamos WatchDog mientras dibujamos
  #endif

  if(bytesPerPixel) { //Si es un sprite color...
    uint32_t visibleBytesPerRow=(r.x2-r.x1+1)*_bytesPerPixel; //Número de bytes visibles que contiene una línea
    bytesPerRow=width*_bytesPerPixel; //Número de bytes que contiene una línea del sprite
    for(uint16_t row=r.y1;row<=ry2;row++) { //Recorremos las filas visibles del display
      f.seek(offsetFile+bytesPerRow*(row-y)); //Posicionamos offset en archivo
      //Leemos la fila visible completa directamente en la memoria de vídeo
      f.read(&_videoMem[row][offsetX],visibleBytesPerRow);
    }
  } else { //Si es un sprite monocromo...
    bytesPerRow=width; //Número de bytes que contiene una línea
    uint16_t page1=r.y1>>3,page2=ry2>>3; //Calculamos página inicial y final visibles
    uint16_t rx1=r.x1,ry1=r.y1,rx2=r.x2; //Optimización de bucles
    if(r.y1%8) { //No se puede tratar por páginas...
      byte value;
      uint16_t row;
      for(uint16_t page=page1;page<=page2;page++) { //Recorremos las páginas visibles del display
        f.seek(offsetFile+bytesPerRow*(page-page1)); //Posicionamos offset en archivo
        for(uint16_t col=rx1;col<=rx2;col++) { //Recorremos las columnas visibles del display
          value=f.read();
          for(byte rowInPage=0;rowInPage<8;rowInPage++) { //Recorremos las filas de la página
            row=(page<<3)+rowInPage+ry1; //Calculamos la fila
            //Si la fila es visible...dibujamos el pixel
            if(row<=ry2) _drawPixelMono(col,row,value & 1);
            else break; //Si esta fila ya no es visible...salimos del bucle
            value>>=1;
          }
        }
      }
    } else { //Se puede tratar por páginas...
      for(uint16_t page=page1;page<=page2;page++) { //Recorremos las páginas visibles del display
        f.seek(offsetFile+bytesPerRow*(page-page1)); //Posicionamos offset en archivo
        //Leemos la fila visible completa directamente en la memoria de vídeo
        f.read(&_videoMem[page][rx1],bytesPerRow);
      }
    }
  }

  #ifdef ESP8266
    ESP.wdtEnable(1000); //Reactivamos las interrupciones de WatchDog
  #endif
  
  f.close(); //Hemos terminado de utilizar el archivo
  return 0; //Todo Ok
}

//Cambia los pixels de un color por otro
//Sólo para sprites color
//Devuelve true si lo consigue
void RoJoSprite2::replaceColor(uint32_t source,uint32_t destination) {
  //Si los colores son iguales...no hay que hacer nada
  if(source==destination) return;

  uint32_t color=0;
  byte *_videoMemRow;
  for(int16_t y=_yMax-1;y>=0;y--) {
    _videoMemRow=_videoMem[y];
    for(int16_t x=_xMax-1;x>=0;x--) {
      memcpy(&color,_videoMemRow,_bytesPerPixel);
      //Si el color del pixel es el que buscamos...lo reemplazamos
      if(color==source) memcpy(_videoMemRow,&destination,_bytesPerPixel);
      _videoMemRow+=_bytesPerPixel;
    }
  }
}

//Crea un sprite con el texto indicado basado en una fuente
//Se indica el color del texto y de fondo (opcional)
//Respuesta: true si lo consigue
bool RoJoSprite2::print(String filenameFon,String text,uint32_t textColor,uint32_t backColor) {
  //Dimensiones del sprite
  uint16_t width,heigth;
  //Si no hemos podido calcular las dimensiones del texto...terminamos con error
  if(!infoPrint(filenameFon,text,&width,&heigth)) return false;
  //Si el sprite no tiene dimensión...terminamos con error
  if(width==0 || heigth==0) return false;
  //Fijamos el tamaño del sprite. Si no podemos...terminamos con error
  if(!setSize(width,heigth)) return false;
  //Fijamos el color de fondo
  clear(backColor);
  //Dibujamos el texto con la función de RoJoGraph y devolvemos respuesta
  return printOver(filenameFon,text,textColor);
}

//Crea un sprite con el texto indicado con borde basado en una fuente
//Se indica el color del texto, de fondo y del borde
//Respuesta: true si lo consigue
bool RoJoSprite2::print(String filenameFon,String text,uint32_t textColor,uint32_t backColor,uint32_t borderColor) {
  //Creamos el sprite que contendrá el texto sin bordes
  RoJoSprite2 textSprite(_bytesPerPixel);
  if(_bytesPerPixel) { //Si el sprite es color...
    //Si no podemos crear el sprite con el texto...terminamos con error
    if(!textSprite.print(filenameFon,text,borderColor,backColor)) return false;
    //Fijamos tamaño de sprite final
    //Será 2 pixels mayor que el del texto simple en cada dimensión
    setSize(textSprite._xMax+2,textSprite._yMax+2);
    //Lo pintamos del color de fondo
    clear(backColor);
    //Copiamos el sprite de texto con el fondo transparente movido un
    //pixel en cada una de las direcciones
    drawSprite(&textSprite,2,1,backColor);
    drawSprite(&textSprite,0,1,backColor);
    drawSprite(&textSprite,1,2,backColor);
    drawSprite(&textSprite,1,0,backColor);
    //Cambiamos el color del texto del sprite por el definitivo
    textSprite.replaceColor(borderColor,textColor);
    //Copiamos el sprite de texto con el fondo transparente en
    //la posición correcta
    drawSprite(&textSprite,1,1,backColor);
  } else { //El sprite es monocromo...
    //Si no podemos crear el sprite con el texto...terminamos con error
    if(!textSprite.print(filenameFon,text,1)) return false;
    //Fijamos tamaño de sprite final
    //Será 2 pixels mayor que el del texto simple en cada dimensión
    setSize(textSprite._xMax+2,textSprite._yMax+2);
    //Copiamos el sprite de texto con el fondo transparente movido un
    //pixel en cada una de las direcciones
    drawSprite(&textSprite,2,1,0);
    drawSprite(&textSprite,0,1,0);
    drawSprite(&textSprite,1,2,0);
    drawSprite(&textSprite,1,0,0);
    textSprite.negative();
    drawSprite(&textSprite,1,1,1);
    //Tenemos un sprite con fondo negro, borde blanco y texto negro
    //Si se quería con texto blanco...lo invertimos
    if(textColor) negative();
    //Con sprites monocromos no tenemos en cuenta los parámetros backColor & borderColor
  }
  //Ya no necesitamos el sprite de texto
  textSprite.end();
  //Todo Ok
  return true;
}

//Redimensiona un sprite
//Devuelve true si lo consigue
bool RoJoSprite2::resize(RoJoSprite2 *source,uint16_t width,uint16_t height) {
  uint16_t sourceSizeX=source->_xMax,sourceSizeY=source->_yMax,offsetY;
  //Si las medidas son las originales...simplemente lo copiamos
  if(sourceSizeX==width && sourceSizeY==height) copy(source);
  else { //Si las medidas cambian...
    //Borramos el sprite actual y creamos una nuevo con el tamaño indicado
    if(!setSize(width,height)) return false;;
    //Recorremos todas las filas
    for(int16_t y=height-1;y>=0;y--) {
      offsetY=(y*sourceSizeY)/height;
      //Recorremos todas las columnas
      for(int16_t x=width-1;x>=0;x--)
        //Calculamos el color del pixel procesado y lo aplicamos
        _drawPixel(x,y,source->_getPixel((x*sourceSizeX)/width,offsetY));
    }
  }
  return true;
}

//Guarda el sprite en un archivo
//Respuesta: true si se consigue
bool RoJoSprite2::save(String filename) {
  //Si no tiene dimensión...terminamos con error
  if(_xMax+_yMax==0) return false;

  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_WRITE); //Creamos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"w"); //Creamos el archivo en SPIFFS
  #endif
  //Si hubo algún problema...devolvemos error
  if(!f) return false;
  //Escribimos la profundidad de color
  f.write((_bytesPerPixel==0)?1:_bytesPerPixel*8); //Escribimos la profundidad de color
  f.write((byte *)&_xMax,2); //Escribimos la anchura
  f.write((byte *)&_yMax,2); //Escribimos la altura
  if(_bytesPerPixel) { //Si es un sprite color...
    uint32_t bytesPerRow=_xMax*_bytesPerPixel;
    for(uint16_t row=0;row<_yMax;row++) f.write(_videoMem[row],bytesPerRow);
  }
  //Si es un sprite monocromo...
  else for(uint16_t page=0;page<_pageMax;page++) f.write(_videoMem[page],_xMax);
  f.close(); //Cerramos el archivo
  return true; //Todo Ok
}

//Extrae parte de un sprite creando otro
//Respuesta: true si todo es correcto
bool RoJoSprite2::copy(RoJoSprite2 *source,int16_t x,int16_t y,int16_t width,int16_t height) {
  //Si los sprites tienen distinta profundidad de color...terminamos con error
  if(_bytesPerPixel!=source->_bytesPerPixel) return false;
  if(width==0 || height==0) { //Si no tiene dimensiones...
    //..tomaremos las dimensiones del sprite origen
    width=source->_xMax;
    height=source->_yMax;
  }
  displayRange r=source->visibleRange(&x,&y,&width,&height); //Comprobamos si hay área visible
  if(!r.visible) end(); //Si no es visible...vaciamos el sprite destino
  else { //Si es parcial o totalmente visible...
    uint16_t rx1=r.x1,rx2=r.x2,ry1=r.y1,ry2=r.y2;
    uint16_t pixelsPerRow=rx2-rx1+1;
    if(!setSize(pixelsPerRow,ry2-ry1+1)) return false; //Si falta memoria...terminamos con error
    if(_bytesPerPixel) { //Si es un sprite color...
      uint32_t offsetX=rx1*_bytesPerPixel;
      uint32_t bytesPerVisibleRow=_bytesPerPixel*pixelsPerRow;
      for(uint16_t row=ry1;row<=ry2;row++) { //Recorremos filas del sprite destino
        memcpy(_videoMem[row-ry1],&source->_videoMem[row][offsetX],bytesPerVisibleRow);
      }
    } else { //Si es un sprite monocromo...
      if(r.y1%8>0 || ry2%8>0) { //Si no se puede copiar por páginas...
        for(uint16_t row=ry1;row<=ry2;row++) {
          for(uint16_t col=rx1;col<=rx2;col++) {
            _drawPixel(col-rx1,row-ry1,source->_getPixel(col,row));
          }
        }
      } else { //Si se puede copiar por páginas...
        ry1>>=3; ry2>>=3;//Pasamos de filas a páginas
        for(uint16_t page=ry1;page<=ry2;page++) {
          memcpy(_videoMem[page-ry1],&source->_videoMem[page][rx1],pixelsPerRow);
        }
      }
    }
  }
  return true; //Todo Ok
}

//Crea un nuevo sprite rotando el origen
//El parámetro angle puede valer 90, 180 o 270 grados
//Devuelve código de error:
//  0 : no hay errores
//  1 : La profundidad de color es distinta para el origen y el destino
//  2 : El ángulo de rotación no es 90, 180 ni 270 grados
//  3 : No hay memoria suficiente
byte RoJoSprite2::rotate(RoJoSprite2 *source,uint16_t angle) {
  //Cuando se rota un sprite monocromo 90 o 270 grados, se ajusta la altura del
  //destino a páginas completas, por lo tanto puede aumentar su tamaño.
  //Por eso siempre se deben recorrer los pixels del origen, nunca del destino.
  if(_bytesPerPixel!=source->_bytesPerPixel) return 1;
  //Variables para optimizar los bucles
  uint16_t offset,_yMaxS=source->_yMax,_xMaxS=source->_xMax;
  switch (angle) {
    case 90:
      if(!setSize(_yMaxS,_xMaxS)) return 3;
      for(int16_t y=_yMaxS-1;y>=0;y--) {
        offset=_yMaxS-1-y;
        for(int16_t x=_xMaxS-1;x>=0;x--) _drawPixel(offset,x,source->_getPixel(x,y));
      }
      break;
    case 180:
      if(!setSize(_xMaxS,_yMaxS)) return 3;
      for(int16_t y=_yMax-1;y>=0;y--) {
        offset=_yMax-1-y;
        for(int16_t x=_xMax-1;x>=0;x--)
          _drawPixel(_xMax-1-x,offset,source->_getPixel(x,y));
      }
      break;
    case 270:
      if(!setSize(_yMaxS,_xMaxS)) return 3;
      for(int16_t x=_xMaxS-1;x>=0;x--) {
        offset=_xMaxS-1-x;
        for(int16_t y=_yMaxS-1;y>=0;y--) _drawPixel(y,offset,source->_getPixel(x,y));
      }
      break;
    default: //Ángulo desconocido
      return 2;
      break;
  }
  return 0; //Todo Ok
}

//Crea un nuevo sprite reflejado horizontalmente
//Devuelve código de error:
//  0 : no hay errores
//  1 : La profundidad de color es distinta para el origen y el destino
//  2 : No hay memoria suficiente
byte RoJoSprite2::flipH(RoJoSprite2 *source) {
  if(_bytesPerPixel!=source->_bytesPerPixel) return 1;
  if(!setSize(source->_xMax,source->_yMax)) return 2;
  for(int16_t y=_yMax-1;y>=0;y--) {
    for(int16_t x=_xMax-1;x>=0;x--) {
      _drawPixel(x,y,source->_getPixel(_xMax-x-1,y));
    }
  }
  return 0; //Todo Ok  
}

//Crea un nuevo sprite reflejado verticalmente
//Devuelve código de error:
//  0 : no hay errores
//  1 : La profundidad de color es distinta para el origen y el destino
//  2 : No hay memoria suficiente
byte RoJoSprite2::flipV(RoJoSprite2 *source) {
  if(_bytesPerPixel!=source->_bytesPerPixel) return 1;
  if(!setSize(source->_xMax,source->_yMax)) return 2;
  if(_bytesPerPixel) { //Si es un sprite color...lo volteamos por filas
    uint32_t bytesPerRow=_xMax*_bytesPerPixel;
    for(int16_t col=_yMax-1;col>=0;col--) { //Recorremos todas las filas
      memcpy(_videoMem[col],source->_videoMem[_yMax-col-1],bytesPerRow); //Copiamos la fila completa
    }
  } else { //Si es un sprite monocromo...lo volteamos pixel a pixel
    for(int16_t row=_yMax-1;row>=0;row--) {
      for(int16_t col=_xMax-1;col>=0;col--) {
        _drawPixel(col,row,source->_getPixel(col,_yMax-row-1));
      }
    }
  }
  return 0; //Todo Ok  
}

//Fusión de sprites
//Genera un sprite como combinación de dos (s1 y s2) en base a un nivel (0=s1,255=s2)
//Devuelve el código de error:
//  0: sin errores
//  1: sprite 1 y 2 tienen distintos tamaños
//  2: fallo al crear sprite respuesta
byte RoJoSprite2::fade(RoJoSprite2 *s1,RoJoSprite2 *s2,byte level) {
  uint16_t xMaxLocal=s1->_xMax; //Anotamos anchura de sprite 1
  uint16_t yMaxLocal=s1->_yMax; //Anotamos altura de sprite 1
  if(xMaxLocal!=s2->_xMax || yMaxLocal!=s2->_yMax) return 1; //Error. Deben tener el mismo tamaño
  if(!setSize(xMaxLocal,yMaxLocal)) return 2; //Error. No se puede crear el sprite de respuesta
  byte pixel1[3],pixel2[3];
  for(int16_t y=yMaxLocal-1;y>=0;y--) { //Recorremos todas las filas
    for(int16_t x=xMaxLocal-1;x>=0;x--) { //Recorremos todas las columnas
      s1->getColor(s1->_getPixel(x,y),&pixel1[0],&pixel1[1],&pixel1[2]);
      s2->getColor(s2->_getPixel(x,y),&pixel2[0],&pixel2[1],&pixel2[2]);
      for(byte channel=0;channel<3;channel++) { //Recorremos los tres canales de color de cada pixel
        pixel1[channel]+=(level*(pixel2[channel]-pixel1[channel]))/255;
      }
      _drawPixel(x,y,getColor(pixel1[0],pixel1[1],pixel1[2]));
    }
  }
  return 0; //Todo Ok
}

//Convierte la imagen a su negativo (sólo monocromo)
//Devuelve true si lo consigue
bool RoJoSprite2::negative() {
  if(_bytesPerPixel) return false; //Sólo para sprites monocromos
  byte *offsetPage;
  for(int16_t page=_pageMax-1;page>=0;page--) {
    offsetPage=_videoMem[page];
    for(int16_t x=_xMax-1;x>=0;x--) offsetPage[x]^=0xFF;
  }
  return true;
}

#endif

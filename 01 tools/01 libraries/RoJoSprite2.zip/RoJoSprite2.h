/*
  Nombre de la librería: RoJoSprite2.h
  Versión: 20210502
  Autor: Ramón Junquera
  Descripción:
    Gestión de sprites

    El sistema de archivos donde se guardan y leen los sprites es seleccionable
    mediante la constante global del preprocesador ROJO_PIN_CS_SD
    Estas constantes se definen en el archivo platformio.ini.

    Selección del sistema de archivos.
      Si se declara la constante ROJO_PIN_CS_SD y se le asigna un valor, se
      selecciona la SD como sistema de archivos.
      El valor de ROJO_PIN_CS_SD corresponde con el pin CS de la SD.
      Si no se declara esta constante, se utilizará SPIFFS.
      Ej.: build_flags = -D ROJO_PIN_CS_SD=15

    Tabla de compatibilidad de sistemas de archivos:

            SD SPIFFS
    Arduino SI NO
    ESP     SI SI
    RPi     NO SI

    Formatos de archivo
      sprite (.spr) monocromo
        offset: 0, len: 1, type: byte, info: color depth = 1
        offset: 1, len: 2, type: uint16_t, info: sprite width in pixels
        offset: 3, len: 2, type: uint16_t, info: sprite height in pixels
        offset: 5, len: 1, type: byte, info: data for page (0,0)
        offset: 6, len: 1, type: byte, info: data for page (1,0)
        ...

      sprite (.spr) grises
        offset: 0, len: 1, type: byte, info: color depth = 8
        offset: 1, len: 2, type: uint16_t, info: sprite width in pixels
        offset: 3, len: 2, type: uint16_t, info: sprite height in pixels
        offset: 5, len: 1, type: byte, info: color for pixel (0,0)
        offset: 6, len: 1, type: byte, info: color for pixel (1,0)
        ...

      sprite (.spr) color16
        offset: 0, len: 1, type: byte, info: color depth = 16
        offset: 1, len: 2, type: uint16_t, info: sprite width in pixels
        offset: 3, len: 2, type: uint16_t, info: sprite height in pixels
        offset: 5, len: 2, type: uint16_t, info: color for pixel (0,0)
        offset: 7, len: 2, type: uint16_t, info: color for pixel (1,0)
        ...
      
      sprite (.spr) color24
        offset: 0, len: 1, type: byte, info: color depth = 24
        offset: 1, len: 2, type: uint16_t, info: sprite width in pixels
        offset: 3, len: 2, type: uint16_t, info: sprite height in pixels
        offset: 5, len: 1, type: byte, info: color R for pixel (0,0)
        offset: 6, len: 1, type: byte, info: color G for pixel (0,0)
        offset: 7, len: 1, type: byte, info: color B for pixel (0,0)
        offset: 8, len: 1, type: byte, info: color R for pixel (1,0)
        ...

      fuente de texto (.fon)
        offset: 0, len: 1, type: byte, info: charMin
        offset: 1, len: 1, type: byte, info: charMax
        offset: 2, len: 1, type: byte, info: charPages
        offset: 3, len: 1, type: byte, info: charWidth for char 0 (=charMin)
        offset: 4, len: 2, type: uint16_t, info: charOffset = graphic data offset for char 0 (=charMin)
        offset: 6, len: 1, type: byte, info: charWidth for char 1
        offset: 7, len: 2, type: uint16_t, info: charOffset = graphic data offset for char 1
        ...
        offset: charOffset for char 0, len: charPages, type: byte, info: grafic data for char 0

  Notas:
  - Los colores en sprites monocromos tendrán el siguiente significado:
     0: borra
     1: dibuja
     2: invierte
     3: transparente, no cambia nada
     4 o mayor: sobreescribe la página completa
  - Se evita el uso de new/delete para la gestión de memoria. Cuando se solicita la reserva de más
    memoria de la disponible en ESP, se produce una excepción, y en Arduino deja el sistema inestable.
    Con malloc/free no ocurre esto. Simplemente devuelve un puntero nulo.
  - La memoria disponible para variables no está contenida en un único bloque de bytes contiguos.
    Habitualmente está fragmentada en distintos espacios. Por lo tanto, aunque el sistema muestre
    una cantidad de memoria disponible, no se podrá reservar toda ella en una única solicitud.
*/

#ifndef RoJoSprite2_h
#define RoJoSprite2_h

#include <Arduino.h>
#include <RoJoGraph2.h> //Funciones gráficas avanzadas

class RoJoSprite2:public RoJoGraph2 {
  protected:
    uint16_t _xMax,_yMax,_pageMax; //Anchura y altura en pixels y número de páginas
    void _drawPixelColor(uint16_t x,uint16_t y,uint32_t color); //Dibuja un pixel color
    void _drawPixelMono(uint16_t x,uint16_t y,bool color); //Dibuja un pixel monocromo
    void _drawPixel(uint16_t x,uint16_t y,uint32_t color); //Dibuja un pixel
    void _drawSprite2(RoJoSprite2 *source,int16_t x,int16_t y,displayRange *r,uint32_t invisibleColor,bool invisible); //Dibuja un sprite sobre otro
    bool _drawSprite1(RoJoSprite2 *source,int16_t x=0,int16_t y=0,uint32_t invisibleColor=0,bool invisible=false); //Dibuja un sprite sobre otro
    uint32_t _getPixel(uint16_t x,uint16_t y); //Devolvemos color de pixel
  public:
    byte **_videoMem; //Puntero a memoria de vídeo. Array de arrays de filas
    uint32_t getPixel(int16_t x,int16_t y); //Devolvemos color de pixel
    RoJoSprite2(byte bytesPerPixel=2); //Constructor
    void end(); //Libera el array de gráficos
    bool setSize(uint16_t x,uint16_t y); //Fija un nuevo tamaño
    virtual ~RoJoSprite2(); //Destructor
    virtual uint16_t xMax(); //Anchura en pixels
    virtual uint16_t yMax(); //Altura en pixels
    virtual bool drawPixel(int16_t x,int16_t y,uint32_t color); //Dibuja un pixel
    virtual bool block(int16_t x,int16_t y,int16_t width=1,int16_t height=1,uint32_t color=0);
    byte loadSprite(String filename); //Carga la información del sprite desde un archivo
    byte loadBMP(String filename); //Carga un archivo bmp en el sprite
    virtual bool drawSprite(RoJoSprite2 *source,int16_t x=0,int16_t y=0); //Dibuja un sprite en unas coordenadas
    virtual bool drawSprite(RoJoSprite2 *source,int16_t x,int16_t y,uint32_t invisibleColor); //Dibuja un sprite en unas coordenadas
    virtual byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo
    void replaceColor(uint32_t source,uint32_t destination); //Cambia los pixels de un color por otro
    bool print(String filenameFon,String text,uint32_t textColor,uint32_t backColor=0); //Crea sprite de texto
    bool print(String filenameFon,String text,uint32_t textColor,uint32_t backColor,uint32_t borderColor); //Crea un sprite de texto con borde
    bool resize(RoJoSprite2 *source,uint16_t width,uint16_t height); //Redimensiona un sprite
    bool save(String filename); //Guarda la información del sprite en un archivo
    bool copy(RoJoSprite2 *source,int16_t x=0,int16_t y=0,int16_t width=0,int16_t height=0); //Extrae parte de un sprite creando otro
    byte rotate(RoJoSprite2 *source,uint16_t angle);
    byte flipH(RoJoSprite2 *source); //Reflejo horizontal
    byte flipV(RoJoSprite2 *source); //Reflejo vertical
    byte fade(RoJoSprite2 *s1,RoJoSprite2 *s2,byte level); //Transición
    bool negative(); //Convierte la imagen a su negativo (sólo monocromo)
    bool setBytesPerPixel(byte bytesPerPixel);
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoSprite2.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


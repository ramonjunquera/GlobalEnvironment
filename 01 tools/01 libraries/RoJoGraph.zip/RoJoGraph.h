/*
  Nombre de la librería: RoJoGraph.h
  Versión: 20201126
  Autor: Ramón Junquera
  Descripción:
    Funciones gráficas avanzadas
*/

#ifndef RoJoGraph_h
#define RoJoGraph_h

#include <Arduino.h>
#ifdef ROJO_PIN_CS_SD //Si debemos utilizar SD...
  #ifdef __arm__ //Si es una Raspberry...
    #error Raspberry has not SD
  #endif
  //No es una Raspberry
  //Puede tener SD. Lo cargamos
  #include <SD.h> //Librería de gestión de SD
#else //Si debemos utilizar SPIFFS...
  #ifdef ARDUINO_ARCH_AVR //Si es una placa Arduino...
    #error Arduino family has not SPIFFS
  #endif
  //No es una placa Arduino. Puede tener SPIFFS
  //Cargamos la librería en función del dispositivo
  #ifdef ESP32 //Si es un ESP32...
    #include <SPIFFS.h> //Librería de gestión SPIFFS para ESP32
  #else //Si cualquier otra cosa (ESP8266 o RPi)...
    #include <FS.h> //Librería de gestión SPIFFS para ESP8266
  #endif
#endif

//Estructura para guardar rangos de pantalla
struct displayRange {
  bool visible=false;
  uint16_t x1;
  uint16_t x2;
  uint16_t y1;
  uint16_t y2;
};

//Estructura para color de 24 bits
struct RoJoColor {
  byte channels[3]; //Guardamos los canales de color en un simple array
  void set24(uint32_t c) { //Guardamos el color como uint32_t 0x--RRGGBB
    channels[2]=c && 0xFF; //B
    c>>=8;
    channels[1]=c && 0xFF; //G
    c>>=8;
    channels[0]=c && 0xFF; //R
  }
  void set16(uint16_t c) { //Guardamos el color como uint16_t 0bRRRRRGGGGGGBBBBB
    channels[0]=(c >> 8) & 0b11111000; //R
    channels[1]=(c >> 3) & 0b11111100; //G
    channels[2]=(c << 3) & 0b11111000; //B
  }
  uint32_t get24() { //Devolvemos color en uint32_t 0x--RRGGBB
    return ((uint32_t)channels[0])<<16 | ((uint32_t)channels[1])<<8 | (uint32_t)channels[2];
  }
  uint16_t get16() { //Devolvemos color en uint16_t 0bRRRRRGGGGGGBBBBB
    uint16_t c = channels[0] >> 3; //R
    c <<= 6; //Hacemos sitio para G
    c |= channels[1] >> 2; //G
    c <<= 5; //Hacemos sitio para B
    c |= channels[2] >> 3; //B
    return c;
  }
};

class RoJoGraph {
  private:
    void _ellipse(int16_t x,int16_t y,uint16_t rx,uint16_t ry,RoJoColor color,bool fill); //Dibuja una elipse
  protected:
    byte _colorDepth=0; //Profundidad de color. Inicialmente ninguna
  public:
    void begin(); //Inicialización
    virtual uint16_t xMax(); //Anchura de display (dummy)
    virtual uint16_t yMax(); //Altura de display (dummy)
    displayRange visibleRange(int16_t x,int16_t y,uint16_t xx,uint16_t yy); //Calcula el rango visible
    virtual bool drawPixel(int16_t x,int16_t y,RoJoColor color); //Dibuja un pixel (dummy)
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor color); //Dibuja una línea
    virtual bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor color); //Dibuja un rectángulo relleno
    virtual void clear(RoJoColor color); //Borra el área de dibujo
    virtual void clear(); //Borra el área de dibujo
    virtual bool rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor borderColor); //Dibuja un rectángulo sin relleno
    void triangle(int16_t x1,int16_t y1,int16_t x2,int16_t y2,int16_t x3,int16_t y3,RoJoColor borderColor); //Dibuja un triángulo sin relleno
    void triangleFill(int16_t x1,int16_t y1,int16_t x2,int16_t y2,int16_t x3,int16_t y3,RoJoColor fillColor); //Dibuja un triángulo relleno
    void circle(int16_t x,int16_t y,int16_t r,RoJoColor color); //Dibuja una circunferencia
    void disk(int16_t x,int16_t y,int16_t r,RoJoColor color); //Dibuja un círculo
    void ellipse(int16_t x,int16_t y,uint16_t rx,uint16_t ry,RoJoColor color); //Dibuja una elipse
    void ellipseFill(int16_t x,int16_t y,uint16_t rx,uint16_t ry,RoJoColor color); //Dibuja una elipse rellena
    byte infoBMP(String filename,uint16_t *width,uint16_t *height,byte *colorDepth); //Información de archivo BMP
    virtual byte drawBMP(String filename,int16_t x=0,int16_t y=0); //Dibuja un bmp directamente de un archivo
    byte infoSprite(String filename,uint16_t *width,uint16_t *height,byte *colorDepth); //Información de archivo de sprite
    virtual byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo
    bool printOver(String filenameFon,String text,RoJoColor textColor,int16_t x=0,int16_t y=0); //Imprime texto
    bool infoPrint(String filenameFon,String text,uint16_t *width,uint16_t *heigth); //Información sobre un texto

}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoGraph.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


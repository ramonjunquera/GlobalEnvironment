/*
  Nombre de la librería: RoJoList.h
  Autor: Ramón Junquera
  Fecha; 20181202
  Descripción:
    Gestión de listas
    El tipo del valor es seleccionable
*/

//Impedimos que se defina los métodos más de una vez
#pragma once

#include <Arduino.h>

template <class Tvalue>
struct RoJoListNode
{
  //Estructura de un nodo de la lista
  Tvalue *value;
  RoJoListNode *nextNode=nullptr;
};

template <class Tvalue>
class RoJoList
{
  private:  //Definición de métodos/variables privadas
    uint16_t _count=0; //Número de registros
    RoJoListNode<Tvalue> *firstNode=nullptr; //Puntero a nodo inicial
    RoJoListNode<Tvalue> *lastNode=nullptr; //Puntero a nodo final
  public: //Definición de métodos/variables públicas
    uint16_t count(); //Número de nodos en el diccionario
    bool add(Tvalue *value,uint16_t index=0); //Añade un nuevo nodo en cierta posición
    bool index(Tvalue **value,uint16_t index=0); //Obtiene el nodo de una posición
    void add2end(Tvalue *value); //Añade un nuevo nodo al final de la lista
    bool remove(uint16_t index=0); //Elimina un nodo de una posición
    void clear(); //Borra todos los nodos de la lista
    ~RoJoList(); //Destructor
    
}; //Punto y coma obligatorio para que no de error

#include "RoJoList.cpp" //Obligatorio cuando se utilizan clases con templates


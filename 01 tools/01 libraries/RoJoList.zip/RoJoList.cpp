/*
  Nombre de la librería: RoJoList.h
  Autor: Ramón Junquera
  Fecha; 20210412
  Descripción:
    Gestión de listas
    El tipo del valor es seleccionable
*/

#ifndef RoJoList_cpp
#define RoJoList_cpp

#include <RoJoList.h>

//Devuelve el número de nodos de la lista
template<class Tvalue>
uint16_t RoJoList<Tvalue>::count() {
  return _count;
}

//Obtiene el valor de un nodo
//Por defecto el primero
//Devuelve true si lo consigue
template<class Tvalue>
bool RoJoList<Tvalue>::index(Tvalue **value,uint16_t index) {
  //Inicialmente el valor es un puntero nulo
  *value=nullptr;
  //Si nos piden un item inexistente...no podemos devolverlo
  if(index>=_count) return false;
  //Nos piden un índice existente
  //Puntero de nodo procesado
  RoJoListNode<Tvalue> *node;
  //Inicialmente el primero
  node=firstNode;
  //Índice del nodo procesado
  uint16_t currentIndex=0;
  //Mientras el índice procesado no sea el que queremos...el nodo actual será el siguiente
  while(currentIndex++<index) node=node->nextNode;
  //Tenemos el nodo solicitado
  //Anotamos el valor
  *value=node->value;
  //Todo ok
  return true;
}

//Elimina un nodo de una posición
//Por defecto el primero
//Devuelve true si se consigue
template<class Tvalue>
bool RoJoList<Tvalue>::remove(uint16_t index) {
  //Si el índice solicitado es mayor que el número de nodos...no podemos borrarlo
  if(index>=_count) return false;
  //Si sólo hay un nodo...
  if(firstNode->nextNode==nullptr) {
    //Primero actualizamos punteros y después borramos el nodo!
    //Anotamos el puntero del único nodo
    RoJoListNode<Tvalue> *node=firstNode;
    //El primero y último nodo son nulos
    firstNode=lastNode=nullptr;
    //No tendremos nodos
    _count=0;
    //Borramos tanto el valor como el nodo
    delete node->value;
    delete node;
    //Lo hemos conseguido
    return true;
  }
  //Tenemos más de un nodo!

  //Si tenemos que borrar el primero...
  if(index==0) {
    //Anotamos el puntero del primer nodo
    RoJoListNode<Tvalue> *node=firstNode;
    //El primer nodo debe apuntar al segundo
    firstNode=firstNode->nextNode;
    //Tenemos un nodo menos
    _count--;
    //Borramos el antiguo primer nodo
    delete node->value;
    delete node;
    //Conseguido!
    return true;
  }
  //Tenemos más de un nodo y no queremos borrar el primero

  //Puntero de nodo procesado y nodo anterior
  RoJoListNode<Tvalue> *node,*previousNode;
  //Comenzamos desde el segundo
  node=firstNode->nextNode;
  previousNode=firstNode;
  //Índice del nodo procesado
  uint16_t currentIndex=1;
  
  //Mientras el índice procesado no sea el que queremos...saltamos al siguiente
  while(currentIndex++<index) {
    previousNode=node;
    node=node->nextNode;
  }
  //Tenemos el nodo solicitado

  //El nodo anterior apuntará al siguiente del actual
  previousNode->nextNode=node->nextNode;
  //Si el nodo era el último...el nodo previo será el último
  if(previousNode->nextNode==nullptr) lastNode=previousNode;
  //Tenemos un nodo menos
  _count--;
  //Borramos el nodo actual
  delete node->value;
  delete node;
  //Todo correcto
  return true;
}

//Borra todos los nodos de la lista
template<class Tvalue>
void RoJoList<Tvalue>::clear() {
  //Mientras haya items en el diccionario...borramos el primero
  while(_count) remove();
}

//Añade un nuevo nodo en cierta posición
//Por defecto, al principio
//Devuelve true si lo ha conseguido
template<class Tvalue>
bool RoJoList<Tvalue>::add(Tvalue *value,uint16_t index) {
  //Si el índice está fuera de rango...no se puede hacer
  if(index>_count) return false;
  //Creamos un nodo nuevo
  RoJoListNode<Tvalue> *node=new RoJoListNode<Tvalue>;
  //Anotamos su contenido
  node->value=value;
  //Si la lista está vacía...será el primero y último nodo
  if(_count==0) firstNode=lastNode=node;
  else { //La lista no está vacía
    //Si se quiere insertar en primera posición...
    if(index==0) {
      //El nodo nuevo apuntará al actual primero
      node->nextNode=firstNode;
      //El primer nodo será el nuevo
      firstNode=node;
    } else { //El nuevo nodo no es el primero
      //Si se quiere insertar en última posición...
      if(index==_count) {
        lastNode->nextNode=node;
        lastNode=node;
      } else { //El nuevo nodo no es el último
        //Debemos localizar el nodo previo. Comenzamos por el primero
        RoJoListNode<Tvalue> *previousNode=firstNode;
        uint16_t indexPrevious=0;
        while(indexPrevious<index-1) {
          previousNode=previousNode->nextNode;
          indexPrevious++;
        }
        //Tenemos el nodo previo localizado. Lo insertamos
        node->nextNode=previousNode->nextNode;
        previousNode->nextNode=node;
      }
    }
  }
  //Ya tenemos un nodo más
  _count++;
  //Todo Ok
  return true;
}

//Añade un nuevo nodo a la lista por el final
template<class Tvalue>
void RoJoList<Tvalue>::add2end(Tvalue *value) {
  add(value,_count);
}

//Destructor
template<class Tvalue>
RoJoList<Tvalue>::~RoJoList() {
  clear();
}

#endif
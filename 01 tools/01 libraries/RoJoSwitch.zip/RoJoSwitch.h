/*
  Nombre de la librería: RoJoSwitch.h
  Versión: 20190926
  Autor: Ramón Junquera
  Descripción:
    Gestión de un interruptor.
    Utiliza las resistencias PULL_UP internas.
    El interruptor debe ir conectado a tierra y al pin que lee su estado.
*/

#ifndef RoJoSwitch_h
#define RoJoSwitch_h

#include <Arduino.h>

class RoJoSwitch {
  private:
    //Pin en el que está conectado el interruptor
    byte _pinSwitch;
    //Momento del último cambio
    uint32_t long _lastTime=0;
    //Último estado comprobado. false = pulsado, true = soltado
    bool _lastStatus=true;
    //Guardará el flag de si ha ha sido pulsado
    bool _buttonPressed=false;
    //Guardará el flag de si ha sido soltado
    bool _buttonReleased=false;
    //Función que hace las comprobaciones y guarda los resultados en las variable privadas
    void _check();
  public:
    //Constructor. Se pasa el pin al que está conectado el pulsador. La otra pata del pulsador debe ir a GND
    RoJoSwitch(byte pin);
    //Tiempo de espera (en milisegundos) para evitar efecto rebote, tanto al pulsar como al soltar
    //Por defecto tiene un valor de una décima de segundo
    uint32_t delayTime=50;
    //Comprueba si ha sido pulsado
    bool pressed();
    //Comprueba si ha sido soltado
    bool released();
    //Devuelve el estado actual del interruptor
    bool pressing();
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoSwitch.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

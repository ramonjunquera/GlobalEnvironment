/*
  Nombre de la librería: RoJoSSD1306.h
  Versión: 20180221
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED I2C 0.96" 128x64 SSD1306

  Nota:
  El tamaño del buffer I2C de las distintas placas nos limita el número
  de bytes que podemos enviar en una petición.
  Tras muchas pruebas estos son los resultados:
    UNO/Nano:  16 bytes
    ESP8266:   30 bytes
    ESP32:     29 bytes
    RPi:      128 bytes
    
  Nota: En RPi el flujo del buffer de escritura lo gestiona la propia
  función, por lo tanto no tendría límite. Lo fijamos en 128 bytes que
  es la longitud de una fila.

  Nota:
  La memoria de vídeo del display es de 1Kb.
  El driver tiene una memoria de vídeo de trabajo (videoMem) y una memoria de vídeo del display (_videoMem)
  La memoria de vídeo de trabajo permite leer y escribir información directamente.
  La memoria de vídeo del display mantiene la información que se está mostrando en ese instante en el
  display (la última enviada).
  El método show() se encarga de sincronizar ambas. Las compara y envía solo las diferencias.
  Este sistema consige una tasa de refresco mucho más alta. El movimiento de un sprite por pantalla es
  muchísimo más rápido.
  Supnemos que lo que más ralentiza es el envío de la información por el bus I2C.
  Esto es cierto en placas rápidas (ESP/RPi). En placas lentas (Mega) la diferencia es mínima.
*/

#ifndef RoJoSSD1306_cpp
#define RoJoSSD1306_cpp

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
#define UseSD

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#ifdef UseSD //Si debemos utilizar una terjeta SD...
  #include "RoJoSSD1306SD.h"
  #include "RoJoSpriteSD.h"
#else //Si debemos utilizar SPIFFS
  #include "RoJoSSD1306.h"
  #include "RoJoSprite.h"
#endif

void RoJoSSD1306::begin(uint32_t freq)
{
  //Inicialización del display
  //Permite fijar la frecuencia

  //Activamos la conexión I2C
  Wire.begin();
  //Fijamos la frecuencia del bus I2C
  Wire.setClock(freq);
  
  //Secuencia de inicialización.
  //Creamos un buffer de bytes con todos los comandos
  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos

    ,0x8D //Rango de voltaje
    ,0x14 //Voltaje superior a 3.3V

    ,0x20 //Orden de escritura gráfica
    ,0x00 //Modo horizontal

    ,0xC8 //Orientación vertical con los pines de conexión en la parte superior
    ,0xA1 //Orientación horizontal. De izquierda a derecha 0-->128

    ,0xDA //Filas entrelazadas
    ,0x10 //Modo no entrelazado

    ,0x81 //Ajustamos el contraste
    ,0x00 //Al mínimo

    ,0xAF //Encendemos el display
  };

  //Enviamos el buffer por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar comandos

  //Llenamos la memoria de vídeo del display con datos
  for(byte x=0;x<xMax;x++) //Recorremos todas las columnas
    for(byte p=0;p<8;p++) //Recorremos todas las páginas
      _videoMem[p][x]=255; //Valor distinto a cero
  //Borramos la memoria de vídeo de trabajo
  clear();
  //Obligamos a refrescar y escribir la memoria de vídeo
  //Con esto conseguimos limpiar el display y sincronizar las memorias
  //de vídeo
  show();
  //Activamos el modo inverso. fondo=negro,dibujo=blanco
  reverse(true);
}

void RoJoSSD1306::clear()
{
  //Borra la memoria de vídeo pública

  for(byte x=0;x<xMax;x++) //Recorremos todas las columnas
    for(byte p=0;p<8;p++) //Recorremos todas las páginas
      videoMem[p][x]=0; //Lo borramos
}

void RoJoSSD1306::_setPage(byte page)
{
  //Selecciona la página en la que se encribirá la información gráfica

  //Secuencia de inicialización.
  //Creamos un buffer de bytes con todos los comandos
  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos

    ,0x22 //Comando para definir el rango de páginas que utilizaremos : [0,7]
    ,page //Desde la página indicada
    ,0x07 //Hasta la última (7)
  };

  Wire.beginTransmission(_oledId); //Abrimos comunicación con el display
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar datos
  _initSetPage=true; //Se ha inicializado la página actual
}

void RoJoSSD1306::_setColumn(byte column)
{
  //Selecciona la columna en la que se encribirá la información gráfica

  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos

    ,0x21 //Comando para definir el rango de columnas que utilizaremos: [0,127]
    ,column //Desde la columna indicada
    ,0x7F //Hasta la última (127)
  };
  
  Wire.beginTransmission(_oledId); //Abrimos comunicación con el display
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar datos
}

void RoJoSSD1306::_sendGraphicBytes(byte page,byte firstColumn,byte lastColumn)
{
  //Envía por I2C datos gráficos
  //Se supone que ya tenemos preparada la posición de escritura en el display

  //Calculamos el número de bytes a enviar
  byte len=lastColumn-firstColumn+2;
  //Creamos un buffer para guardar lo que queremos enviar
  byte buffer[len];
  //El primer valor es 0x40 para indicar que se enviarán datos
  buffer[0]=0x40;
  //Copiamos el resto de datos
  for(byte i=1;i<len;i++) buffer[i]=_videoMem[page][firstColumn+i-1];
  //Abrimos comunicación con el display
  Wire.beginTransmission(_oledId); 
  //Enviamos el buffer al display
  Wire.write(buffer,len);
  //Hemos terminado de enviar datos
  Wire.endTransmission(); 
}

void RoJoSSD1306::show()
{
  //Envía al display las diferencias entre la memoria de vídeo de 
  //trabajo y la del display

  byte c; //Columna
  
  for(byte p=0;p<8;p++) //Recorremos todas las páginas
  {
    //Por ahora no se ha inicializado SetPage para la página actual
    _initSetPage=false;
    //Comenzamos por la primera columna
    c=0;
    //Mientras no hayamos procesado todas las columnas...
    while(c<xMax)
    {
      //Si el byte actual no se ha modificado...
      if(videoMem[p][c]==_videoMem[p][c])
      {
        //...no tenemos en cuenta este byte. Pasaremos al siguiente
        c++;
      }
      else //El byte actual ha sido modificado y debe ser enviado
      {
        //Si no se ha inicializado SetPage...lo hacemos ahora
        if(!_initSetPage) _setPage(p);
        //Indicamos que el próximo byte a enviar se encuentra en esta columna
        _setColumn(c);
        //Consideramos este byte como procesado/enviado
        //Actualizamos su valor en la memoria de vídeo del display
        _videoMem[p][c]=videoMem[p][c];

        //Por ahora la última columna modificada es la primera
        byte lastChangedColumn=c;
        //Columna procesada = la siguiente a la primera
        byte processedColumn=c+1;
        //Mientras la columna procesada esté dentro del rango visible
        //y el rango de columnas sea inferior al máximo permitido por
        //el buffer I2C y llevamos menos de 5 bytes sin modificar...
        while(processedColumn<xMax && processedColumn-c<=_maxBufferLenthI2C && processedColumn-lastChangedColumn<=5)
        {
          //Si la columna procesada se debe enviar...
          if (videoMem[p][processedColumn]!=_videoMem[p][processedColumn])
          {
            //...anotamos que la última columna con cambios es la actual
            lastChangedColumn=processedColumn;
            //Consideramos este byte como procesado/enviado
            _videoMem[p][processedColumn]=videoMem[p][processedColumn];
          }
          //Aumentamos la posición de la columna procesada
          processedColumn++;
        } //end while
        //Los bytes a enviar irán desde la primera columna: c
        //hasta el último modificado: lastChangedColumn
        _sendGraphicBytes(p,c,lastChangedColumn);
        //La primera columna pasará a ser la actual
        c=processedColumn;
      }
    }
  }
  //La escritura de datos en el bus I2C consume bastantes 
  //recursos del procesador, porque gestiona un buffer de salida.
  //Si escribimos gran cantidad de datos contínuamente podemos conseguir 
  //que la rutina que gestiona la escritura I2C no permita que el proceso
  //del timer del WatchDog (WDT) se refresque.
  //Si WDT consigue terminar la cuenta supondrá que el programa se ha
  //bloqueado y a continuación provocará un reset por software que
  //reiniciará la placa.
  //Para evitar que esto ocurra incluimos aquí un refresco manual del WDT
  //La función yield() en placas Arduino es igual que ESP.wdtFeed() en
  //ESP8266
  yield();
}

void RoJoSSD1306::setPixel(int16_t x,int16_t y,byte color)
{
  //Dibuja un pixel
  //Color: 0 = lo activa, 1 = lo desactiva, 2 = lo invierte

  //Si no está en el rango visible...hemos terminado
  if(!_inScreen(x,y)) return;

  //Calculamos y aplicamos la máscara
  _mask(y/8,x,1<<(y%8),color);
}

bool RoJoSSD1306::getPixel(int16_t x,int16_t y)
{
  //Devuelve el estado de un pixel

  //Si no está en el rango visible...está apagado
  if(!_inScreen(x,y)) return false;
  //Las coordenadas son visibles
  return (videoMem[y/8][x] & (1<<(y%8)));
}

bool RoJoSSD1306::_inScreen(int16_t x,int16_t y)
{
  //Están las coordenadas dentro del rango visible?
  return  x>=0 && x<xMax && y>=0 && y<yMax;
}

void RoJoSSD1306::_mask(byte page,byte x,byte mask,byte color)
{
  //Aplica una máscara al byte de una página (de la memoria de vídeo)
  //Dependiendo del color
  //  color 0: borra
  //  color 1: dibuja
  //  color 2: invierte
  //  color 3: transparente
  //  color 4: sobrerescribe
  switch(color)
  {
    case 0: //Desactivar pixels
      videoMem[page][x]&=~mask;
      break;
    case 1: //Activar pixels
      videoMem[page][x]|=mask;
      break;
    case 2: //Invertir pixels
      videoMem[page][x]^=mask;
      break;
    case 4: //Escribe la máscara tal cual (sobreescribe)
      videoMem[page][x]=mask;
    default: //Cualquier otra opción
      break;
  }
}

void RoJoSSD1306::lineV(int16_t x,int16_t y1,int16_t y2,byte color)
{
  //Dibuja línea vertical
  //Es un método mucho más rápido que cualquier otra línea
  //Colores permitidos:
  //  color 0: borra
  //  color 1: dibuja
  //  color 2: invierte
  //  color 3: transparente
  
  //Si el color es transparente...hemos terminado
  if(color>2) return;

  //Si la columna está fuera de rango...hemos terminado
  if(x<0 || x>=xMax) return;
  //La columna está en un rango visible
   
  //Siempre se debe cumplir que y1<=y2
  if(y1>y2) _swap(&y1,&y2);

  //Si la recta no es visible...hemos terminado
  if(y1>=yMax || y2<0) return;
  //Toda o parte de la recta es visible

  //Recortamos la parte que no sea visible
  if(y1<0) y1=0;
  if(y2>=yMax) y2=yMax-1;

  //Calculamos las páginas del punto inicial y final
  byte p1=y1/8;
  byte p2=y2/8;
  //Calculamos el el offset de página inicial y final
  byte o1=y1%8;
  byte o2=y2%8;

  //Supongo que el high-bit del byte de una página está arriba
  //Si no es así, el desarrollo a partir de este punto no es válido

  //Si la recta comienza y termina en la misma página...
  if(p1==p2)
  {
    //...aplicamos el cambio sólo a byte de esa página
    _mask(p1,x,(1<<(o2+1))-(1<<o1),color);
  }
  else //La recta no comienza y termina en la misma página
  {
    //Calculamos byte de página de inicio
    _mask(p1,x,256-(1<<o1),color);
    //Calculamos byte de página de fin
    _mask(p2,x,(1<<(o2+1))-1,color);
    //Rellenamos las páginas intermedias (si las hay)
    for(byte p=p1+1;p<p2;p++) _mask(p,x,255,color);
  }
}

void RoJoSSD1306::_swap(int16_t *a,int16_t *b)
{
  //Intercambia los valores de dos variables enteras
  int t=*a;*a=*b;*b=t;
}

void RoJoSSD1306::_lineH(int16_t y,int16_t x1,int16_t x2,byte color,bool withoutBorder)
{
  //Dibuja linea horizontal
  //Si withoutBorder es true no se diburajá el primer y último punto
  //  color 0: borra
  //  color 1: dibuja
  //  color 2: invierte
  //  color 3: transparente

  //Si el color es transparente...hemos terminado
  if(color>2) return;

  //Si la fila está fuera de rango...hemos terminado
  if(y<0 || y>=yMax) return;
  //La fila está en un rango visible
   
  //Siempre se debe cumplir que x1<=x2
  if(x1>x2) _swap(&x1,&x2);

  //Si debemos quitar los puntos extremos...
  if(withoutBorder)
  {
    x1++; x2--;
    //Si la línea no tiene puntos...hemos terminado
    if(x1>x2) return;
  }

  //Si la recta no es visible...hemos terminado
  if(x1>=xMax || x2<0) return;
  //Toda o parte de la recta es visible

  //Recortamos la parte que no sea visible
  if(x1<0) x1=0;
  if(x2>=xMax) x2=xMax-1;

  //Calculamos la páginas de la recta
  byte page=y/8;
  //Calculamos la máscara
  byte mask=1<<(y%8);

  //Recorremos todas las columnas visibles de la recta
  for(byte x=x1;x<=x2;x++) _mask(page,x,mask,color);
}

void RoJoSSD1306::lineH(int16_t y,int16_t x1,int16_t x2,byte color)
{
  //Dibuja línea horizontal
  _lineH(y,x1,x2,color,false);
}

void RoJoSSD1306::_rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte fillColor,bool withoutBorder)
{
  //Dibuja un rectángulo relleno
  //Si withoutBorder es true, no de dibujará la línea de perímetro
  //Colores permitidos:
  //  color 0: borra
  //  color 1: dibuja
  //  color 2: invierte
  //  color 3: transparente

  //Si el color es transparente...hemos terminado
  if(fillColor>2) return;

  //Siempre se debe cumplir que y1<=y2 y x1<=x2
  if(y1>y2) _swap(&y1,&y2);
  if(x1>x2) _swap(&x1,&x2);

  //Si no debemos dibujar los bordes..
  if(withoutBorder)
  {
    //..reducimos en uno los límites del rectángulo
    x1++; x2--; y1++; y2--;
    //Si el rectángulo no tiene área...hemos terminado
    if(x1>x2 || y1>y2) return;
  }
  
  //Si el rectángulo no es visible...hemos terminado
  if(x1>=xMax || x2<0 || y1>=yMax || y2<0) return;
  //Todo o parte del rectángulo es visible

  //Recortamos la parte que no sea visible
  if(x1<0) x1=0;
  if(x2>=xMax) x2=xMax-1;
  if(y1<0) y1=0;
  if(y2>=yMax) y2=yMax-1;

  //Recorremos todas las columnas y dibujamos las rectas verticales
  for(byte x=x1;x<=x2;x++) lineV(x,y1,y2,fillColor);
}

void RoJoSSD1306::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte fillColor)
{
  //Dibuja un rectángulo relleno
  _rect(x1,y1,x2,y2,fillColor,false);
}

void RoJoSSD1306::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte fillColor,byte borderColor)
{
  //Dibuja rectángulo con borde y relleno
  //Colores permitidos:
  //  color 0: borra
  //  color 1: dibuja
  //  color 2: invierte
  //  color 3: transparente

  //Si tiene borde..
  if(borderColor<3)
  {
    //..lo dibujamos
    _lineH(y1,x1,x2,borderColor,true);
    _lineH(y2,x1,x2,borderColor,true);
    if(abs(y1-y2)>0)
    {
      lineV(x1,y1,y2,borderColor);
      lineV(x2,y1,y2,borderColor);
    }
    
  }
  //Si no tiene relleno..hemos terminado
  if(fillColor>2) return;
  
  //Dibujamos el relleno
  _rect(x1,y1,x2,y2,fillColor,true);
}

void RoJoSSD1306::line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte color)
{
  //Dibuja una línea utilizando el algoritmo de Bresenham

  const bool steep=abs(y2-y1)>abs(x2-x1);
  
  if(steep)
  {
    _swap(&x1,&y1);
    _swap(&x2,&y2);
  }
 
  if(x1>x2)
  {
    _swap(&x1,&x2);
    _swap(&y1,&y2);
  }
 
  int16_t dx=x2-x1;
  int16_t dy=abs(y2-y1);
 
  int16_t err=dx/2;
  const int16_t ystep=y1<y2?1:-1;
 
  for(;x1<x2;x1++)
  {
    if(steep) setPixel(y1,x1,color);
    else setPixel(x1,y1,color);
 
    err-=dy;
    if(err<0)
    {
      y1+=ystep;
      err+=dx;
    }
  }
}

void RoJoSSD1306::drawSpritePage(int16_t x,int16_t page,RoJoSprite *sprite,byte color)
{
  //Dibuja un sprite en una página y columna
  //Colores permitidos:
  //  color 0: borra
  //  color 1: dibuja
  //  color 2: invierte
  //  color 3: transparente
  //  color 4: sobrerescribe

  int16_t xScreen,pageScreen;

  //Recorremos las páginas
  for(uint16_t pageCount=0;pageCount<(*sprite).heightPages();pageCount++)
  {
    //Calculamos la página de pantalla
    pageScreen=page+pageCount;
    //Si es visible...
    if(pageScreen>=0 && pageScreen <8)
    {
      //Recorremos todas las columnas
      for(uint16_t xCount=0;xCount<(*sprite).width();xCount++)
      {
        //Calculamos la columna de pantalla
        xScreen=x+xCount;
        //Si está dentro de la pantalla...
        if(xScreen>=0 && xScreen<128)
        {
          //Dibujamos el byte
          _mask(pageScreen,xScreen,(*sprite).getPage(xCount,pageCount),color);
        }
      }
    }
  }
}

void RoJoSSD1306::drawSprite(int16_t x,int16_t y,RoJoSprite *sprite,byte color)
{
  //Dibuja un sprite en unas coordenadas
  //Colores permitidos:
  //  color 0: borra
  //  color 1: dibuja
  //  color 2: invierte
  //  color 3: transparente

  //Si el color es transparente...hemos terminado
  if(color>2) return;

  //Recorremos todas las filas
  for(uint16_t yCount=0;yCount<(*sprite).heightPages()*8;yCount++)
  {
    //Recorremos todas las columnas
    for(uint16_t xCount=0;xCount<(*sprite).width();xCount++)
    {
      //Si el pixel está activo..lo dibujamos en el display
      if((*sprite).getPixel(xCount,yCount)) setPixel(x+xCount,y+yCount,color);
    }
  }
}

void RoJoSSD1306::reverse(bool reverseMode)
{
  //Fija el display en modo invertido/normal (blanco <-> negro)
  //Por defecto se encuentra en modo invertido
  //  reverseMode = false -> pixel encendido = negro
  //  reverseMode = true  -> pixel encendido = blanco
  
  //Secuencia de inicialización.
  //Creamos un buffer de bytes con todos los comandos
  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos
    ,(byte)(reverseMode?0xA6:0xA7) //Dependiendo del parámetro aplicamos un modo u otro
  };
  //Enviamos el buffer por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar comandos
}

void RoJoSSD1306::getSprite(int16_t x1,int16_t page1,int16_t x2,int16_t page2,RoJoSprite *sprite)
{
  //Toma parte de la memoria de vídeo para crear un sprite

  //Borramos el sprite
  (*sprite).clean();
  //Siempre se debe cumplir que x1<=x2
  if(x1>x2) _swap(&x1,&x2);
  //Siempre se debe cumplir que page1<=page22
  if(page1>page2) _swap(&page1,&page2);
  //Si está fuera de pantalla...hemos terminado
  if(x1>=128 || x2<0 || page1>=8 || page2<0) return;
  //Recortamos las zonas no visibles
  if(x1<0) x1=0;
  if(x2>=128) x2=127;
  if(page1<0) page1=0;
  if(page2>=8) page2=7;
  //Dimensionamos el sprite
  uint16_t spriteWidth=x2-x1+1;
  uint16_t spritePages=page2-page1+1;
  (*sprite).setSize(spriteWidth,spritePages);
  //Copiamos el contenido de pantalla al sprite
  for(byte x=0;x<spriteWidth;x++)
    for(byte page=0;page<spritePages;page++)
      (*sprite).drawPage(x,page,videoMem[page1+page][x1+x],4); //4=sobreescribiendo
}

#endif

/*
  Nombre de la librería: RoJoSSD1306.h
  Versión: 20180524
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED I2C 0.96" 128x64 SSD1306
*/

#ifndef RoJoSSD1306_h
#define RoJoSSD1306_h

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
#define UseSD

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#ifdef UseSD //Si debemos utilizar una terjeta SD...
  #include "RoJoSpriteSD.h"
#else //Si debemos utilizar SPIFFS
  #include "RoJoSprite.h"
#endif

class RoJoSSD1306
{
  private:
    //Identificador del display en en bus I2C
    const byte _oledId=0x3C;
    //Máximo número de bytes a enviar por I2C en una petición.
    //Depende de la placa
    #ifdef ESP8266
      const byte _maxBufferLenthI2C=30; //para ESP8266
    #elif defined(ESP32)
      const byte _maxBufferLenthI2C=29; //para ESP32
    #elif defined(ARDUINO_ARCH_AVR)
      const byte _maxBufferLenthI2C=16; //para placas Arduino
    #else
      const byte _maxBufferLenthI2C=128; //para RPi
    #endif    
    //Se ha inicializado la página actual?
    bool _initSetPage;
    //Indica la página en la que se escribirá la información gráfica
    void _setPage(byte page);
    //Indica la columna en la que se escribirá la información gráfica
    void _setColumn(byte column);
    //Envía datos de gráficos
    void _sendGraphicBytes(byte page,byte firstColumn,byte lastColumn);
    //La memoria de vídeo interna es un sprite
    RoJoSprite *_videoMem;
  public:
    const byte xMax=128; //Anchura de display en pixels
    const byte pagesMax=8; //Altura de display de páginas
    const byte yMax=8*pagesMax; //Altura de display en pixels
    //La memoria de vídeo es un sprite
    RoJoSprite *videoMem;
    //Inicialización
    void begin(byte pinCS_SD=SS,byte pinSDA=255,byte pinSCL=255,byte pinRST=255);
    //Envía memoria de vídeo al display
    void show();
    //Fija el display en modo invertido (blanco <-> negro)
    void reverse(bool reserveMode);
    //Destructor
    ~RoJoSSD1306();
}; //Punto y coma obligatorio para que no de error

#endif


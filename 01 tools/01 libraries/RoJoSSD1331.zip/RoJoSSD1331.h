/*
  Nombre de la librería: RoJoSSD1331.h
  Versión: 20190627
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 0.95" 96x64 SSD1331
    Permite la gestión de sprites
*/

#ifndef RoJoSSD1331_h
#define RoJoSSD1331_h

#include <Arduino.h>
#include <RoJoDisplayDriver.h>

class RoJoSSD1331:public RoJoDisplayDriver
{
  private:
    uint32_t _maxFreqSPI(); //Máxima frecuencia SPI soportada por el display
    void _setCursorRangeX(int16_t x1,int16_t x2); //Define rango X
    void _setCursorRangeY(int16_t y1,int16_t y2); //Define rango Y
    const byte _xMax=96; //Anchura de display
    const byte _yMax=64; //Altura de display
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _fill(bool f); //Activa/desactiva el relleno de los rectángulos
    void _rect(byte x1,byte y1,byte x2,byte y2,byte borderR,byte borderG,byte borderB,byte fillR,byte fillG,byte fillB); //Dibuja un rectángulo. Función interna
  public:
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void reset();
    //Dibuja un pixel
    bool drawPixel(int16_t x,int16_t y,uint16_t color);
    //Dibuja un rectángulo con borde y relleno
    bool rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte borderR,byte borderG,byte borderB,byte fillR,byte fillG,byte fillB);
    bool rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t borderColor,uint16_t fillColor);
    //Dibuja un rectángulo sin relleno
    bool rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte borderR,byte borderG,byte borderB);
    bool rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t borderColor);
    //Copia un área en otra
    void copy(byte x1,byte y1,byte x2,byte y2,byte x3,byte y3);
    //Hace una zona más oscura
    void darker(byte x1,byte y1,byte x2,byte y2);
    //Dibuja una línea
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte r,byte g,byte b);
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color);
    bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte r,byte g,byte b); //Dibuja un rectángulo relleno de un color
    bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color=0); //Dibuja un rectángulo relleno de un color
    void sleep(bool mode); //Activa/Desactiva modo hibernación
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoSSD1331.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


/*
  Nombre de la librería: RoJoSSD1331.h
  Versión: 20190906
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 0.95" 96x64 SSD1331

  La siguiente librería permite la gestión del display a través de los
  pines del bus SPI controlados por hardware.

  Todas las funciones escriben directamente sobre el display.
  No se utiliza ninguna técnica de buffer (simple o doble) para reducir
  la tasa de transferencia por SPI.
  Los dispositivos con suficiente memoria podrán hacerlo gracias a
  la compatibilidad con RoJoSprite.

  Este modelo de display incluye algunas funciones gráficas integradas
  para dibujar líneas o rectángulos.
  La librería permite utilizar todas las funciones integradas.
  
  Nota:
  La librería no tiene en cuenta los pines CS controlados por hardware.
  Se puede definir cualquier pin para CS porque se gestiona por software.
  En placas ESP estos pines se pueden desactivar.
  En Raspberry no. Esto quiere decir que RPi siempre seguirá gestionando
  el pin CS que tenga activo en ese momento.
  La ventaja de definir el pin CS por software es que podemos tener
  varios dispositivos SPI conectados a distintos pines de control y 
  no tendremos interferencias entre ellos.

  El sistema de archivos del cual se leen los sprites o fuentes
  es seleccionable mediante la constante global del preprocesador ROJO_PIN_CS_SD
  Estas constantes se definen en el archivo platformio.ini.

  Selección del sistema de archivos.
    Si se declara la constante ROJO_PIN_CS_SD y se le asigna un valor, se
    selecciona la SD como sistema de archivos.
    El valor de ROJO_PIN_CS_SD corresponde con el pin CS de la SD.
    Si no se declara esta constante, se utilizará SPIFFS.
    Ej.: build_flags = -D ROJO_PIN_CS_SD=15

  Tabla de compatibilidad de sistemas de archivos:

            SD SPIFFS
    Arduino SI NO
    ESP     SI SI
    RPi     NO SI
 */

#ifndef RoJoSSD1331_cpp
#define RoJoSSD1331_cpp

#include <RoJoSSD1331.h>

//Anchura de display
uint16_t RoJoSSD1331::xMax() {
  return _xMax;
}

//Altura de display
uint16_t RoJoSSD1331::yMax() {
  return _yMax;
}

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoSSD1331::_writeCommand(byte command,...) {
  //SD1331 envía los parámetros en modo comando!

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos comando
  //Los parámetros de un comando también se pasan como comandos

  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0) {
    //...enviamos el parámetro
    SPI.transfer((byte)paramValue);
  }
  //Hemos terminado de trabajar con la lista
  va_end(paramList);
  //Siempre terminamos dejando activo el modo de envío de datos
  digitalWrite(_pinDC,HIGH);
}

//Resetea el display
void RoJoSSD1331::reset() {
  digitalWrite(_pinRES,LOW);
  delay(10);
  digitalWrite(_pinRES,HIGH);
  delay(10);

  //Secuencia de inicialización
  _startCOMM();
    _writeCommand(0xA0,0x72,-1); //Fijamos orden de componentes de color a RGB
    _writeCommand(0xA1,0x00,-1); //Fijamos como primera línea la 0
    _writeCommand(0xA2,0x00,-1); //Set Display Offset
    _writeCommand(0xA4,-1); //Set Display mode = Normal
    _writeCommand(0xA8,0x3F,-1); //Set Multiplex Ratio = 1/64 duty
    _writeCommand(0xAD,0x8E,-1); //Set Master Configuration = Select External VCC Supply
    _writeCommand(0xB1,0x31,-1); //Phase 1 and 2 period adjustement
    _writeCommand(0xB3,0xF0,-1); //Display Clock Divider = 7:4 / Oscillator Frequency 3:0 = CLK Div Ratio (A[3:0]+1 = 1..16)
    _writeCommand(0x8A,0x64,-1); //Set Second precharge speed for A
    _writeCommand(0x8B,0x78,-1); //Set Second precharge speed for B
    _writeCommand(0x8C,0x64,-1); //Set Second precharge speed for C
    _writeCommand(0xBB,0x3A,-1); //Set Precharge Level
    _writeCommand(0xBE,0x3E,-1); //Set VCOMH
    _writeCommand(0x87,0x06,-1); //Master Current Control
    _writeCommand(0x81,0x91,-1); //Set Constrast for Color A
    _writeCommand(0x82,0x50,-1); //Set Constrast for Color B
    _writeCommand(0x83,0x7D,-1); //Set Constrast for Color C
  _endCOMM();
  //Borramos la pantalla
  clear();
  //Salimos del modo de bajo consumo
  sleep(false);
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
void RoJoSSD1331::_setCursorRangeX(int16_t x1,int16_t x2) {
  _writeCommand(0x15,x1,x2,-1);
}
void RoJoSSD1331::_setCursorRangeY(int16_t y1,int16_t y2) {
  _writeCommand(0x75,y1,y2,-1);
}
void RoJoSSD1331::_setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2) {
  _setCursorRangeY(y1,y2);
  _setCursorRangeX(x1,x2);
}

//Dibuja un rectángulo. Función interna del display
void RoJoSSD1331::_rect(byte x1,byte y1,byte x2,byte y2,RoJoColor colorBorder,RoJoColor colorFill) {
  _writeCommand(0x22,x1,y1,x2,y2,colorBorder.channels[0],colorBorder.channels[1],colorBorder.channels[2],colorFill.channels[0],colorFill.channels[1],colorFill.channels[2],-1);
  //Es necesario darle un tiempo para que termine de dibujar
  delay(3);
}

//Activa/desactiva el relleno de los rectángulos. Función interna del display
void RoJoSSD1331::_fill(bool f) {
  _writeCommand(0x26,f?0x01:0x00,-1);
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoSSD1331::block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor color) {
  //Ordenamos coordenadas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
   //Calculamos el área visible
  displayRange dr=visibleRange(x1,y1,x2-x1+1,y2-y1+1);
  //Si no hay área visible...hemos terminado
  if(!dr.visible) return false;

  _startCOMM();
    _fill(true);
    _rect(dr.x1,dr.y1,dr.x2,dr.y2,color,color);
  _endCOMM();
  //Tiene parte visible
  return true;
}

//Dibuja un pixel
//Devuelve true si el pixel es visible
bool RoJoSSD1331::drawPixel(int16_t x,int16_t y,RoJoColor color) {
  //Si el pixel está fuera de pantalla...hemos terminado;
  if((x<0)||(y<0)||(x>=_xMax)||(y>=_yMax)) return false;

  _startCOMM();
    _setCursorRange(x,y,x,y);
    SPI.transfer16(color.get16());
  _endCOMM();
  return true;
}

//Dibuja una línea
void RoJoSSD1331::line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor color) {
  _startCOMM();
    _writeCommand(0x21,x1,y1,x2,y2,color.channels[0],color.channels[1],color.channels[2],-1);
  _endCOMM();
  delay(1); //Necesita un momento para dibujar la línea
}

//Dibuja un rectángulo con borde y relleno
//Devuelve si tiene parte visible
bool RoJoSSD1331::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor colorBorder,RoJoColor colorFill) {
  //Ordenamos coordenadas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
  //Si está completamente dentro de la pantalla...
  if(x1>=0 && x2<_xMax && y1>=0 && y2<_yMax) {
    //...utilizamos la función gráfica implementada por hardware
    _startCOMM();
      _fill(true);
      _rect(x1,y1,x2,y2,colorBorder,colorFill);
    _endCOMM();
    return true; //Tiene parte visible
  }
  //El rectángulo no es totalmente visible
  //Dibujaremos el rectángulo en dos pasos: borde + relleno
  //Dibujamos el borde por software
  bool visible=RoJoGraph::rect(x1,y1,x2,y2,colorBorder);
  //Si tiene relleno...lo dibujamos
  if(x2-x1>1 && y2-y1>1) visible|=block(x1+1,y1+1,x2-1,y2-1,colorFill);
  //Devolvemos si es visible
  return visible;
}

//Dibuja un rectángulo sin relleno
//Devuelve si tiene parte visible
bool RoJoSSD1331::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor colorBorder) {
  //Intercambiamos coordenadas erróneas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
  //Si está completamente dentro de la pantalla...
  if(x1>=0 && x2<_xMax && y1>=0 && y2<_yMax) {
    //...utilizamos la función gráfica implementada por hardware
    _startCOMM();
      _fill(false);
      _rect(x1,y1,x2,y2,colorBorder,{0,0,0});
    _endCOMM();
    return true; //Tiene parte visible
  }
  //El rectángulo no es totalmente visible
  //Utilizamos la función por software
  return RoJoGraph::rect(x1,y1,x2,y2,colorBorder);
}

//Copia un área en otra
//Área original definida por puntos 1 y 2
//Área destino comienza en punto 3
//El área destino puede sobreescribir el origen
void RoJoSSD1331::copy(byte x1,byte y1,byte x2,byte y2,byte x3,byte y3) {
  _startCOMM();
    _writeCommand(0x23,x1,y1,x2,y2,x3,y3,-1);
  _endCOMM();
  delay(3); //Es necesario darle un tiempo
}

//Hace una zona más oscura
//Una zona ya oscurecida no se oscurecerá más por volver a aplicar la función
void RoJoSSD1331::darker(byte x1,byte y1,byte x2,byte y2) {
  _startCOMM();
    _writeCommand(0x24,x1,y1,x2,y2,-1);
  _endCOMM();
  delay(2); //Es necesario darle un tiempo
}

//Activa/Desactiva el modo hibernación
void RoJoSSD1331::sleep(bool mode) {
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startCOMM(); //Iniciamos conexión SPI
    if(mode) { //Si activamos el modo hibernación...
      _writeCommand(0xAE,-1); //Display Off
      _writeCommand(0xB0,0x1A,-1); //Enable Power Save mode
    } else { //Si desactivamos el modo hibernación...
      _writeCommand(0xB0,0x0B,-1); //Disable Power Save Mode
      _writeCommand(0xAF,-1); //Display On
    }
  _endCOMM(); //Finalizamos conexión SPI
}

//Inicialización
void RoJoSSD1331::begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM) {
  //Este display tiene una profundidad de color de 16 bits (color)
  _colorDepth=16;
  //Si no se ha indicado frecuencia...la decidiremos nosotros
  if(!freqCOMM) {
    #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
      freqCOMM=10000000; //10 MHz para no interferir con la SD
    #else //Si utilizamos SPIFFS...
      freqCOMM=79999999; //<80 MHz
    #endif
  }
  //Definimos las caraterísticas de la conexión SPI
  _spiSetting=SPISettings(freqCOMM,MSBFIRST,SPI_MODE0);
  //Inicializamos las conexiones SPI
  SPI.begin();
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif

  //Guardamos los parámetros en variables internas
  _pinDC=pinDC;
  _pinRES=pinRES;
  _pinCS=pinCS;
  //Siempre escribiremos en los pines DC, RES y CS
  pinMode(_pinDC,OUTPUT);
  pinMode(_pinRES,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinRES,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip
  //Reseteamos el display
  reset();
  //Llamamos a la inicialización de la clase padre
  RoJoGraph::begin(); //Principalmente inicializa SPIFFS
}

//Dibuja un archivo de sprite en unas coordenadas
//Sobreescribe la información existente
//Respuesta: true si lo consigue
byte RoJoSSD1331::drawSprite(String filename,int16_t x,int16_t y) {
  //Este método no es imprescindible, puesto que ya está definido en RoJoGraph
  //Lo hacemos para optimizarlo

  //Tabla de errores (los primeros son los de infoSprite):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida
  //  3 : La profundidad de color no coincide con la del display

  //Declaración de variables
  uint16_t width,height; //Anchura y altura
  byte colorDepth; //Profundidad de color
  //Leemos los valores del archivo bmp
  byte errorCode=infoSprite(filename,&width,&height,&colorDepth);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Si la profundidad de color no coincide con la del display...terminamos con error
  if(_colorDepth!=colorDepth) return 3;

  //Calculamos el área visible
  displayRange r=visibleRange(x,y,width,height);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;

  uint16_t color;
  uint32_t rowLength=width*2; //Número de bytes que contiene una línea
  uint32_t offsetBase=5+2*(r.x1-x); //Offset de datos gráficos. Se la columna inicial
  uint32_t ry2=r.y2,rx2=r.x2,y32=y;

  //Nota:
  //Diferenciaremos si el sistema de archivos es SPIFFS o SD
  //Podemos utilziar la conexión SPI con el display al mismo tiempo que trabajamos con SPIFFS sin interferencias
  //Con una SD no es posible, porque ambos dispositivos utilizan la conexión SPI. Por lo tanto, tendremos
  //que asegurarnos de mantener sólo una conexión SPI en cada momento.
  //Si definimos un rango de dibujo en el display, lo recordará aunque finalicemos la transacción.
  //Incluso recordará la posición del cursor para la escritura del siguiente dato gráfico

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    _endCOMM();
    //Recorremos las filas visibles del display
    for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
      //Posicionamos offset en archivo
      f.seek(offsetBase+rowLength*(yy-y32));
      //Recorremos las columnas visibles del display
      for(uint32_t xx=r.x1;xx<=rx2;xx++) {
        //Leemos el color
        f.read((byte *)&color,2);
        //Dibujamos el pixel
        _startCOMM();
          SPI.transfer16(color);
        _endCOMM();
      }
    }
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
      //Recorremos las filas visibles del display
      for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
        //Posicionamos offset en archivo
        f.seek(offsetBase+rowLength*(yy-y32));
        //Recorremos las columnas visibles del display
        for(uint32_t xx=r.x1;xx<=rx2;xx++) {
          //Leemos el color
          f.read((byte *)&color,2);
          //Dibujamos el pixel
          SPI.transfer16(color);
        }
      }
    _endCOMM();
  #endif

  
  //hemos terminado de utilizar el archivo
  f.close();
  //Todo Ok
  return 0;
}

//Dibuja un sprite en unas coordenadas
//Sobreescribe la información existente
bool RoJoSSD1331::drawSprite(RoJoSprite *sprite,int16_t x,int16_t y) {
  //Calculamos el área visible
  displayRange r=visibleRange(x,y,sprite->xMax(),sprite->yMax());
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startCOMM();
    //Definimos el rango del cursor
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    //Calculamos el rango visible del sprite origen
    int16_t dx1=r.x1-x,dx2=r.x2-x,dy1=r.y1-y,dy2=r.y2-y;
    //Recorremos todas las filas visibles del sprite origen
    for(int16_t dy=dy1;dy<=dy2;dy++) {
      //Recorremos todas las columnas visibles del sprite origen y enviamos el color del pixel
      for(int16_t dx=dx1;dx<=dx2;dx++) SPI.transfer16(sprite->getPixel(dx,dy).get16());
      #ifdef ESP8266
        yield(); //Refrescamos WatchDog
      #endif
    }
  _endCOMM();
  return true;
}

//Sincroniza dos sprites y envía las diferencias al display.
//Los sprites deben tener el mismo tamaño.
//Respuesta: true si todo es correcto
bool RoJoSSD1331::drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x,int16_t y) {
  //Se detectan las diferencias entre los dos sprites y se escriben sobre el sprite destino
  //y se envían al display.
  //Finalmente el sprite destino queda igual que el origen.

  //Anotamos las medidas del sprite origen
  int16_t xMaxSprite=source->xMax(),yMaxSprite=source->yMax();
  //Si los sprites tienen distinto tamaño...terminamos con error
  if(xMaxSprite!=(int16_t)destination->xMax() || yMaxSprite!=(int16_t)destination->yMax()) return false;
  //Comprobamos si tiene parte visible
  displayRange r=visibleRange(x,y,xMaxSprite,yMaxSprite);
  //Si no es visible...terminamos correctamente
  if(!r.visible) return true;
  //El sprite es total o parcialmente visible
  //En el display se dibujará el sprite en el rango: r.x1,r.y1,r.x2,r.y2
  //Se mostrará el siguiente rango del sprite: r.x1-x,r.y1-y,r.x2-x,r.y2-y
  //Es más sencillo recorrer las filas y columnas del sprite y si se detectan
  //diferencias, hacer la conversión a coordenadas de display
  
  //Calculamos la última fila y columna a procesar en el sprite
  //Reaprovechamos variables
  xMaxSprite=r.x2-x;
  yMaxSprite=r.y2-y;

  bool selectedRangeY; //Se ha seleccionado el rango vertical con la fila procesada?
  int16_t xSprite; //Columna procesada. Coordenada x del sprite
  _startCOMM();
    //Recorremos todas las filas visibles del sprite
    for(int16_t ySprite=r.y1-y;ySprite<=yMaxSprite;ySprite++) {
      //Por ahora no se ha inicializado el rango vertical para la fila actual
      selectedRangeY=false;
      //Comenzamos por la primera columna
      xSprite=r.x1-x;
      //Mientras no hayamos procesado todas las columnas...
      while(xSprite<=xMaxSprite) {
        //Si el pixel actual no se ha modificado...
        if(source->getPixel(xSprite,ySprite).get24()==destination->getPixel(xSprite,ySprite).get24()) {
          //...no tenemos en cuenta este pixel. Pasaremos al siguiente
          xSprite++;
        } else { //El pixel actual ha sido modificado...
          //Si no se ha seleccionado la fila actual...
          if(!selectedRangeY) {
		        //...lo hacemos ahora. Coinvertimos a coordenadas de display
		        _setCursorRangeY(y+ySprite,y+ySprite);
		        //y lo anotamos
		        selectedRangeY=true;
		      }
          //Consideramos este pixel como procesado
          //Actualizamos su valor en el sprite destino
          //destination->drawPixel(xSprite,ySprite,source->getPixel(xSprite,ySprite));
          Serial.println("drawPixel="+String(destination->drawPixel(xSprite,ySprite,source->getPixel(xSprite,ySprite))));
          //Por ahora la última columna modificada es la primera
          int16_t lastChangedColumn=xSprite;
          //Columna procesada = la siguiente a la primera
          int16_t processedColumn=xSprite+1;
          //Mientras llevemos menos de 5 pixels sin modificar...
          while(processedColumn-lastChangedColumn<=5) {
            //Si el pixel de la columna procesada ha cambiado...
            if(source->getPixel(processedColumn,ySprite).get24()!=destination->getPixel(processedColumn,ySprite).get24()) {
              //...anotamos que la última columna con cambios es la actual
              lastChangedColumn=processedColumn;
              //Consideramos este pixel como procesado
              //Actualizamos su valor en el sprite destino
              destination->drawPixel(processedColumn,ySprite,source->getPixel(processedColumn,ySprite));
            }
            //Aumentamos la posición de la columna procesada
            processedColumn++;
          } //end while
          //Seleccionamos como rango horizontal desde la columna actual hasta la última modificada
          //Convertimos a coordenadas de display
          _setCursorRangeX(x+xSprite,x+lastChangedColumn);
          //Enviamos los datos gráficos
          for(int16_t x0=xSprite;x0<=lastChangedColumn;x0++) SPI.transfer16(source->getPixel(x0,ySprite).get16());
          //La primera columna pasará a ser la actual
          xSprite=processedColumn;
        }
      }
      #ifdef ESP8266
        yield(); //Refrescamos WatchDog
      #endif
    }
  _endCOMM();
  //Todo Ok
  return true;
}

// Inicia una transacción SPI
void RoJoSSD1331::_startCOMM() {
  SPI.beginTransaction(_spiSetting);
  digitalWrite(_pinCS,LOW);
}

// Finaliza una transacción SPI
void RoJoSSD1331::_endCOMM() {
  digitalWrite(_pinCS,HIGH);
  SPI.endTransaction();
}

//Dibuja un archivo bmp en unas coordenadas
//Sobreescribe la información existente
//Respuesta: código de error
byte RoJoSSD1331::drawBMP(String filename,int16_t x,int16_t y) {
  //Tabla de errores (los primeros son los de infoBMP):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe.
  //  2 : La firma del tipo de archivo no coincide
  //  3 : Anchura demasiado grande
  //  4 : Altura demasiado grande
  //  5 : El número de planos no es 1
  //  6 : La profundidad de color no está reconocida
  //  7 : Está comprimido
  //  8 : La profundidad de color no coincide con la del display

  //Formato BMP
  //CABECERA
  //offset # descripción
  //------ - -----------
  //   0   2 "BM" constante
  //   2   4 tamaño de archivo
  //   6   4 reservado
  //  10   4 offset de inicio de datos gráficos
  //  14   4 tamaño de cabecera
  //  18   4 anchura en pixels
  //  22   4 altura en pixels
  //  26   2 número de planos (habitualmente 1)
  //  28   2 bits por pixel (habitualmente 24 para imágenes a color)
  //  30   4 compresión (habitualmente 0=ninguna)
  //  34   4 tamaño de imágen
  //  38   4 resolución horizontal
  //  42   4 resolución vertical
  //  46   4 tamaño de la tabla de color
  //  50   4 contador de colores importantes

  //DATOS GRÁFICOS
  //Se guardan por filas
  //Las filas están invertidas. La primera que encontramos corresponde a la última de la imágen
  //El número de bytes de una fila debe ser múltiplo de 4. Si no lo es, se completarán con bytes vacíos
  //Por cada fila, las columnas van en orden: de izquierda a derecha
  //El primer dato gráfico contendrá información sobre el pixel de abajo a la izquierda
  //En monocromo los volores están invertidos

  //Declaración de variables
  byte errorCode=0; //Código de error a devolver
  uint16_t width,height; //Anchura y altura
  byte colorDepth; //Profundidad de color
  
  //Leemos los valores del archivo bmp
  errorCode=infoBMP(filename,&width,&height,&colorDepth);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Si la profundidad de color no coincide con la del display...terminamos con error
  if(_colorDepth!=colorDepth) return 8;

  //Calculamos el área visible
  displayRange r=visibleRange(x,y,width,height);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;

  //Calculamos el número de bytes que contiene una línea
  uint32_t rowLength;
  if(_colorDepth==16) rowLength=width*3; //color
  else { //monocromo
    rowLength=width/8;
    if(width%8) rowLength++;
  }
  //El número de bytes de una línea debe ser múltiplo de 4
  if(rowLength%4) rowLength+=4-(rowLength%4);

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
  #endif
  //Suponemos que no hay errores de apertura en el archivo, porque lo hemos
  //probado hace un momento con infoBMP

  //Leemos el offset de inicio de datos gráficos
  uint32_t offsetBase=0; //Offset de datos gráficos. Base (primer pixel)
  f.seek(10);
  f.read((byte *)&offsetBase,4);
  //El offset con el que trabajaremos será el del primer pixel de la primera línea
  offsetBase+=(uint32_t)rowLength*((uint32_t)height-1);

  //Diferenciaremos la rutina de decodificación gráfica dependiendo del sistema de archivos de origen
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    //Definimos rango de escritura en el display
    _startCOMM();
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    _endCOMM();
    byte color[3]; //Componentes de color de un pixel
    RoJoColor color1;
    uint32_t ry2=r.y2,y32=y;
    offsetBase+=(r.x1-x)*3; //Sumamos el offset de x
    //Recorremos las filas visibles del display
    for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
      //Calculamos y posicionamos el offset en el archivo
      f.seek(offsetBase-rowLength*(yy-y32));
      //Recorremos las columnas visibles del display
      for(uint16_t xx=r.x1;xx<=r.x2;xx++) {
        //Leemos los componentes de color
        f.read(color,3);
        _startCOMM();
          //Guardamos el color en el orden correcto (BGR)
          color1={color[2],color[1],color[0]};
          //Lo codificamos en un color 565
          SPI.transfer16(color1.get16());
        _endCOMM();
      }
    }
  #else //Si utilizamos SPIFFS...
    byte color[3]; //Componentes de color de un pixel
    RoJoColor color1;
    uint32_t ry2=r.y2,y32=y;
    offsetBase+=(r.x1-x)*3; //Sumamos el offset de x
    _startCOMM();
      //Definimos rango de escritura en el display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
      //Recorremos las filas visibles del display
      for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
        //Calculamos y posicionamos el offset en el archivo
        f.seek(offsetBase-rowLength*(yy-y32));
        //Recorremos las columnas visibles del display
        for(uint16_t xx=r.x1;xx<=r.x2;xx++) {
          //Leemos los componentes de color
          f.read(color,3);
          //Guardamos el color en el orden correcto (BGR)
          color1={color[2],color[1],color[0]};
          //Lo codificamos en un color 565
          SPI.transfer16(color1.get16());
        }
        #ifdef ESP8266
          yield(); //Refrescamos WatchDog
        #endif
      }
    _endCOMM();
  #endif
  //hemos terminado de utilizar el archivo
  f.close();
  //Devolvemos código de error
  return errorCode;
}

#endif

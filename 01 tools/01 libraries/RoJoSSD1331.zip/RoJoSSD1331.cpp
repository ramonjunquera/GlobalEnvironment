/*
  Nombre de la librería: RoJoSSD1331.h
  Versión: 20190627
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED SPI 0.95" 96x64 SSD1331

  La siguiente librería permite la gestión del display a través de los
  pines del bus SPI controlados por hardware.

  Todas las funciones escriben directamente sobre el display.
  No se utiliza ninguna técnica de buffer (simple o doble) para reducir
  la tasa de transferencia por SPI.
  Los dispositivos con suficiente memoria podrán hacerlo gracias a
  la compatibilidad con RoJoSprite16.

  Este modelo de display incluye algunas funciones gráficas integradas
  para dibujar líneas o rectángulos.
  La librería permite utilizar todas las funciones integradas.
  
  Nota:
  La librería no tiene en cuenta los pines CS controlados por hardware.
  Se puede definir cualquier pin para CS porque se gestiona por software.
  En placas ESP estos pines se pueden desactivar.
  En Raspberry no. Esto quiere decir que RPi siempre seguirá gestionando
  el pin CS que tenga activo en ese momento.
  La ventaja de definir el pin CS por software es que podemos tener
  varios dispositivos SPI conectados a distintos pines de control y 
  no tendremos interferencias entre ellos.

  El sistema de archivos del cual se leen los sprites o fuentes
  es seleccionable mediante la constante global del preprocesador ROJO_PIN_CS_SD
  Estas constantes se definen en el archivo platformio.ini.

  Selección del sistema de archivos.
    Si se declara la constante ROJO_PIN_CS_SD y se le asigna un valor, se
    selecciona la SD como sistema de archivos.
    El valor de ROJO_PIN_CS_SD corresponde con el pin CS de la SD.
    Si no se declara esta constante, se utilizará SPIFFS.
    Ej.: build_flags = -D ROJO_PIN_CS_SD=15

  Tabla de compatibilidad de sistemas de archivos:

            SD SPIFFS
    Arduino SI NO
    ESP     SI SI
    RPi     NO SI
 */

#ifndef RoJoSSD1331_cpp
#define RoJoSSD1331_cpp

#include <RoJoSSD1331.h>

//Máxima frecuencia SPI soportada por el display
uint32_t RoJoSSD1331::_maxFreqSPI()
{
  return 79999999;
}

//Anchura de display
uint16_t RoJoSSD1331::xMax()
{
  return _xMax;
}

//Altura de display
uint16_t RoJoSSD1331::yMax()
{
  return _yMax;
}

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoSSD1331::_writeCommand(byte command,...)
{
  //SD1331 envía los parámetros en modo comando!

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos comando
  //Los parámetros de un comando también se pasan como comandos

  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0)
  {
    //...enviamos el parámetro
    SPI.transfer((byte)paramValue);
  }
  //Hemos terminado de trabajar con la lista
  va_end(paramList);
  //Siempre terminamos dejando activo el modo de envío de datos
  digitalWrite(_pinDC,HIGH);
}

//Resetea el display
void RoJoSSD1331::reset()
{
  digitalWrite(_pinRES,LOW);
  delay(10);
  digitalWrite(_pinRES,HIGH);
  delay(10);

  //Secuencia de inicialización
  _startSPI();
    _writeCommand(0xA0,0x72,-1); //Fijamos orden de componentes de color a RGB
    _writeCommand(0xA1,0x00,-1); //Fijamos como primera línea la 0
    _writeCommand(0xA2,0x00,-1); //Set Display Offset
    _writeCommand(0xA4,-1); //Set Display mode = Normal
    _writeCommand(0xA8,0x3F,-1); //Set Multiplex Ratio = 1/64 duty
    _writeCommand(0xAD,0x8E,-1); //Set Master Configuration = Select External VCC Supply
    _writeCommand(0xB0,0x0B,-1); //Power Save Mode = Disabled
    _writeCommand(0xB1,0x31,-1); //Phase 1 and 2 period adjustement
    _writeCommand(0xB3,0xF0,-1); //Display Clock Divider = 7:4 / Oscillator Frequency 3:0 = CLK Div Ratio (A[3:0]+1 = 1..16)
    _writeCommand(0x8A,0x64,-1); //Set Second precharge speed for A
    _writeCommand(0x8B,0x78,-1); //Set Second precharge speed for B
    _writeCommand(0x8C,0x64,-1); //Set Second precharge speed for C
    _writeCommand(0xBB,0x3A,-1); //Set Precharge Level
    _writeCommand(0xBE,0x3E,-1); //Set VCOMH
    _writeCommand(0x87,0x06,-1); //Master Current Control
    _writeCommand(0x81,0x91,-1); //Set Constrast for Color A
    _writeCommand(0x82,0x50,-1); //Set Constrast for Color B
    _writeCommand(0x83,0x7D,-1); //Set Constrast for Color C
    _writeCommand(0xAF,-1); //Display On
  _endSPI();
  //Borramos la pantalla
  clear();
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
void RoJoSSD1331::_setCursorRangeX(int16_t x1,int16_t x2)
{
  _writeCommand(0x15,x1,x2,-1);
}
void RoJoSSD1331::_setCursorRangeY(int16_t y1,int16_t y2)
{
  _writeCommand(0x75,y1,y2,-1);
}

//Dibuja un rectángulo. Función interna del display
void RoJoSSD1331::_rect(byte x1,byte y1,byte x2,byte y2,byte borderR,byte borderG,byte borderB,byte fillR,byte fillG,byte fillB)
{
  _writeCommand(0x22,x1,y1,x2,y2,borderR,borderG,borderB,fillR,fillG,fillB,-1);
  //Es necesario darle un tiempo para que termine de dibujar
  delay(3);
}

//Activa/desactiva el relleno de los rectángulos. Función interna del display
void RoJoSSD1331::_fill(bool f)
{
  _writeCommand(0x26,f?0x01:0x00,-1);
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoSSD1331::block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte r,byte g,byte b)
{
  //Intercambiamos coordenadas erróneas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
   //Calculamos el área visible
  displayRange dr=visibleRange(x1,y1,x2-x1+1,y2-y1+1);
  //Si no hay área visible...hemos terminado
  if(!dr.visible) return false;

  _startSPI();
    _fill(true);
    _rect(dr.x1,dr.y1,dr.x2,dr.y2,r,g,b,r,g,b);
  _endSPI();
  
  //Tiene parte visible
  return true;
}
bool RoJoSSD1331::block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color)
{
  byte r,g,b;
  getComponents(color,&r,&g,&b);
  return block(x1,y1,x2,y2,r,g,b);
}

//Dibuja un pixel
//Devuelve true si lo consigue si el pixel es visible
bool RoJoSSD1331::drawPixel(int16_t x,int16_t y,uint16_t color)
{
  //Si el pixel está fuera de pantalla...hemos terminado;
  if((x<0)||(y<0)||(x>=_xMax)||(y>=_yMax)) return false;

  _startSPI();
    _setCursorRange(x,y,x,y);
    SPI.transfer16(color);
  _endSPI();
  return true;
}

// Dibuja una línea
void RoJoSSD1331::line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte r,byte g,byte b)
{
  _startSPI();
    _writeCommand(0x21,x1,y1,x2,y2,r,g,b,-1);
  _endSPI();
  delay(1); //Necesita un momento para dibujar la línea
}
void RoJoSSD1331::line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color)
{
  //Redefinimos el método line de RoJoGraph porque la función está implementada
  //por hardware
  byte r,g,b;
  getComponents(color,&r,&g,&b);
  line(x1,y1,x2,y2,r,g,b);
}

//Dibuja un rectángulo con borde y relleno
//Devuelve si tiene parte visible
bool RoJoSSD1331::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte borderR,byte borderG,byte borderB,byte fillR,byte fillG,byte fillB)
{
  //Intercambiamos coordenadas erróneas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
  //Si está completamente dentro de la pantalla...
  if(x1>=0 && x2<_xMax && y1>=0 && y2<_yMax)
  {
    //...utilizamos la función gráfica implementada por hardware
    _startSPI();
      _fill(true);
      _rect(x1,y1,x2,y2,borderR,borderG,borderB,fillR,fillG,fillB);
    _endSPI();
    return true; //Tiene parte visible
  }
  //El rectángulo no es totalmente visible
  //Utilizamos funciones por software
  bool visible=rect(x1,y1,x2,y2,getColor(borderR,borderG,borderB));
  //Si tiene relleno...lo dibujamos
  if(x2-x1>1 && y2-y1>1) visible|=block(x1+1,y1+1,x2-1,y2-1,getColor(fillR,fillG,fillB));
  //Devolvemos si es visible
  return visible;
}
bool RoJoSSD1331::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t borderColor,uint16_t fillColor)
{
  byte borderR,borderG,borderB,fillR,fillG,fillB;
  getComponents(borderColor,&borderR,&borderG,&borderB);
  getComponents(fillColor,&fillR,&fillG,&fillB);
  return rect(x1,y1,x2,y2,borderR,borderG,borderB,fillR,fillG,fillB);
}

//Dibuja un rectángulo sin relleno
//Devuelve si tiene parte visible
bool RoJoSSD1331::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte borderR,byte borderG,byte borderB)
{
  //Intercambiamos coordenadas erróneas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
  //Si está completamente dentro de la pantalla...
  if(x1>=0 && x2<_xMax && y1>=0 && y2<_yMax)
  {
    //...utilizamos la función gráfica implementada por hardware
    _startSPI();
      _fill(false);
      _rect(x1,y1,x2,y2,borderR,borderG,borderB,0,0,0);
    _endSPI();
    return true; //Tiene parte visible
  }
  //El rectángulo no es totalmente visible
  //Utilizamos la función por software
  return RoJoGraph::rect(x1,y1,x2,y2,getColor(borderR,borderG,borderB));
}
bool RoJoSSD1331::rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t borderColor)
{
  byte borderR,borderG,borderB;
  getComponents(borderColor,&borderR,&borderG,&borderB);
  return rect(x1,y1,x2,y2,borderR,borderG,borderB);
}

//Copia un área en otra
//Área original definida por puntos 1 y 2
//Área destino comienza en punto 3
//El área destino puede sobreescribir el origen
void RoJoSSD1331::copy(byte x1,byte y1,byte x2,byte y2,byte x3,byte y3)
{
  _startSPI();
    _writeCommand(0x23,x1,y1,x2,y2,x3,y3,-1);
  _endSPI();
  delay(3); //Es necesario darle un tiempo
}

//Hace una zona más oscura
//Una zona ya oscurecida no se oscurecerá más por volver a aplicar la función
void RoJoSSD1331::darker(byte x1,byte y1,byte x2,byte y2)
{
  _startSPI();
    _writeCommand(0x24,x1,y1,x2,y2,-1);
  _endSPI();
  delay(2); //Es necesario darle un tiempo
}

//Activa/Desactiva el modo hibernación
void RoJoSSD1331::sleep(bool mode)
{
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startSPI(); //Iniciamos conexión SPI
    if(mode) //Si activamos el modo hibernación...
    {
      _writeCommand(0xAE,-1); //Display Off
      _writeCommand(0xB0,0x1A,-1); //Enable Power Save mode
    }
    else //Si desactivamos el modo hibernación...
    {
      _writeCommand(0xB0,0x0B,-1); //Disable Power Save Mode
      _writeCommand(0xAF,-1); //Display On
    }
  _endSPI(); //Finalizamos conexión SPI
}

#endif

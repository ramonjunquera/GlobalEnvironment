/*
  Nombre de la librería: RoJoST7789V2.h
  Versión: 20201115
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RoJoST7789V2 SPI 135x240
*/

#ifndef RoJoST7789V2_h
#define RoJoST7789V2_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoGraph.h> //Gestión de gráficos avanzados
#ifdef ARDUINO_M5Stick_C
  #include <Wire.h> //Para gestión de chip de alimentación AXP192
#endif

class RoJoST7789V2:public RoJoGraph {
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    void _setCursorRangeX(int16_t x1,int16_t x2); //Define rango X
    void _setCursorRangeY(int16_t y1,int16_t y2); //Define rango Y
    void _setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2); //Define  rango X & Y
    const uint16_t _xMaxDefault=135; //Anchura de display sin rotación
    const uint16_t _yMaxDefault=240; //Altura de display sin rotación
    uint16_t _xMax; //Anchura de display
    uint16_t _yMax; //Altura de display
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _startCOMM(); //Inicia comunicación
    void _endCOMM(); //Finaliza comunicación
    SPISettings _spiSetting; //Características de la conexión SPI
    byte _rotationCodes[4]={0x08,0x68,0xC8,0xA8}; //Configuraciones de rotación
    const uint16_t _x0Default[4]={52,40,53,40}; //Coordenada x asignada a la primera columna
    const uint16_t _y0Default[4]={40,53,40,52}; //Coordenada y asignada a la primera fila
    uint16_t _x0; //Coordenada x asignada a la primera columna
    uint16_t _y0; //Coordenada y asignada a la primera fila
  public:
    void sleep(bool mode); //Activa/Desactiva el modo hibernación
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,RoJoColor color); //Dibuja un rectángulo relleno
    void reset(); //Reset
    bool drawPixel(int16_t x,int16_t y,RoJoColor color); //Dibuja un pixel
    void begin(byte pinRES=18,byte pinDC=23,byte pinCS=5,uint32_t freqCOMM=39999999,byte pinCLK=13,byte pinMOSI=15,int8_t pinMISO=-1); //Inicialización
    bool drawSprite(RoJoSprite *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo
    bool drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x=0,int16_t y=0); //Sincroniza dos sprites
    void rotation(byte r); //Configura la rotación
};

#ifdef __arm__
  #include <RoJoST7789V2.cpp> //Para guardar compatibilidad con RPi
#endif

#endif
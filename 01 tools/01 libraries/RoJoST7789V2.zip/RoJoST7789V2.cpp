/*
  Nombre de la librería: RoJoST7789V2.h
  Versión: 20200211
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RoJoST7789V2 SPI 135x240
*/

#ifndef RoJoST7789V2_cpp
#define RoJoST7789V2_cpp

#include <RoJoST7789V2.h>

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoST7789V2::_writeCommand(byte command,...) {
  //ST7735S envía la información (comando y parámetros) en paquetes de 8bits (byte)
  //El comando se envía en modo comando y sus parámetros en modo datos

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos el comando
  //Todos los parámetros deben pasarse en modo datos
  //Lo activamos ahora y nos aseguramos que quedará así al finalizar
  digitalWrite(_pinDC,HIGH); //Modo datos
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0) {
    //...enviamos el parámetro
    SPI.transfer(paramValue);
  }
  //Hemos terminado de trabajar con la lista
  va_end(paramList);
}

// Inicia comunicación
void RoJoST7789V2::_startCOMM() {
  SPI.beginTransaction(_spiSetting);
  digitalWrite(_pinCS,LOW);
}

// Finaliza comunicación
void RoJoST7789V2::_endCOMM() {
  digitalWrite(_pinCS,HIGH);
  SPI.endTransaction();
}

// Activa/Desactiva el modo hibernación
void RoJoST7789V2::sleep(bool mode) {
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startCOMM();
    if(mode) {
      _writeCommand(0x10,-1); //Sleep IN
      _writeCommand(0x28,-1); //Display OFF
    } else {
      _writeCommand(0x29,-1); //Display ON
      _writeCommand(0x11,-1); //Sleep OUT
      delay(125); //Se deben esperar al menos 120ms
    }
  _endCOMM();
}

//Reset & inicialización
void RoJoST7789V2::reset() {
  //Hard reset
  digitalWrite(_pinRES,LOW);
  delay(20);
  digitalWrite(_pinRES,HIGH);
  delay(120);
  //Soft reset
  _startCOMM();
    _writeCommand(0x01,-1); //Comando soft reset
  _endCOMM();
  delay(125); //Se deben esperar al menos 120ms
  //Secuencia de inicialización
  _startCOMM();
    //0x3A : COLMOD : Interface pixel format
    //  param 1 = 0x55 = 0b01010101
    //    bit 0-2 = Control interface color format
    //      0b011 = 12-bit/pixel
    //      0b101 = 16-bit/pixel
    //      0b110 = 18-bit/pixel
    //      0b111 = 16M truncated
    //    bit 3 = siempre 0
    //    bit 4-6 = RGB interface color format
    //      0b101 = 65K
    //      0b110 = 262K
    //    bit 7 = siempre 0
    _writeCommand(0x3A,0x55,-1); //Usamos 65K colores en formato 16bit
    //0xC0 : LCMCTRL : LCM control
    //  param1 = 0x0C = 0b00001100
    //    bit 0 : XGS : XOR GS setting in command 0xE4
    //    bit 1 : XMV : XOR MV setting in command 0x36
    //    bit 2 : XMH : this bit can reverse source output order ans only support for RGB interface without RAM
    //    bit 3 : XMX : XOR MX setting in command 0x36
    //    bit 4 : XINV
    //    bit 5 : XBRG : XOR RGB setting in command 0x36
    //    bit 6 : XMY : XOR MY setting in command 0x36
    //    bit 7 : siempre 0
    //    default value = 0x2C = 0b00101100
    _writeCommand(0xC0,0x0C,-1);
    //0x21 : INVON : Display inversion on
    _writeCommand(0x21,-1);
    //0x13 : NORON : Normal display mode on
    _writeCommand(0x13,-1);
  _endCOMM();
  //Rotación por defecto=0: 135x240. Vertical. En M5StickC+ el botón M5 abajo
  rotation(0);
  //Borramos el display
  clear();
  //Salimos del modo de bajo consumo
  sleep(false);
}

//Inicialización
void RoJoST7789V2::begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM,byte pinCLK,byte pinMOSI,int8_t pinMISO) {
  //En M5Stick-C es necesario activar la alimentación al display desde el chip
  //AXP192 que gestiona la batería
  #ifdef ARDUINO_M5Stick_C
    Wire.begin(21,22);
    byte wireBuffer[]={
      0x12,
      0x4D //Enable DC-DC1, OLED_VDD, 5B V_EXT
    };
    Wire.beginTransmission(0x34);
    Wire.write(wireBuffer,2);
    Wire.endTransmission();
  #endif
  //Este display tiene una profundidad de color de 16 bits (color)
  _bytesPerPixel=2;
  //Definimos las caraterísticas de la conexión SPI
  _spiSetting=SPISettings(freqCOMM,MSBFIRST,SPI_MODE0);
  //Indicamos los pines SPI.
  //El pin MISO no se utiliza para este display
  #ifdef ESP32 //Si una placa ESP32...
    SPI.begin(pinCLK,pinMISO,pinMOSI); //Seleccionaremos los pines SPI
  #else //Para cualquier otra placa...
    SPI.begin(); //No podemos seleccionar los pines SPI
  #endif
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif
  //Guardamos los parámetros en variables internas
  _pinDC=pinDC;
  _pinCS=pinCS;
  _pinRES=pinRES;
  //Siempre escribiremos en los pines DC, RES y CS
  pinMode(_pinDC,OUTPUT);
  pinMode(_pinRES,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinRES,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip
  //Reseteamos el display
  reset();
  //Llamamos a la inicialización de la clase padre
  RoJoGraph2::begin(); //Principalmente inicializa SPIFFS
}

// Configura la rotación
void RoJoST7789V2::rotation(byte r) {
  //     M5Stick C
  // r : posición botón M5   : orientación
  //---  -------------------   -----------
  // 0 : abajo                 vertical (*)
  // 1 : derecha               apaisado
  // 2 : arriba                vertical
  // 3 : izquierda             apaisado
  
  r%=4; //Nos aseguramos que es un valor permitido
  _startCOMM();
    //Código correspondiente a la rotación
    _writeCommand(0x36,_rotationCodes[r],-1);
  _endCOMM();
  //Calculamos los nuevos tamaños de pantalla
  _x0=_x0Default[r];
  _y0=_y0Default[r];
  if(r%2) { //Si la rotación es impar...
    //El formato será apaisado
    _xMax=_yMaxDefault;
    _yMax=_xMaxDefault;
  } else { //Si la rotación es par...
    //El formato será vertical
    _xMax=_xMaxDefault;
    _yMax=_yMaxDefault;
  }
}

//Anchura de display (dummy)
uint16_t RoJoST7789V2::xMax() {
  return _xMax;
}

//Altura de display (dummy)
uint16_t RoJoST7789V2::yMax() {
  return _yMax;
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
void RoJoST7789V2::_setCursorRangeY(int16_t y1,int16_t y2) {
  //0x2B=Page Address Set
  _writeCommand(0x2B,-1);
  SPI.transfer16(_y0+y1);
  SPI.transfer16(_y0+y2);
}
void RoJoST7789V2::_setCursorRangeX(int16_t x1,int16_t x2) {
  //0x2A=Column Address Set
  _writeCommand(0x2A,-1);
  SPI.transfer16(_x0+x1);
  SPI.transfer16(_x0+x2);
  //Write memory
  _writeCommand(0x2C,-1);
}
void RoJoST7789V2::_setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2) {
  _setCursorRangeY(y1,y2);
  _setCursorRangeX(x1,x2);
}

//Dibuja un pixel
//Devuelve true si lo consigue si el pixel es visible
bool RoJoST7789V2::drawPixel(int16_t x,int16_t y,uint32_t color) {
  //Si las coordenadas están fuera de rango...terminamos
  if(x<0 || x>=(int16_t)_xMax || y<0 || y>=(int16_t)_yMax) return false;

  _startCOMM();
    _setCursorRange(x,y,x,y);
    SPI.transfer16(color);
  _endCOMM();
  return true;
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoST7789V2::block(int16_t x,int16_t y,int16_t width,int16_t height,uint32_t color) {
  //Calculamos el área visible
  displayRange r=visibleRange(&x,&y,&width,&height);
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startCOMM();
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    for(uint16_t row=r.y1;row<=r.y2;row++)
      for(uint16_t col=r.x1;col<=r.x2;col++)
        SPI.transfer16(color);
  _endCOMM();
  
  //Tiene parte visible
  return true;
}

//Dibuja un sprite en unas coordenadas
//Sobreescribe la información existente
bool RoJoST7789V2::drawSprite(RoJoSprite2 *sprite,int16_t x,int16_t y) {
  //Calculamos el área visible
  displayRange r=visibleRange(x,y,sprite->xMax(),sprite->yMax());
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  uint16_t rx1=r.x1-x,rx2=r.x2-x,ry2=r.y2-y;
  _startCOMM();
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    for(uint16_t row=r.y1-y;row<=ry2;row++) {
      for(uint16_t col=rx1;col<=rx2;col++) SPI.transfer16(sprite->getPixel(col,row));
    }
  _endCOMM();
  return true;
}

//Dibuja un sprite directamente desde un archivo
byte RoJoST7789V2::drawSprite(String filename,int16_t x,int16_t y) {
  //Este método no es imprescindible, puesto que ya está definido en RoJoGraph
  //Lo hacemos para optimizarlo

  //Tabla de errores (los primeros son los de infoSprite):
  //  0 : No hay errores. Todo correcto
  //  1 : No se puede abrir el archivo. Posiblemente no existe
  //  2 : La profundidad de color no está reconocida
  //  3 : La profundidad de color no coincide con la del display

  //Declaración de variables
  uint16_t width,height; //Anchura y altura
  byte bytesPerPixel; //Profundidad de color
  //Leemos los valores del archivo bmp
  byte errorCode=infoSprite(filename,&width,&height,&bytesPerPixel);
  //Si tenemos algún error...lo devolvemos
  if(errorCode) return errorCode;
  //No tenemos errores

  //Si la profundidad de color no coincide con la del display...terminamos con error
  if(_bytesPerPixel!=bytesPerPixel) return 3;

  //Calculamos el área visible
  displayRange r=visibleRange(x,y,width,height);
  //Si no hay área visible...hemos terminado ok
  if(!r.visible) return 0;

  uint32_t rowLength=width*2; //Número de bytes que contiene una línea
  uint32_t offsetBase=5+2*(r.x1-x); //Offset de datos gráficos. Se la columna inicial
  uint32_t ry2=r.y2,rx2=r.x2,y32=y; //Tipo uint32_t
  uint32_t pixelsPerLine=rx2-(uint32_t)r.x1+1;
  uint32_t bytesPerLine=2*pixelsPerLine;
  bool spriteFullLine=pixelsPerLine==width; //Leeremos toda la anchura del sprite?
  byte *fullLine=new byte[bytesPerLine]; //Reservamos memoria para contener una línea completa
  byte *b1,*b2; //Punteros del primer y segundo byte para swap
  byte temp; //Puntero a byte temporal para swap

  //Nota:
  //Diferenciaremos si el sistema de archivos es SPIFFS o SD
  //Podemos utilizar la conexión SPI con el display al mismo tiempo que trabajamos con SPIFFS
  //sin interferencias.
  //Con una SD no es posible, porque ambos dispositivos utilizan la conexión SPI. Por lo tanto,
  //tendremos que asegurarnos de mantener sólo una conexión SPI en cada momento.
  //Si definimos un rango de dibujo en el display, lo recordará aunque finalicemos la transacción.
  //Incluso recordará la posición del cursor para la escritura del siguiente dato gráfico
  
  //Nota:
  //La lectura tanto de sistems de archivos es lenta debido a que se debe localizar el dato
  //a leer. La lectura de varios bytes contiguos es muchísimo más rápida que byte a byte.
  //En el envío de información pro SPI no ocurre lo mismo, puesto que no se debe calcular
  //ningún offset.
  //Puesto que no podemos leer el archivo entero en memoria porque es posible que no tengamos
  //suficiente memoria y porque quizás no se muestra el sprite completo, lo leeremos línea
  //a línea.
  //Reservaremos memoria suficiente para contener la parte visible de una línea.
  //Cargaremos la información desde el archivo en una sola lectura.
  //Después enviaremos los datos por SPI.
  //Antes de ello debemos intercambiar los bytes de cada pixel.

  //Leemos los datos gráficos
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename,FILE_READ); //Abrimos el archivo en la SD
    //Posicionamos el offset al principio de los datos gráficos
    f.seek(offsetBase+rowLength*((uint32_t)r.y1-y32));
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    _endCOMM();
    //Recorremos las filas visibles del display
    for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
      //Si es necesario...posicionamos offset en archivo
      if(!spriteFullLine) f.seek(offsetBase+rowLength*(yy-y32));
      f.read(fullLine,bytesPerLine); //Leemos la línea completa
      //Intercambiamos bytes de cada pixel
      b1=fullLine; b2=b1+1;//Comenzamos desde el primer byte
      for(uint32_t pixel=0;pixel<pixelsPerLine;pixel++) { //Recorremos todos los pixels de la línea
        temp=*b1; *b1=*b2; *b2=temp; //swap
        b1+=2; b2+=2; //Siguiente pixel
      }
      _startCOMM();
        SPI.transfer(fullLine,bytesPerLine); //Transferimos la línea completa
      _endCOMM();
    }
  #else //Si utilizamos SPIFFS...
    //...ya se inicializó en el constructor
    File f=SPIFFS.open(filename,"r"); //Abrimos el archivo en SPIFFS
    //Posicionamos el offset al principio de los datos gráficos
    f.seek(offsetBase+rowLength*((uint32_t)r.y1-y32));
    _startCOMM();
      //Definimos rango de escritura en display
      _setCursorRange(r.x1,r.y1,r.x2,r.y2);
      //Recorremos las filas visibles del display
      for(uint32_t yy=(uint32_t)r.y1;yy<=ry2;yy++) {
        //Si es necesario...posicionamos offset en archivo
        if(!spriteFullLine) f.seek(offsetBase+rowLength*(yy-y32));
        f.read(fullLine,bytesPerLine); //Leemos la línea completa
        //Intercambiamos bytes de cada pixel
        b1=fullLine; b2=b1+1;//Comenzamos desde el primer byte
        for(uint32_t pixel=0;pixel<pixelsPerLine;pixel++) { //Recorremos todos los pixels de la línea
          temp=*b1; *b1=*b2; *b2=temp; //swap
          b1+=2; b2+=2; //Siguiente pixel
        }
        SPI.transfer(fullLine,bytesPerLine); //Transferimos la línea completa
      }
    _endCOMM();
    delete[] fullLine; //Liberamos la memoria reservada para contener una línea
  #endif
  
  //hemos terminado de utilizar el archivo
  f.close();
  //Todo Ok
  return 0;
}

//Sincroniza dos sprites y envía las diferencias al display.
//Los sprites deben tener el mismo tamaño.
//Respuesta: true si todo es correcto
bool RoJoST7789V2::drawSpriteSync(RoJoSprite2 *source,RoJoSprite2 *destination,int16_t x,int16_t y) {
  //Se detectan las diferencias entre los dos sprites y se escriben sobre el sprite destino
  //y se envían al display.
  //Finalmente el sprite destino queda igual que el origen.

  //Anotamos las medidas del sprite origen
  int16_t xMaxSprite=source->xMax();
  int16_t yMaxSprite=source->yMax();
  //Si los sprites tienen distinto tamaño...terminamos con error
  if(xMaxSprite!=(int16_t)destination->xMax() || yMaxSprite!=(int16_t)destination->yMax()) return false;
  //Si los sprites tienen distinta profundidad...terminamos con error
  if(source->bytesPerPixel()!=_bytesPerPixel || destination->bytesPerPixel()!=_bytesPerPixel) return false;
  //Comprobamos si tiene parte visible
  displayRange r=visibleRange(x,y,xMaxSprite,yMaxSprite);
  //Si no es visible...terminamos correctamente
  if(!r.visible) return true;
  //El sprite es total o parcialmente visible
  //En el display se dibujará el sprite en el rango: r.x1,r.y1,r.x2,r.y2
  //Se mostrará el siguiente rango del sprite: r.x1-x,r.y1-y,r.x2-x,r.y2-y
  //Es más sencillo recorrer las filas y columnas del sprite y si se detectan
  //diferencias, hacer la conversión a coordenadas de display
  
  //Calculamos la última fila y columna a procesar en el sprite
  //Reaprovechamos variables
  xMaxSprite=r.x2-x;
  yMaxSprite=r.y2-y;

  bool selectedRangeY; //Se ha seleccionado el rango vertical con la fila procesada?
  int16_t xSprite; //Columna procesada. Coordenada x del sprite
  _startCOMM();
    //Recorremos todas las filas visibles del sprite
    for(int16_t ySprite=r.y1-y;ySprite<=yMaxSprite;ySprite++) {
      //Por ahora no se ha inicializado el rango vertical para la fila actual
      selectedRangeY=false;
      //Comenzamos por la primera columna
      xSprite=r.x1-x;
      //Mientras no hayamos procesado todas las columnas...
      while(xSprite<=xMaxSprite) {
        //Si el pixel actual no se ha modificado...
        if(source->getPixel(xSprite,ySprite)==destination->getPixel(xSprite,ySprite)) {
          //...no tenemos en cuenta este pixel. Pasaremos al siguiente
          xSprite++;
        }
        else { //El pixel actual ha sido modificado...
          //Si no se ha seleccionado la fila actual...
          if(!selectedRangeY) {
		        //...lo hacemos ahora. Coinvertimos a coordenadas de display
		        _setCursorRangeY(y+ySprite,y+ySprite);
		        //y lo anotamos
		        selectedRangeY=true;
		      }
          //Consideramos este pixel como procesado
          //Actualizamos su valor en el sprite destino
          destination->drawPixel(xSprite,ySprite,source->getPixel(xSprite,ySprite));
          //Por ahora la última columna modificada es la primera
          int16_t lastChangedColumn=xSprite;
          //Columna procesada = la siguiente a la primera
          int16_t processedColumn=xSprite+1;
          //Mientras llevemos menos de 5 pixels sin modificar...
          while(processedColumn-lastChangedColumn<=5) {
            //Si el pixel de la columna procesada ha cambiado...
            if(source->getPixel(processedColumn,ySprite)!=destination->getPixel(processedColumn,ySprite)) {
              //...anotamos que la última columna con cambios es la actual
              lastChangedColumn=processedColumn;
              //Consideramos este pixel como procesado
              //Actualizamos su valor en el sprite destino
              destination->drawPixel(processedColumn,ySprite,source->getPixel(processedColumn,ySprite));
            }
            //Aumentamos la posición de la columna procesada
            processedColumn++;
          } //end while
          //Seleccionamos como rango horizontal desde la columna actual hasta la última modificada
          //Convertimos a coordenadas de display
          _setCursorRangeX(x+xSprite,x+lastChangedColumn);
          //Enviamos los datos gráficos
          for(int16_t x0=xSprite;x0<=lastChangedColumn;x0++) SPI.transfer16(source->getPixel(x0,ySprite));
          //La primera columna pasará a ser la actual
          xSprite=processedColumn;
        }
      }
      #ifdef ESP8266
        yield(); //Refrescamos WatchDog
      #endif
    }
  _endCOMM();
  //Todo Ok
  return true;
}

#endif
/*
  Nombre de la librería: RoJoABC.h
  Versión: 20180124
  Autor: Ramón Junquera
  Descripción:
    Gestión de fuentes
    Sólo compatible con las familias de placas ESP32 y ESP8266 y
      Raspberry Pi 3
*/

#ifndef RoJoABC_cpp
#define RoJoABC_cpp

#include <Arduino.h>
#if defined(ESP32)
  #include <SPIFFS.h>
#else
  #include <FS.h>
#endif
#include "RoJoSprite.h"
#include "RoJoABC.h"

RoJoABC::RoJoABC()
{
  //Constructor

  //Inicializamos el acceso a archivos de SPIFFS
  SPIFFS.begin();
}

bool RoJoABC::_charInFont(byte c)
{
  //El carácter pertenece a la fuente?
  return (c>=_charMin && c<=_charMax);
}

byte RoJoABC::_charWidth(byte c)
{
  //Devuelve la anchura de un carácter
  //Le pasamos como parámetros el archivo de fuentes y el carácter

  //Si el no carácter pertenece a la fuente...la anchura es cero
  if(!_charInFont(c)) return 0;
  //Definimos la variable que guardará la anchura
  byte width;
  //Posicionamos el puntero de lectura del archivo
  _f.seek(3+_charCount*2+c-_charMin,SeekSet);
  //Leemos la anchura
  _f.readBytes((char *)&width,1);
  //La devolvemos
  return width;
}

uint16_t RoJoABC::_charIndex(byte c)
{
  //Devuelve el índice de inicio de los datos gráficos de un carácter
  //Le pasamos como parámetros el archivo de fuentes y el carácter

  //Si el carácter no pertenece a la fuente...el índice es cero
  if(!_charInFont(c)) return 0;
  //Definimos la variable que guardará el índice
  uint16_t index;
  //Posicionamos el puntero de lectura del archivo
  _f.seek(3+2*(c-_charMin),SeekSet);
  //Leemos el índice
  _f.readBytes((char *)&index,2);
  //Lo devolvemos
  return index;
}

bool RoJoABC::print(String fileNameFon,String text,RoJoSprite *sprite)
{
  //Crea un sprite con el texto indicado basado en una fuente
  //Devuelve false ante cualquier error

  //Abrimos el archivo indicado del SPIFFS como sólo lectura
  _f=SPIFFS.open(fileNameFon,"r");
  //Si hubo algún problema...hemos terminado
  if(!_f) return false;

  //Leemos ASCII del primer carácter de la fuente
  _f.readBytes((char *)&_charMin,1);
  //Leemos ASCII del último carácter de la fuente
  _f.readBytes((char *)&_charMax,1);
  //Leemos el número de páginas
  _f.readBytes((char *)&_pages,1);
  //Calculamos el número de caracteres de la fuente
  _charCount=_charMax-_charMin+1;

  //Inicialmente la anchura del sprite es 0
  uint16_t spriteWidth=0;
  //Byte gráfico actualmente procesado
  byte pageByte;

  //Calculamos la anchura del sprite
  //Recorremos todos los caracteres del texto
  for(uint16_t i=0;i<text.length();i++)
  {
    //Si el carácter pertenece a la fuente...
    if(_charInFont(text[i]))
    {
      //...este carácter será representado
      //Si este no es el primer carácter, añadiremos una
      //columna de separación.
      if(spriteWidth>0) spriteWidth++;
      
      //Añadimos la anchura del carácter
      spriteWidth+=_charWidth(text[i]);
    }
  }
  //Tenemos calculada la anchura del sprite en spriteWidth

  //Fijamos el tamaño del sprite
  (*sprite).setSize(spriteWidth,_pages);
  //Si el sprite tiene anchura...
  if(spriteWidth>0)
  {
    //Variable para guardar la posición x en la que estamos
    //escribiendo en el sprite
    uint16_t x=0;
    //Volvemos a recorrer todos los caracteres del string
    for(byte i=0;i<text.length();i++)
    {
      //Si el carácter está dentro del rango de la fuente...
      if(_charInFont(text[i]))
      {
        //Si no es el primer carácter...dejaremos una separación
        if(x>0) x++;
        //Obtenemos las propiedades del carácter
        byte chWidth = _charWidth(text[i]);
        uint16_t chIndex = _charIndex(text[i]);
        //Posicionamos la lectura del archivo
        _f.seek(5+_charCount*3+chIndex,SeekSet);
        //Recorremos todas las páginas de altura
        for(byte p=0;p<_pages;p++)
        {
          //Recorremos las columnas que forman el carácter
          for(byte c=0;c<chWidth;c++)
          {
            //Leemos el byte de la página
            _f.readBytes((char *)&pageByte,1);
            //Lo escribimos en el sprite
            (*sprite).setPage(x+c,p,pageByte,4);
          }
        }
        //El siguiente caracter lo comenzaremos a escribir a una
        //distacia igual a la anchura del carácter escrito
        x+=chWidth;
      }
    }
  }
  //Hemos terminado de leer el archivo de fuentes. Lo cerramos
  _f.close();
  //Todo correcto
  return true;
}

#endif


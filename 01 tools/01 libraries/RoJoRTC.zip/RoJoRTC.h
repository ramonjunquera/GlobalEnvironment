/*
  Nombre de la librería: RoJoRTC.h
  Versión: 20191120
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del RTC genérico
    Se incluye la definición de la estructura RoJoDateTime
    El reloj sólo es capaz de almacenar 2 dígitos para el año. Supondremos que el año del reloj corresponde con las
    dos últimas cifras de un año del siglo 21 (20xx).
*/

#ifndef RoJoRTC_h
#define RoJoRTC_h

#include <Arduino.h>
#include <Wire.h>

struct RoJoDateTime {
  byte second=0; //[0,59]
  byte minute=0; //[0,59]
  byte hour=0; //En formato 24 horas
  byte weekDay=0; //lun=0,dom=6
  byte day=0; //[1,31]
  byte month=0; //enero=1, diciembre=12
  uint16_t year=0; //Completo. Con sus 4 dígitos
};

class RoJoRTC {
  protected:
    byte _clockID; //Identificador I2C
    byte _bcd2dec(byte n); //Convierte de Binary Coded Decimal a Decimal
    byte _dec2bcd(byte n); //Convierte de Decimal a Binary Coded Decimal
    //Creamos un array con los segundos que contienen los meses del año acumulados.
    //Sólo llegamos hasta noviembre
    //Mes - días - segundos - acumulado
    //Ene     31    2678400     2678400
    //Feb     28    2419200     5097600
    //Mar     31    2678400     7776000
    //Abr     30    2592000    10368000
    //May     31    2678400    13046400
    //Jun     30    2592000    15638400
    //Jul     31    2678400    18316800
    //Ago     31    2678400    20995200
    //Sep     30    2592000    23587200
    //Oct     31    2678400    26265600
    //Nov     30    2592000    28857600
    const uint32_t _secondsPerMonth[11]={2678400,5097600,7776000,10368000,13046400,15638400,18316800,20995200,23587200,26265600,28857600};
    bool _leapYear(uint16_t y); //Indica si el año indicado es bisiesto
  public:
    const String dayName[7]={"Lun","Mar","Mie","Jue","Vie","Sab","Dom"};
    uint32_t datetime2seconds(RoJoDateTime *t); //Calcula el número se segundos transcurridos entre el 1-Ene-1900 hasta la fecha indicada
    void seconds2datetime(uint32_t s,RoJoDateTime *t); //Calcula la fecha correspondiente a los segundos trascurridos desde el 1-Ene-1900
    virtual bool begin(byte clockID,int8_t pinSDA=-1,int8_t pinSCL=-1); //Inicializa el RTC
    virtual void get(RoJoDateTime *t); //Obtiene la hora
    virtual void set(RoJoDateTime *t); //Fijar fecha y hora
    void set1900(uint32_t seconds1900); //Fijar fecha y hora con segundos desde 1-Ene-1900
    void set1970(uint32_t seconds1970); //Fijar fecha y hora con segundos desde 1-Ene-1970
};

#ifdef __arm__
  #include <RoJoRTC.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

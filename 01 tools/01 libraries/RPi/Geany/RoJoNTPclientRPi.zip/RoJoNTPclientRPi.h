/*
  Nombre de la librería: RoJoNTPclientRPi.h
  Versión: 20191127
  Autor: Ramón Junquera
  Descripción:
    Permite obtener la hora de un servidor NTP
    Versión exclusiva para Raspberry Pi
*/

#ifndef RoJoNTPclientRPi_h
#define RoJoNTPclientRPi_h

#include <Arduino.h>
#include <netdb.h>
#include <string.h>

class RoJoNTPclient {
  private:
    String _ntpServer; //Nombre del servidor NTP
    int32_t _secondsOffset; //Diferencia por timeZone y summerTime en segundos
  public:
    void begin(String ntpServer,int8_t timeZone,bool summerTime); //Inicialización
    uint32_t get(); //Devuelve el tiempo en segundos desde 1900
};

#ifdef __arm__
  #include <RoJoNTPclientRPi.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

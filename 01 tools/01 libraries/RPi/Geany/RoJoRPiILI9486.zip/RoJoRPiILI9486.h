/*
  Nombre de la librería: RoJoRPiILI9486.h
  Versión: 20180413
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RPI_ILI9486 SPI 3.5" 320x480 para RPi
    Permite la gestión de sprites
*/

#ifndef RoJoRPiILI9486_h
#define RoJoRPiILI9486_h

#include <Arduino.h>
#include <SPI.h> //Gestión de comunicaciones SPI
#include "RoJoSprite16.h" //Gestión de sprites color

#ifdef __arm__ //Si es una RPi...
  #include <FS.h>
#else //Si es una RPi...
  #error Driver for RPi only
#endif

class RoJoRPiILI9486
{
  private:
    //Tamaño del display sin rotación
    const uint16_t _xMaxDefault=320; //Anchura de display
    const uint16_t _yMaxDefault=480; //Altura de display
    //Pinout
    const byte _pinRES_display=25;
    const byte _pinDC_display=24;
    const byte _pinCS_display=8;
    //Tamaño del display teniendo en cuenta la rotación
    uint16_t _xMax=320; //Anchura de display
    uint16_t _yMax=480; //Altura de display
    //Configuraciones de rotación
    byte _rotationCodes[4]={0b01001000,0b00101000,0b10001000,0b11101000};
    //La memoria de vídeo interna es un sprite
    RoJoSprite16 *_videoMem;
    //Características de la conexión SPI
    const SPISettings _spiSetting=SPISettings(8000000,MSBFIRST,SPI_MODE0); //Frecuencia 80MHz
    //Inicia una transacción SPI
    void _startSPI();
    //Finaliza una transacción SPI
    void _endSPI();
    //Cambia estado del pin CS
    void _changeCS(bool s);
    //Escribe un comando en el display
    void _writeCommand(byte command);
    //Escribe un en el display
    void _writeData(byte d); //Un dato de 8bits
    //Fija el rango horizontal del cursor
    void _setCursorRangeX(int16_t x1,int16_t x2);
    //Fija el rango vertical del cursor
    void _setCursorRangeY(int16_t y1,int16_t y2);
    //Fija el rango del cursor
    void _setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2);
  public:
    //La memoria de vídeo es un sprite
    RoJoSprite16 *videoMem;
    //Reset
    void softReset();
    void hardReset();
    //Sale del modo de bajo consumo
    void sleepOut();
    //Entra en modo de bajo consumo
    void sleepIn();
    //Activar display
    void on();
    //Desactivar display
    void off();
    //Inicialización
    void begin();
    //Obtiene el código de color en base a sus componentes
    uint16_t getColor(byte r,byte g,byte b);
    //Descompone un color en sus componentes
    void getComponents(uint16_t color,byte *r,byte *g,byte *b);
    //Configura la rotación
    void rotation(byte r);
    //Devuelve la anchura
    uint16_t xMax();
    //Devuelve la altura
    uint16_t yMax();
    //Envía memoria de vídeo al display
    void show();
}; //Punto y coma obligatorio para que no de error

#endif


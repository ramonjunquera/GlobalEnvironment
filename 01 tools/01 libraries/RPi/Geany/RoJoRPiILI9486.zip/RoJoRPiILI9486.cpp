/*
  Nombre de la librería: RoJoRPiILI9486.h
  Versión: 20180413
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RPI_ILI9486 SPI 3.5" 320x480 para RPi
    Permite la gestión de sprites
*/

#ifndef RoJoRPiILI9486_cpp
#define RoJoRPiILI9486_cpp

#include <Arduino.h>
#include <SPI.h> //Gestión de comunicaciones SPI
#include "RoJoRPiILI9486.h" //Gestión del display
#include "RoJoSprite16.h" //Gestión de sprites color

#ifdef __arm__ //Si es una RPi...
  #include <FS.h>
#else //Si es una RPi...
  #error Driver for RPi only
#endif

void RoJoRPiILI9486::_startSPI()
{
  //Inicia una transacción SPI
  SPI.beginTransaction(_spiSetting);
}

void RoJoRPiILI9486::_endSPI()
{
  //Finaliza una transacción SPI
  SPI.endTransaction();
}

void RoJoRPiILI9486::_writeCommand(byte command)
{
  //Escribe un comando en el display

  digitalWrite(_pinDC_display,LOW); //Enviaremos un comando
  _changeCS(false); //Seleccionamos el display
  SPI.transfer(command); //Enviamos el comando
  _changeCS(true); //Deseleccionamos el display
  digitalWrite(_pinDC_display,HIGH); //Lo siguiente a enviar será un dato
}

void RoJoRPiILI9486::_writeData(byte d)
{
  //Escribe un dato de 8bits en el display

  _changeCS(false); //Seleccionamos el display
  SPI.transfer(d); //Enviamos el dato
  _changeCS(true); //Deseleccionamos el display
}

void RoJoRPiILI9486::softReset()
{
  _startSPI();
    _writeCommand(0x01); //Comando soft reset
    delay(5);
  _endSPI();

  //Comenzamos una transacción
  _startSPI();
    _writeCommand(0x3A); //Selecciona la profundidad de color de pixel (Interface Pixel Format)
    _writeData(0x55); // 01010101 = 0101 (RGB 16 bits/pixel) + 0101 (CPU 16 bits/pixel). Sólo usamos el formato de 16bits, no de 18.

    _writeCommand(0xC2); //Selecciona la frecuencia de los circuitos de setup (Power Control 3)
    _writeData(0x44); // 01000100 = 0100 (setup cycle for circuits 1/4/5 = 2H) + 0100 (setup cycle for circuits 2/3 = 8H)

    _writeCommand(0xC5); //(VCOM Control)
    _writeData(0x00); //NV memory is not programmed
    _writeData(0x00); //VCM_REG = -2
    _writeData(0x00); //VCOM value from NV memory
    _writeData(0x00); //VCM_OUT = -2

    _writeCommand(0xE0); //Set the gray scale voltage to adjust the gamma characteristics of the TFT panel (PGAMCTRL: Positive Gamma Control)
    _writeData(0x0F); //VP0
    _writeData(0x1F); //VP1
    _writeData(0x1C); //VP2
    _writeData(0x0C); //VP4
    _writeData(0x0F); //VP6
    _writeData(0x08); //VP13
    _writeData(0x48); //VP20
    _writeData(0x98); //VP36 & VP27
    _writeData(0x37); //VP43
    _writeData(0x0A); //VP50
    _writeData(0x13); //VP57
    _writeData(0x04); //VP59
    _writeData(0x11); //VP61
    _writeData(0x0D); //VP62
    _writeData(0x00); //VP63

    _writeCommand(0xE1); //Set the gray scale voltage to adjust the gamma characteristics of the TFT panel (NGAMCTRL: Negative Gamma Correction)
    _writeData(0x0F); //VN0
    _writeData(0x32); //VN1
    _writeData(0x2E); //VN2
    _writeData(0x0B); //VN4
    _writeData(0x0D); //RVN6
    _writeData(0x05); //VN13
    _writeData(0x47); //VN20
    _writeData(0x75); //VN36 & VN27
    _writeData(0x37); //VN43
    _writeData(0x06); //VN50
    _writeData(0x10); //VN57
    _writeData(0x03); //VN59
    _writeData(0x24); //VN61
    _writeData(0x20); //VN62
    _writeData(0x00); //VN63

    _writeCommand(0x20); //(Display Inversion OFF)
  _endSPI();

  //Si aun no se ha creado el sprite de la memoria de vídeo...lo creamos
  if(!videoMem) videoMem = new RoJoSprite16();
  //Si aun no se ha creado el sprite de la memoria de vídeo...lo creamos
  if(!_videoMem) _videoMem = new RoJoSprite16();
  //Rotación 0: 320x480. Vertical. Conector arriba dcha
  rotation(0);
  //Encendemos el display
  on();
  //Salimos del modo de bajo consumo
  sleepOut();
  
  //Obligamos a refrescar y escribir la memoria de vídeo
  //Con esto conseguimos limpiar el display y sincronizar las memorias de vídeo
  show();
}

void RoJoRPiILI9486::hardReset()
{
  //Hace un hard reset
  
  //Reseteo de hardware
  digitalWrite(_pinRES_display,LOW);
  delay(20);
  digitalWrite(_pinRES_display,HIGH);
  delay(150);
  //Siempre despues de un hard reset se debe hacer un soft reset
  softReset();
}

void RoJoRPiILI9486::sleepOut()
{
  //Sale del modo de bajo consumo

  _startSPI();
    _writeCommand(0x11); //Sleep OUT
    delay(120);
  _endSPI();
}

void RoJoRPiILI9486::sleepIn()
{
  //Entra en modo de bajo consumo

  //En este modo se desactiva la pantalla, pero se conserva la memoria de vídeo
  //y sigue admitiendo nuevos comandos.

  _startSPI();
    _writeCommand(0x10); //Sleep IN
    delay(5);
  _endSPI();
}

void RoJoRPiILI9486::on()
{
  //Activa el display

  _startSPI();
    _writeCommand(0x29); //Display ON
  _endSPI();
}

void RoJoRPiILI9486::off()
{
  //Activa el display

  _startSPI();
    _writeCommand(0x28); //Display OFF
  _endSPI();
}

void RoJoRPiILI9486::begin()
{
  //Inicialización del display

  //Inicializamos las conexiones SPI
  SPI.begin();
  
  //Siempre escribiremos en los pines DC, RES y CS
  pinMode(_pinDC_display,OUTPUT);
  pinMode(_pinRES_display,OUTPUT);
  pinMode(_pinCS_display,OUTPUT);

  digitalWrite(_pinRES_display,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC_display,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS_display,HIGH); //Comenzamos sin seleccionar el chip
  
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  SPI.setHwCs(false);

  //Inicializamos el acceso al sistema de archivos
  SPIFFS.begin();

  hardReset();
}

void RoJoRPiILI9486::_setCursorRangeX(int16_t x1,int16_t x2)
{
  //Fija el rango de horizontal del cursor
  //Funcion interna. Sin gestión de SPI
  //No comprobamos coherencia de parámetros

  _writeCommand(0x2A); //0x2A=Column Address Set
  _writeData((byte)(x1>>8));
  _writeData((byte)(x1 & 0xFF));
  _writeData((byte)(x2>>8));
  _writeData((byte)(x2 & 0xFF));
}

void RoJoRPiILI9486::_setCursorRangeY(int16_t y1,int16_t y2)
{
  //Fija el rango de vertical del cursor
  //Funcion interna. Sin gestión de SPI
  //No comprobamos coherencia de parámetros

  _writeCommand(0x2B); //0x2B=Page Address Set
  _writeData((byte)(y1>>8));
  _writeData((byte)(y1 & 0xFF));
  _writeData((byte)(y2>>8));
  _writeData((byte)(y2 & 0xFF));
}

void RoJoRPiILI9486::_setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2)
{
  //Fija el rango de horizontal y vertical del cursor
  //Funcion interna. Sin gestión de SPI
  //No comprobamos coherencia de parámetros

  _setCursorRangeX(x1,x2);
  _setCursorRangeY(y1,y2);
}

uint16_t RoJoRPiILI9486::getColor(byte r,byte g,byte b)
{
  //Obtiene el código de color en base a sus componentes
    
  //La profundidad de color de cada canal es:
    
  //  Canal : color : bits
  //  -----   -----   ----
  //    R     red       5
  //    G     green     6
  //    B     blue      5
  //La composición final de los 16 bits quedará así:
  // RRRRRGGG GGGBBBBB
    
  uint16_t c = r >> 3;
  c <<= 6;
  c |= g >> 2;
  c <<= 5;
  c |= b >> 3;
  return c;
}

void RoJoRPiILI9486::getComponents(uint16_t color,byte *r,byte *g,byte *b)
{
  //Descompone un color en sus componentes
  
  //El color lo tenemos en formato
  // RRRRRGGG GGGBBBBB
  *r = color >> 11;
  *g = (color >> 5) & 0b111111;
  *b = color & 0b11111;
}

uint16_t RoJoRPiILI9486::xMax()
{
  //Devuelve la anchura
  return _xMax;
}

uint16_t RoJoRPiILI9486::yMax()
{
  //Devuelve la altura
  return _yMax;
}

void RoJoRPiILI9486::rotation(byte r)
{
  //Configura la rotación

  // r : posición conector : orientación : código
  //---  -----------------   -----------   -------
  // 0 : arriba dcha         vertical      0b01001000 = BGR(00001000) + MX(01000000)
  // 1 : arriba izda         apaisado      0b00101000 = BGR(00001000) + MV(00100000)
  // 2 : abajo izda          vertical      0b10001000 = BGR(00001000) + MY(10000000)
  // 3 : abajo dcha          apaisado      0b11101000 = BGR(00001000) + MV(00100000) + MX(01000000) + MY(10000000)
  
  //Nos aseguramos que es un valor permitido
  r%=4;
  
  _startSPI();
    _writeCommand(0x36);  //Memory access control
    _writeData(_rotationCodes[r]); //Código correspondiente a la rotación
  _endSPI();
  
  //Si la rotación es impar
  if(r%2)
  {
    //El formato será apaisado
    _xMax=_yMaxDefault;
    _yMax=_xMaxDefault;
  }
  else
  {
    //El formato será vertical
    _xMax=_xMaxDefault;
    _yMax=_yMaxDefault;
  }
  
  //Dimensionamos el sprite de la memoria de vídeo
  (*videoMem).setSize(_xMax,_yMax);
  //Dimensionamos el sprite de la memoria interna de vídeo
  (*_videoMem).setSize(_xMax,_yMax);
  //Llenamos la memoria de vídeo interna con datos
  //Esto obligará a actualizar la pantalla completa en el siguiente refresco
  (*_videoMem).clear(0,0,_xMax-1,_yMax-1,1);
}

void RoJoRPiILI9486::_changeCS(bool status)
{
  //Cambia estado del pin CS
  
  //Esta función se crea porque en procesadores rápidos, el display no
  //detecta a tiempo el cambio del estado del pin CS. Necesita un
  //instante.
  //Para consumir el tiempo necesario, volvemos a aplicar el mismo estado
  //al pin CS.
  
  digitalWrite(_pinCS_display,status);
  digitalWrite(_pinCS_display,status);
}

void RoJoRPiILI9486::show()
{
  //Envía al display las diferencias entre la memoria de vídeo de 
  //trabajo y la memoria interna de vídeo
  
  bool selectedRangeY; //Se ha seleccionado el rango vertical con la fila procesada?
  int16_t x; //Columna
  uint16_t lastChangedColumn; //Última columna modificada
  uint16_t processedColumn; //Columna procesada

  _startSPI();
  for(int16_t y=0;y<_yMax;y++) //Recorremos todas filas
  {
    //Por ahora no se ha inicializado el rango vertical para la fila actual
    selectedRangeY=false;
    //Comenzamos por la primera columna
    x=0;
    //Mientras no hayamos procesado todas las columnas...
    while(x<_xMax)
    {
      //Si el pixel actual no se ha modificado...
      if((*videoMem).getPixel(x,y)==(*_videoMem).getPixel(x,y))
      {
        //...no tenemos en cuenta este pixel. Pasaremos al siguiente
        x++;
      }
      else //El byte actual ha sido modificado y debe ser enviado
      {
        //Si no se ha seleccionado la fila actual...
        if(!selectedRangeY)
        {
		  //...lo hacemos ahora
		  _setCursorRangeY(y,y);
		  //y lo anotamos
		  selectedRangeY=true;
		}
        //Consideramos este pixel como procesado/enviado
        //Actualizamos su valor en la memoria de vídeo interna
        (*_videoMem).drawPixel(x,y,(*videoMem).getPixel(x,y));
        //Por ahora la última columna modificada es la primera
        lastChangedColumn=x;
        //Columna procesada = la siguiente a la primera
        processedColumn=x+1;
        //Mientras la columna procesada esté dentro del rango visible
        //y llevemos menos de 5 bytes sin modificar...
        while(processedColumn<_xMax && processedColumn-lastChangedColumn<=5)
        {
          //Si el pixel de la columna procesada se debe enviar (porque es distinto)...
          if((*videoMem).getPixel(processedColumn,y)!=(*_videoMem).getPixel(processedColumn,y))
          {
            //...anotamos que la última columna con cambios es la actual
            lastChangedColumn=processedColumn;
            //Consideramos este byte como procesado/enviado
            (*_videoMem).drawPixel(processedColumn,y,(*videoMem).getPixel(processedColumn,y));
          }
          //Aumentamos la posición de la columna procesada
          processedColumn++;
        } //end while
        //Seleccionamos como rango horizontal desde la columna actual hasta la última distinta
        _setCursorRangeX(x,lastChangedColumn);
        //Enviamos los datos gráficos
        _writeCommand(0x2C); //Write memory
        _changeCS(false); //Seleccionamos el display
        for(uint16_t x0=x;x0<=lastChangedColumn;x0++) SPI.transfer16((*videoMem).getPixel(x0,y));
        _changeCS(true); //Deseleccionamos el display
        //La primera columna pasará a ser la actual
        x=processedColumn;
      }
    }
  }
  _endSPI();
}

#endif

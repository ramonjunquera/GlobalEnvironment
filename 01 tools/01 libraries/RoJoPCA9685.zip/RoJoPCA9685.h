/*
  Nombre de la librería: RoJoPCA9685.h
  Versión: 20180530
  Autor: Ramón Junquera
  Descripción:
    Gestión de PCA9685 - 16xPWM
*/

#ifndef RoJoPCA9685_h
#define RoJoPCA9685_h

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C

class RoJoPCA9685
{
  private:
    //Identificador del módulo PCA9685
    byte _i2cId;
    //Envía comando
    void _writeCommand(byte commandId,byte data);
    //Array de valores máximos de servos (180 grados)
    uint16_t _max[16];
    //Array de valores mínimos de servos (0 grados)
    uint16_t _min[16];
  public:
    //Inicialización
    void begin(byte i2cId=0x40,byte pinSDA=255,byte pinSCL=255);
    //Reset
    void reset(void);
    //Fija frecuencia PWM
    void setFreq(float freq);
    //Fija valor PWM para un canal
    void setPWM(byte channel,uint16_t level);
    //Fija los valores límite de un servo para un canal (0 y 180 grados)
    void setServoLimits(byte channel,uint16_t minValue,uint16_t maxValue);
    //Fija un servo a un ángulo
    void setServoDegrees(byte channel,byte degrees);
}; //Punto y coma obligatorio para que no de error

#endif

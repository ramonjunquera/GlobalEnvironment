/*
  Nombre de la librería: RoJoPCA9685.h
  Versión: 20180530
  Autor: Ramón Junquera
  Descripción:
    Gestión de PCA9685 - 16xPWM
*/

#ifndef RoJoSprite16_cpp
#define RoJoSprite16_cpp

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#include "RoJoPCA9685.h"

void RoJoPCA9685::begin(byte i2cId,byte pinSDA,byte pinSCL)
{
  //Inicialización

  //Guardamos el identificador I2C en la variable privada
  _i2cId=i2cId;
  //Inicializamos el protocolo I2C
  #if defined(ARDUINO_ARCH_AVR) || defined(__arm__) //Si es una placa Arduino o una RPi ...
    //En las placas Arduino o RPi, no se pueden seleccionar los pines I2C
    //Los posibles pines I2C no se tendrán en cuenta
    Wire.begin();
  #else //No es una placa Arduino ni RPi. Es una ESP.
    //Si se ha indicado pin de I2C (SDA & SCL)...activamos el I2C personalizado
    if(pinSCL<255) Wire.begin(pinSDA,pinSCL);
    //...y si no...usamos una I2C con los pines por defecto
    else Wire.begin();
  #endif
  //Reseteamos el módulo
  reset();
  //Fijamos la frecuencia del bus I2C a 400KHz
  Wire.setClock(400000);
  //Fijamos los valores por defecto máximo y mínimos de los servos
  for(byte c=0;c<16;c++)
  {
    _min[c]=170;
    _max[c]=610;
  }
}

void RoJoPCA9685::reset(void)
{
  //Resetea el módulo
  
  //Antes de resetear, apagamos todos los canales del módulo
  //Para ello les asignamos a todos a la vez un inicio de 0 y un final de 0
  //Param 0: 0xFA : dirección base para todos los canales
  //Param 1: 0 : all leds on LB
  //Param 2: 0 : all leds on HB
  //Param 3: 0 : all leds off LB
  //Param 4: 0 : all leds off HB
  byte buffer[5]={0xFA,0,0,0,0};
  Wire.beginTransmission(_i2cId);
  Wire.write(buffer,5);
  Wire.endTransmission();
  
  //Enviamos comando de reset
  _writeCommand(0x00,0x80); //Comando: PCA9685_MODE1. Valor: reset
  //Una petición de reset tarda aproximadamente 500 microsegundos
  //en dejar el módulo operativo de nuevo.
  //Por seguridad nosotros esperaremos un milisegundo
  delay(1);
  //Fijamos por defecto la frecuencia de refresco al máximo: 1600Hz
  setFreq(1600);
}

void RoJoPCA9685::setFreq(float freq)
{
  //Fija la frecuencia de refresco
  //Debería estar en el rango de 24 a 1600 Hz

  //Calculamos el prescale. Es el valor que indica al reloj
  //interno del módulo cada cuántos ciclos debe refrescar el
  //estado de PWM de todos sus canales.
  //El PCA9685 tiene un reloj interno de 25 MHz (25000000 Hz).
  //La fórmula correcta es la siguiente:
  //byte prescale = 25000000/4096/freq;
  //La fórmula resumida queda así:
  byte prescale = 6103.5/freq;

  _writeCommand(0x00,0x10); //Comando: PCA9685_MODE1. Valor: sleep para que el cambio no afecte
  _writeCommand(0xFE,prescale); //Comando: PCA9685_PRESCALE. Valor: prescale calculado
  _writeCommand(0x00,0xA0); //Comando: PCA9685_MODE1. Valor: despierta en modo normal con auto incremento
  delay(5); //Tarda un momento en despertar
}

void RoJoPCA9685::setPWM(byte channel,uint16_t level)
{
  //Fija valor PWM para un canal
  
  byte buffer[5]={6+4*channel,0,0,(byte)(level&0xFF),(byte)(level>>8)};
  Wire.beginTransmission(_i2cId);
  Wire.write(buffer,5);
  Wire.endTransmission();
}

void RoJoPCA9685::_writeCommand(byte commandId,byte data)
{
  //Envía un comando por I2C
  
  byte buffer[2]={commandId,data};
  Wire.beginTransmission(_i2cId);
  Wire.write(buffer,2);
  Wire.endTransmission();
}

void RoJoPCA9685::setServoLimits(byte channel,uint16_t minValue,uint16_t maxValue)
{
  //Fija los valores límite de un servo para un canal (0 y 180 grados)

  //Guardamos los valores
  _min[channel]=minValue;
  _max[channel]=maxValue;
}

void RoJoPCA9685::setServoDegrees(byte channel,byte degrees)
{
  //Fija un servo a un ángulo

  setPWM(channel,(float)(_max[channel]-_min[channel])*(float)degrees/180.0+(float)_min[channel]);
}

#endif

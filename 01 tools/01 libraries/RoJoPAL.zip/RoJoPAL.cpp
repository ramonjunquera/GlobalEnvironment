/*
  Nombre de la librería: RoJoPAL.h
  Versión: 20210201
  Autor: Ramón Junquera
  Descripción:
    Gestión de señal de vídeo compuesta PAL
*/

#ifndef RoJoPAL_cpp
#define RoJoPAL_cpp

#include <RoJoPAL.h>

//Inicializacion
//- *spr : puntero a sprite de grises máx 653x218
//- pinRCA : pin de salida de vídeo. Obligatorio in DAC (el 25 o el 26). Por defecto 25
//Devuelve true si todo es Ok
bool RoJoPAL::begin(RoJoSprite2 *spr,byte pinRCA) {
  if(spr->xMax()==0) return false; //Sprite vacío
  if(spr->bytesPerPixel()!=1) return false; //Sólo se admiten sprites grises
  if(spr->xMax()>_RoJoPAL_xMaxVisible || spr->yMax()>_RoJoPAL_yMaxVisible) return false; //Demasiado grande
  _spr=spr; //Guardamos el puntero del sprite en la variable privada
  //Calculamos los márgenes
  _marginLeft=(_RoJoPAL_xMaxDisplay-spr->xMax())/2;
  _marginUp=(_RoJoPAL_yMaxDisplay-spr->yMax())/2;
  _marginDown=_RoJoPAL_yMaxDisplay-_marginUp-spr->yMax();

  //Calculamos la tabla de conversión de tonos
  for(uint16_t i=0;i<256;i++) _tone[i]=((_RoJoPAL_signalBlack>>8)+i*((_RoJoPAL_signalWhite>>8)-(_RoJoPAL_signalBlack>>8)+1)/255)<<8;

  i2s_driver_uninstall(I2S_NUM_0); //Nos aseguramos que no se utilice el canal 0 de I2S
  i2s_config_t i2s_config={ //Definición de configuración I2S
    //Parámetros:
    //  I2S_MODE_MASTER : Generaremos nosotros mismos la señal de reloj
    //  I2S_MODE_TX : La señal será de envío
    //  I2S_MODE_DAC_BUILT_IN : La señal se enviará a los DAC integrados
    //Nota: Como los DAC integrados tienen una resolución de 8 bits, no se tiene en cuenta
    //el tamaño de la muestra. Sólo se entregan al DAC los 8 primeros bits y el resto
    //se descartan.
    .mode=(i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN),
    .sample_rate=10000,  //No será el valor real. Se calculará más adelante
    .bits_per_sample=I2S_BITS_PER_SAMPLE_16BIT, //Tamaño más pequeño. No se admiten 8 bits
    .channel_format=I2S_CHANNEL_FMT_ONLY_LEFT,
    //Imprescindible indicar que sólo se tendrán en cuenta los primeros bits de la muestra
    //con valor I2S_COMM_FORMAT_I2S_MSB. Si indicamos que se tienen en cuenta todos con
    //I2S_COMM_FORMAT_I2S, no se enviará nada.
    .communication_format=I2S_COMM_FORMAT_I2S_MSB,
    .intr_alloc_flags=ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count=2,
    .dma_buf_len=_RoJoPAL_samplesPerLine //El buffer contendrá la línea completa
  };
  //Sólo se puede utilizar el canal 0 de I2S para trabajcar con DAC o ADC.
  if(i2s_driver_install(I2S_NUM_0,&i2s_config,0,NULL)) return false;
  switch (pinRCA) { //Activamos el DAC que corresponde
    case 25:
      i2s_set_dac_mode(I2S_DAC_CHANNEL_RIGHT_EN);
      break;
    case 26:
      i2s_set_dac_mode(I2S_DAC_CHANNEL_LEFT_EN);
      break;
    default: //Si no es ninguno de los anteriores...
      return false; //...devolvemos error
      break;
  }
  //La frecuencia de muestreo asignada no es la correcta.
  //Configuramos la frecuencia máxima (13.333 MHz) utilizando registros.
  SET_PERI_REG_BITS(I2S_CLKM_CONF_REG(0),I2S_CLKM_DIV_A_V,1,I2S_CLKM_DIV_A_S);
  SET_PERI_REG_BITS(I2S_CLKM_CONF_REG(0),I2S_CLKM_DIV_B_V,1,I2S_CLKM_DIV_B_S);
  SET_PERI_REG_BITS(I2S_CLKM_CONF_REG(0),I2S_CLKM_DIV_NUM_V,2,I2S_CLKM_DIV_NUM_S); 
  SET_PERI_REG_BITS(I2S_SAMPLE_RATE_CONF_REG(0),I2S_TX_BCK_DIV_NUM_V,2,I2S_TX_BCK_DIV_NUM_S);
  return true; //Todo Ok
}

//Envía las muestras contenidas en el array _line
void RoJoPAL::_sendVideoRow() {
  size_t bytes_written = 0;
  i2s_write(I2S_NUM_0,(const void *)_line,_RoJoPAL_samplesPerLine*2,&bytes_written,portMAX_DELAY);
}
  
//Llena el array _line con una señal un número determinado de veces
//Nota: counter debe ser un número par
void RoJoPAL::_fillLine(uint16_t signal,uint16_t counter) {
  for(uint16_t t=counter;t>0;t--) _line[_linePos++]=signal;
}

//Compone y envía las líneas del sprite
void RoJoPAL::_showSprite() {
  //Todas la líneas con información gráfica comparten:
  //- Cabecera de sincronización horizontal
  //- Márgen izquierdo
  //- Márgen derecho
  //- Pie de sincronización horizontal

  //Rellenaremos estos datos comunes una sóla vez
  uint16_t xMax=_spr->xMax(),yMax=_spr->yMax();;
  _linePos=0;
  //Cabecera de sincronización horizontal
  _fillLine(_RoJoPAL_signalNull,64);
  _fillLine(_RoJoPAL_signalBase,76);
  uint16_t spriteOffset=_linePos+_marginLeft; //Guardamos posición de inicio de sprite
  //Márgen izquierdo + imagen + márgen derecho
  _fillLine(_RoJoPAL_signalBlack,_RoJoPAL_xMaxDisplay);
  //Final de sincronización horizontal
  _fillLine(_RoJoPAL_signalBase,22);

  //Rellenamos sólo la información del sprite
  byte *videoMemSprRow;
  for(byte y=0;y<yMax;y++) { //Recorremos todas las filas del sprite
    videoMemSprRow=_spr->_videoMem[y];
    //Recorremos todas los pixels de anchura del sprite
    //Convertimos al rango de tonos de PAL
    //Y guardamos el resultado en la posición de la línea que corresponde
    //Bucle inverso para optimizar velocidad (siempre se compara con constante 0)
    for(int16_t x=xMax-1;x>=0;x--) _line[(spriteOffset+x)^1]=_tone[videoMemSprRow[x]];
    _sendVideoRow(); //Mostramos la línea que hemos confeccionado
  }
}

//Escribe un pulso largo en media memoria de línea
void RoJoPAL::_fillLineLong() {
  _fillLine(_RoJoPAL_signalNull,396);
  _fillLine(_RoJoPAL_signalBase,30);
}

//Escribe un pulso corto en media memoria de línea
void RoJoPAL::_fillLineShort() {
  _fillLine(_RoJoPAL_signalBase,30);
  _fillLine(_RoJoPAL_signalNull,396);
}

//Escribe una línea negra en la memoria de línea
void RoJoPAL::_fillLineBlack() {
  _linePos=0;
  _fillLine(_RoJoPAL_signalNull,64);
  _fillLine(_RoJoPAL_signalBase,76);
  _fillLine(_RoJoPAL_signalBlack,690);
  _fillLine(_RoJoPAL_signalBase,22);
}

//Escribe la señal base en media memoria de línea
void RoJoPAL::_fillLineBase() {
  _fillLine(_RoJoPAL_signalBase,426);
}

//Escribe un pulso medio en media memoria de línea
void RoJoPAL::_fillLineMedium() {
  _fillLine(_RoJoPAL_signalNull,62);
  _fillLine(_RoJoPAL_signalBase,364);
}

void RoJoPAL::_sendVideoFrame() {
  //Líneas impares
  //_line 1: long + long
  //_line 2: long + long
  _linePos=0; _fillLineLong(); _fillLineLong();
  _sendVideoRow();
  _sendVideoRow();

  //_line 3: long + short
  _linePos=0; _fillLineLong(); _fillLineShort();
  _sendVideoRow();

  //_line 4: short + short
  //_line 5: short + short
  _linePos=0; _fillLineShort(); _fillLineShort();
  _sendVideoRow();
  _sendVideoRow();

  //_line 6: negra*_marginUp
  _fillLineBlack();
  for(byte c=0;c<_marginUp;c++) _sendVideoRow();

  //_line 6+_marginUp: imágen*yMax
  _showSprite(); //Compone y muestra las líneas del sprite

  //_line 6+_marginUp+yMax: negra*_marginDown
  _fillLineBlack();
  for(byte c=0;c<_marginDown;c++) _sendVideoRow();
  _sendVideoRow(); //Las líneas impares tienen una línea más de margen inferior

  //_line 311: short + short
  //_line 312: short + short
  _linePos=0; _fillLineShort(); _fillLineShort();
  _sendVideoRow();
  _sendVideoRow();

  //_line 313: short + long. Última de las líneas impares
  _linePos=0; _fillLineShort(); _fillLineLong();
  _sendVideoRow(); 

  //Líneas pares
  //_line 314: long + long
  //_line 315: long + long
  _linePos=0; _fillLineLong(); _fillLineLong();
  _sendVideoRow();
  _sendVideoRow();

  //_line 316: short + short
  //_line 317: short + short
  _linePos=0; _fillLineShort(); _fillLineShort();
  _sendVideoRow();
  _sendVideoRow();

  //_line 318: short + señal base
  _linePos=0; _fillLineShort(); _fillLineBase();
  _sendVideoRow();

  //_line 319: negra*_marginUp
  _fillLineBlack();
  for(byte c=0;c<_marginUp;c++) _sendVideoRow();

  //_line 319+_marginUp: imágen*yMax
  _showSprite(); //Compone y muestra las líneas del sprite

  //_line 319+_marginUp+yMax: negra*_marginDown
  _fillLineBlack();
  for(byte c=0;c<_marginDown;c++) _sendVideoRow();

  //_line 623: medium + short
  _linePos=0; _fillLineMedium(); _fillLineShort();
  _sendVideoRow();

  //_line 624: short + short
  //_line 625: short + short. Última de las líneas pares
  _linePos=0; _fillLineShort(); _fillLineShort();
  _sendVideoRow();
  _sendVideoRow();
}

RoJoPAL PAL; //Creamos objeto de gestion
bool _PAL_requestStop=false; //No se ha solicitado su parada
bool _PAL_running=false; //El refresco no está activo

void PAL_refreshTask(void *parameter) { //Función de tarea
  _PAL_running=true; //Se activa el refresco de pantalla
  //Mientras no se solicite detener...seguimos refrescando la pantalla
  while(!_PAL_requestStop) PAL._sendVideoFrame();
  _PAL_requestStop=false; //Informamos que hemos atendido la solicitud
  _PAL_running=false; //El refresco de pantalla está inactivo
  vTaskDelete(NULL); //Borramos la tarea actual
}

//Inicialización del driver PAL
//Devuelve true si lo consigue
bool PAL_begin(RoJoSprite2 *spr,byte pinRCA) {
  PAL_end(); //Nos aseguramos que el refresco de pantalla está desactivado
  //Pasamos todos los parámetros a la inicialización de la clase
  //Si no podemos inicializar...devolvemos error
  if(!PAL.begin(spr,pinRCA)) return false;
  //Lanzamos tarea de refresco de pantalla en core 0
  xTaskCreatePinnedToCore(PAL_refreshTask,"",1024,NULL,1,NULL,0);
  return true; //Todo Ok
}

//Finaliza el refresco de pantalla
void PAL_end() {
  if(!_PAL_running) return; //Si no está en marcha...hemos terminado
  _PAL_requestStop=true; //Solicitamos detener la tarea de refresco
  while(_PAL_requestStop) delay(1); //Esperamos hasta que se atienda la solicitud
}

#endif

/*
  Nombre de la librería: RoJoMelody.h
  Fecha: 20191004
  Autor: Ramón Junquera
  Tema: Librería para reproducción de melodías
*/

#ifndef RoJoMelody_cpp
#define RoJoMelody_cpp

#include <RoJoMelody.h>

//Constructor
RoJoMelody::RoJoMelody(byte pinBuzzerParameter) {
  pinBuzzer=pinBuzzerParameter; //Guardamos el pin al que está conectado el buzzer
  notesCount=0; //Inicialmente la canción no tiene notas
};

//Devuelve el valor numérico del carácter [0-9]
//Si no es numérico, devuelve 10
byte RoJoMelody::valueChar(char chr) {
  //Si es un carácter numérico...devuelve su valor
  if(chr>='0' && chr<='9') return chr-48;
  //Si no es un carácter numérico...devuelve 10
  return 10;
}

//Devuelve el número de la nota. 0 si no es un caracter de nota. 13 si es la nota de silencio
byte RoJoMelody::isNote(char chr) {
  switch(chr) {
    case 'C': return 1;
    case 'D': return 3;
    case 'E': return 5;
    case 'F': return 6;
    case 'G': return 8;
    case 'A': return 10;
    case 'B': return 12;
    case 'S': return 13;
  }
  return 0; //Si no es ninguna de las anteriores...devuelve 0
};

//Finaliza la reproducción de la canción
void RoJoMelody::stop() {
  noTone(pinBuzzer); //Paramos el sonido
  _playing=false; //Ya no se reproduce
}  

//Memoriza una nueva canción. Devuelve true si lo consigue
boolean RoJoMelody::setSong(String song,boolean loopingParameter) {
  //song contiene la cadena con la canción codificada
  //looping indica si la canción debe comenzar de nuevo al terminar
  
  stop(); //Paramos cualquier reproducción en curso
  looping=loopingParameter; //Guardamos si debe repetirse
  
  //Definimos valores iniciales
  byte lastOctave=4;
  byte octave=0;
  boolean octaveRead=false;  
  uint16_t lastDuration=500;
  uint16_t duration=0;
  byte note=0;
  char chr;
  byte noteRead;
  byte valueRead;
  
  song+="S"; //Añadimos a la cadena un silencio al final
  notesCount=0; //Por ahora no tenemos notas en la canción
  
  for(byte pos=0;pos<song.length();pos++) { //Recorremos todos los caracteres de la cadena
    chr=song[pos]; //Tomamos nota del carácter a procesar
    noteRead=isNote(chr); //Comprobamos si el carácter actual corresponde a una nota
    if(noteRead>0) { //Si corresponde a una nota...
      //La nota anterior no tendrá más detalles y deberíamos escribirla
      //Si no se le ha definido octava para la nota actual...la octava será la de la nota anterior
      if(octave==0) octave=lastOctave;
      //Si no se ha definido duración para la nota actual...la duración será la de la nota anterior
      if(duration==0) duration=lastDuration;
      //Si la nota actual es > 0 es que no es la primera nota y hay que tomarla en cuenta
      if(note>0) {
        //Calculamos y anotamos su frecuencia
        notes[notesCount][0]=freq10[note-1] >> (10-octave);
        //Anotamos su duración y pasamos a la siguiente nota de la canción
        notes[notesCount++][1]=duration;
      
      /*
        Serial.print("note=");
        Serial.print(note,DEC);
        Serial.print(",octave=");
        Serial.print(octave,DEC);
        Serial.print(",duration=");
        Serial.print(duration,DEC);
        Serial.print(",freq=");
        Serial.println(notes[notesCount-1][0],DEC);
      */
      
      }
      
      note=noteRead; //A partir de ahora, la nota actual será la nota leida
      octaveRead=false; //Y aun no hemos leido la octava
      lastOctave=octave; //La octava de la nota anterior será la actual
      octave=0; //Y la octava actual no se ha definido
      lastDuration=duration; //La duración de la nota anterior será la actual
      duration=0; //Y la duración de la nota actual no se ha definido
    }
    else  { //El carácter leido no es una nota...
      //Si es el símbolo de #...la nota sube medio tono
      if(chr=='#') note++;
      else { //No es el símbolo de #
        //Si es el signo - que separa la duración...la octava ya está leida
        if(chr=='-') octaveRead=true;
        else { //Tampoco es el signo -
          //Obtenemos el valor del carácter actual, porque tiene que ser un número
          valueRead=valueChar(chr);
          //Si el carácter no es numérico...es un error
          if(valueRead>9) return false;
          //El carácter leido en numérico
          //Si tenemos que actualizar las octavas porque aun no ha salido el separador de duración...
          if(!octaveRead)
            //...el valor actual se añade como unidades de la octava
            octave=octave*10+valueRead;
          else //La octava ya se anotó. El Valor actual es de la duración
            //...el valor actual se añade como unidades a la duración
            duration=duration*10+valueRead;
        }
      }
    }
  }
  //Hemos terminado de procesar la canción
  //Los datos que nos quedan por anotar corresponden al silencio que quemos añadido al comenzar la rutina
  //y no lo tendremos en cuenta
  return true; //Todo Ok
};

//Inicia la reproducción de la canción
void RoJoMelody::start() {
  stop(); //Paramos cualquier reproducción en curso
  if(notesCount>0) { //Si la canción tiene alguna nota...
    _currentNote=0; //Comenzamos por el principio
    _playing=true; //La reproducción está activa
    tone(pinBuzzer,notes[0][0]); //Reproducimos la primera nota
    _lastTime=millis(); //Tomamos nota del tiempo de inicio
  }
}

//Mantiene la gestión de la reproducción de la canción
void RoJoMelody::play() {
  if(_playing) { //Si se está reproduciendo la canción
    uint64_t currentTime=millis(); //Tomemos nota del tiempo actual
    if(currentTime-_lastTime>notes[_currentNote][1]) { //Si ya ha pasado el tiempo de duración de la nota actual...
      _currentNote++; //Pasamos a la siguiente nota
      if(_currentNote==notesCount) { //Si hemos llegado al final de la canción...
        if(!looping) { //Si la canción no se repite
          stop(); //La canción se ha terminado
          return; //Salimos de la función
        }
        _currentNote=0; //Hemos llegado al final y la canción se repite. Volvemos a empezar
      }
      //Si la frecuencia a reproducir es nula...silenciamos el buzzer
      if(notes[_currentNote][0]==0) noTone(pinBuzzer);
      //Si la frecuencia no es nula...reproducimos la nota
      else tone(pinBuzzer,notes[_currentNote][0]);
      _lastTime=currentTime; //Tomamos nota del tiempo de inicio de la nota
    }
  }
}

//Indica si se está reproduciendo la canción
boolean RoJoMelody::playing() {
  return _playing;
}

#endif
/*
  Nombre de la librería: RoJoMelody.h
  Fecha: 20191004
  Autor: Ramón Junquera
  Tema: Librería para reproducción de melodías
  Requisitos:
    - El objeto debe poder cambiar la canción tantas veces como se quiera.
    - No deberíamos preocuparnos por conocer la frecuencia de las notas.
    - Debe tener un sistema de codificación de canciones sencillo.
    - Llamaremos a la librería tantas veces como nos sea posible. Habitualmente, una por cada ciclo de ejecución.
    - Tenemos que saber si se está reproduciendo la canción.
    - Tenemos que poder repetir contínuamente una canción.
    - Tenemos que poder parar e iniciar a voluntad una canción.
  Descripción:
    Tenemos que las notas de la escala musical son: Do, Re, Mi, Fa, Sol, La, Si
    Si utilizamos la nomenclatura inglesa tenemos: C,D,E,F,G,A,B
    La definición de la escala cromática (con todos los medios tonos) será: C,C#,D,D#,E,F,F#,G,G#,A,A#,B
    Por convención se toma que el La central de un teclado de piano vibra con una frecuencia de 440Hz.
    Este La corresponde con el de la cuarta octava: A4 vibra a 440Hz
    La fórmula matemática para obtener las frecuencias de cualquier nota en cualquier octava es:
    f(n,o)=440*2^(o+(n-58/12)
    Donde n es el número de nota contando la primera como el Do: C=1,C#=2,D=3,D#=4,E=5,F=6,F#=7,G=8,G#=9,A=10,A#=11,B=12.
    o es el número de octava con valores útiles desde o=1 hasta o=10.
    Puesto que no pretendemos utilizar cálculos exponenciales para obtener cada una de la frecuencias que nos pidan
    utilizaremos un sisma más sencillo.
    Sabiendo que la frecuencia de una nota se duplica al subir una octava, calcularemos las frecuencias de la octava más
    alta (en este caso la 10), y cuando nos pidan una nota de una escala inferior, simplemente haremos una división.
    La tabla de frecuencias de la octava 10 es la siguiente:
    C  = 16744Hz
    C# = 17739Hz
    D  = 18794Hz
    D# = 19912Hz
    E  = 21096Hz
    F  = 22350Hz
    F# = 23679Hz
    G  = 25087Hz
    G# = 26579Hz
    A  = 28160Hz
    A# = 29834Hz
    B  = 31608Hz
    
    Como sistema de codificación utilizaremos cadenas de caracteres (String), porque son fáciles de manejar.
    Necesitamos definir una sintaxis para la cadena que represente la canción: [nota][sostenido][octava][-duración]...
      [nota]: es una de las letras correspondientes a cada nota: C,D,E,F,G,A,B,S. Es un valor obligatorio. S corresponde con el silencio
      [sostenido]: corresponde al símbolo #. Es un valor optativo.
      [octava]: es un valor numérico entre 1 y 10. Es un valor optativo. Si no se indica se tomará la misma octava que la nota
        anterior. Por defecto, una canción siempre comienza en la octava 4.
      [-]: es el signo que separa la nota/octava de su duración. Si no hay duración no es necesario.
      [duración]: es un valor numérico que indica la duración de la nota en milisegundos. Es un valor optativo. Si no se indica, la duración
        será la misma que la nota anterior. Por defecto, una canción comienza con una duración de 500ms.
    
    Por lo tanto para codificar que reproduzca la escala musica de la tercera octava, con una duración de un segundo por nota, tendremos:
    C3-1000DEFGHABC4
    Reproducir el Do de la octava 4, 5 y 6, con una duración de medio segundo, seguido de un silencio de medio segundo
    CSC5SC6
*/

#ifndef RoJoMelody_h
#define RoJoMelody_h

#include <Arduino.h>
#ifdef ESP32
  #include <RoJoToneESP32.h>
#endif

class RoJoMelody {
  private:
    byte pinBuzzer; //Pin donde está conectado el zumbador
    boolean looping; //Indica si la canción debe comenzar de nuevo al terminar
    //Tabla de frecuencias de la décima octava. La nota 13 es el silencio
    uint16_t freq10[13] = {16744,17739,18794,19912,21096,22350,23679,25087,26579,28160,29834,31608,0};
    uint16_t notes[255][2]; //Array que contendrá la frecuencia y duración de cada nota
    byte notesCount; //Número total de notas
    byte valueChar(char chr); //Calcula el valor numérico de un carácter
    byte isNote(char chr); //Devuelve el número de la nota que representa el carácter
    byte _currentNote; //Nota que se está reproduciendo en este momento
    uint64_t _lastTime; //Tiempo de inicio de la nota actual
    boolean _playing; //Variable que indica si se está reproduciendo una canción
  public:
    RoJoMelody(byte pinBuzzer); //Constructor
    boolean setSong(String song,boolean looping); //Memoriza una nueva canción
    void play(); //Mantiene el control de la reproducción de la canción
    void start(); //Inicia la reproducción de una canción
    void stop(); //Finaliza la reproducción de una canción
    boolean playing(); //Indica si se está reproduciendo una canción
}; //Punto y coma obligatorio para que no de error

#endif


/*
  Nombre de la librería: RoJoStepper.h
  Autor: Ramón Junquera
  Fecha: 20181018
  Descripción:
    Gestión de un motor paso a paso modelo 28BYJ-48
    Permite escoger el tipo de secuencia utilizará:
    - 0: máxima precisión (4096 pasos/vuelta)
    - 1: máximo torque (2048 pasos/vuelta)
    - 2: mínimo consumo (2048 pasos/vuelta)
    
    Librería exclusiva para placas Arduino debido a que utiliza interrupciones
    gestionadas por la librería RoJoTimer
*/

#ifndef RoJoStepper_h
#define RoJoStepper_h
#include <Arduino.h>
#include <RoJoTimer.h> //Gestión de timers Arduino
#include <RoJoDictionary.h> //Gestión de diccionarios

struct RoJoSeqType
{
  //Estructura con los tipos de secuencias de pasos
  byte stepsCount; //Número de pasos para completar un ciclo
  byte stepsStatus[8]; //Configuración de los imanes
};

struct RoJoStepperMotor
{
  //Estructura que almacena todos los detalles del estado de un motor
  int32_t currentPos; //Posición actual
  int32_t destinationPos; //Posición destino
  byte currentStep; //Paso actual
  byte seqType; //Tipo de secuencia
  bool enable; //Motor activo?
  byte pins[4]; //Pines de conexión
};

class RoJoStepper
{
  private:  //Definición de métodos/variables privadas
    static byte _timerId; //Identificador de timer
    static RoJoTimer _timer; //Objeto para gestionar el timer
    //Definición de tipos de secuencias de pasos
    static const RoJoSeqType _seqTypes[3]=
    {
      {8,{B1000,B1100,B0100,B0110,B0010,B0011,B0001,B1001}}, //MaxPrecission
      {4,{B1100,B0110,B0011,B1001,0,0,0,0}}, //MaxTorque
      {4,{B1000,B0100,B0010,B0001,0,0,0,0}}  //MinPower
    };
    static RoJoDictionary<byte,RoJoStepperMotor> _motorDicc; //Diccionario en el que se guardan los detalles de los motores
    static void _refresh(); //Función llamada de la interrupción
  public: //Definición de métodos/variables públicas
    static bool startTimer(byte timerId); //Inicia el timer indicado
    static void stopTimer(); //Detiene el timer
    static bool addMotor(byte motorId,byte pin1,byte pin2,byte pin3,byte pin4,byte sequenceType); //Añade un nuevo motor
    static bool remove(byte motorId); //Elimina un motor
    static bool enableMotor(byte motorId,bool status); //Activa/Desactiva un motor
    static bool go(byte motorId,int32_t destination); //Ir a una posición
    static bool busy(byte motorId); //Está actualmente en movimiento?
    static bool reset(byte motorId); //Resetea la posición actual y destino a 0
}; //Punto y coma obligatorio para que no de error

#endif

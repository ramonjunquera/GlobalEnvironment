/*
  Nombre de la librería: RoJoStepper.h
  Autor: Ramón Junquera
  Fecha: 20181018
  Descripción:
    Gestión de un motor paso a paso modelo 28BYJ-48
    Permite escoger el tipo de secuencia utilizará:
    - 0: máxima precisión (4096 pasos/vuelta)
    - 1: máximo torque (2048 pasos/vuelta)
    - 2: mínimo consumo (2048 pasos/vuelta)
    
    Librería exclusiva para placas Arduino debido a que utiliza interrupciones
    gestionadas por la librería RoJoTimer
*/

#include <Arduino.h>
#include "RoJoStepper.h"

//Definición de variables estáticas de clase para que se reserve memoria para ellas
static byte RoJoStepper::_timerId; //Identificador de timer
static RoJoTimer RoJoStepper::_timer; //Timer utilizado
static const RoJoSeqType RoJoStepper::_seqTypes[3]; //Definición de tipos de secuencias de pasos
static RoJoDictionary<byte,RoJoStepperMotor> RoJoStepper::_motorDicc; //Diccionario de motores

static bool RoJoStepper::startTimer(byte timerId)
{
  //Fija el timer a utilizar y lo pone en marcha
  //Devuelve true si lo consigue

  //Nota:
  //Las interrupciones sirven para todos los motores que definamos
  //Cada vez que se produzca una se intentará avanzar un paso más en cada motor.
  //Los motores tienen una limitación de tiempo definida por su inercia.
  //Además la limitación también está influida por el tipo de secuencia.
  //Una secuencia de 8 pasos por vuelta se puede aplicar más rápido que una de 4.
  //Concretamente la secuencia de 8 vuelta se aplica sin errores con un 
  //periodo de 1300 microsegundos (como la primera).
  //En cambio una de 8 pasos necesita 2049 microsegundos.
  //Como sólo utilizaremos una interrupción debemos tomar la mayor para guardar
  //compatibilidad con todas.
  //Además la aumentaremos un poco para asegurarnos que aunque el motor
  //sea ligeramente distinto, también funcione.
  //Lo dejaremos en un periodo de 2060 microsegundos.
  //Esto significa que si la primera secuencia necesita 4096 pasos para dar una
  //vuelta completa y da un paso cada 2060 microsegundos, girará a una velocidad
  //de 4096*2060=8437760 microsegundos/vuelta ~ 8.4 segundos/vuelta
  //Si utilizamos secuencias de 4 pasos, tardaremos la mitad ~4.2 segundos/vuelta

  //Si no podemos aplicar la configuración al timer...terminamos con error
  if(!_timer.set(timerId,RoJoStepper::_refresh,2060)) return false;
  //Activamos el timer
  _timer.start();
  //Todo Ok
  return true;
}

static void RoJoStepper::stopTimer()
{
  //Detiene el timer actual

  _timer.stop();
}

static bool RoJoStepper::addMotor(byte motorId,byte pin1,byte pin2,byte pin3,byte pin4,byte sequenceType)
{
  //Añade un nuevo motor
  //  motorId: identificador único del motor definido por el usuario
  //  pinX: pines de conexión
  //  sequenceType: tipo de secuencia de pasos
  //    0 - Máxima precisión
  //    1 - Máximo torque
  //    2 - Mínimo consumo
  //Devuelve true si se ha podido aplicar la configuración

  //Si el tipo de secuencia está fuera de rango...terminamos con error
  if(sequenceType>2) return false;
  //Creamos una nueva estructura para el motor a añadir
  RoJoStepperMotor *pMotor=new RoJoStepperMotor;
  //Guardamos los detalles del motor en ella
  pMotor->seqType=sequenceType;
  pMotor->pins[0]=pin1;
  pMotor->pins[1]=pin2;
  pMotor->pins[2]=pin3;
  pMotor->pins[3]=pin4;
  //El resto de valores se quedan por defecto
  pMotor->currentPos=0;
  pMotor->destinationPos=0;
  pMotor->currentStep=0;
  pMotor->enable=false;
  //Configuramos los pines del motor como salidas
  for(byte p=0;p<4;p++) pinMode(pMotor->pins[p],OUTPUT);
  //Guardamos el motor en el diccionario de motores
  _motorDicc.add(motorId,pMotor);
  //Todo correcto
  return true;
}

static bool RoJoStepper::remove(byte motorId)
{
  //Elimina un motor del diccionario
  //Devuelve true si lo consigue
  
  return _motorDicc.remove(motorId);
}

static bool RoJoStepper::enableMotor(byte motorId,bool status)
{
  //Activa/Desactiva un motor
  //Devuelve true si se ha conseguido

  //Definimos la variable donde recuperaremos los datos del motor procesado
  RoJoStepperMotor *pMotor;
  //Recuperamos estado del motor. Si no lo ha conseguido (porque no existe)...indicamos que no se ha podido
  if(!_motorDicc.value(motorId,&pMotor)) return false;
  //Hemos conseeguido recuperar los datos del motor indicado
  //Guardamos valor del nuevo estado
  pMotor->enable=status;
  //Todo ok
  return true;
}

static bool RoJoStepper::go(byte motorId,int32_t destination)
{
  //Fija posición destino para un motor
  //Devuelve true si lo consigue

  //Definimos la variable donde recuperaremos los datos del motor procesado
  RoJoStepperMotor *pMotor;
  //Recuperamos estado del motor. Si no lo ha conseguido (porque no existe)...indicamos que no se ha podido
  if(!_motorDicc.value(motorId,&pMotor)) return false;
  //Hemos conseeguido recuperar los datos del motor indicado
  //Guardamos valor de posición destino
  pMotor->destinationPos=destination;
  //Todo ok
  return true;
}

static bool RoJoStepper::busy(byte motorId)
{
  //El motor indicado está en movimiento?

  //Definimos la variable donde recuperaremos los datos del motor procesado
  RoJoStepperMotor *pMotor;
  //Recuperamos estado del motor. Si se ha conseguido (porque existe)...
  if(_motorDicc.value(motorId,&pMotor))
  {
    //Si está activado...
    if(pMotor->enable)
    {
      //Si no coinciden las posiciones actuales y de destino...es que está en marcha
      if(pMotor->currentPos != pMotor->destinationPos) return true;
    }
  }
  //Por alguna razón no está en movimiento
  return false;
}

static bool RoJoStepper::reset(byte motorId)
{
  //Resetea la posición actual y destino a 0
  //Devuelve true si lo consigue

  //Definimos la variable donde recuperaremos los datos del motor procesado
  RoJoStepperMotor *pMotor;
  //Recuperamos estado del motor. Si no lo ha conseguido (porque no existe)...indicamos que no se ha podido
  if(!_motorDicc.value(motorId,&pMotor)) return false;
  //Hemos conseeguido recuperar los datos del motor indicado
  //Asignamos valor cero tanto a posición actual como destino
  pMotor->destinationPos=pMotor->currentPos=0;
  //Todo ok
  return true;
}

static void RoJoStepper::_refresh()
{
  //Función llamada por la interrupción
  //Se gestionan todos los motores del diccionario

  //Definimos las variables donde recuperaremos los datos del motor procesado
  byte motorId;
  RoJoStepperMotor *pMotor;
  
  //Recorremos todos los motores del diccionario
  for(byte m=0;m<_motorDicc.count();m++)
  {
    //Obtenemos los datos del motor procesado
    _motorDicc.index(m,&motorId,&pMotor);
    //Si el motor está activo...
    if(pMotor->enable)
    {
      //Si la posición actual es distinta a la posición de destino...
      if(pMotor->currentPos != pMotor->destinationPos)
      {
        //Tenemos que dar el siguiente paso
        //Calculamos si el paso a dar será positivo o negativo, en función de la 
        //posición actual y la de destino
        int32_t delta=(pMotor->currentPos < pMotor->destinationPos)?1:-1;
        //Incrementamos el paso actual en delta y lo mantenemos entre los límites de la secuencia
        pMotor->currentStep+=delta;
        pMotor->currentStep%=_seqTypes[pMotor->seqType].stepsCount;
        //Incrementamos la posición actual en delta
        pMotor->currentPos+=delta;
        //Debemos aplicar el estado correspondiente al paso actual a los pines de salida
        //Recorremos los 4 pines...y aplicamos el estado que le corresponde para el paso actual
        for(byte p=0;p<4;p++) digitalWrite(pMotor->pins[p],_seqTypes[pMotor->seqType].stepsStatus[pMotor->currentStep] & (1<<p));
      }
    }
  }
}


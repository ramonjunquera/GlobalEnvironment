/*
  Nombre de la librería: RoJoTimer1.h
  Versión: 20170921
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino para la gestión del timer 1
*/

//Comprobamos que la placa es compatible
#if !defined(ARDUINO_ARCH_AVR)
  #error Library RoJoTimer1 is only compatible with Arduino family devices
#endif  

#ifndef RoJoTimer1_h
#define RoJoTimer1_h

#include <Arduino.h>
#include <avr/io.h> 
#include <avr/interrupt.h>

class RoJoTimer1
{
  private:  //Definición de métodos/variables privadas
    void (*_f)(); //Función de llamada cuando se produzca la interrupción
    uint32_t _period; //Periodo en microsegundos
    const uint32_t _clockFreq=16; //Frecuencia del reloj en MHz
    const uint32_t _maxCTC=65535; //Máximo valor del contador del timer
    #define _prescalersTimer1 5 //Número de prescalers del timer 1
    const uint32_t _prescalers[_prescalersTimer1]={1,8,64,256,1024}; //Valores de los prescalers
    uint32_t _myCTC; //CTC propio de la clase
    uint32_t _myCTCcounter; //Contador actual de nuestro CTC
  public: //Definición de métodos/variables públicas
    void _run(); //Función llamada en cada interrupción
    void begin(void (*f)(),uint32_t period); //Inicialización de timer. Parámetros: función de llamada, periodo en microsegundos
    void end(); //Deshabilita la interrupción
}; //Punto y coma obligatorio para que no de error

//En el .cpp se ha definido timer1 como variable global, que también queremos utilizar aquí
//Por eso la referenciamos con extern
extern RoJoTimer1 timer1;

#endif

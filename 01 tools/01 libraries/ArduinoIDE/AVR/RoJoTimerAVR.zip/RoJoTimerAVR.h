/*
  Nombre de la librería: RoJoTimerAVR.h
  Versión: 20181022
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino para la gestión de timers
*/

//Comprobamos que la placa es compatible
#if !defined(ARDUINO_ARCH_AVR)
  #error Library RoJoTimerAVR is only compatible with Arduino family devices
#endif  

#ifndef RoJoTimerAVR_h
#define RoJoTimerAVR_h

#include <Arduino.h>
#include <avr/io.h> 
#include <avr/interrupt.h>

class RoJoTimerAVR
{
  private:  //Definición de métodos/variables privadas
    byte _timerId; //Identificador del timer
    uint32_t _period; //Periodo en microsegundos
    const uint32_t _prescalers[2][7]={{1024,256,64,8,1,0,0},{1024,256,128,64,32,8,1}}; //Series de valores de los prescalers
    const byte _prescalersCount[2]={5,7}; //Número de prescalers de cada serie
    const byte _prescalersSerieTimer[5]={0,1,0,0,0}; //Serie de prescalers a utilizar por cada timer
    const uint32_t _maxCTC[2]={65535,255}; //Máximo valor del contador del timer para una serie de prescalers
    #ifdef ARDUINO_AVR_MEGA2560 //Si es una Mega...
      const byte maxTimerId=5; //...el máximo de interrupciones es 5
    #else //Si es cualquier otra (UNO o Nano)...
      const byte maxTimerId=2; //...sólo tienen 2 interrupciones
    #endif 
  public: //Definición de métodos/variables públicas
    bool set(byte timerId,void (*f)(),uint32_t period); //Inicialización de timer. Parámetros: función de llamada, periodo en microsegundos
    void start(); //Inicia las interrupciones
    void stop(); //Detiene las interrupciones
}; //Punto y coma obligatorio para que no de error

#endif

/*
  Nombre de la librería: RoJoTimerAVR.h
  Versión: 20181022
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino para la gestión de timers.
    Está probada con las siguienes placas: UNO, Nano y Mega.
    Facilita la gestión de timers (interrupciones por software).
    Las placas UNO y Nano tienen dos interrupciones de software: la 1 y la 2.
    Arduino Mega tiene las misma y 3 más, numeradas del 1 al 5.
    Se pueden crean varios objetos RoJoTimer, siempre que a cada uno de ellos se le asigne
    un timer distinto.
    La clase sólo tiene 3 métodos:
      bool set(byte timerId,void (*f)(),uint32_t period);
      void start();
      void stop();
    El método set permite configurar el timer con los siguientes parámetros:
      timerId: un número entre 1 y 5 para Mega y 1 y 2 para UNO/Nano
      f(): función a la que se debe llamar el timer cuando salte (no puede tener parámetros nbi devolver valores)
      period: periodo en microsegundos
    El método devuelve true cuando ha se considera que la configuración es correcta.
    Si la configuración es correcta, detiene cualquier timer que se encuentre en el indicado.
    Los métodos de start y stop sirven para arrancar o detener el timer.

    Los timers 1, 3, 4 y 5 son iguales. Con la misma resolución y prescalers. El 2 es distinto
    porque tiene una resolución mayor. Pero la clase permite gestionarlos por igual.
    
    La librería se encarga de seleccionar el prescaler más adecuado para el periodo requerido.
    Si el periodo es mayor que el ofrecido por el mayor prescaler sin CTC, se utiliza un CTC
    adicional que permite extenderlo de manera transparente al usuario.

    Nota:
    Cuando los periodos solicitados exceden el máximo que pude ofrecer el timer por hardware, comienzan a perder
    exactitud.
    Por ejemplo, si fijamos un periodo de 1 segundo (1000000 microsegundos), los timers 1,3,4 y 5 son capaces de 
    abordarlo por hardware y su exactitud es bastante buena. En cambio el 2, al tener más resolución, no puede y
    debe utilizar un CTC (contador) por software. Por eso se contabiliza un poco más de un segundo (aproximadamente 
    1.015 segundos).
*/

#include <Arduino.h>
//Como trabajaremos directamente con los registros del procesador, incluiremos las librerías de gestión del fabricante
//del procesador. No hacemos referencia a librerías de Arduino.
#include <avr/io.h> 
#include <avr/interrupt.h>
#include "RoJoTimerAVR.h"

void (*_f[5])(); //Array de funciones de llamada para timers
uint32_t _myCTCcounter[5]; //Contador actual de nuestro CTC
uint32_t _myCTC[5]; //CTC propio de la clase

bool RoJoTimerAVR::set(byte timerId,void (*f)(),uint32_t period)
{
  //Inicialización de timer. Parámetros: identificador del timer, función de llamada,
  //periodo en microsegundos.
  //La función a la que se llamará cuando salte la interrupción no debe tener 
  //parámetros y no puede devolver nada

  //Si el identificador de timer es inválido..devolvemos error
  if(timerId>maxTimerId || timerId<1) return false;
  //Guardamos los parámetros en las variable privadas
  //Guardamos el identificador del timer en la variable privada
  _timerId=timerId;
  //Detenemos cualquier timer con el mismo identificador
  stop();
  //Anotamos el periodo en la variable interna
  _period=period;
  //Anotamos la función de llamada en el array de funciones
  _f[timerId-1]=f;
  //Todo correcto
  return true;
}

void RoJoTimerAVR::start()
{
  //Inicia las interrupciones

  uint32_t prescalerPeriod; //Periodo del prescaler sin CTC
  const uint32_t _clockFreq=16; //Frecuencia del reloj en MHz
  byte prescalerIndex=0xFF; //Índice del prescaler seleccionado. Inicialmente ninguno.
  uint32_t CTC; //CTC seleccionado
  uint32_t myCTC=1; //CTC propio seleccionado. Inicialmente cada interrupción
  byte prescalerSerie=_prescalersSerieTimer[_timerId-1]; //Serie del prescaler
  

  //Recorremos los prescalers
  for(byte p=0;p<_prescalersCount[prescalerSerie];p++)
  {
    //Calculamos el periodo del prescaler sin CTC
    prescalerPeriod=(_prescalers[prescalerSerie][p]*_maxCTC[prescalerSerie])/_clockFreq;
    //Si el prescaler no acepta un periodo tan grande...no buscamos más
    if(prescalerPeriod<_period) break;
    //Con este prescaler podemos obtener el periodo buscado...anotamos que es un prescaler válido
    else prescalerIndex=p;
  }
  //Hemos terminado de comprobar si nos sirve algún prescaler para obtener el periodo indicado

  //Si vale alguno...
  if(prescalerIndex<0xFF)
  {
    //No utilizaremos CTC propio. Con el CTC adecuado podemos obtener el periodo indicado
    //Calculamos el valor de CTC con la siguiente fórmula:
    //CTC = (tiempo deseado / resolución timer) -1 = (tiempo deseado * frecuencia / prescaler) -1
    CTC=((_period*_clockFreq)/_prescalers[prescalerSerie][prescalerIndex])-1;
  }
  else //Ningún presacaler nos sirve. Son todos demasiado pequeños
  {
    //Tomaremos el prescaler más grande como válido
    prescalerIndex=0;
    //Debemos calcular con qué combinación de CTC y myCTC obtenemos el periodo indicado
    //Hasta ahora conocemos el periodo deseado y el periodo del mayor prescaler sin CTC
    //Y que el periodo seleccionado excede al del prescaler
    //Calculamos cuántas veces entra el periodo del prescaler en el que nos interesa
    //Siempre le sumamos uno por si tiene resto
    myCTC=_period/prescalerPeriod+1;
    //Ya tenemos el CTC propio
    //Calcularemos el CTC del prescaler suponiendo que buscamos un como periodo el periodo indicado entre
    //el valor de nuestro CTC. La fórmula es la misma:
    //  CTC = (tiempo deseado / resolución timer) -1 = (tiempo deseado * frecuencia / prescaler) -1
    CTC=(((_period/myCTC)*_clockFreq)/_prescalers[prescalerSerie][prescalerIndex])-1;
  }
  //Ya tenemos todos los valores que necesitamos para configurar el timer

  //Deshabilitamos las interrupciones globales
  cli();
  //Dependiendo del identificador de timer
  switch(_timerId)
  {
    case 1: //Timer 1
      //Fijamos el registro TCCR1A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR1A=0;
      //Activamos el prescaler seleccionado que corresponde con _prescalersCount[prescalerSerie]-prescalerIndex
      //Además activamos el bit 4 (0x1000) para indicar que usaremos CTC
      TCCR1B=_prescalersCount[prescalerSerie]-prescalerIndex+8;
      //En el registro TIMSK1 activamos el segundo bit (OCIE1A) para que salte la interrupción al llegar al CTC
      //definido en el registro OCR1A
      TIMSK1=0b10;
      //Definimos el valor del CTC para el timer 1
      OCR1A=CTC;
      break;
    case 2: //Timer 2
      //Fijamos el registro TCCR2A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR2A=0;
      //Activamos el prescaler seleccionado que corresponde con _prescalersCount[prescalerSerie]-prescalerIndex
      //Además activamos el bit 4 (0x1000) para indicar que usaremos CTC
      TCCR2B=_prescalersCount[prescalerSerie]-prescalerIndex+8;
      //En el registro TIMSK2 activamos el segundo bit (OCIE2A) para que salte la interrupción al llegar al CTC
      //definido en el registro OCR2A
      TIMSK2=0b10;
      //Definimos el valor del CTC para el timer
      OCR2A=CTC;
      break;
#ifdef ARDUINO_AVR_MEGA2560 //Si es una Mega...
    case 3: //Timer 3
      //Fijamos el registro TCCR3A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR3A=0;
      //Activamos el prescaler seleccionado que corresponde con _prescalersCount[prescalerSerie]-prescalerIndex
      //Además activamos el bit 4 (0x1000) para indicar que usaremos CTC
      TCCR3B=_prescalersCount[prescalerSerie]-prescalerIndex+8;
      //En el registro TIMSK3 activamos el segundo bit (OCIE3A) para que salte la interrupción al llegar al CTC
      //definido en el registro OCR3A
      TIMSK3=0b10;
      //Definimos el valor del CTC para el timer
      OCR3A=CTC;
      break;
    case 4: //Timer 4
      //Fijamos el registro TCCR4A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR4A=0;
      //Activamos el prescaler seleccionado que corresponde con _prescalersCount[prescalerSerie]-prescalerIndex
      //Además activamos el bit 4 (0x1000) para indicar que usaremos CTC
      TCCR4B=_prescalersCount[prescalerSerie]-prescalerIndex+8;
      //En el registro TIMSK4 activamos el segundo bit (OCIE4A) para que salte la interrupción al llegar al CTC
      //definido en el registro OCR4A
      TIMSK4=0b10;
      //Definimos el valor del CTC para el timer
      OCR4A=CTC;
      break;
    case 5: //Timer 5
      //Fijamos el registro TCCR5A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR5A=0;
      //Activamos el prescaler seleccionado que corresponde con _prescalersCount[prescalerSerie]-prescalerIndex
      //Además activamos el bit 4 (0x1000) para indicar que usaremos CTC
      TCCR5B=_prescalersCount[prescalerSerie]-prescalerIndex+8;
      //En el registro TIMSK5 activamos el segundo bit (OCIE5A) para que salte la interrupción al llegar al CTC
      //definido en el registro OCR5A
      TIMSK5=0b10;
      //Definimos el valor del CTC para el timer
      OCR5A=CTC;
      break;
#endif //Si en una Mega      
  }
  //Reseteamos el contador actual de nuestro CTC
  _myCTCcounter[_timerId-1]=0;
  //Asignamos el valor a nuestro CTC
  _myCTC[_timerId-1]=myCTC;
  //Volvemos a activar las interrupciones
  sei();
}

void RoJoTimerAVR::stop()
{
  //Detiene las interrupciones

  //Deshabilitamos las interrupciones globales
  cli();
  switch(_timerId)
  {
    case 1: //Timer 1
      //Fijamos el registro TCCR1A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR1A=0;
      //Desactivamos cualquier prescaler
      TCCR1B=0;
      //Desactivamos cualquier salto por interrupción
      TIMSK1=0b10;
      break;
    case 2: //Timer 2
      //Fijamos el registro TCCR2A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR2A=0;
      //Desactivamos cualquier prescaler
      TCCR2B=0;
      //Desactivamos cualquier salto por interrupción
      TIMSK2=0b10;
      break;
#ifdef ARDUINO_AVR_MEGA2560 //Si es una Mega...
    case 3: //Timer 3
      //Fijamos el registro TCCR3A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR3A=0;
      //Desactivamos cualquier prescaler
      TCCR3B=0;
      //Desactivamos cualquier salto por interrupción
      TIMSK3=0b10;
      break;
    case 4: //Timer 4
      //Fijamos el registro TCCR4A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR4A=0;
      //Desactivamos cualquier prescaler
      TCCR4B=0;
      //Desactivamos cualquier salto por interrupción
      TIMSK4=0b10;
      break;
    case 5: //Timer 5
      //Fijamos el registro TCCR5A a 0 para que se mantengan los valores por defecto de la forma de onda
      TCCR5A=0;
      //Desactivamos cualquier prescaler
      TCCR5B=0;
      //Desactivamos cualquier salto por interrupción
      TIMSK5=0b10;
      break;
#endif //Si en una Mega
  }
  //Volvemos a activar las interrupciones
  sei();
}

//Definición de funciones de interrupción por defecto

ISR(TIMER1_COMPA_vect)
{
  //Función a la que se llama cuando se produce una interrupción del timer 1
  //Con el parámetro TIMER1_COMPA_vect indicamos que se llama cuando se alcanza el CTC definido del timer 1

  //Timer 1
  const byte timerId=0;
  //Aumentamos el contador de nuestro CTC. Si ya debemos ejecutar la función...
  if(++_myCTCcounter[timerId]>=_myCTC[timerId])
  {
    _myCTCcounter[timerId]=0; //Reseteamos el contador
    _f[timerId](); //Llamamos a la función indicada
  }
}

ISR(TIMER2_COMPA_vect)
{
  //Función a la que se llama cuando se produce una interrupción del timer 2
  //Con el parámetro TIMER2_COMPA_vect indicamos que se llama cuando se alcanza el CTC definido del timer 2

  //Timer 2
  const byte timerId=1;
  //Aumentamos el contador de nuestro CTC. Si ya debemos ejecutar la función...
  if(++_myCTCcounter[timerId]>=_myCTC[timerId])
  {
    _myCTCcounter[timerId]=0; //Reseteamos el contador
    _f[timerId](); //Llamamos a la función indicada
  }
}

#ifdef ARDUINO_AVR_MEGA2560 //Si es una Mega...

ISR(TIMER3_COMPA_vect)
{
  //Función a la que se llama cuando se produce una interrupción del timer 3
  //Con el parámetro TIMER3_COMPA_vect indicamos que se llama cuando se alcanza el CTC definido del timer 3

  //Timer 3
  const byte timerId=2;
  //Aumentamos el contador de nuestro CTC. Si ya debemos ejecutar la función...
  if(++_myCTCcounter[timerId]>=_myCTC[timerId])
  {
    _myCTCcounter[timerId]=0; //Reseteamos el contador
    _f[timerId](); //Llamamos a la función indicada
  }
}

ISR(TIMER4_COMPA_vect)
{
  //Función a la que se llama cuando se produce una interrupción del timer 4
  //Con el parámetro TIMER4_COMPA_vect indicamos que se llama cuando se alcanza el CTC definido del timer 4

  //Timer 4
  const byte timerId=3;
  //Aumentamos el contador de nuestro CTC. Si ya debemos ejecutar la función...
  if(++_myCTCcounter[timerId]>=_myCTC[timerId])
  {
    _myCTCcounter[timerId]=0; //Reseteamos el contador
    _f[timerId](); //Llamamos a la función indicada
  }
}

ISR(TIMER5_COMPA_vect)
{
  //Función a la que se llama cuando se produce una interrupción del timer 5
  //Con el parámetro TIMER5_COMPA_vect indicamos que se llama cuando se alcanza el CTC definido del timer 5

  //Timer 5
  const byte timerId=4;
  //Aumentamos el contador de nuestro CTC. Si ya debemos ejecutar la función...
  if(++_myCTCcounter[timerId]>=_myCTC[timerId])
  {
    _myCTCcounter[timerId]=0; //Reseteamos el contador
    _f[timerId](); //Llamamos a la función indicada
  }
}

#endif //Si en una Mega

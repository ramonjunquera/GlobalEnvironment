/*
  Nombre de la librería: RoJoTimer3.h
  Versión: 20180621
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino para la gestión del timer 3
*/

//Comprobamos que la placa es compatible
#if !defined(ARDUINO_AVR_MEGA2560)
  #error Library RoJoTimer3 is only compatible with Arduino Mega
#endif  

#ifndef RoJoTimer3_h
#define RoJoTimer3_h

#include <Arduino.h>
#include <avr/io.h> 
#include <avr/interrupt.h>

class RoJoTimer3
{
  private:  //Definición de métodos/variables privadas
    void (*_f)(); //Función de llamada cuando se produzca la interrupción
    uint32_t _period; //Periodo en microsegundos
    const uint32_t _clockFreq=16; //Frecuencia del reloj en MHz
    const uint32_t _maxCTC=65535; //Máximo valor del contador del timer
    #define _prescalersTimer3 5 //Número de prescalers
    const uint32_t _prescalers[_prescalersTimer3]={1,8,64,256,1024}; //Valores de los prescalers
    uint32_t _myCTC; //CTC propio de la clase
    uint32_t _myCTCcounter; //Contador actual de nuestro CTC
  public: //Definición de métodos/variables públicas
    void _run(); //Función llamada en cada interrupción
    void begin(void (*f)(),uint32_t period); //Inicialización de timer. Parámetros: función de llamada, periodo en microsegundos
    void end(); //Deshabilita la interrupción
}; //Punto y coma obligatorio para que no de error

//En el .cpp se ha definido timer1 como variable global, que también queremos utilizar aquí
//Por eso la referenciamos con extern
extern RoJoTimer3 timer3;

#endif

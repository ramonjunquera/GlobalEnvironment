/*
  Nombre de la librería: RoJoTimer2.h
  Versión: 20180621
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino para la gestión del timer 2

    Sólo con incluir la librería se crea el objeto timer2, que tiene dos métodos públicos:
    - void begin(void (*f)(),uint32_t period)
    - void end()
    El método begin inicializa el timer para que se llame a la función del primer parámetro
    cada cierto tiempo definido en el segundo parámetro.
    La función no puede devolver nada ni tener parámetros.
    El tiempo del periodo se mide en microsegundos.

    El método end deshabilita la interrupción.

    La librería se encarga de seleccionar el prescaler más adecuado para el periodo requerido.
    Aunque el periodo del máximo prescaler sin CTC es de 4.2s, incluye su propio CTC para que
    se acepte cualquier valor de periodo. Máximo 2^32-1=4294967295 microsegundos = 4294967 ms =
    ~ 4295 s ~ 72 minutos.

    Se puede llamar repetidas veces al método begin sin llamar a end. Esto hará que se
    inicialice el timer con la nueva configuración.

    Existe un método público llamado _run, que es utilizado internamente debido a que la función
    de interrupción está predefinida.    
*/

#include <Arduino.h>
//Como trabajaremos directamente con los registros del procesador, incluiremos las librerías de gestión del fabricante
//del procesador. No hacemos referencia a librerías de Arduino.
#include <avr/io.h> 
#include <avr/interrupt.h>
#include "RoJoTimer2.h"

void RoJoTimer2::_run()
{
  //Método llamado cuando salta una interrupción

  //Aumentamos el contador de nuestro CTC. Si ya debemos ejecutar la función...
  if(++_myCTCcounter>=_myCTC)
  {
    _myCTCcounter=0; //Reseteamos el contador
    _f(); //Llamamos a la función indicada
  }
}

void RoJoTimer2::begin(void (*f)(),uint32_t period)
{
  //Inicialización de timer. Parámetros: función de llamada, periodo en microsegundos
  //La función a la que se llamará cuando salte la interrupción no debe tener 
  //parámetros y no puede devolver nada

  byte prescalerIndex=0xFF; //Índice del prescaler seleccionado. Inicialmente ninguno.
  uint32_t CTC; //CTC seleccionado
  uint32_t myCTC=1; //CTC propio seleccionado. Inicialmente cada interrupción
  uint32_t prescalerPeriod; //Periodo del prescaler sin CTC

  //Guardamos los parámetros en las variable privadas
  _f=f;
  _period=period;

  //Recorremos los prescalers en orden inverso
  for(int8_t p=_prescalersTimer2-1;p>=0;p--)
  {
    //Calculamos el periodo del prescaler sin CTC
    prescalerPeriod=(_prescalers[p]*_maxCTC)/_clockFreq;
    //Si el prescaler no acepta un periodo tan grande...no buscamos más
    if(prescalerPeriod<_period) break;
    //Con este prescaler podemos obtener el periodo buscado...anotamos que es un prescaler válido
    else prescalerIndex=p;
  }
  //Hemos terminado de comprobar si nos sirve algún prescaler para obtener el periodo indicado

  //Si vale alguno...
  if(prescalerIndex<0xFF)
  {
    //No utilizaremos CTC propio. Con el CTC adecuado podemos obtener el periodo indicado
    //Calculamos el valor de CTC con la siguiente fórmula:
    //CTC = (tiempo deseado / resolución timer) -1 = (tiempo deseado * frecuencia / prescaler) -1
    CTC=((_period*_clockFreq)/_prescalers[prescalerIndex])-1;
  }
  else //Ningún presacaler nos sirve. Son todos demasiado pequeños
  {
    //Tomaremos el prescaler más grande como válido
    prescalerIndex=_prescalersTimer2-1;
    //Debemos calcular con qué combinación de CTC y myCTC obtenemos el periodo indicado
    //Hasta ahora conocemos el periodo deseado y el periodo del mayor prescaler sin CTC
    //Y que el periodo seleccionado excede al del prescaler
    //Calculamos cuántas veces entra el periodo del prescaler en el que nos interesa
    //Siempre le sumamos uno por si tiene resto
    myCTC=_period/prescalerPeriod+1;
    //Ya tenemos el CTC propio
    //Calcularemos el CTC del prescaler suponiendo que buscamos un como periodo el periodo indicado entre
    //el valor de nuestro CTC. La fórmula es la misma
    //CTC = (tiempo deseado / resolución timer) -1 = (tiempo deseado * frecuencia / prescaler) -1
    CTC=(((_period/myCTC)*_clockFreq)/_prescalers[prescalerIndex])-1;
  }
  //Ya tenemos todos los valores que necesitamos para configurar el timer

  //Deshabilitamos las interrupciones globales
  cli();
  //Fijamos el registro TCCR2A a 0 para que se mantengan los valores por defecto de la forma de onda
  TCCR2A=0;
  //Activamos el prescaler seleccionado que corresponde con prescalerIndex+1
  //Además activamos el bit 4 (0x1000) para indicar que usaremos CTC
  TCCR2B=prescalerIndex+9;
  //En el registro TIMSK2 activamos el segundo bit (OCIE2A) para que salte la interrupción al llegar al CTC
  //definido en el registro OCR2A
  TIMSK2=0b10;
  //Definimos el valor del CTC para el timer
  OCR2A=CTC;
  //Reseteamos el contador actual de nuestro CTC
  _myCTCcounter=0;
  //Asignamos el valor a nuestro CTC
  _myCTC=myCTC;
  //Volvemos a activar las interrupciones
  sei();
}

void RoJoTimer2::end()
{
  //Deshabilita la interrupción

  //Deshabilitamos las interrupciones globales
  cli();
  //Fijamos el registro TCCR2A a 0 para que se mantengan los valores por defecto de la forma de onda
  TCCR2A=0;
  //Desactivamos cualquier prescaler
  TCCR2B=0;
  //Desactivamos cualquier salto por interrupción
  TIMSK2=0b10;
  //Volvemos a activar las interrupciones
  sei();
}

//Aquí finaliza la definición de métodos de la clase
//Pero incluimos en el mismo archivo código que nos ayuda con la gestión

//Definimos timerClass como variable global de la clase
RoJoTimer2 timer2;

ISR(TIMER2_COMPA_vect)
{
  //Función a la que se llama cuando se produce una interrupción
  //Con el parámetro TIMER2_COMPA_vect indicamos que se llama cuando se alcanza el CTC definido del timer 2

  //Llamamos al método de la clase
  timer2._run();
}



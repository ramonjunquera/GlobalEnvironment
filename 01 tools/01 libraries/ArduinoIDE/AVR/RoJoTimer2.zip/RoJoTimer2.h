/*
  Nombre de la librería: RoJoTimer2.h
  Versión: 20170921
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas Arduino para la gestión del timer 2
*/

//Comprobamos que la placa es compatible
#if !defined(ARDUINO_ARCH_AVR)
  #error Library RoJoTimer2 is only compatible with Arduino family devices
#endif  

#ifndef RoJoTimer2_h
#define RoJoTimer2_h

#include <Arduino.h>
#include <avr/io.h> 
#include <avr/interrupt.h>

class RoJoTimer2
{
  private:  //Definición de métodos/variables privadas
    void (*_f)(); //Función de llamada cuando se produzca la interrupción
    uint32_t _period; //Periodo en microsegundos
    const uint32_t _clockFreq=16; //Frecuencia del reloj en MHz
    const uint32_t _maxCTC=255; //Máximo valor del contador del timer
    #define _prescalersTimer2 7 //Número de prescalers del timer 2
    const uint32_t _prescalers[_prescalersTimer2]={1,8,32,64,128,256,1024}; //Valores de los prescalers
    uint32_t _myCTC; //CTC propio de la clase
    uint32_t _myCTCcounter; //Contador actual de nuestro CTC
  public: //Definición de métodos/variables públicas
    void _run(); //Función llamada en cada interrupción
    void begin(void (*f)(),uint32_t period); //Inicialización de timer. Parámetros: función de llamada, periodo en microsegundos
    void end(); //Deshabilita la interrupción
}; //Punto y coma obligatorio para que no de error

//En el .cpp se ha definido timer1 como variable global, que también queremos utilizar aquí
//Por eso la referenciamos con extern
extern RoJoTimer2 timer2;

#endif

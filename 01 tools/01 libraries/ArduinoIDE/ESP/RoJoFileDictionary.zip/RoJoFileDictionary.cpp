/*
  Nombre de la librería: RoJoFileDictionary.h
  Versión: 20180314
  Autor: Ramón Junquera
  Descripción:
    Simulación de clase diccionario basado en archivo de SPIFFS.
    Guarda pares de valores (registros) en un archivo de texto.
    Un registro consta de clave (key) y valor asociado (value).
    Las claves son únicas.
    Cada registro se almacena en una línea.
    La clave se separa de su valor por el carácter ;
*/


#ifndef RoJoFileDictionary_cpp
#define RoJoFileDictionary_cpp

#include <Arduino.h>
#ifdef ESP32 //Si es un ESP32...
  #include <SPIFFS.h> 
#else //Si cualquier otra cosa (ESP8266 o RPi)...
  #include <FS.h>
#endif
#include "RoJoFileDictionary.h"


void RoJoFileDictionary::begin(String fileName)
{
  //Inicialización

  //Inicializamos el acceso a archivos
  SPIFFS.begin();
  //Anotamos el nombre del archivo que guarda el diccionario
  _fileName=fileName;

  //Nos aseguramos que el archivo existe y anotamos el número de registros actuales
  //Abrimos el archivo de diccionaro como sólo lectura
  File f=SPIFFS.open(_fileName,"r");
  //Si no se pudo abrir (porque no existe)...
  if(!f)
  {
    //..se crea
    f=SPIFFS.open(_fileName,"w");
    //Se cierra
    f.close();
    //Hemos terminado
    //Quedará anotado que no tenemos registros (valor de inicialización)
    return;
  }
  //Tenemos el archivo abierto

  //Mientras el archivo tenga algo que leer...
  while(f.available())
  {
    //Leemos la línea completa y no la guardamos
    f.readStringUntil('\n');
    //Aumentamos el contador de registros
    _count++;
  }
  //Cerramos el archivo
  f.close();
}

uint16_t RoJoFileDictionary::count()
{
  //Devuelve el número de items en el diccionario
  return _count;
}

bool RoJoFileDictionary::containsKey(String key)
{
  //Indica si existe la clave indicada

  //Abrimos el archivo como sólo lectura
  File f=SPIFFS.open(_fileName,"r");
  //Mientras el archivo tenga algo que leer...
  while(f.available())
  {
    //...leemos la clave
    String keyRead=f.readStringUntil(';');
    //Si la clave coincide con la que buscamos...
    if(keyRead==key)
    {
      //...cerramos el archivo
      f.close();
      //Indicamos que la clave existe
      return true;
    }
    //Leemos el resto de línea
    keyRead=f.readStringUntil('\n');
  }
  //Hemos terminado de leer el archivo. Lo cerramos
  f.close();
  //No hemos encontrado la clave buscada
  return false;
}

bool RoJoFileDictionary::remove(String key)
{
  //Elimina una clave
  //Devuelve true si la clave existía

  //Hemos encontrado la clave buscada?. Inicialmente no
  bool keyFound=false;
  
  //Creamos el nombre del archivo temporal
  String tempFile=_fileName+"$";
  //Abrimos el archivo como sólo lectura
  File f=SPIFFS.open(_fileName,"r");
  //Abrimos el archivo temporal como escritura
  File t=SPIFFS.open(tempFile,"w");
  //Mientras el archivo tenga algo que leer...
  while(f.available())
  {
    //...leemos la clave
    String keyRead=f.readStringUntil(';');
    //Leemos el valor
    String valueRead=f.readStringUntil('\n');
    //Si la clave coincide con la que buscamos...
    if(keyRead==key)
    {
      //...anotamos que hemos encontrado la clave
      keyFound=true;
    }
    else //Si no es la clave que buscamos...
    {
      //...escribimos el registro en el archivo temporal
      t.println(keyRead+";"+valueRead);
    }
  }
  //Hemos terminado de leer el archivo.
  //Cerramos tanto el temporal como el de diccionario
  t.close();
  f.close();
  //Si hemos encontrado la clave buscada...
  if(keyFound)
  {
    //...borramos el archivo de diccionario
    SPIFFS.remove(_fileName);
    //Renombramos el temporal al de diccionario
    SPIFFS.rename(tempFile,_fileName);
    //Recucimos el número de registros
    _count--;
  }
  else //No hemos encontrado la clave buscada
  {
    //Borramos el archivo temporal
    SPIFFS.remove(tempFile);
  }
  return keyFound;
}

void RoJoFileDictionary::clear()
{
  //Borra el contenido del diccionario

  //Borramos el archivo del diccionario
  SPIFFS.remove(_fileName);
  //Y lo creamos de nuevo
  File f=SPIFFS.open(_fileName,"w");
  f.close();
  //ya no tenemos registros
  _count=0;
}

bool RoJoFileDictionary::add(String key,String value)
{
  //Añade un item al diccionario
  //Si ya existe lo actualiza
  //Devuelve true si ya existía la clave

  //Borramos la clave si es que existe
  //Y anotamos si ya existía
  bool alreadyExists=remove(key);
  //Añadimos la nueva
  //Abrimos el archivo como lectura/escritura
  File f=SPIFFS.open(_fileName,"r+");
  //Leemos todas las líneas del archivo
  while(f.available()) {f.readStringUntil('\n');}
  //Escribimos el nuevo registro
  f.println(key+";"+value);
  //Cerramo archivo
  f.close();
  //Tenemos un nuevo registro
  _count++;
  //Respondemos si ya existía la clave
  return alreadyExists;
}

bool RoJoFileDictionary::add(RoJoFileDictionaryItem item)
{
  //Añade un item al diccionario
  //Si ya existe lo actualiza
  //Devuelve true si ya existía la clave
  return add(item.key,item.value);
}

String RoJoFileDictionary::value(String key,String defaultValue)
{
  //Obtiene el valor de una clave
  //Si no existe devuelve el valor por defecto

  String keyRead;
  String valueRead;
  File f=SPIFFS.open(_fileName,"r");
  while(f.available())
  {
    keyRead=f.readStringUntil(';');
    valueRead=f.readStringUntil('\n');
    if(keyRead==key)
    {
      f.close();
      return valueRead;
    }
  }
  f.close();
  return defaultValue;
}

String RoJoFileDictionary::key(uint16_t index)
{
  //Obtiene la clave de una posición
  //Si el índice está fuera de rango devuelve una clave vacía
  
  //Si el índice está fuera de rango...hemos terminado
  if(index>=_count) return "";
  
  return item(index).key;
}

String RoJoFileDictionary::value(uint16_t index)
{
  //Obtiene el valor de una posición
  //Si el índice está fuera de rango devuelve un valor vacío

  //Si el índice está fuera de rango...hemos terminado
  if(index>=_count) return "";

  return item(index).value;
}

RoJoFileDictionaryItem RoJoFileDictionary::item(uint16_t index)
{
  //Obtiene el item de una posición
  //Si el índice está fuera de rango devuelve un item con clave y valor vacíos

  //Creamos el item a devolver
  RoJoFileDictionaryItem a;
  //Si el índice es válido...
  if(index<_count)
  {
    File f=SPIFFS.open(_fileName,"r");
    for(uint16_t i=0;i<index+1;i++)
    {
      a.key=f.readStringUntil(';');
      a.value=f.readStringUntil('\n');
    }
    f.close();
  }
  return a;
}

#endif


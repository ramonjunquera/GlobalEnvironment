/*
  Nombre de la librería: RoJoTimerESP8266.h
  Versión: 20191007
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP8266 para la gestión de timers.
    Las placas ESP8266 tienen 2 timers por hardware, el 0 y el 1.
    El timer 0 es utilizado en la gestión de wifi, por lo tanto y no es conveniente utilizarlo.
    Sólo nos queda el timer 1 a disposición del usuario.
    Por esta razón, no solicitaremos nunca el número de timer, siempre será el 1.
    El timer 1 tiene disponibles 3 prescalers (o divisores):
      varName    val div   freq    period     max
      ---------- --- --- -------- -------- --------------
      TIM_DIV1    0    1    80MHz 0.0125us  0.1048575875s
      TIM_DIV16   1   16     5MHz 0.2000us  1.6777214s
      TIM_DIV256  3  256 312.5KHz 3.2000us 26.8435424s

    En la tabla se muestran los detalles de cada uno de ellos.
    Se tiene en cuenta que el procesador tiene un reloj de 80MHz.
    La tabla también será valida aunque configuremos el procesador a 160MHz.
    La frecuencia se calcula como la frecuencia de reloj (80MHz) entre el prescaler:
      frecuencia=freq=80MHz/div
    El periodo es el inverso de la frecuencia. Es el mínimo tiempo que puede transcurrir
    entre dos interrupciones:
      periodo=period=1/freq
    El timer tiene una resolución de 23 bits. Por lo tanto el valor máximo del CTC es de
    2^23-1=8388607.
    Para calcular el máximo periodo o máxima duración del timer para un prescaler, multiplicamos
    el valor del periodo por el máximo CTC:
      max=period*(2^23-1)=period*8388607
    Podemos comprobar que el timer no es capaz de esperar más de 26.8s con el prescaler más alto.
    Si solicitamos un periodo mayor, se reducirá siempre a este valor.
    La función interna timer1_enable tiene la siguiente sintaxis:
      void timer1_enable(uint8_t divider, uint8_t int_type, uint8_t reload)
      El primer parámetro (divider) el es divisor o prescaler.
      El segundo parámetro es el tipo de finalización de ciclo. Los posibles valores son:
        varName   val
        --------- ---
        TIM_EDGE   0
        TIM_LEVEL  1

        El timer 1 determina el final de ciclo con TIM_EDGE (llegando al final del contador CTC).
        El timer 0 lo determina con TIM_LEVEL.
        Puesto que sólo gestionaremos el timer 1, siempre utilizaremos TIM_EDGE.
      El tercer parámetro es el tipo de recarga de ciclo. Los posibles valores son:
        varName    val
        ---------- ---
        TIM_SINGLE  0
        TIM_LOOP    1

        TIM_SINGLE configura el timer con un ciclo único. Una vez que salte la interrupción no se
        volverá a cargar (no se repetirá). Es un timer de una única ejecución.
        TIM_LOOP recargará automáticamente el ciclo. Se repite de manera indefinida.
    La función a la que llama el timer en cada ciclo no debe devolver valores ni tener parámetros.
    Si la ejecución de la función produce errores o provoca resets aleatorios, añadiremos la
    instrucción ICACHE_RAM_ATTR antes del nombre de la función. Por ejemplo:
      void ICACHE_RAM_ATTR functionName()
    Esta instrucción copia el código de la función que habitualmente se encuentra en memoria flash a la
    memoria IRAM. En el ESP8266 es un sección de memoria de 32Kb reservada para funciones de interrupción.
    Realmente no tenemos las 32Kb disponibles, sino que sólo suelen sobrar unas 3Kb. Por eso sólo
    utilizaremos esta instrucción cuando sea estrictamente necesario.

    La clase utiliza la misma sintaxis que Ticker

    El método attach se encarga de calcular tanto el prescaler/divisor como el el CTC necesarios para
    configurar el timer en base al periodo indicado. Guarda los valores en variables internas e inicia
    el timer.
    Si hay posibilidad de utilizar varios prescalers, siempre se toma la opción del más preciso.
    La familia ESP ya tiene una librería para timers llamada Ticker.h. Los timers se gestionan por software.
    No son demasiado precisos y si reducimos el periodo comienza a fallar. El uso de timers por 
    hardware permite que los tiempos de ejecución sean más exáctos aunque se reduzca el periodo máximo
    a utilizar.
*/

#include <RoJoTimerESP8266.h>

//Detiene las interrupciones del timer 1  
void RoJoTimerESP8266::detach() {
  timer1_disable();
}

//Inicia el timer
void RoJoTimerESP8266::_start(uint32_t microseconds,void (*callback)(),bool oneTime) {
  //Tabla de divisores/prescalers
  const byte prescalers[]={TIM_DIV1,TIM_DIV16,TIM_DIV256}; //={0,1,3}
  //Tabla con los periodos máximos en microsegundos
  const uint32_t maxPeriods[]={104857,1677721,26843542};
  //Tabla con los periodos mínimos en microsegundos * factor
  const uint32_t minPeriods[]={125,2,32};
  //Tabla de factores
  const uint32_t factors[]={10000,10,10};
  byte prescalerIndex=255; //Indice del prescaler. Inicialmente ninguno
  byte _divider; //Divisor/prescaler seleccionado
  uint32_t _CTC; //Valor del contador de ciclos
  
  //Nos aseguramos de detener el timer
  detach();
  //Inicializamos el timer 1
  timer1_isr_init();
  //Asignamos la función de interrupción
  timer1_attachInterrupt(callback);
  //Calculamos el prescaler/divisor
  //Inicialmente no tenemos definido un prescaler
  _divider=255;
  //Recorremos los periodos de los prescalers en sentido descendente...
  //Si el periodo máximo del prescaler admite el periodo deseado...
  //Anotamos el índice del prescaler
  for(byte i=2;i<255;i--) if(microseconds<=maxPeriods[i]) prescalerIndex=i;
  //Si no hemos encontrado un prescaler adecuado (porque el periodo es demasiado grande)...
  if(prescalerIndex>2) {
    //...limitaremos el periodo al máximo que puede soportar
    prescalerIndex=2;
    microseconds=maxPeriods[prescalerIndex];
  }
  //Hemos encontrado un prescaler adecuado!. Lo anotamos
  _divider=prescalers[prescalerIndex];
  //Debemos calcular el CTC
  _CTC=(microseconds*factors[prescalerIndex])/minPeriods[prescalerIndex];

  //Asignamos divisor y tipo de ciclo
  //  TIM_SINGLE = 0 : el timer sólo saltará una vez
  //  TIM_LOOP = 1 : el timer se repetirá de forma indefinida
  timer1_enable(_divider,TIM_EDGE,oneTime?TIM_SINGLE:TIM_LOOP);
  //Asignamos CTC
  timer1_write(_CTC);
}

//Activa el timer indefinidamente
void RoJoTimerESP8266::attach(float seconds, void (*callback)()) {
  //Convertimos el periodo a microsegundos y lanzamos el timer indefinidamente
  _start(seconds*1000000.0,callback,false);
}

//Activa el timer indefinidamente
void RoJoTimerESP8266::attach_ms(uint32_t milliseconds, void (*callback)()) {
  //Convertimos el periodo a microsegundos y lanzamos el timer indefinidamente
  _start(milliseconds*1000,callback,false);
}

//Activa el timer una vez
void RoJoTimerESP8266::once(float seconds, void (*callback)()) {
  //Convertimos el periodo a microsegundos y lanzamos el timer una sola vez
  _start(seconds*1000000.0,callback,true);
}

//Activa el timer una vez
void RoJoTimerESP8266::once_ms(uint32_t milliseconds, void (*callback)()) {
  //Convertimos el periodo a microsegundos y lanzamos el timer indefinidamente
  _start(milliseconds*1000,callback,true);
}

//El timer está activo?
bool RoJoTimerESP8266::active() {
  //Si el timer está activo (T1C) y además tiene la alarma activa (TEIE)...está en marcha
  return T1C>0 && (TEIE & 2)>0;
}
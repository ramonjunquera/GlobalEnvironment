/*
  Nombre de la librería: RoJoTimerESP8266.h
  Versión: 20181026
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP8266 para la gestión de timers.
    Las placas ESP8266 tienen 2 timers por hardware, el 0 y el 1.
    El timer 0 es utilizado en la gestión de wifi, por lo tanto y no es conveniente utilizarlo.
    Sólo nos queda el timer 1 a disposición del usuario.
    Por esta razón, no solicitaremos nunca el número de timer a utilizar.
    La clase está hecha con métodos y variables estáticas, por lo tanto, no será necesario
    instanciar un objeto. Se llama directamente a los métodos.
    El timer 1 tiene disponibles 3 prescalers (o divisores):
      varName    val div   freq    period     max
      ---------- --- --- -------- -------- --------------
      TIM_DIV1    0    1    80MHz 0.0125us  0.1048575875s
      TIM_DIV16   1   16     5MHz 0.2000us  1.6777214s
      TIM_DIV256  3  256 312.5KHz 3.2000us 26.8435424s

      En la tabla se muestran los detalles de cada uno de ellos.
      Se tiene en cuenta que el procesador tiene un reloj de 80MHz.
      La tabla también será valida aunque configuremos el procesador a 160MHz.
      La frecuencia se calcula como la frecuencia de reloj (80MHz) entre el prescaler:
        freq=80MHz/div : frecuencia
      El periodo es el inverso de la frecuencia. Es el mínimo tiempo que puede transcurrir
      entre dos interrupciones:
        period=1/freq : periodo
      El timer tiene una resolución de 23 bits. Por lo tanto el valor máximo del CTC es de
      2^23-1=8388607.
      Para calcular el máximo periodo o máxima duración del timer para un prescaler, multiplicamos
      el valor del periodo por el máximo CTC:
        max=period*(2^23-1)=period*8388607
      Podemos comprobar que el timer no es capaz de esperar más de 26.8s con el prescaler más alto.
      El método set de la clase devolverá un error si se intenta fijar un periodo superior a este valor.
    La función interna timer1_enable tiene la siguiente sintaxis:
      void timer1_enable(uint8_t divider, uint8_t int_type, uint8_t reload)
      El primer parámetro (divider) el es divisor o prescaler.
      El segundo parámetro es el tipo de finalización de ciclo. Los posibles valores son:
        varName   val
        --------- ---
        TIM_EDGE   0
        TIM_LEVEL  1

        El timer 1 determina el final de ciclo con TIM_EDGE (llegando al final del contador CTC).
        El timer 0 lo determina con TIM_LEVEL.
        Puesto que sólo gestionaremos el timer 1, siempre utilizaremos TIM_EDGE.
      El tercer parámetro el el tipo de recarga de ciclo. Los posibles valores son:
        varName    val
        ---------- ---
        TIM_SINGLE  0
        TIM_LOOP    1

        TIM_SINGLE configura el timer con un ciclo único. Una vez que salte la interrupción no se
        volverá a cargar (no se repetirá). Es un timer de una única ejecución.
        TIM_LOOP recargará automáticamente el ciclo. Se repite de manera indefinida.
    La función a la que llama el timer en cada ciclo no debe devolver valores ni tener parámetros.
      Si la ejecución de la función produce errores o provoca resets aleatorios, añadiremos la
      instrucción ICACHE_RAM_ATTR antes del nombre de la función. Por ejemplo:
        void ICACHE_RAM_ATTR functionName()
      Esta instrucción copia el código de la función que habitualmente se encuentra en memoria flash a la
      memoria IRAM. En el ESP8266 es un sección de memoria de 32Kb reservada para funciones de interrupción.
      Realmente no tenemos las 32Kb disponibles, sino que sólo suelen sobrar unas 3Kb. Por eso sólo
      utilizaremos esta instrucción cuando sea estrictamente necesario.
    La clase sólo tiene tres métodos: set, start y stop.
    El método set se encaga de calcular tanto el prescaler/divisor como el el CTC necesarios para
    configurar el timer en base al periodo indicado. Guarda los valores en variables internas y los
    utiliza en el método start para iniciar el timer.
    Si hay posibilidad de utilizar varios prescalers, siempre se toma la opción del más preciso.
    La familia ESP ya tiene una librería para timers llamada Ticker.h. Los timers se gestionan por software.
    No son demasiado precisos y si reducimos el periodo comienza a fallar. El uso de timers por 
    hardware permite que los tiempos de ejecución sean más exáctos aunque se reduzca el periodo máximo
    a utilizar.
*/

#include <Arduino.h>
#include "RoJoTimerESP8266.h"

//Reserva de memoria de variables estáticas
byte RoJoTimerESP8266::_divider; //Divisor/prescaler seleccionado
uint32_t RoJoTimerESP8266::_CTC; //Valor del contador de ciclos

bool RoJoTimerESP8266::set(void (*f)(),uint32_t period)
{
  //Inicialización de timer. Parámetros: función de llamada, periodo en microsegundos.
  //La función a la que se llamará cuando salte la interrupción no debe tener 
  //parámetros y no puede devolver nada.
  //Devuelve true si ha podido configurar el timer

  //Tabla de divisores/prescalers
  const byte prescalers[]={TIM_DIV1,TIM_DIV16,TIM_DIV256}; //={0,1,3}
  //Tabla con los periodos máximos en microsegundos
  const uint32_t maxPeriods[]={104857,1677721,26843542};
  //Tabla con los periodos mínimos en microsegundos * factor
  const uint32_t minPeriods[]={125,2,32};
  //Tabla de factores
  const uint32_t factors[]={10000,10,10};
  //Indice del prescaler. Inicialmente ninguno (=255)
  byte prescalerIndex=255;
  
  //Nos aseguramos de detener el timer
  stop();
  //Inicializamos el timer 1
  timer1_isr_init();
  //Asignamos la función de interrupción
  timer1_attachInterrupt(f);
  //Calculamos el prescaler/divisor
  //Inicialmente no tenemos definido un prescaler
  _divider=255;
  //Recorremos los periodos de los prescalers en sentido descendente...
  //Si el periodo máximo del prescaler admite el periodo deseado...
  //Anotamos el índice del prescaler
  for(byte i=2;i<255;i--) if(period<=maxPeriods[i]) prescalerIndex=i;
  //Si no hemos encontrado un prescaler adecuado (porque el periodo es demasiado grande)...
  //...hemos terminado con error
  if(prescalerIndex>2) return false;
  //Hemos encontrado un prescaler adecuado!. Lo anotamos
  _divider=prescalers[prescalerIndex];
  //Debemos calcular el CTC
  _CTC=(period*factors[prescalerIndex])/minPeriods[prescalerIndex];
  //Todo ok
  return true;
}

void RoJoTimerESP8266::start(bool oneTime)
{
  //Inicia el timer
  //El parámetro indica si se debe ejecutar una sóla vez o indefinido

  //Nos aseguramos de detener el timer
  stop();
  //Asignamos divisor y tipo de ciclo
  //  TIM_SINGLE = 0 : el timer sólo saltará una vez
  //  TIM_LOOP = 1 : el timer se repetirá de forma indefinida
  timer1_enable(_divider,TIM_EDGE,oneTime?TIM_SINGLE:TIM_LOOP);
  //Asignamos CTC
  timer1_write(_CTC);
}

void RoJoTimerESP8266::stop()
{
  //Detiene las interrupciones del timer 1  
  timer1_disable();
}



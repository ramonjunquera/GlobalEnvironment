/*
  Nombre de la librería: RoJoTimerESP8266.h
  Versión: 20181109
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP8266 para la gestión de timers
*/

//Comprobamos que la placa es compatible
#if not defined(ARDUINO_ARCH_ESP8266)
  #error Library RoJoTimerESP8266 is only compatible with ESP8266 family devices
#endif  

#pragma once //Evita el uso clásico de la comparativa de etiqueta para evitar cargas múltiples

#include <Arduino.h>

class RoJoTimerESP8266
{
  private:  //Definición de métodos/variables privadas
    static byte _divider; //Divisor/prescaler seleccionado
    static uint32_t _CTC; //Valor del contador de ciclos
  public: //Definición de métodos/variables públicas
    static bool set(void (*f)(),uint32_t period); //Inicialización de timer. Parámetros: función de llamada, periodo en microsegundos
    static void start(bool oneTime); //Inicia el timer
    static void stop(); //Detiene el timer
}; //Punto y coma obligatorio para que no de error

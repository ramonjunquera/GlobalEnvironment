/*
  Nombre de la librería: RoJoTimerESP8266.h
  Versión: 20191007
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP8266 para la gestión de timers
*/

//Comprobamos que la placa es compatible
#if not defined(ARDUINO_ARCH_ESP8266)
  #error Library RoJoTimerESP8266 is only compatible with ESP8266 family devices
#endif  

#pragma once //Evita el uso clásico de la comparativa de etiqueta para evitar cargas múltiples

#include <Arduino.h>

class RoJoTimerESP8266 {
  private:  //Definición de métodos/variables privadas
    void _start(uint32_t microseconds,void (*callback)(),bool oneTime); //Inicia el timer
  public: //Definición de métodos/variables públicas
    void attach(float seconds, void (*callback)()); //Activa el timer indefinidamente
    void attach_ms(uint32_t milliseconds, void (*callback)()); //Activa el timer indefinidamente
    void once(float seconds, void (*callback)()); //Activa el timer una vez
    void once_ms(uint32_t milliseconds, void (*callback)()); //Activa el timer una vez
    void detach(); //Detiene el timer
    bool active(); //El timer está activo?
}; //Punto y coma obligatorio para que no de error

/*
  Nombre de la librería: RoJoNTPclientESP.h
  Versión: 20191127
  Autor: Ramón Junquera
  Descripción:
    Permite obtener la hora de un servidor NTP
    Exclusivo para placas ESP
*/

#ifndef RoJoNTPclient_h
#define RoJoNTPclient_h

#include <Arduino.h>
#include <WiFiUdp.h>

class RoJoNTPclient {
  private:
    String _ntpServer; //Nombre del servidor NTP
    int32_t _secondsOffset; //Diferencia por timeZone y summerTime en segundos
    WiFiUDP _udp; //Gestión de paquetes UDP
    byte _packetBuffer[48]; //Buffer de paquetes
  public:
    void begin(String ntpServer,int8_t timeZone,bool summerTime); //Inicialización
    uint32_t get(); //Devuelve el tiempo en segundos desde 1900
};

#ifdef __arm__
  #include <RoJoNTPclient.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

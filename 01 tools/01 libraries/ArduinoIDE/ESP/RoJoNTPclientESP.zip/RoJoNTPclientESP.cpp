/*
  Nombre de la librería: RoJoNTPclientESP.h
  Versión: 20191127
  Autor: Ramón Junquera
  Descripción:
    Permite obtener la hora de un servidor NTP
    Exclusivo para placas ESP
*/

#ifndef RoJoNTPclient_cpp
#define RoJoNTPclient_cpp

#include <RoJoNTPclientESP.h>

//Inicialización
void RoJoNTPclient::begin(String ntpServer,int8_t timeZone,bool summerTime) {
  _ntpServer=ntpServer; //Guardamos el nombre del servidor NTP
  _secondsOffset=(timeZone+summerTime)*3600; //Calculamos el offset en segundos
  _udp.begin(2390); //Recibiremos paquetes UDP por el puerto 2390
}

//Devuelve el tiempo en segundos desde 1900
//Devuelve 0 si no lo consigue
uint32_t RoJoNTPclient::get() {
  //Preparamos el paquete udp para que sea una solicitud de envío de hora
  //Inicializamos el buffer que contendrá la respuesta, llenándolo de ceros
  memset(_packetBuffer,0,48);
  //Rellenamos las posiciones con los valores correctos para hacer la solicitud al servidor NTP
  _packetBuffer[0] = 0b11100011; // LI, Version, Mode
  _packetBuffer[1] = 0;          // Stratum, or type of clock
  _packetBuffer[2] = 6;          // Polling Interval
  _packetBuffer[3] = 0xEC;       // Peer Clock Precision
  //Los 8 bytes intermedios (del 4 al 11) son ceros (fijados antes). Corresponden a Root Delay & Root Dispersion
  _packetBuffer[12]  = 49;
  _packetBuffer[13]  = 0x4E;
  _packetBuffer[14]  = 49;
  _packetBuffer[15]  = 52;
  //Hemos terminado de asignar los valores a todos los bytes del paquete para la solicitud NTP
  //Enviamos el paquete de solicitud siempre al puerto 123/udp
  _udp.beginPacket(_ntpServer.c_str(),123); //Indicamos la dirección de destino y el puerto
  _udp.write(_packetBuffer,48); //Escribimos (enviamos) el paquete de 48 bytes
  _udp.endPacket(); //Finalizamos el envío del paquete
  //Paquete de solicitud enviado!

  //Definimos la variable que contendrá el número de segundos transcurridos desde el 1 de enero de 1900
  //Inicialmente su valor es 0
  //Es el valor que devolveremso si no hemos podido obtener el tiempo de internet
  unsigned long secsSince1900=0;

  //Comprobamos cada décima de segundo si ha llegado un paquete con la longitud esperada
  //Lo repetimos un máximo de 10 veces (tiempo máximo = 1 segundo)
  for(byte t=0;t<10;t++) {
    //Esperamos un décima de segundo
    delay(100);
    //Si hemos recibido, al menos, un paquete completo...
    if(_udp.parsePacket()>=48) {
      //Leemos el paquete recibido y lo guardamos en el buffer
      _udp.read(_packetBuffer,48);
      //La marca del tiempo se encuentra a partir del byte 40 del paquete recibido
      //Indica los segundos transcurridos desde el 1 de enero de 1900
      //En forma de uint32_t (4 bytes)
      //Leemos 4 bytes a partir de la posición 40
      //El primero es el que más peso tiene (como siempre)
      for(byte i=0;i<4;i++) secsSince1900=(secsSince1900<<8)+_packetBuffer[40+i];
      //Hemos conseguido tener en secsSince1900 el número de segundos transcurridos desde
      //el 1 de enero de 1900 en la zona del meridiano de Greenwich
      secsSince1900+=_secondsOffset; //Añadimos la diferencia por timeZone & summerTime
      break; //Salimos del bucle (for)
    }
  }
  //Hemos esperado suficiente para recibir el paquete con el tiempo, y no ha llegado.
  //O sí lo tenemos y hemos obligado a terminar el bucle
  //De cualquier manera, podemos informar del resultado
  _udp.stop(); //Terminamos de utilizar la clase que gestiona los paquetes udp
  return secsSince1900; //Devolvemos el resultado
}

#endif

/*
  Nombre de la librería: RoJoESP32PWML.h
  Versión: 20181109
  Autor: Ramón Junquera
  Descripción:
    Gestión de PWM para placas ESP32 usando el método ledc

    A fecha actual el paquete de instrucciones para compatibilizar las placas ESP32 con el IDE
    de Arduino no está totalmente desarrollado.
    Concretamente la instrucción analogWrite para gestionar PWM no existe.
    Se ha creado la función con el mismo nombre y parámetros que la original.
    La única diferencia es que devolverá false si no ha podido completarse.

    Con el método ledc disponemos de 16 canales (timers) de una resolución máxima de 15 bits.
    Para guardar compatibilidad con otras librerías de PWM de ESP32, fijaremos la resolución 
    a 8 bits. Por lo tanto tendremos 256 niveles de intensidad de PWM.
    Cada canal puede ser programado con su propia amplitud de onda.
    Una vez configurado un canal se asocia a un pin, que tendrá el estado de la onda.
    Por lo tanto, con esta librería podremos tener un máximo de 16 pines PWM con valores distintos.

    Con una resolución de 8 bits podemos alcanzar una frecuencia máxima de 312500 Hz.
    Es la frecuencia que utilizaremos.

    La función encarga de:
    - Comprobar si ya existe un canal que tenga asignado el pin solicitado para reutilizarlo.
    - Desactivar canales cuyo nivel es 0
    - Buscar canales libres para nuevas peticiones.
*/

#include <Arduino.h>
#include "RoJoAnalogWriteESP32L.h"

bool analogWrite(byte pin,byte level)
{
  //Asigna un nivel PWM a un pin
  //Devuelve false si no ha podido

  //Array con los pines asignados a cada canal
  //Inicialmente todos desasignados (=0)
  static byte _pinsPWM[16]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

  //Último canal vacío
  byte lastEmpty=0xFF; 

  //El pin indicado tiene ya abierto un canal?
  //Recorremos todos los canales
  for(byte c=0;c<16;c++)
  {
    //Si hemos encontrado un canal asignado a este pin...
    if(_pinsPWM[c]==pin)
    {
      //Si el nivel es distinto de cero...cambiamos el nivel PWM del canal
      if(level) ledcWrite(c,level);
      else //Si el nivel es cero...
      {
        //...desasignamos el pin del canal
        ledcDetachPin(pin);
        //Ponemos el pin a low
        digitalWrite(pin,LOW);
        //Anotamos que está desasignado
        _pinsPWM[c]=0;
      }
      //Hemos terminado correctamente
      return false;
    }
    else //Este canal no está asignado al pin indicado
    {
      //Si el canal está sin asignar...anotamos que está vacío
      if(_pinsPWM[c]==0) lastEmpty=c;
    }
  }
  //Hemos recorrido todos los canales y ninguno está asignado al pin indicado
  //Si tenemos algún canal desasignado...
  if(lastEmpty!=0xFF)
  {
    //...lo utilizaremos
    //Lo anotamos
    _pinsPWM[lastEmpty]=pin;
    //Fijamos el canal a la máxima frecuencia con una resolución de 8 bits
    ledcSetup(lastEmpty,312500,8);
    //Fijamos el nivel al solicitado
    ledcWrite(lastEmpty,level);
    //Asociamos el pin al canal
    ledcAttachPin(pin,lastEmpty);
    //Hemos terminado correctamente
    return false;
  }
  //No tenemos canales desasignados para la petición
  //Devolvemos error
  return true;
}


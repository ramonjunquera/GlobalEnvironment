/*
  Nombre de la librería: RoJoBalancer
  Autor: Ramón Junquera
  Fecha: 20200828
  Descripción:
    Balanceador de carga para las 2 CPUs de un ESP32.
    Asigna CPU automáticamente a cada nueva tarea teniendo en cuenta cuál es
    la que menos tareas tiene asignada.
    En C++ no existen las clases estáticas como en C#, pero sus métodos sí
    pueden serlo.
    La clase no necesita inicialización.
    Ni siquiera es necesario instanciarla.
    Es suficiente con añadir el include y referenciar al método.

    Puesto que el programa principal siempre se asigna a la CPU1 con prioridad 1,
    se comienza con 1 tarea para esa CPU.
    Todas las tareas tienen siempre la misma prioridad que el programa principal.
    Así el balanceo será más equilibrado.

    De la misma manera que se llama al método addTask para crear una nueva tarea,
    se debe llamar al método deleteTask antes de finalizar una tarea.
*/

#ifndef RoJoBalancer_h
#define RoJoBalancer_h

//Comprobamos que la placa es compatible
#if !defined(ESP32)
  #error Library RoJoBalancer is only compatible with ESP32 devices
#endif 

#include <Arduino.h>

class RoJoBalancer {
  private:  //Definición de métodos/variables privadas
    static int8_t _tasksDiff; //Tasks running in CPU1 - running in CPU0
  public: //Definición de métodos/variables públicas
    static bool addTask(TaskFunction_t func,void *funcParams,uint32_t stackSize=2000); //Añade una nueva tarea
    static void deleteTask(); //Elimina una tarea
}; //Punto y coma obligatorio para que no de error

#endif

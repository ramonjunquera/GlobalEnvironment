/*
  Nombre de la librería: RoJoBalancer
  Autor: Ramón Junquera
  Fecha: 20200828
  Descripción:
    Balanceador de carga para las 2 CPUs de un ESP32.
    Asigna CPU automáticamente a cada nueva tarea teniendo en cuenta cuál es
    la que menos tareas tiene asignada.
    En C++ no existen las clases estáticas como en C#, pero sus métodos sí
    pueden serlo.
    La clase no necesita inicialización.
    Ni siquiera es necesario instanciarla.
    Es suficiente con añadir el include y referenciar al método.

    Puesto que el programa principal siempre se asigna a la CPU1 con prioridad 1,
    se comienza con 1 tarea para esa CPU.
    Todas las tareas tienen siempre la misma prioridad que el programa principal.
    Así el balanceo será más equilibrado.

    De la misma manera que se llama al método addTask para crear una nueva tarea,
    se debe llamar al método deleteTask antes de finalizar una tarea.
*/

#ifndef RoJoBalancer_cpp
#define RoJoBalancer_cpp

#include <RoJoBalancer.h>

//Declaramos las variables estáticas de la clase
//_tasksDiff = tareas corriendo en CPU1 - tareas corriendo en CPU0
//Inicialmente tCPU1=1 (programa principal) y tCPU0=0
//Por lo tanto: _tasksDiff=tCPU1-tCPU0=1-0=1
int8_t RoJoBalancer::_tasksDiff=1;

//Añade una nueva tarea
//Devuelve true si se ha creado con éxito
bool RoJoBalancer::addTask(TaskFunction_t func,void *funcParams,uint32_t stackSize) {
  //Decidimos la CPU en la que lanzaremos la tarea
  byte cpuIndex;
  if(_tasksDiff>0) { //Si CPU1 tiene más carga que CPU0...
    cpuIndex=0; //Seleccionaremos la CPU0
    _tasksDiff--; //La diferencia de tareas se reduce
  } else { //Si la CPU0 tiene más carga que CPU1...
    cpuIndex=1; //Seleccionaremos la CPU1
    _tasksDiff++; //La diferencia de tareas aumenta
  }
  return xTaskCreatePinnedToCore(func,"",stackSize,funcParams,1,NULL,cpuIndex);
}

//Elimina una tarea
void RoJoBalancer::deleteTask() {
  //Si la tarea actual está siendo ejecutada en CPU1...reducimos la diferencia
  if(xPortGetCoreID()) _tasksDiff--;
  //Si la tarea actual está siendo ejecutada en CPU0...aumentamos la diferencia
  else _tasksDiff++;
  vTaskDelete(NULL); //Finalizamos la tarea actual
}

#endif
/*
  Nombre de la librería: RoJoTimerESP32.h
  Versión: 20181109
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP32 para la gestión de timers.
*/

#include <Arduino.h>
#include "RoJoTimerESP32.h"

bool RoJoTimerESP32::set(byte timerId,void (*f)(),uint64_t period)
{
  //Inicialización de timer.
  //Parámetros:
  // - timerId: identificador del timer [0,3]
  // - f: función de llamada
  // - period: periodo en microsegundos
  //Devuelve true si consigue crear el timer
  //La función a la que se llamará cuando salte la interrupción no debe tener 
  //parámetros y no puede devolver nada.

  //Si el identificador en mayor que el permitido...hemos terminado con error
  if(timerId>3) return false;
  //Nos aseguramos de detener y borrar el timer
  stop();
  //Guardamos el identificador del timer en la variable privada
  _timerId=timerId;
  //Guardamos la función del timer en la variable privada
  _f=f;
  //Teniendo el periodo deseado para el timer, debemos calcular el prescaler y la alarma.
  //El periodo de del timer se calcula:
  //  periodo=alarma*periodo actualización=alarma/frecuencia actualización=alarma/frecuencia base*prescaler=
  //  =alarma*prescaler/80000000
  //Para que el periodo se mida en microsegundos, multiplicamos a todo por un millón
  //  periodo(us)=alarma*prescaler/80
  //Aplicando el prescaler más alto (65535) y la alarma más baja (1) tenemos el periodo más alto que
  //podemos conseguir sólo con el prescaler es de:
  //  periodo(us)=65535/80=819us
  //Calcularemos la alarma como el número de veces que debo repetir el prescaler más alto
  _alarm=period/819;
  //Si la división no es exácta (tiene resto)...sumamos uno a la alarma
  if(_alarm%819) _alarm++;
  //El prescaler se calcula como:
  //  periodo(us)=alarma*prescaler/80 -> prescaler=80*periodo(us)/alarma
  _prescaler=80*period/_alarm;
  //Todo ok
  return true;
}

bool RoJoTimerESP32::start(bool oneTime)
{
  //Inicia el timer
  //El parámetro indica si se debe ejecutar una sóla vez o indefinido
  //Devuelve true si se consigue poner en marcha

  //Si el prescaler es cero es que aun no se ha configurado...error
  if(!_prescaler) return false;
  //Nos aseguramos de detener el timer
  stop();
  //Creamos un timer nuevo en el identificador indicado, con el prescaler calculado y 
  //con un contador ascendente
  _myTimer=timerBegin(_timerId,_prescaler,true);
  //Asignamos la función de interrupción. El timer será de tipo edge
  timerAttachInterrupt(_myTimer,_f,true);
  //Fijamos la alarma e indicamos si es repetitiva
  timerAlarmWrite(_myTimer,_alarm,!oneTime);
  //Activamos el timer
  timerAlarmEnable(_myTimer);
  //Todo ok
  return true;
}

void RoJoTimerESP32::stop()
{
  //Detiene y borra el timer

  //Si hay algún timer definido...
  if(_myTimer)
  {
    //...lo detenemos
    timerEnd(_myTimer);
    //Anotamos que lo hemos borrado
    _myTimer=NULL;
  }
}



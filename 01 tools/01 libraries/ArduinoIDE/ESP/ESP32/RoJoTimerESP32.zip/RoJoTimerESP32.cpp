/*
  Nombre de la librería: RoJoTimerESP32.h
  Versión: 20201125
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP32 para la gestión de timers
    Se respeta la nomenclatura de métodos de Ticker
  Notas:
  - Se encuentra una incompatibilidad con la librería driver/i2s.h
    Sólamente con hacer referencia a la función i2s_driver_install, la clase
    RoJoTimerESP32 fallará en todos sus métodos en sus instancias locales.
    Es cambio si la clase se instancia como global, funcionará.
*/

#include <RoJoTimerESP32.h>

//Canstructor
//  timerId es opcional. Por defecto es 0.
RoJoTimerESP32::RoJoTimerESP32(byte timerId) {
  //Guardamos el identificador de timer en variable privada
  //Nos aseguramos que es menor que 4
  _timerId=timerId%4;
}

//Destructor
RoJoTimerESP32::~RoJoTimerESP32() {
  detach();
}

//Asigna identificador de timer
void RoJoTimerESP32::setTimerId(byte timerId) {
  detach();
  _timerId=timerId%4;
}

//Inicia el timer
void RoJoTimerESP32::_start(uint64_t period_us,void (*callback)(),bool oneTime) {
  //El parámetro indica si se debe ejecutar una sóla vez o indefinido
  //Devuelve true si se consigue poner en marcha

  //Nos aseguramos de detener y borrar el timer
  detach();
  //Guardamos la función del timer en la variable privada
  _functionTimer=callback;
  //Conociendo el periodo deseado para el timer, debemos calcular el prescaler y la alarma.
  //El periodo del timer se calcula:
  //  periodo_s=alarma*periodo_actualización_s=alarma/frecuencia_actualización=
  //  =alarma/frecuencia_base*prescaler=alarma*prescaler/80000000
  //Para que el periodo se mida en microsegundos, multiplicamos a todo por un millón
  //  periodo_us=alarma*prescaler/80
  //Intentaremos siempre maximizar el valor del prescaler para evitar errores

  //Suponiendo que utilizamos el prescaler más alto (65535), calculamos cuál seria su alarma.
  //_alarm=(period_us*80)/65335=(period_us*16)/13107
  //Pero siempre tomaremos el entero superior. Ej.: De 1.25 tomaremos 2. De 4 tomamos 4. De 0.021 tomamos 1
  //Esto corresponde a la función ceil() que trata números de coma flotante.
  //No existe esta función para enteros. La implementamos como:
  //res=ceil(num/den)=1+((num-1)/den)
  _alarm=1+((period_us*16-1)/13107);
  _prescaler=(80*period_us)/_alarm; //Ya tenemos la alarma. Calcularemos el prescaler

  //Creamos un timer nuevo en el identificador indicado, con el prescaler calculado y 
  //con un contador ascendente
  _myTimer=timerBegin(_timerId,_prescaler,true);
  //Asignamos la función de interrupción. El timer será de tipo edge
  timerAttachInterrupt(_myTimer,_functionTimer,true);
  //Fijamos la alarma e indicamos si es repetitiva
  timerAlarmWrite(_myTimer,_alarm,!oneTime);
  //Activamos el timer
  timerAlarmEnable(_myTimer);
}

//Activa el timer indefinidamente
void RoJoTimerESP32::attach_ms(uint32_t period_ms, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance indefinidamente
  _start(period_ms*1000,callback,false);
}

//Activa el timer indefinidamente
//El periodo se indica en segundos
void RoJoTimerESP32::attach(float period_s, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance indefinidamente
  _start(period_s*1000000.0,callback,false);
}

//Activa el timer una sola vez
//El periodo se indica en milisegundos
void RoJoTimerESP32::once_ms(uint32_t period_ms, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance una sola vez
  _start(period_ms*1000,callback,true);
}

//Activa el timer una sola vez
//El periodo se indica en segundos
void RoJoTimerESP32::once(float period_s, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance una sola vez
  _start(period_s*1000000.0,callback,true);
}

//Detiene y borra el timer
void RoJoTimerESP32::detach() {
  if(_myTimer) { //Si hay algún timer definido...
    timerEnd(_myTimer); //...lo detenemos
    _myTimer=NULL; //Anotamos que lo hemos borrado
  }
}

//El timer está activo?
bool RoJoTimerESP32::active() {
  //Si existe...lo consultamos
  if(_myTimer) return timerAlarmEnabled(_myTimer);
  //Si no existe, seguro que no está activo
  return false;
}

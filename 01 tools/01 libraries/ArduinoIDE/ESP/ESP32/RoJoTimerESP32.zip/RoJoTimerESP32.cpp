/*
  Nombre de la librería: RoJoTimerESP32.h
  Versión: 20191005
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP32 para la gestión de timers.
*/

#include <RoJoTimerESP32.h>

//Canstructor
RoJoTimerESP32::RoJoTimerESP32(byte timerId) {
  //Guardamos el identificador de timer en variable privada
  //Nos aseguramos que es menor que 4
  _timerId=timerId%4;
}

//Inicia el timer
void RoJoTimerESP32::_start(uint64_t microseconds,void (*callback)(),bool oneTime) {
  //El parámetro indica si se debe ejecutar una sóla vez o indefinido
  //Devuelve true si se consigue poner en marcha

  //Nos aseguramos de detener y borrar el timer
  detach();
  //Guardamos la función del timer en la variable privada
  _functionTimer=callback;
  //Teniendo el periodo deseado para el timer, debemos calcular el prescaler y la alarma.
  //El periodo de del timer se calcula:
  //  periodo=alarma*periodo actualización=alarma/frecuencia actualización=alarma/frecuencia base*prescaler=
  //  =alarma*prescaler/80000000
  //Para que el periodo se mida en microsegundos, multiplicamos a todo por un millón
  //  periodo(us)=alarma*prescaler/80
  //Aplicando el prescaler más alto (65535) y la alarma más baja (1) tenemos el periodo más alto que
  //podemos conseguir sólo con el prescaler es de:
  //  periodo(us)=65535/80=819us
  //Calcularemos la alarma como el número de veces que debo repetir el prescaler más alto
  _alarm=microseconds/819;
  //Si la división no es exácta (tiene resto)...sumamos uno a la alarma
  if(_alarm%819) _alarm++;
  //El prescaler se calcula como:
  //  periodo(us)=alarma*prescaler/80 -> prescaler=80*periodo(us)/alarma
  _prescaler=(80*microseconds)/_alarm;

  //Creamos un timer nuevo en el identificador indicado, con el prescaler calculado y 
  //con un contador ascendente
  _myTimer=timerBegin(_timerId,_prescaler,true);
  //Asignamos la función de interrupción. El timer será de tipo edge
  timerAttachInterrupt(_myTimer,_functionTimer,true);
  //Fijamos la alarma e indicamos si es repetitiva
  timerAlarmWrite(_myTimer,_alarm,!oneTime);
  //Activamos el timer
  timerAlarmEnable(_myTimer);
}

//Activa el timer indefinidamente
void RoJoTimerESP32::attach_ms(uint32_t milliseconds, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance indefinidamente
  _start(milliseconds*1000,callback,false);
}

//Activa el timer indefinidamente
void RoJoTimerESP32::attach(float seconds, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance indefinidamente
  _start(seconds*1000000.0,callback,false);
}

//Activa el timer una sola vez
void RoJoTimerESP32::once_ms(uint32_t milliseconds, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance una sola vez
  _start(milliseconds*1000,callback,true);
}

//Activa el timer una sola vez
void RoJoTimerESP32::once(float seconds, void (*callback)()) {
  //Pasamos los segundos a microsegundos llamamos al método _start para que se lance una sola vez
  _start(seconds*1000000.0,callback,true);
}

//Detiene y borra el timer
void RoJoTimerESP32::detach() {
  //Si hay algún timer definido...
  if(_myTimer) {
    //...lo detenemos
    timerEnd(_myTimer);
    //Anotamos que lo hemos borrado
    _myTimer=NULL;
  }
}

//El timer está activo?
bool RoJoTimerESP32::active() {
  //Si existe...lo consultamos
  if(_myTimer) return timerAlarmEnabled(_myTimer);
  //Si no existe, seguro que no está activo
  return false;
}

/*
  Nombre de la librería: RoJoTimerESP32.h
  Versión: 20181108
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP32 para la gestión de timers
*/

//Comprobamos que la placa es compatible
#if not defined(ARDUINO_ARCH_ESP32)
  #error Library RoJoTimerESP32 is only compatible with ESP32 family devices
#endif  

#pragma once //Evita el uso clásico de la comparativa de etiqueta para evitar cargas múltiples

#include <Arduino.h>

class RoJoTimerESP32
{
  private:  //Definición de métodos/variables privadas
    hw_timer_t *_myTimer; //Puntero a estructura de timer
    byte _timerId; //Identificador  del timer [0,3]
    uint16_t _prescaler;
    uint64_t _alarm;
    void (*_f)(); //Función de timer
  public: //Definición de métodos/variables públicas
    bool set(byte timerId, void (*f)(),uint64_t period); //Inicialización de timer
    bool start(bool oneTime); //Inicia el timer
    void stop(); //Detiene el timer
}; //Punto y coma obligatorio para que no de error

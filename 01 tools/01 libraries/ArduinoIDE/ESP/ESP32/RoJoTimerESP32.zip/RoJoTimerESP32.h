/*
  Nombre de la librería: RoJoTimerESP32.h
  Versión: 20201118
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP32 para la gestión de timers
    Se respeta la nomenclatura de métodos de Ticker
*/

//Comprobamos que la placa es compatible
#if not defined(ARDUINO_ARCH_ESP32)
  #error Library RoJoTimerESP32 is only compatible with ESP32 family devices
#endif  

#pragma once //Evita el uso clásico de la comparativa de etiqueta para evitar cargas múltiples

#include <Arduino.h>

class RoJoTimerESP32 {
  private:  //Definición de métodos/variables privadas
    hw_timer_t *_myTimer; //Puntero a estructura de timer
    byte _timerId; //Identificador  del timer [0,3]
    uint16_t _prescaler;
    uint64_t _alarm;
    void (*_functionTimer)(); //Función de timer
    void _start(uint64_t period_us,void (*callback)(),bool oneTime); //Inicia el timer
  public: //Definición de métodos/variables públicas
    RoJoTimerESP32(byte timerId); //Constructor
    void attach(float period_s, void (*callback)()); //Activa el timer indefinidamente
    void attach_ms(uint32_t period_ms, void (*callback)()); //Activa el timer indefinidamente
    void once(float period_s, void (*callback)()); //Activa el timer una vez
    void once_ms(uint32_t period_ms, void (*callback)()); //Activa el timer una vez
    void detach(); //Detiene el timer
    bool active(); //El timer está activo?
}; //Punto y coma obligatorio para que no de error

/*
  Nombre de la librería: RoJoI2Sa.h
  Versión: 20201125
  Autor: Ramón Junquera
  Descripción:
    Librería exclusiva para placas ESP32 para la gestión de dispositivos de 
    audio analógicos por I2S.
    Permite leer o escribir en pines analógicos un buffer de memoria a una
    frecuencia determinada.

  Funciones públicas:
    bool RoJoI2Sa_end(byte timerId)
    bool RoJoI2Sa_begin(byte timerId,byte pin,float freq)
    bool RoJoI2Sa_read(byte timerId,uint16_t *buffer,uint32_t samples)
    bool RoJoI2Sa_write(byte timerId,byte *buffer,uint32_t samples)
    void RoJoI2Sa_convert16to8(uint16_t *bufferIn,byte *bufferOut,uint32_t samples,float gain)
    void RoJoI2Sa_convert16to8(int16_t *bufferIn,byte *bufferOut,uint32_t samples,float gain)
*/

//Comprobamos que la placa es compatible
#if not defined(ARDUINO_ARCH_ESP32)
  #error Library RoJoI2Sa is only compatible with ESP32 family devices
#endif  

#pragma once //Evita el uso clásico de la comparativa de etiqueta para evitar cargas múltiples

#include <Arduino.h>
#include <RoJoTimerESP32.h> //Gestión de timers

struct _RoJoI2SaChannel { //Contiene todas la variables necesarias para una transmisión
  byte pin; //Pines de entrada (micrófono) o salida (speaker)
  float period_s=0; //Periodo en segundos
  RoJoTimerESP32 myTimer; //Timer
  uint32_t samplePos; //Posición actual de la muestra
  uint32_t samples; //Número total de muestras
  byte *buffer; //Puntero a buffer
  bool reading; //Estamos leyendo (true) o escribiendo (false)
  SemaphoreHandle_t mySema; //Puntero a semáforo
};

//Tenemos disponibles 4 timers -> 4 transmisiones simultáneas
_RoJoI2SaChannel _RoJoI2SaChannels[4];

//Finaliza un canal
//Devuelve true si lo consigue
bool RoJoI2Sa_end(byte timerId) {
  if(timerId>3) return false;
  _RoJoI2SaChannel *c=&_RoJoI2SaChannels[timerId];
  if(c->period_s>0) {
    c->myTimer.detach();
    c->period_s=0;
  }
  return true;
}

//Inicialización
//Parámetros:
//  timerId : identificador de timer [0,3]
//  pin : pin analógico de entrada (micrófono) o salida (speaker)
//  freq : frecuencia de muestreo en Hz
//Devuelve true si lo consigue
bool RoJoI2Sa_begin(byte timerId,byte pin,float freq) {
  if(freq==0) return false;
  if(!RoJoI2Sa_end(timerId)) return false;
  _RoJoI2SaChannel *c=&_RoJoI2SaChannels[timerId];
  c->pin=pin;
  c->period_s=1.0/freq;
  c->myTimer.setTimerId(timerId);
  return true;
}

//(interna) Lectura/escritura de la siguiente muestra de un timer
void _RoJoI2SaInt(byte timerId) {
  _RoJoI2SaChannel *c=&_RoJoI2SaChannels[timerId];
  if(c->reading) *(uint16_t*)(c->buffer+2*c->samplePos++)=analogRead(c->pin);
  else dacWrite(c->pin,c->buffer[c->samplePos++]);
  if(c->samplePos==c->samples) { //Si hemos llegado al final de la memoria...
    c->myTimer.detach(); //Finalizamos el timer
    xSemaphoreGive(c->mySema); //Incrementamos el contador del semáforo (a 1)
  } 
}

//(interna) Función de interrupción para timer 0
void _RoJoI2SaInt0() { _RoJoI2SaInt(0); }
//(interna) Función de interrupción para timer 1
void _RoJoI2SaInt1() { _RoJoI2SaInt(1); }
//(interna) Función de interrupción para timer 2
void _RoJoI2SaInt2() { _RoJoI2SaInt(2); }
//(interna) Función de interrupción para timer 3
void _RoJoI2SaInt3() { _RoJoI2SaInt(3); }

//(interna) Lanza una comunicación
//  timerId : identificador de timer [0,3]
//  *buffer : puntero a buffer de memoria
//  samples : número de muestras
//  reading : true->de lectura, false->de escritura
//Devuelve true si lo consigue
bool _RoJoI2Sa_rw(byte timerId,byte *buffer,uint32_t samples,bool reading) {
  if(timerId>3) return false;
  _RoJoI2SaChannel *c=&_RoJoI2SaChannels[timerId];
  c->samplePos=0;
  c->buffer=buffer;
  c->samples=samples;
  c->reading=reading;
  c->mySema=xSemaphoreCreateBinary(); //Creamos semáforo binario con valor 0
  switch(timerId) {
    case 0: c->myTimer.attach(c->period_s,_RoJoI2SaInt0); break;
    case 1: c->myTimer.attach(c->period_s,_RoJoI2SaInt1); break;
    case 2: c->myTimer.attach(c->period_s,_RoJoI2SaInt2); break;
    case 3: c->myTimer.attach(c->period_s,_RoJoI2SaInt3); break;
  }
  xSemaphoreTake(c->mySema,portMAX_DELAY); //Esperamos a que finalice la comunicación
  vSemaphoreDelete(c->mySema); //Borramos el semáforo
  if(!reading) dacWrite(c->pin,0); //Si es escritura...silenciamos el buzzer
  return true;
}

//Lee datos de un dispositivo de entrada
//Parámetros:
//  timerId : identificador de timer [0,3]
//  *buffer : puntero a buffer de memoria que recogerá la muestras de 16 bits
//  samples : número de muestras
//Devuelve true si lo consigue
bool RoJoI2Sa_read(byte timerId,uint16_t *buffer,uint32_t samples) {
  return _RoJoI2Sa_rw(timerId,(byte*)buffer,samples,true);
}

//Escribe datos de un dispositivo de salida
//Parámetros:
//  timerId : identificador de timer [0,3]
//  *buffer : puntero a buffer de memoria contiene las muestras a escribir
//  samples : número de muestras
bool RoJoI2Sa_write(byte timerId,byte *buffer,uint32_t samples) {
  return _RoJoI2Sa_rw(timerId,buffer,samples,false);
}

//Convierte datos uint16_t a byte:
// *bufferIn : puntero a buffer de entrada con datos uint16_t
// *bufferOut : puntero a buffer de salida con datos byte
// gain : factor de amplificación. Por defecto 16
void RoJoI2Sa_convert16to8(uint16_t *bufferIn,byte *bufferOut,uint32_t samples,float gain=16) {
  //Nota:
  //Los circuitos ADC de ESP32 devuelven datos en formato uint16_t con 12bits de precisión
  //Los circuitos DAC de ESP32 aceptan datos den formato byte con 8bits de precisión
  //Con una amplificación x16 compensamos los 4bits de precisión que le falta a la muestra
  //(12bits) para alcanzar los 16bits del dato.
  for(uint32_t i=0;i<samples;i++) bufferOut[i]=constrain((float)bufferIn[i]/256.0*gain,0,255);
}

//Convierte datos int16_t a byte:
// *bufferIn : puntero a buffer de entrada con datos int16_t
// *bufferOut : puntero a buffer de salida con datos byte
// gain : factor de amplificación. Por defecto 16
void RoJoI2Sa_convert16to8(int16_t *bufferIn,byte *bufferOut,uint32_t samples,float gain=16) {
  //Nota:
  //Un micrófono mono devuelve devuelven datos en formato int16_t con 12bits de precisión
  //Los circuitos DAC de ESP32 aceptan datos den formato byte con 8bits de precisión
  //Con una amplificación x16 compensamos los 4bits de precisión que le falta a la muestra
  //(12bits) para alcanzar los 16bits del dato. En la práctica y con un buzzer estándar no es
  //suficiente y se necesitan amlificaciones entre 32 y 64.
  for(uint32_t i=0;i<samples;i++) bufferOut[i]=constrain((float)bufferIn[i]/256.0*gain+127.0,0,255);
}

/*
 * Autor: Ramón Junquera
 * Fecha: 20200911
 * Tema: Gestión de matrices bidimensionales de tipo float MultiTasking
 * Restricciones: Sólo para ESP32
 * Nota: Aproximadamente un 40% más rápida que RoJoFloatMatrix
 */

#include "RoJoFloatMatrix.h"

struct _taskParam { //Estructura de parámetro para tareas
  RoJoFloatMatrix *A,*B,*Z; //Matrices para operar
  void *a,*b; //Punteros a parámetros adicionales
  uint16_t firstRow; //Primera fila a procesar
  uint16_t lastRow; //Última fila a procesar
  SemaphoreHandle_t sema; //Semáforo para informar el fin de tarea
  void (*f)(_taskParam*); //Función de cálculo de tarea
};

//Tarea de producto matricial Z=A*B
void RoJoFloatMatrix::_mProdTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrA; //Puntero a fila de A
  float *mrZ; //Puntero a fila de Z
  uint16_t items=p->A->_cols; //Obtenemos el número de items (columnas de A)
  float sum;
  float **mB=p->B->m; //Puntero de array de B
  uint16_t colsZ=p->Z->_cols; //Columnas de Z
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrA=p->A->m[row]; //Anotamos fila de matriz A
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) {
      sum=0; //Comenzamos a sumar
      for(uint16_t i=0;i<items;i++) sum+=mrA[i]*mB[i][col];
      mrZ[col]=sum;
    }
  }
}

//Tarea de suma matricial Z=Z+A
void RoJoFloatMatrix::_mSumTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrA; //Puntero a fila de A
  float *mrZ; //Puntero a fila de Z
  uint16_t colsZ=p->Z->_cols; //Columnas de Z
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrA=p->A->m[row]; //Anotamos fila de matriz A
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    //Recorremos columnas y sumamos A a Z (Z=Z+A)
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]+=mrA[col];
  }
}

//Tarea de copia matricial Z=A
void RoJoFloatMatrix::_mCopyTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrA; //Puntero a fila de A
  float *mrZ; //Puntero a fila de Z
  uint16_t *deltaRows=(uint16_t*)p->a;
  uint16_t *deltaCols=(uint16_t*)p->b;
  uint16_t colsA=p->A->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) {
    mrA=p->A->m[row]; //Anotamos fila de matriz A
    mrZ=p->Z->m[row+*deltaRows]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsA;col++) mrZ[col+*deltaCols]=mrA[col];
  }
}

//Tarea traspuesta Z=T(A)
void RoJoFloatMatrix::_TTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float **mA=p->A->m; //Puntero a array de A
  float *mrZ; //Puntero a fila de Z
  uint16_t colsZ=p->Z->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) {
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]=mA[col][row];
  }
}

//Tarea de llenado de valores aleatorios entre a y b
void RoJoFloatMatrix::_fillRandTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrZ; //Puntero a fila de Z
  uint16_t colsZ=p->Z->_cols;
  float *minValue=(float*)p->a;
  float *maxValue=(float*)p->b;
  float delta=((float)RAND_MAX)/(*maxValue-*minValue);
  for(uint16_t row=p->firstRow;row<=lastRow;row++) {
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]=*minValue+((float)random(RAND_MAX)/delta);
  }
}

//Tarea de llenado con el valor a
void RoJoFloatMatrix::_fillTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrZ; //Puntero a fila de Z
  uint16_t colsZ=p->Z->_cols;
  float *a=(float*)p->a;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) {
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]=*a;
  }
}

//Tarea de cálculo de maxmin entre las columnas a y b
//Devuelve resultados en Z
void RoJoFloatMatrix::_maxminTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrA; //Puntero a fila de A
  float *mrZ=p->Z->m[p->firstRow>0]; //Fila con la que trabajaremos
  uint16_t *firstCol=(uint16_t*)p->a;
  uint16_t *lastCol=(uint16_t*)p->b;
  float min=mrZ[0];
  float max=mrZ[1];
  float value;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) {
    mrA=p->A->m[row]; //Anotamos fila de matriz A
    for(uint16_t col=*firstCol;col<=*lastCol;col++) {
      value=mrA[col];
      if(value<min) min=value;
      if(value>max) max=value;
    }
  }
  mrZ[0]=min;
  mrZ[1]=max;
}

//Tarea de cálculo de producto escalar por un valor Z=Z*a
void RoJoFloatMatrix::_eProdVTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  uint16_t colsZ=p->Z->_cols;
  float *mrZ; //Puntero a fila de Z
  float *a=(float*)p->a;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]*=*a;
  }
}

//Tarea de cálculo de producto escalar matricial Z=A*B
void RoJoFloatMatrix::_eProdMTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrA,*mrB,*mrZ; //Punteros a filas
  uint16_t colsZ=p->Z->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrA=p->A->m[row]; //Anotamos fila de matriz A
    mrB=p->B->m[row]; //Anotamos fila de matriz B
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]=mrA[col]*mrB[col];
  }
}

//Tarea de cálculo de función de un parámetro Z=fa(A)
void RoJoFloatMatrix::_f1Task(_taskParam *p) {
  float (*f)(float)=(float(*)(float))p->a;
  uint16_t lastRow=p->lastRow;
  float *mrA,*mrZ; //Punteros a filas
  uint16_t colsZ=p->Z->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrA=p->A->m[row]; //Anotamos fila de matriz A
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]=f(mrA[col]);
  }
}

//Tarea de cálculo de función de dos parámetros Z=fa(A,B)
void RoJoFloatMatrix::_f2Task(_taskParam *p) {
  float (*f)(float,float)=(float(*)(float,float))p->a;
  uint16_t lastRow=p->lastRow;
  float *mrA,*mrB,*mrZ; //Punteros a filas
  uint16_t colsZ=p->Z->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrA=p->A->m[row]; //Anotamos fila de matriz A
    mrB=p->B->m[row]; //Anotamos fila de matriz B
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]=f(mrA[col],mrB[col]);
  }
}

//Tarea de cálculo de suma de matriz columna
void RoJoFloatMatrix::_sumColTask(_taskParam *p) {
  float v;
  uint16_t lastRow=p->lastRow;
  float **mA=p->A->m; //Puntero de array de A
  float *mrZ; //Puntero a fila de Z
  uint16_t colsZ=p->Z->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrZ=p->Z->m[row]; //Anotamos fila de matriz Z
    v=mA[row][0];
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]+=v;
  }
}

//Tarea de cálculo de suma de matriz fila
void RoJoFloatMatrix::_sumRowTask(_taskParam *p) {
  uint16_t lastRow=p->lastRow;
  float *mrA=p->A->m[0]; //Puntero a primera fila de A
  float *mrZ; //Puntero a fila de Z
  uint16_t colsZ=p->Z->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrZ=p->Z->m[row]; //Puntero a fila de Z
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]+=mrA[col];
  }
}

//Tarea de cálculo de reordenamiento en base a una lista
void RoJoFloatMatrix::_scrambleTask(_taskParam *p) {
  uint16_t *sList=(uint16_t*)p->a;
  uint16_t lastRow=p->lastRow;
  float *mrZ; //Puntero a fila de Z
  float **mA=p->A->m; //Puntero a array de datos de A
  uint16_t colsZ=p->Z->_cols;
  for(uint16_t row=p->firstRow;row<=lastRow;row++) { //Recorremos todas las filas...
    mrZ=p->Z->m[row];
    for(uint16_t col=0;col<colsZ;col++) mrZ[col]=mA[sList[row]][col];
  }
}

//Función de tarea de cálculo
//Función interna. No se hacen verificaciones.
void RoJoFloatMatrix::_calcTask(void *param) {
  _taskParam *p=(_taskParam*)param;
  p->f(p); //Llamamos a la función indicada
  xSemaphoreGive(p->sema); //Incrementamos el contador del semáforo
  delete p; //Liberamos memoria de parámetro
  vTaskDelete(NULL); //Eliminamos la tarea
}

//Generador de tareas
//Parámetros:
//  RoJoFloatMatrix *A,*B,*Z : matrices
//  void *a,*b : punteros a parámetros adicionales
//  uint16_t rows : número de filas
//  f : función de tarea de cálculo
//Devuelve true si todo es correcto
bool RoJoFloatMatrix::_splitRows(RoJoFloatMatrix *A,RoJoFloatMatrix *B,RoJoFloatMatrix *Z,void *a,void *b,uint16_t rows,void (*f)(_taskParam*)) {
  if(rows==0) return false;
  //Creamos semáforo para informar del fin de tarea
  SemaphoreHandle_t sema=xSemaphoreCreateCounting(2,0);
  if(sema==NULL) return false; //Si no hay memoria...devolvemos error
  _taskParam *p; //Puntero a parámetro de cada tarea
  byte tasks=rows>1; //Calculamos el número de tareas-1 que lanzaremos
  uint16_t delta=rows/2; //Número de filas por tarea (si tenemos 2)
  for(byte task=0;task<=tasks;task++) { //Recorremos todas las tareas a crear...
    p=new _taskParam;
    p->A=A;
    p->B=B;
    p->Z=Z;
    p->a=a;
    p->b=b;
    p->firstRow=delta*task;
    if(task==tasks) p->lastRow=rows-1; //Si es la última tarea tomará hasta el final
    else p->lastRow=delta-1; //Si es la primera tarea tomará la primera mitad
    p->sema=sema;
    p->f=f;
    //Lanzamos una tarea en cada CPU. Si sólo hay una, en la CPU0
    xTaskCreatePinnedToCore(_calcTask,"",2000,(void*)p,1,NULL,task);
  }
  //Esperamos a que terminen todas las tareas
  for(byte task=0;task<=tasks;task++) xSemaphoreTake(sema,portMAX_DELAY);
  vSemaphoreDelete(sema); //Borramos el semáforo
  //En la secuencia de finalización de las tareas de cálculo se notifica
  //a través del semáforo, se libera la memoria de parámetros y finalmente
  //se destruye la tarea.
  //El programa principal continúa en cuanto recibe la notificación por el
  //semáforo, pero realmente la tarea no ha terminado.
  //Si hacemos un uso intensivo de la librería, es posible que se queden
  //tareas de cálculo sin cerrar, porque no se tiene tiempo para ello.
  //Si el número total de tareas supera los 60, corremos el riesgo de que
  //se bloquee el sistema.
  //Para evitarlo, comprobaremos el número total de tareas y si supera un
  //valor prudencial, reduciremos la prioridad del programa principal a 0,
  //permitiendo que las tareas en ejecución pendientes de ser cerradas, que
  //tiene prioridad 1, lo hagan. Cuando todas las tareas de prioridad 1
  //hayan terminado, se devolverá el control al programa principal y
  //podremos recuerar la prioridad original.
  if(uxTaskGetNumberOfTasks()>55) {
    vTaskPrioritySet(NULL,0);
    vTaskPrioritySet(NULL,1);
  }
  return true; //Todo Ok
}

//Descarga memoria
void RoJoFloatMatrix::end() {
  if(_rows>0) { //Si tenemos algo guardado en la matriz...
    //Recorremos todas las filas...y las borramos
    for(uint16_t i=0;i<_rows;i++) delete[] m[i];
    delete[] m; //Borramos la propia matriz
    _rows=_cols=0; //Anotamos que la matriz está vacía
  }
}

//Destructor
RoJoFloatMatrix::~RoJoFloatMatrix() {
  end();
}

//Redimensionar
//Parámetros:
//- rows : número de filas
//- cols : número de columnas
//Respuesta: true si lo consigue
bool RoJoFloatMatrix::redim(uint16_t rows,uint16_t cols) {
  //Si alguna de las dimensiones es nula...error
  if(rows==0 || cols==0) return false;
  //El valor de las dimensiones es correcto
  end(); //Nos aseguramos que la matriz está vacía
  //Anotamos las dimensiones en las variables privadas
  _rows=rows; _cols=cols;
  //Creamos un array de punteros con tantos elementos como columnas
  m=new float*[rows];
  //Creamos un array para posición de _m con tantos elementos como
  //columnas
  for(uint16_t i=0;i<rows;i++) m[i]=new float[cols];
  return true; //Todo Ok
}

//Constructor con tamaño
RoJoFloatMatrix::RoJoFloatMatrix(uint16_t rows,uint16_t cols) {
  redim(rows,cols); //Asignamos tamaño
}

//Constructor para asignación
RoJoFloatMatrix::RoJoFloatMatrix(RoJoFloatMatrix &A) {
  //Dimensionamos la matrix actual como la del parámetro
  redim(A._rows,A._cols);
  mCopy(&A);
}

//Llena la matriz con una secuencia en un rango
//El primer valor coincidirá con minValue
//Y el último con maxValue
bool RoJoFloatMatrix::linspace(float minValue,float maxValue,uint16_t samples) {
  if(maxValue<=minValue || samples<2) return false;
  //Dimensionamos matriz con tantas filas como muestras y una sola columna
  redim(samples,1);
  //Calculamos sus valores
  float k=(maxValue-minValue)/(samples-1);
  for(uint16_t i=0;i<samples;i++) m[i][0]=minValue+i*k;
  return true; //Todo Ok
}

//Devuelve el número de columnas
uint16_t RoJoFloatMatrix::cols() {
  return _cols;
}

//Devuelve el número de filas
uint16_t RoJoFloatMatrix::rows() {
  return _rows;
}

//Traspone matriz
//Devuelve true si lo consigue
bool RoJoFloatMatrix::T(RoJoFloatMatrix *A) {
  if(!redim(A->_cols,A->_rows)) return false;
  return _splitRows(A,NULL,this,NULL,NULL,_rows,_TTask);
}

//Llena la matriz con valores aleatorios entre dos límites
//Respuesta: true si lo consigue
bool RoJoFloatMatrix::fillRand(float minValue,float maxValue) {
  if(minValue>=maxValue) return false; //Si los límites no son correctos...error
  randomSeed(analogRead(0)); //Generamos semilla aleatoria
  return _splitRows(NULL,NULL,this,(void*)&minValue,(void*)&maxValue,_rows,_fillRandTask);
}

//Llena la matriz con un valor
//Respuesta: true si lo consigue
bool RoJoFloatMatrix::fill(float value) {
  return _splitRows(NULL,NULL,this,(void*)&value,NULL,_rows,_fillTask);
}

//Calcula máx y min de un rango de columnas
//Devuelve true si lo consigue
bool RoJoFloatMatrix::maxminRangeCol(float *min,float *max,uint16_t firstCol,uint16_t lastCol) {
  if(_rows==0 || firstCol>lastCol || lastCol>=_cols) return false;
  byte tasks=_rows>1; //Calculamos tareas-1
  RoJoFloatMatrix mm(tasks+1,2); //Tantas filas como tareas y 2 col para min max
  mm.fill(m[0][firstCol]); //Llenamos la matriz de resultados con el primer valor
  //Solicitamos creación de tareas:
  //  A : Matriz actual
  //  Z : Matrix con resultados
  //  a : primera columna
  //  b : última columna
  //  rows: número de filas
  //  op : operación 6
  if(!_splitRows(this,NULL,&mm,(void*)&firstCol,(void*)&lastCol,_rows,_maxminTask)) return false;
  if(tasks==1) { //Si sólo hay dos tareas...
    if(mm.m[1][0]<mm.m[0][0]) mm.m[0][0]=mm.m[1][0]; //min
    if(mm.m[1][1]>mm.m[0][1]) mm.m[0][1]=mm.m[1][1]; //max
  }
  *min=mm.m[0][0];
  *max=mm.m[0][1];
  return true; //Todo Ok
}

//Calcula máx y min de una matrix
//Devuelve true si lo consigue
bool RoJoFloatMatrix::maxmin(float *min,float *max) {
  return maxminRangeCol(min,max,0,_cols-1);
}

//Calcula máx y min de una columna
//Devuelve true si lo consigue
bool RoJoFloatMatrix::maxminCol(float *min,float *max,uint16_t col) {
  return maxminRangeCol(min,max,col,col);
}

//Producto escalar
//Multiplica los elementos de dos matrices de igual dimensión
bool RoJoFloatMatrix::eProd(RoJoFloatMatrix *A, RoJoFloatMatrix *B) {
  if(A->_rows==0 || A->_rows!=B->_rows || A->_cols!=B->_cols) return false;
  if(!redim(A->_rows,B->_cols)) return false;
  return _splitRows(A,B,this,NULL,NULL,_rows,_eProdMTask);
}

//Producto escalar
//Multiplica todos los elementos de la matriz por un float
bool RoJoFloatMatrix::eProd(float v) {
  if(_rows==0) return false;
  return _splitRows(NULL,NULL,this,(void*)&v,NULL,_rows,_eProdVTask);
}

//Suma matricial. Añade A a la matriz actual
bool RoJoFloatMatrix::mSum(RoJoFloatMatrix *A) {
  //Ambas matrices deben tener dimensión y coincidir
  if(_rows!=A->_rows || _cols!=A->_cols || _rows==0 || _cols==0) return false;
  return _splitRows(A,NULL,this,NULL,NULL,_rows,_mSumTask);
}

//Producto matricial A*B
bool RoJoFloatMatrix::mProd(RoJoFloatMatrix *A,RoJoFloatMatrix *B) {
  //Comprobamos que las dimensiones son correctas
  if(A->_cols!=B->_rows || A->_rows==0 || A->_cols==0 || B->_cols==0) return false;
  if(!redim(A->_rows,B->_cols)) return false;
  return _splitRows(A,B,this,NULL,NULL,_rows,_mProdTask);
}

//Crea el resultado de aplicar una función a una matriz
//Parámetros:
//- f: puntero a función de un sólo parámetro float que devuelve un float
//- p: puntero a matriz usada como parámetro de la función
bool RoJoFloatMatrix::f1(float (*f)(float),RoJoFloatMatrix *p) {
  if(!redim(p->_rows,p->_cols)) return false;
  return _splitRows(p,NULL,this,(void*)f,NULL,_rows,_f1Task);
}

//Crea el resultado de aplicar una función a una matriz
//Parámetros:
//- f: puntero a función de dos parámetros float que devuelve un float
//- p0: puntero a matriz usada como primer parámetro de la función
//- p1: puntero a matriz usada como segundo parámetro de la función
bool RoJoFloatMatrix::f2(float (*f)(float,float),RoJoFloatMatrix *p0,RoJoFloatMatrix *p1) {
  if(p0->_cols!=p1->_cols || p0->_rows!=p1->_rows) return false;
  if(!redim(p0->_rows,p0->_cols)) return false;
  return _splitRows(p0,p1,this,(void*)f,NULL,_rows,_f2Task);
}

//Copia matriz A en local
//Devuelve true si lo consigue
bool RoJoFloatMatrix::mCopy(RoJoFloatMatrix *A) {
  if(!redim(A->_rows,A->_cols)) return false;
  uint16_t delta=0;
  return _splitRows(A,NULL,this,(void*)&delta,(void*)&delta,_rows,_mCopyTask);
}

//Pega filas de A y B guardando el resultado en la matriz actual
//Devuelve true si lo consigue
bool RoJoFloatMatrix::glueRows(RoJoFloatMatrix *A,RoJoFloatMatrix *B) {
  if(A->_cols!=B->_cols) return false;
  uint16_t rowsA=A->_rows,rowsB=B->_rows;
  uint16_t deltaRows=0,deltaCols=0;
  if(!redim(rowsA+rowsB,A->_cols)) return false;
  //Copiamos matriz A
  if(!_splitRows(A,NULL,this,(void*)&deltaRows,(void*)&deltaCols,rowsA,_mCopyTask)) return false;
  deltaRows=rowsA;
  //Copiamos matriz B
  return _splitRows(B,NULL,this,(void*)&deltaRows,(void*)&deltaCols,rowsB,_mCopyTask);
}

//Pega columnas de A y B guardando el resultado en la matriz actual
//Devuelve true si lo consigue
bool RoJoFloatMatrix::glueCols(RoJoFloatMatrix *A,RoJoFloatMatrix *B) {
  if(A->_rows!=B->_rows) return false;
  uint16_t colsA=A->_cols,colsB=B->_cols;
  uint16_t deltaRows=0,deltaCols=0;
  if(!redim(A->_rows,colsA+colsB)) return false;
  //Copiamos matriz A
  if(!_splitRows(A,NULL,this,(void*)&deltaRows,(void*)&deltaCols,_rows,_mCopyTask)) return false;
  deltaCols=colsA;
  //Copiamos matriz B
  return _splitRows(B,NULL,this,(void*)&deltaRows,(void*)&deltaCols,_rows,_mCopyTask);
}

//Suma la matriz columna a todas las columnas
//Devuelve true si lo consigue
bool RoJoFloatMatrix::sumCol(RoJoFloatMatrix *A) {
  if(_rows!=A->_rows || A->_cols!=1) return false;
  return _splitRows(A,NULL,this,NULL,NULL,_rows,_sumColTask);
}

//Suma la matriz fila a todas las filas
//Devuelve true si lo consigue
bool RoJoFloatMatrix::sumRow(RoJoFloatMatrix *A) {
  if(_cols!=A->_cols || A->_rows!=1) return false;
  return _splitRows(A,NULL,this,NULL,NULL,_rows,_sumRowTask);
}

//Crea secuencia desordenada de números enteros con tantos elementos como
//filas tenga la matriz
//La secuencia siempre comienza desde 0
//Devuelve el puntero del array resultante
uint16_t* RoJoFloatMatrix::scrambleList() {
  uint16_t *res=nullptr; //Respuesta
  if(_rows>0) {
    res=new uint16_t[_rows]; //Creamos array de respuesta
    uint16_t *tList=new uint16_t[_rows]; //Creamos array temporal
    for(uint16_t i=0;i<_rows;i++) tList[i]=i; //Lo llenamos con secuencia ordenada
    randomSeed(analogRead(0)); //Generamos semilla aleatoria
    for(uint16_t i=0;i<_rows;i++) { //Recorremos todos los números
      uint16_t index=random(_rows-i);
      res[i]=tList[index];
      for(uint16_t a=index;a<(_rows-i-1);a++) tList[a]=tList[a+1];
    }
    delete[] tList; //Liberamos array temporal
  }
  return res;
}

//Desordena la matriz en base a la lista
bool RoJoFloatMatrix::scramble(uint16_t *sList) {
  //Suponemos que la lista tiene los mismos elementos que la matriz
  RoJoFloatMatrix t; //Creamos matriz temporal
  t.mCopy(this); //Copiamos matriz actual a la temporal
  return _splitRows(&t,NULL,this,(void*)sList,NULL,_rows,_scrambleTask);
}

//Valor promedio de las columnas
//El resultado es una matriz de una sola fila y tantas columnas como la del parámetro
bool RoJoFloatMatrix::meanCols(RoJoFloatMatrix *A) {
  if(A->_rows==0) return false;
  if(!redim(1,A->_cols)) return false;
  float sum;
  uint16_t rows=A->_rows;
  for(uint16_t col=0;col<_cols;col++) {
    sum=0;
    for(uint16_t row=0;row<rows;row++) sum+=A->m[row][col];
    m[0][col]=sum/rows;
  }
  return true; //Todo Ok
}

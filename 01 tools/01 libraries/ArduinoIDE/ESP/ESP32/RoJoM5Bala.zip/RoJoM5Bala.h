/*
  Nombre de la librería: RoJoM5Bala.h
  Versión: 20200221
  Autor: Ramón Junquera
  Descripción:
    Gestión de módulo Bala para M5 Stack
*/

#ifndef RoJoM5Bala_h
#define RoJoM5Bala_h

#include <Arduino.h>
#include <Wire.h>

class RoJoM5Bala {
  private:
    const byte _idI2C=0x56; //Identificador I2C del motor
  public:
    bool begin(int pinSDA=-1,int pinSCL=-1); //Inicialización
    void set(int16_t p0,int16_t p1); //Asigna potencia
    bool get(int16_t *e0,int16_t *e1); //Lee encoders

}; //Punto y coma obligatorio para que no de error

#endif


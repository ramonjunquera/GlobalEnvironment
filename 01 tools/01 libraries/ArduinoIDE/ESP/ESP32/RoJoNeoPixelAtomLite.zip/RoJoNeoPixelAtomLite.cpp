/*
  Nombre de la librería: RoJoNeoPixelAtomLite.h
  Versión: 20201230
  Autor: Ramón Junquera
  Descripción:
    Gestión de led NeoPixel de M5Stack Atom Lite
*/

#ifndef RoJoNeoPixelAtomLite_cpp
#define RoJoNeoPixelAtomLite_cpp

#include <RoJoNeoPixelAtomLite.h>

//Inicialización
void RoJoNeoPixelAtomLite::begin() {
  pinMode(27,OUTPUT); digitalWrite(27,LOW); //Inicializamos pin de conexión con led
  //Apagamos led
  //Es posible que antes de inicializar, el pin ya se encontrase en HIGH.
  //En ese caso, ya se ha enviado el primer bit como 1, que afecta al canal verde
  //que es el primero de los canales que se envía (GRB).
  //Esto provoca que el led tenga algo de componente verde.
  //Puesto que no podemos evitar acciones previas a la inicialización, apagaremos
  //el led 2 veces. La segunda por si hubo problemas com la primera.
  //Esto sólo hay que hacerlo en la inicialización.
  draw(); draw();
}

//Muestra el sprite de momoria de vídeo
void RoJoNeoPixelAtomLite::draw(RoJoColor color) {
  //La comunicación con el controlador de los leds (NeoPixel) se realiza por un
  //único pin y de manera unidireccional: desde el dispositivo a NeoPixel.
  //Por eso inicializamos el pin en modo salida (OUTPUT).
  //Cuando no se transmite, el pin se encuentra en estado LOW.
  //Para transmitir un bit, activaremos el estado HIGH durante un tiempo (pulso).
  //La duración del pulso dependerá del valor que queramos transmitir.
  //Según las especificaciones del fabricante, los tiempos de pulso son:
  // - 0.4us para valor 0
  // - 0.8us para valor 1
  //Además entre dos pulsos debe transcurrir un tiempo mínimo de 1.25us
  //Si no se transmite nada en 300us se supone que ha finalizado la comunicación
  //Para transmitir un byte enviaremos consecutívamente los bits en orden MSB
  //(big endian). Desde el bit más significativo al que menos.
  //Gestionamos el estado de los pines escribiendo directamente en los puertos.

  //Debemos asegurarnos que han transcurrido al menos 300us desde la última
  //comunicación para que NeoPixel entienda que es una transferencia nueva.
  while(micros()-_lastComm<300);
  
  //Definición de variables
  byte currentChannel; //Byte de canal procesado
  byte maskChannel; //Máscara para procesar cada bit de cada canal
  volatile uint32_t *pinCommPort=(uint32_t*)0x3FF44004; //Puerto en variable local
  portDISABLE_INTERRUPTS(); //Evitamos interrupciones durante el envío
  //Intercambiamos los canales R y G porque la secuencia de envío de canales es GRB
  maskChannel=color.channels[0]; color.channels[0]=color.channels[1]; color.channels[1]=maskChannel;
  for(byte indexChannel=0;indexChannel<3;indexChannel++) {//Recorremos todos los canales
    currentChannel=color.channels[indexChannel]; //Obtenemos el byte a procesar
    maskChannel=0b10000000; //Calculamos la máscara del bit de mayor peso
    for(byte currentBit=0;currentBit<8;currentBit++) { //Recorremos los 8 bits del byte procesado
      //Debemos esperar 1.25us en pulso bajo antes de enviar un nuevo bit
      for(byte i=0;i<27;i++) {
        __asm__ __volatile__(
          "nop \n" // ciclo 1
        );
      }
      if((maskChannel & currentChannel) > 0) { //Si debemos enviar un 1...
        //Necesitamos un pulso de 0.8us
        *pinCommPort |= (1<<27); // digitalWrite(_pinComm,HIGH);
        for(byte i=0;i<19;i++) {
          __asm__ __volatile__(
            "nop \n" // ciclo 1
          );
        }
        *pinCommPort &= ~(1<<27); // digitalWrite(_pinComm,LOW);
      } else { //Si debemos enviar un 0...
        //Necesitamos un pulso de 0.4us. En la práctica no es necesario
        *pinCommPort |= (1<<27); // digitalWrite(_pinComm,HIGH);
        *pinCommPort &= ~(1<<27); // digitalWrite(_pinComm,LOW);
      }
      maskChannel>>=1;
    }
  }
  portENABLE_INTERRUPTS(); //Reactivamos interrupciones
  _lastComm=micros(); //Hemos finalizado el envío. Anotamos la hora actual
}

#endif

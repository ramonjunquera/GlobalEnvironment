/*
  Nombre de la librería: RoJoNeoPixelAtomLite.h
  Versión: 20201230
  Autor: Ramón Junquera
  Descripción:
    Gestión de led NeoPixel de M5Stack Atom Lite
*/

#ifndef RoJoNeoPixelAtomLite_h
#define RoJoNeoPixelAtomLite_h

#include <Arduino.h>

//Estructura para color de 24 bits
struct RoJoColor {
  byte channels[3]; //Guardamos los canales de color en un simple array
  void set24(uint32_t c) { //Guardamos el color como uint32_t 0x--RRGGBB
    channels[2]=c && 0xFF; //B
    c>>=8;
    channels[1]=c && 0xFF; //G
    c>>=8;
    channels[0]=c && 0xFF; //R
  }
  void set16(uint16_t c) { //Guardamos el color como uint16_t 0bRRRRRGGGGGGBBBBB
    channels[0]=(c >> 8) & 0b11111000; //R
    channels[1]=(c >> 3) & 0b11111100; //G
    channels[2]=(c << 3) & 0b11111000; //B
  }
  uint32_t get24() { //Devolvemos color en uint32_t 0x--RRGGBB
    return ((uint32_t)channels[0])<<16 | ((uint32_t)channels[1])<<8 | (uint32_t)channels[2];
  }
  uint16_t get16() { //Devolvemos color en uint16_t 0bRRRRRGGGGGGBBBBB
    uint16_t c = channels[0] >> 3; //R
    c <<= 6; //Hacemos sitio para G
    c |= channels[1] >> 2; //G
    c <<= 5; //Hacemos sitio para B
    c |= channels[2] >> 3; //B
    return c;
  }
};

class RoJoNeoPixelAtomLite {
  private:
    uint32_t _lastComm=0; //Tiempo en microsegundos de última comunicación
  public:
    void begin(); //Inicialización
    void draw(RoJoColor color={0,0,0}); //Dibuja memoria actual
}; //Punto y coma obligatorio para que no de error

#endif


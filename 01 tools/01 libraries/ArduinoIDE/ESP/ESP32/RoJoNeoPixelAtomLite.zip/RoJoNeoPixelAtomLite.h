/*
  Nombre de la librería: RoJoNeoPixelAtomLite.h
  Versión: 20210525
  Autor: Ramón Junquera
  Descripción:
    Gestión de led NeoPixel de M5Stack Atom Lite
*/

#ifndef RoJoNeoPixelAtomLite_h
#define RoJoNeoPixelAtomLite_h

#include <Arduino.h>

class RoJoNeoPixelAtomLite {
  private:
    uint32_t _lastComm=0; //Tiempo en microsegundos de última comunicación
  public:
    void begin(); //Inicialización
    void draw(byte r,byte g,byte b); //Dibuja color
}; //Punto y coma obligatorio para que no de error

#endif


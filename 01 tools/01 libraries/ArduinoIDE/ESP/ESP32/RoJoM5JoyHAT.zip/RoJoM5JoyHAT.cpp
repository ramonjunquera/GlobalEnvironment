/*
  Nombre de la librería: RoJoM5JoyHAT.h
  Versión: 20200126
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del HAY de Joystick para M5Stick C
*/

#ifndef RoJoM5JoyHAT_cpp
#define RoJoM5JoyHAT_cpp

#include <RoJoM5JoyHAT.h>

//Inicialización
//Devuelve true si lo consigue
bool RoJoM5JoyHAT::begin() {
  //Inicialización de I2C en bus 1
  //Pines: 0=SDA,26=SCL,freq=400KHz
  Wire1.begin(0,26,400000);
  //Comprobamos si el HAT está conectado
  Wire1.beginTransmission(idI2C); //Abrimos comunicación
  byte error=Wire1.endTransmission(); //Sin enviar nada, cerramos comunicación y anotamos la respuesta
  if(!error) { //Si no hay errores...
    init=true; //Inicializado correctamente
    return true; //Todo OK
  }
  return false; //KO
}

//Obtener datos
//Devuelve true si lo consigue
bool RoJoM5JoyHAT::get(int8_t *x,int8_t *y,bool *button) {
  if(!init) return false; //Si no ha sido inicializado...hemos terminado
  Wire1.beginTransmission(idI2C);
  Wire1.write(0x02); //Comando de solicitud de valores
  Wire1.endTransmission();
  Wire1.requestFrom(idI2C,3); //Necesitamos 3 bytes
  if (Wire1.available()) { //Si hay datos disponibles...
    *x=Wire1.read();
    *y=Wire1.read();
    *button=Wire1.read();
    return true; //Todo OK
  }
  return false; //No había datos disponibles
}

#endif

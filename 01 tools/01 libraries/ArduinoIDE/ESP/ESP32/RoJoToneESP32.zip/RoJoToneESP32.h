/*
  Nombre de la librería: RoJoToneESP32.h
  Versión: 20191004
  Autor: Ramón Junquera
  Descripción:
    Función tone para ESP32

    Las placas ESP32 no tienen implementada la función tone.
    Incluiremos esta funcionalidad con los mismos parámetros que en la 
    original de Arduino.
    Para asignar una frecuencia de pulso a un pin utilizaremos el método libc.
    Si se indica duración, utilizaremos la librería Ticker para crear un
    timer que se encargue de desactivar el tono finalizada la duración.
*/

//Comprobamos que la placa es compatible
#if !defined(ESP32)
  #error Library RoJoToneESP32 is only compatible with ESP32 family devices
#endif  

#ifndef RoJoToneESP32_h
#define RoJoToneESP32_h

#include <Arduino.h>
#include <Ticker.h> //Gestión de timers

struct _toneChannel { //Estructura de configuración de un canal
  byte pin=255; //Pin asociado al canal
  Ticker *timer=nullptr; //Puntero a timer de Ticker para gestionarla duración
};

static _toneChannel _toneChannels[16]; //Configuración de los canales

//Silenciar un pin
static void noTone(byte pin) {
  for(byte ch=0;ch<16;ch++) { //Recorremos todos los canales
    if(_toneChannels[ch].pin==pin) { //Si el canal actual tiene asociado el pin que buscamos...
      if(_toneChannels[ch].timer) { //Si tiene algún timer asociado...
        _toneChannels[ch].timer->detach(); //Desactivamos el timer
        delete _toneChannels[ch].timer; //Eliminamos el timer
        _toneChannels[ch].timer=nullptr; //Anotamos que ya no hay timer
      }
      ledcDetachPin(pin); //Pin desasignado de cualquier canal
      ledcWriteTone(ch,0); //Aplicamos frecuencia 0 al canal actual
      _toneChannels[ch].pin=255; //El canal actual ya no está en uso
      return; //No seguimos buscando
    }
  }
}

//Asigna una frecuencia a un pin
static void tone(byte pin, uint16_t frequency, uint32_t duration=0) {
  if(frequency==0) { //Si la frecuencia es nula...
    noTone(pin); //...es lo mismo que silenciar
    return; //Hemos terminado
  }
  for(byte ch=0;ch<16;ch++) { //Recorremos todos los canales
    if(_toneChannels[ch].pin==pin) { //Si el canal actual tiene asociado el pin que buscamos...
      if(_toneChannels[ch].timer) { //Si tiene algún timer asociado...
        _toneChannels[ch].timer->detach(); //Desactivamos el timer
        //Si tenemos duración...reaprovechamos el timer
        if(duration) _toneChannels[ch].timer->attach_ms(duration,noTone,pin);
        else { //Si no tenemos duración...
          delete _toneChannels[ch].timer; //Eliminamos el timer
          _toneChannels[ch].timer=nullptr; //Anotamos que ya no hay timer
        }
      } else { //Si no tiene un timer asociado...
        if(duration) { //Si tiene duración...
          _toneChannels[ch].timer=new Ticker; //Creamos un nuevo timer
          _toneChannels[ch].timer->attach_ms(duration,noTone,pin); //Lo activamos
        }
      }
      ledcWriteTone(ch,frequency); //Asignamos la frecuencia al canal del pin
      return; //Hemos terminado
    }
  }
  //Hemos recorrido todos los canales y ninguno tiene asociado el pin que buscamos
  //Tenemos que encontrar un canal libre para este pin
  for(byte ch=0;ch<16;ch++) { //Recorremos todos los canales
    if(ledcReadFreq(ch)==0.0) { //Si el canal actual no se está utilizando...
      ledcWriteTone(ch,frequency); //Asignamos frecuencia al canal
      ledcAttachPin(pin,ch); //Asignamos el pin al canal
      _toneChannels[ch].pin=pin; //Anotamos qué pin tiene asociado el canal
      if(duration) { //Si tenemos duración...
        _toneChannels[ch].timer=new Ticker; //Creamos un nuevo timer
        _toneChannels[ch].timer->attach_ms(duration,noTone,pin); //Lo activamos
      }
      return; //Hemos terminado
    }
  }
  //Hemos recorrido todos los canales y no encontramos ninguno libre
  //No podemos hacer nada más :-(
}

#endif
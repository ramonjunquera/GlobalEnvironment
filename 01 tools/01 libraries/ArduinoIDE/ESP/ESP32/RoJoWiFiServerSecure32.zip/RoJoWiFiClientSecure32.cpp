/*
  Nombre de la librería: RoJoWiFiServerSecure32.h
  Autor: Ramón Junquera
  Fecha: 20190506
  Descripción:
    Cliente seguro (SSL)
*/

//Impedimos que se defina los métodos más de una vez
#ifndef RoJoWiFiClientSecure32_CPP
#define RoJoWiFiClientSecure32_CPP

#include <RoJoWiFiClientSecure32.h>

void RoJoWiFiClientSecure32::stop()
{
  //Detiene la conexión
  
  //Si hay alguna conexión...
  if(_SSLconn!=NULL)
  {
    //...la paramos
    SSL_shutdown(_SSLconn);
    //Liberamos la conexión
    SSL_free(_SSLconn);
    //Cerramos el socket
    close(_fd);
    //Ya no tenemos conexión
    _SSLconn=NULL;
  } 
}

RoJoWiFiClientSecure32::RoJoWiFiClientSecure32(int fd,SSL_CTX *SSLcontext):_fd(fd)
{
  //Constructor para cliente con socket
  //Incluimos en la declaración guardar el parámtro del socket en la variable privada

  //Creamos una nueva conexión en el contexto SSL
  _SSLconn=SSL_new(SSLcontext);
  //Si no hemos podido crear la conexión...paramos
  if(_SSLconn==NULL) stop();
  else //Hemos podido crear la conexión...
  {
    //Relacionamos la conexión con la del cliente conectado
    SSL_set_fd(_SSLconn,fd);
    //Si no se acepta la conexión con el cliente...paramos
    if(!SSL_accept(_SSLconn)) stop();
  }
}

RoJoWiFiClientSecure32::~RoJoWiFiClientSecure32()
{
  //Destructor

  stop(); //Detenemos cualquier conexión abierta
}

bool RoJoWiFiClientSecure32::connected()
{
  //Tenemos conexión?
  return _SSLconn!=NULL;
}

int RoJoWiFiClientSecure32::read(byte *buf, size_t size)
{
  //Lee datos del buffer de entrada
  //Parámetros:
  //  - Puntero del buffer
  //  - Tamaño del buffer
  //Devuelve: -1=Error, >=0 = número de bytes leidos

  //Si no tenemos conexión...devolvemos error
  if (_SSLconn==NULL) return -1;
  //Tenemos conexión

  //Leemos el buffer de recepción completo
  //Obtenemos el número de bytes leidos y lo devolvemos
  return SSL_read(_SSLconn,buf,size);
}

String RoJoWiFiClientSecure32::readString()
{
  //Lee todo el texto recibido y lo devuelve en una cadena

  //Cadena de respuesta. Inicialmente vacía
  String answer="";

  //Si no tenemos conexión...devolvemos una cadena vacía
  if (_SSLconn==NULL) return answer;
  //Tenemos conexión

  //Si podemos leer un carácter...
  byte b;
  if(read(&b))
  {
    //...lo añadimos a la cadena
    answer=(char)b;
    //Obtenemos el número de bytes pendientes por leer
    int pendingBytes=available();
    //Si hay algo más que leer...
    if(pendingBytes>0)
    {
      //Creamos un array un byte mayor que el número de caracteres que vamos a leer
      //Este último byte contendrá un cero para marcar el final de cadena
      byte *buf=new byte[pendingBytes+1];
      //El último carácter es cero
      buf[pendingBytes]=0;
      //Leemos todos los datos pendientes
      SSL_read(_SSLconn,buf,pendingBytes);
      //Convertimos el array a String
      answer+=(char *)buf;
      //Liberamos el array
      delete[] buf;
    }
  }
  //Devolvemos la cadena
  return answer;
}

bool RoJoWiFiClientSecure32::read(byte *b)
{
  //Lee el siguiente byte del cliente
  //Devuelve true si lo consigue

  //Si no tenemos conexión...devolvemos error
  if (_SSLconn==NULL) return false;
  //Tenemos conexión

  //Solicitamos leer el siguiente byte
  //Si se ha podido leer algo...devolvemos true, sino false
  return SSL_read(_SSLconn,b,1)>0;
}

void RoJoWiFiClientSecure32::write(String s)
{
  //Envía una cadena al cliente

  //Si hay alguna conexión...enviamos el String
  //Previamente debemos transformarlo a formato C
  if(_SSLconn!=NULL) SSL_write(_SSLconn,s.c_str(),s.length());
}

int RoJoWiFiClientSecure32::available()
{
  //Devuelve el número de bytes pendientes de leer del buffer
  //Nota:
  //Podría ser que se se indique que no hay nada pendiente por leer, pero
  //que se haya recibido algo desde la última vez.
  //Este valor se refresca haciendo una lectura.

  return SSL_pending(_SSLconn);
}

#endif
/*
  Nombre de la librería: RoJoWiFiServerSecure32.h
  Autor: Ramón Junquera
  Fecha: 20190513
  Descripción:
    Cliente seguro (SSL)
*/

//Impedimos que se defina los métodos más de una vez
#ifndef RoJoWiFiClientSecure32_CPP
#define RoJoWiFiClientSecure32_CPP

#include <RoJoWiFiClientSecure32.h>

void RoJoWiFiClientSecure32::stop()
{
  //Detiene la conexión
  
  //Si hay alguna conexión...
  if(_SSLconn!=NULL)
  {
    //...la paramos
    SSL_shutdown(_SSLconn);
    //Liberamos la conexión
    SSL_free(_SSLconn);
    //Cerramos el socket
    close(_fd);
    //Ya no tenemos conexión
    _SSLconn=NULL;
  } 
}

RoJoWiFiClientSecure32::RoJoWiFiClientSecure32(int fd,SSL_CTX *SSLcontext):_fd(fd)
{
  //Constructor para cliente con socket
  //Incluimos en la declaración guardar el parámtro del socket en la variable privada

  //Creamos una nueva conexión en el contexto SSL
  _SSLconn=SSL_new(SSLcontext);
  //Si no hemos podido crear la conexión...paramos
  if(_SSLconn==NULL) stop();
  else //Hemos podido crear la conexión...
  {
    //Relacionamos la conexión con la del cliente conectado
    SSL_set_fd(_SSLconn,fd);
    //Si no se acepta la conexión con el cliente...paramos
    if(!SSL_accept(_SSLconn)) stop();
  }
}

RoJoWiFiClientSecure32::~RoJoWiFiClientSecure32()
{
  //Destructor

  stop(); //Detenemos cualquier conexión abierta
}

bool RoJoWiFiClientSecure32::connected()
{
  //Tenemos conexión?
  return _SSLconn!=NULL;
}

int RoJoWiFiClientSecure32::read(byte *buf, size_t size)
{
  //Lee datos del buffer de entrada
  //Parámetros:
  //  - Puntero del buffer
  //  - Tamaño del buffer
  //Devuelve: -1=Error, >=0 = número de bytes leidos

  //Si no tenemos conexión...devolvemos error
  if (_SSLconn==NULL) return -1;
  //Tenemos conexión

  //Leemos el buffer de recepción completo
  //Obtenemos el número de bytes leidos y lo devolvemos
  return SSL_read(_SSLconn,buf,size);
}

bool RoJoWiFiClientSecure32::read(byte *b)
{
  //Lee el siguiente byte del cliente
  //Devuelve true si lo consigue

  //Si no tenemos conexión...devolvemos error
  if (_SSLconn==NULL) return false;
  //Tenemos conexión

  //Solicitamos leer el siguiente byte
  //Si se ha podido leer algo...devolvemos true, sino false
  return SSL_read(_SSLconn,b,1)>0;
}

bool RoJoWiFiClientSecure32::readFindString(String findText,String endText)
{
  //Lee caracteres hasta encontrar una cadena, detectar
  //la cadena endText o haber leido todos los caracteres pendientes.
  //El parámetro endText es optativo.
  //La longitud de los parámetros findText y endText puede ser distinta.
  //Devuelve true si ha encontrado la cadena

  //Buffer de texto recibido
  String buffer="";
  //Calculamos el tamaño del buffer
  byte bufferLen=findText.length();
  if(endText.length()>bufferLen) bufferLen=endText.length();

  //Inicializamos el buffer a su tamaño correcto
  for(byte c=0;c<bufferLen;c++) buffer+="@";
  //Carácter recibido
  byte c;
  //Mientras recibamos caracteres...
  while(read(&c))
  {
    //Añadimos el carácter recibido al final del buffer
    buffer=buffer.substring(1)+(char)c;

    //Si el final del buffer coincide con la cadena que estamos buscando...lo hemos encontrado!
    if(buffer.substring(bufferLen-findText.length())==findText) return true;
    //Si tenemos cadena de fin...
    if(endText.length())
    {
      //Si el final del buffer coincide con la cadena de fin...
      //...no lo hemos encontrado
      if(buffer.substring(bufferLen-endText.length())==endText) return false;
    }
  }
  //Hemos terminado de leer todos los caracteres y no hemos encontrado
  //la cadena que buscábamos
  return false;
}

String RoJoWiFiClientSecure32::readString(String endText)
{
  //Devuelve el texto recibido hasta encontrar la cadena de marca de fin.
  //Si no encuentra la marca de fin, devuelve todo una cadena vacía.
  
  //Variable en la que guardaremos la respuesta
  String answer="";

  //Carácter recibido
  byte c;
  //Mientras recibamos caracteres...
  while(read(&c))
  {
    //Leemos el siguiente carácter y lo añadimos a la respuesta
    //Añadimos el carácter recibido a la respuesta
    answer+=(char)c;
    //Si el final de la cadena coincide con la marca de fin...
    if(answer.substring(answer.length()-endText.length())==endText)
    {
        //...devolvemos la respuesta sin incluir la marca de fin
      return answer.substring(0,answer.length()-endText.length());
    }
  }
  //Ya no hay más caracteres que leer y no hemos encontrado la
  //marca de fin. Devolvemos cadena vacía
  return "";
}

String RoJoWiFiClientSecure32::readInt()
{
  //Parsea caracteres numéricos
  //Se detiene cuando encuentra un carácter no numérico
  
  //Variable en la que guardaremos la respuesta
  String answer="";
  //Carácter leido
  byte c;
  //Mientras recibamos caracteres...
  while(read(&c))
  {
    //Si es un carácter numérico...lo tomamos como correcto lo añadimos a la respuesta
    if(c>='0' && c<='9') answer+=(char)c;
    //Si no es un carácter numérico...devolvemos el resultado
    else return answer;
  }
  //Hemos terminado de leer todos los caracteres.
  //Devolvemos lo que hayamos podido encontrar
  return answer;
}

void RoJoWiFiClientSecure32::write(String s)
{
  //Envía una cadena al cliente

  //Si hay alguna conexión...enviamos el String
  //Previamente debemos transformarlo a formato C
  if(_SSLconn!=NULL) SSL_write(_SSLconn,s.c_str(),s.length());
}

int RoJoWiFiClientSecure32::available()
{
  //Devuelve el número de bytes pendientes de leer del buffer
  //Nota:
  //Podría ser que se se indique que no hay nada pendiente por leer, pero
  //que se haya recibido algo desde la última vez.
  //Este valor se refresca haciendo una lectura.

  return SSL_pending(_SSLconn);
}

#endif
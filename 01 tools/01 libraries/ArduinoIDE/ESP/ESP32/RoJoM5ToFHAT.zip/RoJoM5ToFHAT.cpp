/*
  Nombre de la librería: RoJoM5ToFHAT.h
  Versión: 20201102
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del HAT ToF para M5Stick C
*/

#ifndef RoJoM5ToFHAT_cpp
#define RoJoM5ToFHAT_cpp

#include <RoJoM5ToFHAT.h>

//Inicialización
//Devuelve true si lo consigue
bool RoJoM5ToFHAT::begin() {
  //Inicialización de I2C en bus 1
  //Pines: 0=SDA,26=SCL,freq=400KHz
  Wire1.begin(0,26,400000);
  //Comprobamos si el HAT está conectado
  Wire1.beginTransmission(_idI2C); //Abrimos comunicación
  byte error=Wire1.endTransmission(); //Sin enviar nada, cerramos comunicación y anotamos la respuesta

  if(error) return false; //Si hay errores...terminamos
  //No hay errores
  _init=true; //Inicializado correctamente
  return true; //Todo OK
}

//Obtener distancia en milímetros
//Si no lo consigue, devuelve 0
uint16_t RoJoM5ToFHAT::get() {
  if(!_init) return 0; //Si no ha sido inicializado...terminamos
  Wire1.beginTransmission(_idI2C);
    Wire1.write(0x00); //Comando de solicitud de pulso VL53L0X_REG_SYSRANGE_START
    Wire1.write(0x01);
  Wire1.endTransmission();
  
  Wire1.beginTransmission(_idI2C);
    Wire1.write(0x14); //Solicitud de datos de distancia VL53L0X_REG_RESULT_RANGE_STATUS
  Wire1.endTransmission();

  byte buffer[12];
  Wire1.requestFrom(_idI2C,(byte)12); //Queremos leer 12 bytes
  Wire1.readBytes(buffer,(byte)12); //Leemos 12 bytes
  
  uint16_t d=buffer[10]<<8 | buffer[11]; //Leemos distancia de los últimos bytes
  //Si la distancia leida es válida...la devolvemos
  if((d>20 && d<=500 && buffer[6]>0) || (d>500 && d<=1400 && buffer[9]<90) || (d>1400 && d<=3000 && buffer[7]>20)) return d;
  return 0; //La distancia leida no es válida
}

#endif

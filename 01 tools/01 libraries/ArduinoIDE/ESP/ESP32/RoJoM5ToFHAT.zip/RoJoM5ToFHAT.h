/*
  Nombre de la librería: RoJoM5ToFHAT.h
  Versión: 20201102
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión del HAT ToF para M5Stick C
*/

#ifndef RoJoM5ToFHAT_h
#define RoJoM5ToFHAT_h

#include <Arduino.h>
#include <Wire.h>

class RoJoM5ToFHAT {
  private:
    const byte _idI2C=0x29; //Identificador del dispositivo en bus I2C
    bool _init=false; //Ha sido inicializado?
  public:
    bool begin(); //Inicialización
    uint16_t get(); //Obtener distancia
};

#endif

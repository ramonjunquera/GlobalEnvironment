﻿/*
  Nombre de la librería: RoJoTelegramBot.h
  Versión: 20180316
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión de bots de Telegram para ESP
*/

#ifndef RoJoTelegramBot_h
#define RoJoTelegramBot_h

//Comprobamos que la placa es compatible
#if !defined(ESP32) && !defined(ESP8266)
  #error Library RoJoSSD1331 is only compatible with ESP32 & ESP8266 family devices
#endif  

#include <Arduino.h>
#include <WiFiClientSecure.h> //Librería para gestión de conexiones https

struct TelegramMessage
{
  String update_id="";
  String message_id="";
  String from_id="";
  String from_name="";
  String chat_id="";
  String date="";
  String text="";
};

class RoJoTelegramBot
{
  private:
    String _botToken; //Token del bot
    const String _telegramHost="api.telegram.org"; //Host de Telegram
    const uint16_t _telegramPort=443; //Puerto de Telegram (https)
    String _lastUpdateId=""; //Identificador del último mensaje recibido
    String _actionCodes[9]={"typing","upload_photo","record_video","record_audio","upload_audio","upload_document","find_location","record_video_note","upload_video_note"};
    String _clienParseInt(WiFiClientSecure *client,uint16_t timeOut);
    bool _clientFindString(WiFiClientSecure *client,uint16_t timeOut,String findText,String endText="");
    String _clientReadString(WiFiClientSecure *client,uint16_t timeOut,String border);
    String _clientFieldInt(WiFiClientSecure *client,uint16_t timeOut,String fieldName,String endText="");
    String _clientFieldString(WiFiClientSecure *client,uint16_t timeOut,String fieldName,String endText="");
  public:
    void begin(String botToken); //Inicializa el la clase
    TelegramMessage getNextMessage(); //Obtiene el siguiente mensaje
    bool sendMessage(String chat_id,String text,String keyboard="",bool resize=false,bool oneTime=false); //Envía un mensaje a un chat
    String sendPhotoRemote(String chat_id,String photo,String caption = "",bool disable_notification = false,String reply_to_message_id = "0");
    String sendPhotoLocal(String chat_id,String fileName); //Envía una imagen local
    bool sendChatAction(String chat_id,byte actionCode); //Envía un mensaje de acción
};

#endif

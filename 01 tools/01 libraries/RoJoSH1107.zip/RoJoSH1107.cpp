/*
  Nombre de la librería: RoJoSH1107.h
  Versión: 20190829
  Autor: Ramón Junquera
  Descripción:
    Gestión de display SH1107 SPI 64x128

  Notas:
  - La versión que contiene el M5 Watch no permite leer el contenido de
    la memoria de vídeo a través de SPI
*/

#ifndef RoJoSH1107_cpp
#define RoJoSH1107_cpp

#include <RoJoSH1107.h>

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoSH1107::_writeCommand(byte command,...) {
  //Este display recibe tanto los comandos como los parámetros en modo comandos
  //y en formato de byte

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer(command); //Enviamos el comando
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0) {
    SPI.transfer(paramValue); //...enviamos el parámetro
  }
  va_end(paramList); //Hemos terminado de trabajar con la lista
  digitalWrite(_pinDC,HIGH); //Modo datos
}

// Activa/Desactiva el modo hibernación
void RoJoSH1107::sleep(bool mode) {
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  //DEBG. Comprobar
  _startCOMM();
    _writeCommand(mode?0xAE:0xAF,-1); //0xAE=display OFF,0xAF=display ON
  _endCOMM();
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
//Este display no permite la definición de rangos, sólo de origen de escritura.
//Las coordenadas verticales no son pixels, sino páginas, puesto que es monocromo.
void RoJoSH1107::_setCursorRangeY(int16_t y1) {
  _writeCommand(0xB0 | (y1 & 0x0F),-1);
}
void RoJoSH1107::_setCursorRangeX(int16_t x1) {
  _writeCommand(0x10 | ((x1>>4) & 0x07),x1 & 0x0F,-1);
}
void RoJoSH1107::_setCursorRange(int16_t x1,int16_t y1) {
  //Combinamos _setCursorRangeY y _setCursorRangeX en un sólo comando para agilizarlo
  _writeCommand(0xB0 | (y1 & 0x0F),0x10 | ((x1>>4) & 0x07),x1 & 0x0F,-1);
}

//Anchura de display
uint16_t RoJoSH1107::xMax() {
  return _xMax;
}

//Altura de display
uint16_t RoJoSH1107::yMax() {
  return _yMax;
}

//Reset & inicialización
void RoJoSH1107::reset() {
  //Hard reset
  digitalWrite(_pinRES,LOW);
  delay(20);
  digitalWrite(_pinRES,HIGH);
  delay(100);
  //Comenzamos una transacción
  _startCOMM();
    _writeCommand(0xDC,0x00,-1); //start line = 0, no scrolling
    _writeCommand(0x20,-1); //set memory addressing mode:page addressing mode, up to down
    _writeCommand(0xA0,-1); //set segment remap, left to right
    _writeCommand(0xA4,-1); //set entire display on: A4:OFF/A5:ON
    _writeCommand(0xA8,0x3F,-1); //set multiplex ratio : Sólo tenemos 64 columnas
    _writeCommand(0xC0,-1); //set common output scan direction, c0: normal, c8: reverse
    _writeCommand(0xD3,0x60,-1); //set display offset
    _writeCommand(0xD5,0x51,-1); //set display clock divide ratio/oscillator frequency 105Hz
    _writeCommand(0xD9,0x22,-1); //Dis-charge /Pre-charge Period Mode Set
    _writeCommand(0xDB,0x35,-1); //vcomh deselect level mode set
    _writeCommand(0xB0,-1); //set page address
  _endCOMM();
  //Modo normal (no invertido)
  reverse(false);
  //Fijamos contraste por defecto
  setContrast(47);
  //Borramos el display
  clear();
  //Salimos del modo de bajo consumo
  sleep(false);
}

//Fija el contraste
void RoJoSH1107::setContrast(byte level) {
  _startCOMM();
    _writeCommand(0x81,level,-1);
  _endCOMM();
}

//Borra el área de dibujo
//El color puede ser 0=negro o cualquier otro valor=blanco
void RoJoSH1107::clear(uint16_t color) {
  //Este display no permite rellenar áreas (comando block)
  //Rellenaremos toda la memoria gráfica del color indicado
  //recorriendo todas las páginas y columnas

  //Nos aseguramos que cualquier otro corresponde con el valor de página 0xFF
  if(color) color=0xFF;
  //Recorremos todas las páginas
  for(byte page=0;page<16;page++) {
    _startCOMM();
      //Fijamos como inicio la primera columna de la página actual
      //Los valores de fin de rango no se tienen en cuenta
      _setCursorRange(0,page);
      //Enviamos tantos ceros como columnas
      for(byte x=0;x<64;x++) SPI.transfer(color);
    _endCOMM();
  }
}

//Display con colores invertidos blanco <-> negro
void RoJoSH1107::reverse(bool mode) {
  //mode == true  : ON=white, OFF=black
  //mode == false : ON=black, OFF=white
  _startCOMM();
    _writeCommand(mode?0xA7:0xA6,-1);
  _endCOMM();
}

// Inicia comunicación
void RoJoSH1107::_startCOMM() {
  SPI.beginTransaction(_spiSetting);
  digitalWrite(_pinCS,LOW);
}

// Finaliza comunicación
void RoJoSH1107::_endCOMM() {
  digitalWrite(_pinCS,HIGH);
  SPI.endTransaction();
}

//Inicialización
void RoJoSH1107::begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM) {
  //Este display tiene una profundidad de color de 1 bit (monocromo)
  _colorDepth=1;
  //Si no se ha indicado frecuencia...utilizaremos la máxima
  if(!freqCOMM) freqCOMM=79999999; //<80 MHz
  //Definimos las caraterísticas de la conexión SPI
  _spiSetting=SPISettings(freqCOMM,MSBFIRST,SPI_MODE0);
  //Inicializamos las conexiones SPI
  SPI.begin();
  //No se controlará el estado del pin CS por hardware. Lo haremos nosotros
  //Esto nos permite compartir el bus SPI con distintos dispositivos
  //En placas Arduino no es posible desactivar el pin CS por defecto
  #ifndef ARDUINO_ARCH_AVR //Si no es un Arduino...
    SPI.setHwCs(false);
  #endif

  //Guardamos los parámetros en variables internas
  _pinDC=pinDC;
  _pinRES=pinRES;
  _pinCS=pinCS;
  //Siempre escribiremos en los pines DC, RES y CS
  pinMode(_pinDC,OUTPUT);
  pinMode(_pinRES,OUTPUT);
  pinMode(_pinCS,OUTPUT);
  //Inicializamos el estado de los pines
  digitalWrite(_pinRES,HIGH); //Comenzamos sin reiniciar el display
  digitalWrite(_pinDC,HIGH); //Comenzamos enviando datos
  digitalWrite(_pinCS,HIGH); //Comenzamos sin seleccionar el chip
  //Reseteamos el display
  reset();
  //Llamamos a la inicialización de la clase padre
  RoJoGraph::begin(); //Principalmente inicializa SPIFFS
}

//Envía un sprite al display comenzando en el origen
//La coordenada vertical 'y' debe ser múltiplo de 8
//Devuelve true si se muestra algo
bool RoJoSH1107::drawSprite(RoJoSprite *sprite,int16_t x,int16_t y) {
  //Si el sprite no es monocromo...terminamos con error
  if(sprite->colorDepth()!=1) return false;
  //Si la coordenada vertical no es múltiplo de 8...terminamos con error
  if(y%8) return false;
  //Calculamos el área visible
  displayRange r=visibleRange(x,y,sprite->xMax(),sprite->yMax());
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  //Convertimos los valores verticales a páginas
  y/=8; r.y1/=8; r.y2/=8;
  
  _startCOMM();
    //Variables para optimizar el bucle
    int16_t ry2=r.y2,rx2=r.x2,offsetY;
    //Recorremos todas las páginas visibles del display
    for(int16_t dy=(int16_t)r.y1;dy<=ry2;dy++) {
      //Calculamos el offset de fila
      offsetY=dy-y;
      //Definimos el rango del cursor
      _setCursorRange(r.x1,dy);
      //Recorremos todas las columnas visibles del sprite y enviamos el valor de la página
      for(int16_t dx=(int16_t)r.x1;dx<=rx2;dx++) SPI.transfer(sprite->getPage(dx-x,offsetY));
    }
  _endCOMM();
  //Todo Ok
  return true;
}

//Sincroniza dos sprites y envía las diferencias al display.
//Los sprites deben tener el mismo tamaño
//Respuesta: true si todo es correcto
bool RoJoSH1107::drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x,int16_t y) {
  //Se detectan las diferencias entre los dos sprites y se escriben sobre el sprite destino
  //y se envían al display.
  //Finalmente el sprite destino queda igual que el origen.

  //Nota. El offset vertical (y) debe ser múltiplo de 8 para poder enviar las páginas completas

  //Anotamos las medidas del sprite origen
  int16_t xMaxSprite=source->xMax();
  int16_t yMaxSprite=source->yMax();
  //Si los sprites tienen distinto tamaño...terminamos con error
  if(xMaxSprite!=(int16_t)destination->xMax() || yMaxSprite!=(int16_t)destination->yMax()) return false;
  //Si alguno de los sprites no es monocromo...terminamos con error
  if(source->colorDepth()!=1 || destination->colorDepth()!=1) return false;
  //Si 'y' no es múltiplo de 8...terminamos con error
  if((y%8)>0) return false;
  //Comprobamos si tiene parte visible
  displayRange r=visibleRange(x,y,xMaxSprite,yMaxSprite);
  //Si no es visible...terminamos correctamente
  if(!r.visible) return true;
  //El sprite es total o parcialmente visible
  //En el display se dibujará el sprite en el rango: r.x1,r.y1,r.x2,r.y2
  //Se mostrará el siguiente rango del sprite: r.x1-x,r.y1-y,r.x2-x,r.y2-y
  //Es más sencillo recorrer las filas y columnas del sprite y si se detectan
  //diferencias, hacer la conversión a coordenadas de display
  
  //En sprites monocromos la medida vertical es la página, no el pixel
  //Recalculamos todas las medidas verticales a páginas
  y/=8;
  r.y1/=8;
  r.y2/=8;
  //Calculamos la última página y columna a procesar en el sprite
  //Reaprovechamos variables
  xMaxSprite=r.x2-x;
  yMaxSprite=r.y2-y;

  bool selectedRangeY; //Se ha seleccionado el rango vertical con la fila procesada?
  int16_t xSprite; //Columna procesada. Coordenada x del sprite
  _startCOMM();
    //Recorremos todas las páfinas visibles del sprite
    for(int16_t ySprite=r.y1-y;ySprite<=yMaxSprite;ySprite++) {
      //Por ahora no se ha inicializado el rango vertical para la página actual
      selectedRangeY=false;
      //Comenzamos por la primera columna
      xSprite=r.x1-x;
      //Mientras no hayamos procesado todas las columnas...
      while(xSprite<=xMaxSprite) {
        //Si el valor de la página actual no se ha modificado...
        if(source->getPage(xSprite,ySprite)==destination->getPage(xSprite,ySprite)) {
          //...no tenemos en cuenta este valor de página. Pasaremos al siguiente
          xSprite++;
        }
        else { //El pixel actual ha sido modificado...
          //Si no se ha seleccionado la página actual...
          if(!selectedRangeY) {
            //...lo hacemos ahora. Convertimos a coordenadas de display
            _setCursorRangeY(y+ySprite);
            //y lo anotamos
            selectedRangeY=true;
          }
          //Consideramos este valor de página como procesado
          //Actualizamos su valor en el sprite destino
          destination->drawPage(xSprite,ySprite,source->getPage(xSprite,ySprite),4);
          //Por ahora la última columna modificada es la primera
          int16_t lastChangedColumn=xSprite;
          //Columna procesada = la siguiente a la primera
          int16_t processedColumn=xSprite+1;
          //Mientras llevemos menos de 5 pixels sin modificar...
          while(processedColumn-lastChangedColumn<=5) {
            //Si el valor de la página de la columna procesada ha cambiado...
            if(source->getPage(processedColumn,ySprite)!=destination->getPage(processedColumn,ySprite)) {
              //...anotamos que la última columna con cambios es la actual
              lastChangedColumn=processedColumn;
              //Consideramos este valor de página como procesado
              //Actualizamos su valor en el sprite destino
              destination->drawPage(processedColumn,ySprite,source->getPage(processedColumn,ySprite),4);
            }
            //Aumentamos la posición de la columna procesada
            processedColumn++;
          } //end while
          //Seleccionamos como rango horizontal desde la columna actual hasta la última modificada
          //Convertimos a coordenadas de display
          _setCursorRangeX(x+xSprite);
          //Enviamos los datos gráficos
          for(int16_t x0=xSprite;x0<=lastChangedColumn;x0++) SPI.transfer(source->getPage(x0,ySprite));
          //La primera columna pasará a ser la actual
          xSprite=processedColumn;
        }
      }
    }
  _endCOMM();
  
  //Todo Ok
  return true;
}

#endif

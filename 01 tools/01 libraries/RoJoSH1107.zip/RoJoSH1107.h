/*
  Nombre de la librería: RoJoSH1107.h
  Versión: 20190829
  Autor: Ramón Junquera
  Descripción:
    Gestión de display SH1107 SPI 64x128

  Notas:
  - La versión que contiene el M5 Watch no permite leer el contenido de
    la memoria de vídeo a través de SPI
*/

#ifndef RoJoSH1107_h
#define RoJoSH1107_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoGraph.h> //Gestión de gráficos avanzados

class RoJoSH1107:public RoJoGraph
{
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    void _setCursorRangeX(int16_t x1); //Define rango X
    void _setCursorRangeY(int16_t y1); //Define rango Y
    void _setCursorRange(int16_t x1,int16_t y1); //Define  rango X & Y
    const byte _xMax=64; //Anchura en pixels
    const byte _yMax=128; //Altura en pixels
    const byte _pageMax=_yMax/8; //Altura en páginas
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _startCOMM(); //Inicia comunicación
    void _endCOMM(); //Finaliza comunicación
    SPISettings _spiSetting; //Características de la conexión SPI
  public:
    void sleep(bool mode); //Activa/Desactiva el modo hibernación
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void reset(); //Reset
    void clear(uint16_t color=0); //Borra el área de dibujo
    bool drawSprite(RoJoSprite *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    bool drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x=0,int16_t y=0); //Sincroniza dos sprites y envía las diferencias al display
    void reverse(bool mode); //Display con colores invertidos blanco <-> negro
    void begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM=0); //Inicialización
	void setContrast(byte level); //Fija el contraste
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoSH1107.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


/*
  Nombre de la librería: RoJoMAX7219.h
  Versión: 20180604
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a matrices de leds.
*/

#ifndef RoJoMAX7219d_cpp
#define RoJoMAX7219d_cpp


#include <Arduino.h>
#include "RoJoMAX7219d.h"

void RoJoMAX7219d::_localCommand(byte command, byte value)
{
  //Envía una instrucción
  shiftOut(_pinDIN_display,_pinCLK_display,MSBFIRST,command);
  shiftOut(_pinDIN_display,_pinCLK_display,MSBFIRST,value);
}

void RoJoMAX7219d::_globalCommand(byte command, byte value)
{
  //Envía una instrucción a todos los chips
  
  //Antes de enviar una instrucción, siempre desactivamos el pin CS
  digitalWrite(_pinCS_display,LOW);
  //Recorremos todos los chips y enviamos la instrucción
  for(byte chip=0;chip<_chainedChips;chip++) _localCommand(command,value);
  //Fin de envío
  digitalWrite(_pinCS_display,HIGH);
}

void RoJoMAX7219d::setBrightness(byte brightness)
{
  //Fija el brillo de los leds
  //El rango de valores permitidos está entre 0 y 15
  //Se podría fijar distinto brillo a cada chip. No lo haremos
  //Asignaremos el mismo a todos
  _globalCommand(0x0A,brightness & 15); //max7219_reg_intensity
}

void RoJoMAX7219d::clear()
{
  //Vacía la memoria de vÃ­deo

  //Recorremos todas las columnas...y las vaciamos
  for(byte x=0;x<_chainedChips*8;x++) videoMem[x]=0;
}

void RoJoMAX7219d::show()
{
  //Envía la memoria de vídeo a la cadena de chips
  
  //Recorreremos todas las columnas que gestiona un chip
  for(byte x=0;x<8;x++)
  {
    //Antes de enviar una serie de instrucciones, siempre desactivamos el pin CS
    digitalWrite(_pinCS_display,LOW);
    //Recorreremos todos los chips
    //Recordemos que la primera instrucción enviada corresponderá al chip con número de
    //secuencia más alto y la última instrucción afectará al chip 0
    for(byte chip=_chainedChips-1;chip!=255;chip--)
    {
      //El comando corresponde con el número de columna + 1
      //Y el valor con el byte de la columna que corresponde en la memoria de vídeo
      _localCommand(x+1,videoMem[chip*8+x]);
    }
    //Fn de envío
    digitalWrite(_pinCS_display,HIGH);
  }
}

void RoJoMAX7219d::begin(byte chainedChips,byte pinDIN_display,byte pinCS_display,byte pinCLK_display)
{
  //Inicialización
  
  //Guardamos los valores de los parámetros en las variables privadas
  _chainedChips=chainedChips;
  _pinDIN_display=pinDIN_display;
  _pinCS_display=pinCS_display;
  _pinCLK_display=pinCLK_display;
  //Definimos los pines de conexión como de salida
  pinMode(_pinDIN_display,OUTPUT);
  pinMode(_pinCS_display,OUTPUT);
  pinMode(_pinCLK_display,OUTPUT);
  //Activamos el pin del reloj
  digitalWrite(_pinCLK_display,HIGH);

  //Desconocido!
  _globalCommand(0x0B,0x07); //max7219_reg_scanLimit
  //Utilizaremos matrices de leds, no displays de dígitos  
  _globalCommand(0x09,0x00); //max7219_reg_decodeMode
  //Salimos del modo shutdown en el que se encuentran al arrancar. Los activamos!  
  _globalCommand(0x0C,0x01); //max7219_reg_shutdown
  //No hace falta hacer el test de display (encender todos los leds) 
  _globalCommand(0x0F,0x00); //max7219_reg_displayTest
  //Fijamos el brillo por defecto a 8
  setBrightness(8);
  //Reservamos memoria suficiente para todos los chips
  videoMem = new byte[_chainedChips*8];
  //Borramos la memoria de vídeo
  clear();
  //Pasamos la memoria de vídeo a la cadena de chips
  show();
}

RoJoMAX7219d::~RoJoMAX7219d()
{
  //Destructor

  //Borramos el sprite con la memoria de vídeo
  delete videoMem;
}

void RoJoMAX7219d::print(int16_t x,byte charCode,bool dot)
{
  //Muestra un carácter (digit display)

  //Si no es visible...hemos terminado
  if(x>=_chainedChips*8) return;
  //Escribimos el caracter
  videoMem[x]=_chars[charCode] | dot;
}

void RoJoMAX7219d::printInt(int64_t number,byte startPos,byte digits,bool leftZeros)
{
  //Muestra un número entero en el display
  
  //Si la longitud es cero...hemos terminado
  if(!digits) return;

  //Si el número es negativo...
  if(number<0)
  {
    //El primer carácter es un menos
    print(startPos,17,false);
    //Ahora mostraremos un número positivo
    number=-number;
    //Comenzaremos en la siguiente posición
    startPos++;
    //Tendremos un dígito menos
    digits--;
  }
  //Definimos variable que contendrá el código de carácter
  byte charCode;
  //Recorremos todos los dígitos
  for(byte d=digits;d>0;d--)
  {
    //Obtenemos el código del carácter a mostrar (unidades)
    charCode=number%10;
    //Si lo que queda del número es cero...
    //...y no se deben mostrar...
    //...y no es el primer dígito escrito...
    //...el carácter a mostrar será un espacio
    if(!number && !leftZeros && digits!=d) charCode=16;
    //Mostramos el dígito de unidades sin punto
    print(startPos+d-1,charCode,false);
    //Eliminamos las unidades
    number/=10;
  }
}

void RoJoMAX7219d::printDec(double number,byte startPos,byte intDigits,byte fracDigits,bool leftZeros)
{
  //Muestra un número decimal en el display
  //Se indican como parámetros el valor a mostrar, el número de digitos enteros (signo incluido),
  //el número de dígitos decimales y si se debe rellenar las posiciones iniciales con ceros

  //La parte entera es cero?
  bool intZero=((int64_t)number)==0;
  //Pasamos a la parte entera tantos decimales como nos indiquen
  for(byte i=0;i<fracDigits;i++) number*=10;
  //Escribimos el número entero con signo incluido
  printInt((int64_t)number,startPos,intDigits+fracDigits,leftZeros);
  //Si la cifra de las unidades es visible...
  if(startPos+intDigits-1<_chainedChips*8)
  {
    //Si no hay que poner ceros a la izquierda...
    //...y la parte entera era cero...
    if(!leftZeros && intZero)
    {
      //...escribimos un cero como cifra de unidades
      videoMem[startPos+intDigits-1]=_chars[0];
    }
    //Activamos el punto en las unidades
    videoMem[startPos+intDigits-1]++;
  }
}

#endif

﻿/*
  Nombre de la librería: RoJoMAX7219.h
  Versión: 20180310
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a matrices de leds.
*/

#ifndef RoJoMAX7219d_h
#define RoJoMAX7219d_h

#include <Arduino.h>

class RoJoMAX7219d
{
  private:
    byte _pinDIN_display;
    byte _pinCS_display;
    byte _pinCLK_display;
    byte _chainedChips; //Número de chips MAX7219 encadenados
    void _localCommand(byte command, byte value); //Envía un único comando
    void _globalCommand(byte command, byte value); //Envía un comando a todos los chips
    //Definición de los caracteres que se pueden mostrar en display de dígitos
    //Formato de bits abcdefgh
    const byte _chars[19]= 
    { 
      0b11111100 // 0 = 0
     ,0b01100000 // 1 = 1
     ,0b11011010 // 2 = 2
     ,0b11110010 // 3 = 3
     ,0b01100110 // 4 = 4
     ,0b10110110 // 5 = 5
     ,0b10111110 // 6 = 6
     ,0b11100100 // 7 = 7
     ,0b11111110 // 8 = 8
     ,0b11110110 // 9 = 9
     ,0b11101110 //10 = A
     ,0b00111110 //11 = b
     ,0b10011100 //12 = C
     ,0b01111010 //13 = d
     ,0b10011110 //14 = E
     ,0b10001110 //15 = F
     ,0b00000000 //16 = space
     ,0b00000010 //17 = -
     ,0b11000110 //18 = º
    };
  public:
    ~RoJoMAX7219d(); //Destructor
    byte *videoMem; //Memoria de vídeo
    void begin(byte chainedChips,byte pinDIN, byte pinCS, byte pinCLK, byte pinCS_SD=SS);
    void setBrightness(byte brightness); //Fija el brillo de los leds
    void clear(); //Limpia la memoria de vídeo
    void show(); //Envía memoria de vídeo a la cadena de chips
    void print(int16_t x,byte charCode,bool dot); //Muestra un carácter (digit display)
    void printInt(int64_t number,byte startPos,byte digits,bool leftZeros); //Muestra un entero (digit display)
    void printDec(double number,byte startPos,byte intDigits,byte fracDigits,bool leftZeros); //Muestra un decimal (digit display)
}; //Punto y coma obligatorio para que no de error

#endif


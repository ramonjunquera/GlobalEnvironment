/*
 * Autor: Ramón Junquera
 * Fecha: 20201111
 * Tema: Gestión de redes neuronales
 */

#ifndef RoJoNeuralNetwork_h
#define RoJoNeuralNetwork_h

#include <Arduino.h>
#include <RoJoFloatMatrix.h> //Gestión de matrices

const byte indexActFmax=3; //Máximo índice de la función de activación
//El índice de la función de activación es:
//  0 : Función personalizada. Es necesario definirla manualmente
//  1 : Función sigmoidea
//  2 : Función ReLU
//  3 : Función lineal

const byte indexCostFmax=1; //Máximo índice de la función de coste
//El índice de la función de coste es:
//  0 : Función personalizada. Es necesario definirla manualmente
//  1 : Función de error cuadrático

//Definición de algunas funciones de activación
float sigmoidF(float x); //Sigmoidea
float sigmoidD(float x); //Derivada de sigmoidea
float reluF(float x); //ReLU
float reluD(float x); //Derivada de ReLU
float lineF(float x); //Función lineal
float lineD(float x); //Derivada de función lineal


//Definición de función de error cuadrático para función de coste
float cuadErrorF(float valueRight,float valueGot); //Función
float cuadErrorD(float valueRight,float valueGot); //Derivada

//Gestión de capas de red neuronal
class RoJoNeuralLayer {
  public:
    float (*_actF)(float); //Puntero de función de activación
    float (*_actFD)(float); //Puntero de derivada de función de activación
    byte _indexActF=0; //Índice de la función de activación
    RoJoFloatMatrix _W; //Coeficientes
    RoJoFloatMatrix _b; //BIAS (término independiente)
    uint16_t inNodes=0; //Número de nodos de entrada
    uint16_t outNodes=0; //Número de nodos de salida/internos
    bool fillRand(float minValue=-1,float maxValue=1); //Llena con aleatorios
    bool begin(uint16_t inNodes,uint16_t outNodes,float minValue=-1,float maxValue=1); //Init
    void end();
    ~RoJoNeuralLayer(); //Destructor
    RoJoFloatMatrix *inValues; //Valores de entrada
    RoJoFloatMatrix outValues; //Valores de salida (aplicada función de activación)
    RoJoFloatMatrix sumW; //Resultados de suma ponderada (weighted sum)
    bool calc(); //Calcula valores de salida
    RoJoFloatMatrix delta;
    bool setIndexActF(byte indexActF); //Define índice de función de activación
    void setIndexActF(float (*actF)(float),float (*actFD)(float)); //Define actF
    bool save(String filename); //Guarda la capa en archivos
};

//Gestión de red neuronal
class RoJoNeuralNetwork {
  protected:
    uint16_t _layersCount=0; //Número de capas (incluida la de entrada)
    RoJoNeuralLayer* *_layers; //Puntero a array de punteros de objetos capa
    float _lr; //learning rate (ratio de aprendizaje)
    float (*_costF)(float,float); //Puntero de función de coste
    float (*_costFD)(float,float); //Puntero de derivada de función de coste
    byte _indexCostF=0; //Índice de la función de coste
    RoJoFloatMatrix _inValues; //Matriz de valores de entrada de primera capa
  public:
    void end();
    ~RoJoNeuralNetwork(); //Destructor
    bool setActF2Layer(uint16_t layerIndex,byte indexActF);
    bool setActF2Layer(uint16_t layerIndex,float (*actF)(float),float (*actFD)(float));
    bool begin(uint16_t hideLayersCount,uint16_t *arrayNodesCount,byte indexActF=1,byte indexCostF=1,float lr=0.05,float minValue=-1,float maxValue=1); //Init
    bool calc(RoJoFloatMatrix *inValues,RoJoFloatMatrix *outValues,bool smallMem=true); //Calcula valores de salida
    bool train(RoJoFloatMatrix *inValues,RoJoFloatMatrix *rightValues,RoJoFloatMatrix *outValues); //Entrenamiento
    bool trainRight(RoJoFloatMatrix *rightValues); //Entrenamiento con valores correctos
    bool trainCostFD(RoJoFloatMatrix *costValues); //Entrenamiento con derivada de matriz de coste
    bool cost(RoJoFloatMatrix *outValues,RoJoFloatMatrix *rightValues,RoJoFloatMatrix *meanCost); //Calcula error
    bool mesh(RoJoFloatMatrix *cXb,RoJoFloatMatrix *cYb,RoJoFloatMatrix *Vb); //Calculamos los valores de mesh
    void setCostF(float (*costF)(float,float),float (*costFD)(float,float));
    bool fillRand(uint16_t layerIndex,float minValue=-1,float maxValue=1); //Llena una capa con valores aleatorios
    bool save(String filename); //Guarda la red neuronal en archivos
    bool load(String filename); //Carga la red neuronal desde archivos
};

#endif

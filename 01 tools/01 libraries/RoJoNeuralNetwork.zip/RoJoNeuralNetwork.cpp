/*
 * Autor: Ramón Junquera
 * Fecha: 20201111
 * Tema: Gestión de redes neuronales
 */

#include "RoJoNeuralNetwork.h"

//Definición de algunas funciones de activación
float sigmoidF(float x) { //Sigmoidea
  return 1/(1+exp(-x));
}
float sigmoidD(float x) { //Derivada de sigmoidea
  return x*(1-x);
}
float reluF(float x) { //ReLU
  if(x<=0) return 0;
  return x;
}
float reluD(float x) { //Derivada de ReLU
  if(x<=0) return 0;
  return 1;
}
float lineF(float x) { //Función lineal
  return x;
}
float lineD(float x) { //Derivada de función lineal
  return 1;
}

//Definición de error cuadrático como función de coste
float cuadErrorF(float valueRight,float valueGot) { //Función
  float t=valueRight-valueGot;
  return t*t;
}
float cuadErrorD(float valueRight,float valueGot) { //Derivada
  return valueRight-valueGot;
}


//class RoJoNeuralLayer--------------------------------------------------------


//Llena con valores aleatorios entre dos límites
//Devuelve true si lo consigue
bool RoJoNeuralLayer::fillRand(float minValue,float maxValue) {
  if(!_W.fillRand(minValue,maxValue)) return false;
  return _b.fillRand(minValue,maxValue);
}

//Inicialización y dimensionamiento
//Parámetros:
//- inNodes : Nodos de entrada
//- outNodes : Nodos de salida/internos
//- minValue : límite inferior de valores aleatorios
//- maxValue : límite superior de valores aleatorios
//Devuelve true si lo consigue
bool RoJoNeuralLayer::begin(uint16_t inNodes,uint16_t outNodes,float minValue,float maxValue) {
  if(inNodes==0 || outNodes==0) return false;
  //Guardamos parámetros
  this->inNodes=inNodes;
  this->outNodes=outNodes;
  //Dimensionamos las matrices
  _W.redim(inNodes,outNodes);
  _b.redim(1,outNodes);
  //Las inicializamos con valores aleatorios
  return fillRand(minValue,maxValue);
}

void RoJoNeuralLayer::end() {
  _b.end();
  _W.end();
  sumW.end();
  outValues.end();
}

//Destructor
RoJoNeuralLayer::~RoJoNeuralLayer() {
  end();
}

//Calcula los valores de salida (con función de activación)
//Devuelve true si lo consigue
bool RoJoNeuralLayer::calc() {
  if(inValues->rows()==0 || inValues->cols()!=inNodes) return false;
  sumW.mProd(inValues,&_W); //Producto matricial
  sumW.sumRow(&_b); //Suma de BIAS
  outValues.f1(_actF,&sumW); //Aplicamos función de activación
  return true; //Todo Ok
}

//Define índice de función de activación
bool RoJoNeuralLayer::setIndexActF(byte indexActF) {
  if(indexActF<1 || indexActF>indexActFmax) return false;
  switch(indexActF) {
    case 1: //Función sigmoidea
      _actF=sigmoidF; //Función
      _actFD=sigmoidD; //Derivada
      break;
    case 2: //Función ReLU
      _actF=reluF; //Función
      _actFD=reluD; //Derivada
      break;
    case 3: //Función lineal
      _actF=lineF; //Función
      _actFD=lineD; //Derivada
      break;
  }
  _indexActF=indexActF; //Anotamos el índice de la función de activación
  return true; //Todo Ok
}

//Define la función de activación (y su derivada) personalizada
void RoJoNeuralLayer::setIndexActF(float (*actF)(float),float (*actFD)(float)) {
  _actF=actF; //Función
  _actFD=actFD; //Derivada
  _indexActF=0; //Función de activación personalizada
}


//class RoJoNeuralNetwork------------------------------------------------------


void RoJoNeuralNetwork::end() {
  if(_layersCount>0) { //Si hay alguna capa...
    _inValues.end(); //Vaciamos la matriz de valores de entrada
    for(uint16_t i=0;i<_layersCount;i++) { //Recorremos todas las capas
      _layers[i]->end(); //Finalizamos la capa
      delete _layers[i]; //Borramos el objeto capa
    }
    delete[] _layers; //Borramos el array de capas
    _layersCount=0; //Anotamos que la red no tiene capas
  }
}

//Destructor
RoJoNeuralNetwork::~RoJoNeuralNetwork() {
  end();
}

//Fija una función de activación tipificada en una capa
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::setActF2Layer(uint16_t layerIndex,byte indexActF) {
  if(layerIndex>=_layersCount) return false;
  return _layers[layerIndex]->setIndexActF(indexActF);
}

//Fija una función de activación (y su derivada) personalizadas para una capa
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::setActF2Layer(uint16_t layerIndex,float (*actF)(float),float (*actFD)(float)) {
  if(layerIndex>=_layersCount) return false;
  _layers[layerIndex]->setIndexActF(actF,actFD);
  return true; //Todo Ok
}

//Fija la funcióin de coste (y su derivada) personalizadas
void RoJoNeuralNetwork::setCostF(float (*costF)(float,float),float (*costFD)(float,float)) {
  _costF=costF; //Función
  _costFD=costFD; //Derivada
  _indexCostF=0; //Función de coste personalizada
}

//Llena una capa con valores aleatorios entre dos límites
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::fillRand(uint16_t layerIndex,float minValue,float maxValue) {
  if(layerIndex>=_layersCount) return false;
  return _layers[layerIndex]->fillRand(minValue,maxValue);
}

//Init
//Parámetros
//- hideLayersCount : Número de capas ocultas
//- *arrayNodesCount : Puntero a array de nodos
//- indexActF : Índice de función de activación general
//- indexCostF : Índice de la función de coste
//- lr : learning rate
//- minValue : límite inferior de valores aleatorios
//- maxValue : límite superior de valores aleatorios 
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::begin(uint16_t hideLayersCount,uint16_t *arrayNodesCount,byte indexActF,byte indexCostF,float lr,float minValue,float maxValue) {
  //El array de nodos tendrá tantos elementos como capas ocultas +1
  //El método inicializa la red neuronal creando las distintas capas
  if(hideLayersCount==0) return false; //Al menos debe existir una capa oculta
  if(indexActF>indexActFmax) return false; //Si el índice es inválido...terminamos
  if(indexCostF>indexCostFmax) return false; //Si el índice es inválido...terminamos
  end(); //Eliminamos cualquier dato actual
  _layersCount=hideLayersCount; //Anotamos número de capas
  _layers=new RoJoNeuralLayer*[_layersCount];
  for(uint16_t i=0;i<_layersCount;i++) { //Primero creamos las capas
    _layers[i]=new RoJoNeuralLayer;
  }
  for(uint16_t i=0;i<_layersCount;i++) { //Después las dimensionamos
    //Si tenemos algún error en el dimensionamiento...
    if(!_layers[i]->begin(arrayNodesCount[i],arrayNodesCount[i+1],minValue,maxValue)) {
      end(); //No fallará porque ya están creadas todas las capas
      return false;
    }
  }
  for(uint16_t i=1;i<_layersCount;i++) { //Recorremos las capas a partir de la segunda
    //La matriz de entrada es la misma que la de salida de la capa anterior
    _layers[i]->inValues=&_layers[i-1]->outValues;
  }
  for(uint16_t i=0;i<_layersCount;i++) { //Recorremos de nuevo las capas...
    if(indexActF>0) { //Si se utilizará una función de activación tipificada...
      _layers[i]->setIndexActF(indexActF); //Asignamos la función de asignación
    } else { //Si se utiliza una función de activación personalizada
      _layers[i]->setIndexActF(nullptr,nullptr); //Se tendrá que definir después
    }
  }
  if(indexCostF>0) { //Si se utiliza una función de coste tipificada...
    switch(indexCostF) {
      case 1: //Función de error cuadrático
        _costF=cuadErrorF; //Función
        _costFD=cuadErrorD; //Derivada
        break;
    }
  } else { //Si se utiliza una función de coste personalizada...
    setCostF(nullptr,nullptr); //Se tendrá que definir después
  }
  _indexCostF=indexCostF; //Guardamos el índice de la función de coste
  _lr=lr; //Guardamos learning rate
  return true; //Todo Ok
}

//Cálculo de forwardPass en todas las capas
//Parámetros:
//- inValues: matriz de valores de entrada (samples,nodos de entrada de la primera capa)
//- outValues: matriz de salida (samples,nodos de salida de la última capa)
//- smalMem: elimina matrices prescindibles para el cálculo, pero no para el aprendizaje
bool RoJoNeuralNetwork::calc(RoJoFloatMatrix *inValues,RoJoFloatMatrix *outValues,bool smallMem) {
  if(_layersCount==0 || inValues->rows()==0 || inValues->cols()!=_layers[0]->inNodes) return false;
  //Si no podemos copiar valores de entrada a matriz interna...terminamos
  //Si este cálculo se reutiliza en un futuro, no dependeremos de la matriz de valores de entrada original
  if(!_inValues.mCopy(inValues)) return false;
  _layers[0]->inValues=&_inValues; //Asignamos valores de entrada de la primera capa
  _layers[0]->calc(); //Calculamos primera capa
  if(smallMem) _layers[0]->sumW.end(); //Vaciamos matriz de suma ponderada para ahorrar memoria
  for(uint16_t layer=1;layer<_layersCount;layer++) { //Recorremos las capas a partir de la segunda
    _layers[layer]->calc(); //Calculamos la capa actual
    if(smallMem) { //Para ahorrar memoria, eliminamos algunas matrices...
      _layers[layer]->inValues->end(); //Vaciamos valores de entrada
      _layers[layer]->sumW.end(); //Vaciamos suma ponderada
    }
  }
  //Devolveremos una copia de los valores de salida de la última capa
  outValues->mCopy(&(_layers[_layersCount-1]->outValues));

  //Ya no necesitamos los valores de la salida de la última capa
  if(smallMem) _layers[_layersCount-1]->outValues.end();
  return true; //Todo Ok
}

//Entrenamiento de la red neuronal con derivada de función de coste
//Toma datos de entrada y salida de un cálculo previo (método calc) con smallMem=false
//Parámetros:
//- costValues: matriz de valores de derivada de la función de coste
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::trainCostFD(RoJoFloatMatrix *costValues) {
  //Nota:
  //Una de las funciones de coste más habituales es el error cuadrático:
  //  el cuadrado de la diferencia entre el valor obterido y el esperado
  //Su derivada es muy sencilla:
  //  la diferencia entre el valor correcto y el obtenido
  //Si utilizamos esta función de coste, sólo debemos entregar la matriz con las deltas
  //que deberíamos añadir los valores obtenidos para convertirlos en los correctos.
  //O la diferencia a aplicar para corregir los datos obtenidos.

  //Si las dimensiones de la matriz de coste no coincide con la de salida...terminamos
  if(costValues->rows()!=_inValues.rows() || costValues->cols()!=_layers[_layersCount-1]->outNodes) return false;
  //Creamos matriz copia de la matriz de coste para no alterar su contenido
  RoJoFloatMatrix delta;
  delta.mCopy(costValues);
  //Creamos matriz para guardar los coeficientes W de la capa previa
  //Puesto que antes de empezar, no tenemos valores coeficientes y después
  //se utilizan para multiplicar, creamos una matriz que no afecte a la
  //multiplicación (matriz unitaria)
  uint16_t outNodesLastLayer=_layers[_layersCount-1]->outNodes;
  RoJoFloatMatrix Wprev;
  Wprev.redim(outNodesLastLayer,1);
  for(uint16_t i=0;i<outNodesLastLayer;i++) Wprev.m[i][0]=1;
  //Creamos matrices temporales para el cálculo de delta
  RoJoFloatMatrix tmp1,tmp2;
  //Recorremos todas las capas en orden inverso...
  for(int16_t layer=_layersCount-1;layer>=0;layer--) {
    tmp2.T(&Wprev); //Traspuesta
    tmp1.mProd(&delta,&tmp2); //Producto Matricial
    //Aplicamos la derivada de la función de activación sobre el resultado
    tmp2.f1(_layers[layer]->_actFD,&(_layers[layer]->outValues));
    delta.eProd(&tmp1,&tmp2); //Producto escalar
    Wprev.mCopy(&(_layers[layer]->_W)); //Guardamos W para utilizarlo en el siguiente ciclo
    tmp1.meanCols(&delta); //Calculamos promedio de cada columna de delta
    tmp1.eProd(-_lr); //Multiplicamos por el negativo de learning rate
    _layers[layer]->_b.mSum(&tmp1); //Lo añadimos al actual BIAS
    tmp1.T(_layers[layer]->inValues); //Traspuesta de valores de entrada
    tmp2.mProd(&tmp1,&delta); //Producto matricial con delta
    tmp2.eProd(-_lr); //Multiplicamos por el negativo de learning rate
    _layers[layer]->_W.mSum(&tmp2); //Lo añadimos al actual W
  }
  return true; //Todo Ok
}

//Entrenamiento de la red neuronal con valores correctos
//Toma datos de entrada y salida de un cálculo previo (método calc) con smallMem=false
//Parámetros:
//- rightValues: matriz de valores de salida correctos (samples, nodos de salida de la última capa)
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::trainRight(RoJoFloatMatrix *rightValues) {
  //Si las dimensiones de la matriz de valores correctos no coincide con la de salida...terminamos
  if(rightValues->rows()!=_inValues.rows() || rightValues->cols()!=_layers[_layersCount-1]->outNodes) return false;
  //No hacemos el cálculo, porque suponemos que ya está hecho
  //calc(inValues,outValues,false);

  //Creamos matriz para guardar el resultado de la derivada de la función de coste
  RoJoFloatMatrix delta;
  //Calculamos delta para la última capa
  delta.f2(_costFD,&(_layers[_layersCount-1]->outValues),rightValues);
  //Devolvemos el resultado del entrenamiento pasando la matriz de coste
  return trainCostFD(&delta);
}

//Entrenamiento de la red neuronal
//Parámetros:
//- inValues: matriz de valores de entrada (samples,nodos de entrada de la primera capa)
//- rightValues: matriz de valores de salida correctos (samples, nodos de salida de la última capa)
//- outValues: matriz de salida de última capa (samples,nodos de salida de la última capa)
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::train(RoJoFloatMatrix *inValues,RoJoFloatMatrix *rightValues,RoJoFloatMatrix *outValues) {
  //Si no podemos completar el cálculo (sin borrar metrices temporales)...terminamos
  if(!calc(inValues,outValues,false)) return false;
  //Entrenamiento del cálculo que acabamos de hacer
  return trainRight(rightValues);
}

//Calcula el error
//Parámetros:
//- outValues: matriz de salida de última capa (samples,nodos de salida de la última capa)
//- rightValues: matriz de valores de salida correctos (samples, nodos de salida de la última capa)
//- meanCost: matriz de error (promedio de resultados de la función de coste).
//Devuelve true si lo consigue
bool RoJoNeuralNetwork::cost(RoJoFloatMatrix *outValues,RoJoFloatMatrix *rightValues,RoJoFloatMatrix *meanCost) {
  //Las matrices de salida y valores correctos deben tener la misma dimensión
  if(outValues->cols()!=rightValues->cols() || outValues->rows()!=rightValues->rows()) return false;
  RoJoFloatMatrix costValues; //Guardará los resultados de la función de coste
  costValues.f2(_costF,outValues,rightValues); //Obtenemos los resultados de la función de coste
  meanCost->meanCols(&costValues); //Devolvemos el promedio de error por parámetro de salida
  return true; //Todo Ok
}

//Calculamos los valores de una colección de puntos definidos por una lista de
//coordenadas horizontales y verticales. Especialmente hecho para mapas de background
//Parámetros:
//- cXb : Lista de coordenadas horizontales
//- cYb : Lista de coordenadas verticales
//- Vb: Matriz en la que devolvemos los valores de los puntos
//Nota:
//- La dimensión de la matriz Vb viene dada por el número de elementos de las
//  listas de coordenadas. Filas=elementos de cYb. Columnas=elementos de cXb.
bool RoJoNeuralNetwork::mesh(RoJoFloatMatrix *cXb,RoJoFloatMatrix *cYb,RoJoFloatMatrix *Vb) {
  uint16_t rows=cYb->rows();
  uint16_t cols=cXb->rows();
  if(rows==0 || cols==0 || cYb->cols()!=1 || cXb->cols()!=1) return false;
  Vb->redim(rows,cols); //Dimensionamos la matriz de salida
  RoJoFloatMatrix X,Z; //Creamos matriz de entrada y salida para red neuronal
  float y; //Coordenada de fila
  X.redim(cols,2); //Introduciremos los datos por filas
  //Por lo tanto, la coordenada de columna permanecerá siempre constante
  //con independencia de la fila
  for(uint16_t col=0;col<cols;col++) X.m[col][0]=cXb->m[col][0];
  for(uint16_t row=0;row<rows;row++) { //Recorremos todas las filas...
    y=cYb->m[row][0]; //Calculamos la coordenada de fila
    //Será constante a todas las columnas
    for(uint16_t col=0;col<cols;col++) X.m[col][1]=y;
    calc(&X,&Z); //Calculamos valor
    //Copiamos el resultado a la matriz de valores
    for(uint16_t col=0;col<cols;col++) Vb->m[row][col]=Z.m[col][0];
  }
  return true; //Todo Ok
}

//Guarda red neuronal en una colección de archivos
//Parámetros:
//  filename : nombre de la colección de archivos sin extensión (Ej: "/myNN")
//Respuesta: true si se consigue
bool RoJoNeuralNetwork::save(String filename) {
  //Nota:
  //Los datos principales de la red neuroral se guardan en el archivo filename.nn
  //Las matrices de las distintas capas se guardarán en:
  //  - Matriz W de capa 34 : filename.34W
  //  - Matriz b de capa 5 : filename.5b
  if(_layersCount==0) return false; //Si está vacía...terminamos con error
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    File f=SD.open(filename+"nn",FILE_WRITE); //Creamos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    File f=SPIFFS.open(filename+".nn","w"); //Creamos el archivo en SPIFFS
  #endif
  if(!f) return false; //Si hubo algún problema...devolvemos error
  //Guardaremos los datos de la red neuronal en el mismo orden que los 
  //parámetros del método begin
  //bool begin(uint16_t hideLayersCount,uint16_t *arrayNodesCount,byte indexActF=1,byte indexCostF=1,float lr=0.05,float minValue=-1,float maxValue=1); //Init

  //Escribimos número de capas ocultas
  f.write((byte*)&_layersCount,2);

  //Escribimos el número de nodos
  //Primero el número de nodos de entrada...
  for(uint16_t layer=0;layer<_layersCount;layer++) 
    f.write((byte*)&(_layers[layer]->inNodes),2);
  //Y después el número de nodos de salida de la última capa
  f.write((byte*)&(_layers[_layersCount-1]->outNodes),2);

  //Escribimos el array de índices de funciones de activación
  for(uint16_t layer=0;layer<_layersCount;layer++) 
    f.write(&(_layers[layer]->_indexActF),1);

  //Escribimos el índice de la función de coste
  f.write(&_indexCostF,1);

  //Escribimos el learning rate
  f.write((byte*)&_lr,4); //Un float ocupa 4 bytes
  
  f.close(); //Cerramos el archivo

  //Ahora guardaremos las matrices W & b de cada capa
  for(uint16_t layer=0;layer<_layersCount;layer++) {
    if(!_layers[layer]->_W.save(filename+"."+String(layer)+"W")) return false;
    if(!_layers[layer]->_b.save(filename+"."+String(layer)+"b")) return false;
  }

  return true; //Todo Ok
}

//Carga la red neuronal desde una colección de archivos
//Parámetros:
//  filename : nombre de la colección de archivos sin extensión (Ej: "/myNN")
//Respuesta: true si se consigue
bool RoJoNeuralNetwork::load(String filename) {
  #ifdef ROJO_PIN_CS_SD //Si se utiliza SD...
    SD.begin(ROJO_PIN_CS_SD);
    if(!SD.exists(filename+".nn")) return false; //Archivo no encontrado
    File f=SD.open(filename+".nn",FILE_READ); //Abrimos el archivo en la SD
  #else //Si utilizamos SPIFFS...
    if(!SPIFFS.exists(filename+".nn")) return false; //Archivo no encontrado
    File f=SPIFFS.open(filename+".nn","r"); //Abrimos el archivo en SPIFFS
  #endif
  //Leemos número de capas ocultas
  uint16_t hideLayers;
  f.read((byte *)&hideLayers,2);

  //Leemos array de número de nodos
  uint16_t topology[hideLayers+1];
  f.read((byte *)topology,2*(hideLayers+1));

  //Leemos array de índices de funciones de activación
  byte indexActF[hideLayers];
  f.read(indexActF,hideLayers);

  //Leemos índice de la función de coste
  byte indexCostF;
  f.read(&indexCostF,1);
  //Si la función es personalizada, se tendrá que volver a definir después
  //Pero para crear la red neuronal utilizaremos una función tipificada
  if(indexCostF==0) indexCostF++;

  //Leemos learning rate
  float lr;
  f.read((byte *)&lr,4);
  
  f.close(); //Cerramos el archivo
  //Creamos la red neuronal utilizando una función tipificada para la
  //función de activación
  if(!begin(hideLayers,topology,1,indexCostF,lr)) return false;
  //Recorremos todas las capas...
  for(uint16_t layer=0;layer<hideLayers;layer++) {
    //Si la función de activación es personalizada, se tendrá que volver
    //a definir después, pero para asignar la función a la capa, 
    //usaremos una tipificada
    if(indexActF[layer]==0) indexActF[layer]++;
    _layers[layer]->_indexActF=indexActF[layer];
    //Cargamos las matrices W & b
    if(_layers[layer]->_W.load(filename+"."+String(layer)+"W")>0) {
      end();
      return false;
    } 
    if(_layers[layer]->_b.load(filename+"."+String(layer)+"b")>0) {
      end();
      return false;
    } 
  }
	return true; //Todo ok
}
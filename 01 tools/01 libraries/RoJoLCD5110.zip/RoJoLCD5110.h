/*
  Nombre de la librería: RoJoLCD5110.h
  Versión: 20190909
  Autor: Ramón Junquera
  Descripción:
    Gestión de display Nokia LCD 5110 SPI 84x48

  Notas:
  - La versión que contiene el M5 Watch no permite leer el contenido de
    la memoria de vídeo a través de SPI
  - La escritura en la memoria de vídeo del display no es instantánea.
    Esto implica que con objetos en movimiento se produzca el efecto "estela"
  - El driver no incluye el método drawSpriteSync porque el principal
    problema no es la velocidad de transmisión, sino el tiempo de refresco

  Selección del sistema de archivos.
    Si se declara la constante ROJO_PIN_CS_SD y se le asigna un valor, se
    selecciona la SD como sistema de archivos.
    El valor de ROJO_PIN_CS_SD corresponde con el pin CS de la SD.
    Si no se declara esta constante, se utilizará SPIFFS.
    Ej.: build_flags = -D ROJO_PIN_CS_SD=15
*/

#ifndef RoJoLCD5110_h
#define RoJoLCD5110_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoGraph.h> //Gestión de gráficos avanzados

class RoJoLCD5110:public RoJoGraph
{
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    void _setCursorRangeX(byte x=0); //Define rango X
    void _setCursorRangeY(byte page=0); //Define rango Y
    void _setCursorRange(byte x=0,byte page=0); //Define  rango X & Y
    const byte _xMax=84; //Anchura en pixels
    const byte _yMax=48; //Altura en pixels
    const byte _pageMax=_yMax/8; //Altura en páginas
    void _writeCommand(byte command,...); //Envía al display una lista de comandos
    void _startCOMM(); //Inicia comunicación
    void _endCOMM(); //Finaliza comunicación
    SPISettings _spiSetting; //Características de la conexión SPI
  public:
    void sleep(bool mode); //Activa/Desactiva el modo hibernación
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    void reset(); //Reset
    void clear(uint16_t color=0); //Borra el área de dibujo
    bool drawSprite(RoJoSprite *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    void reverse(bool mode); //Display con colores invertidos blanco <-> negro
    void begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqCOMM=0); //Inicialización
	void setContrast(byte level); //Fija el contraste
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoLCD5110.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


/*
  Nombre de la librería: RoJoMAX7219.h
  Versión: 20180310
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a matrices de leds.
*/

#ifndef RoJoMAX7219_cpp
#define RoJoMAX7219_cpp

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
//#define UseSD

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#ifdef UseSD //Si debemos utilizar una tarjeta SD...
  #include "RoJoMAX7219SD.h"
  #include "RoJoSpriteSD.h"
#else //Si debemos utilizar SPIFFS
  #include "RoJoMAX7219.h"
  #include "RoJoSprite.h"
#endif

void RoJoMAX7219::_localCommand(byte command, byte value)
{
  //Envía una instrucción
  shiftOut(_pinDIN_display,_pinCLK_display,MSBFIRST,command);
  shiftOut(_pinDIN_display,_pinCLK_display,MSBFIRST,value);
}

void RoJoMAX7219::_globalCommand(byte command, byte value)
{
  //Envía una instrucción a todos los chips
  
  //Antes de enviar una instrucción, siempre desactivamos el pin CS
  digitalWrite(_pinCS_display,LOW);
  //Recorremos todos los chips y enviamos la instrucción
  for(byte chip=0;chip<_chainedChips;chip++) _localCommand(command,value);
  //Fin de envío
  digitalWrite(_pinCS_display,HIGH);
}

void RoJoMAX7219::setBrightness(byte brightness)
{
  //Fija el brillo de los leds
  //El rango de valores permitidos está entre 0 y 15
  //Se podría fijar distinto brillo a cada chip. No lo haremos
  //Asignaremos el mismo a todos
  _globalCommand(0x0A,brightness & 15); //max7219_reg_intensity
}

void RoJoMAX7219::show()
{
  //Envía la memoria de vídeo a la cadena de chips
  
  //Recorreremos todas las columnas que gestiona un chip
  for(byte x=0;x<8;x++)
  {
    //Antes de enviar una serie de instrucciones, siempre desactivamos el pin CS
    digitalWrite(_pinCS_display,LOW);
    //Recorreremos todos los chips
    //Recordemos que la primera instrucción enviada corresponderá al chip con número de
    //secuencia más alto y la última instrucción afectará al chip 0
    for(byte chip=_chainedChips-1;chip!=255;chip--)
    {
      //El comando corresponde con el número de columna + 1
      //Y el valor con el byte de la columna que corresponde en la memoria de vídeo
      _localCommand(x+1,(*videoMem).getPage(chip*8+x,0));
    }
    //Fn de envío
    digitalWrite(_pinCS_display,HIGH);
  }
}

void RoJoMAX7219::begin(byte chainedChips,byte pinDIN_display,byte pinCS_display,byte pinCLK_display,byte pinCS_SD)
{
  //Inicialización
  
  //Guardamos los valores de los parámetros en las variables privadas
  _chainedChips=chainedChips;
  _pinDIN_display=pinDIN_display;
  _pinCS_display=pinCS_display;
  _pinCLK_display=pinCLK_display;
  //Definimos los pines de conexión como de salida
  pinMode(_pinDIN_display,OUTPUT);
  pinMode(_pinCS_display,OUTPUT);
  pinMode(_pinCLK_display,OUTPUT);
  //Activamos el pin del reloj
  digitalWrite(_pinCLK_display,HIGH);

  //Desconocido!
  _globalCommand(0x0B,0x07); //max7219_reg_scanLimit
  //Utilizaremos matrices de leds, no displays de dígitos  
  _globalCommand(0x09,0x00); //max7219_reg_decodeMode
  //Salimos del modo shutdown en el que se encuentran al arrancar. Los activamos!  
  _globalCommand(0x0C,0x01); //max7219_reg_shutdown
  //No hace falta hacer el test de display (encender todos los leds) 
  _globalCommand(0x0F,0x00); //max7219_reg_displayTest
  //Fijamos el brillo por defecto a 8
  setBrightness(8);
  //Creamos el sprite de la memoria de vídeo
  videoMem = new RoJoSprite(pinCS_SD);
  //Dimensionamos el sprite de la memoria de vídeo
  //Siempre tiene una sóla página de altura
  (*videoMem).setSize(chainedChips*8,1);
  //Borramos la memoria de vídeo
  (*videoMem).clear();
  //Pasamos la memoria de vídeo a la cadena de chips
  show();
}

RoJoMAX7219::~RoJoMAX7219()
{
  //Destructor

  //Borramos el sprite con la memoria de vídeo
  (*videoMem).clean();
}

#endif

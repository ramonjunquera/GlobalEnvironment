﻿/*
  Nombre de la librería: RoJoMAX7219.h
  Versión: 20191005
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a matrices o displays
    de dígitos de leds
*/

#ifndef RoJoMAX7219_h
#define RoJoMAX7219_h

#include <Arduino.h>
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoGraph.h> //Gestión de gráficos avanzados

class RoJoMAX7219:public RoJoGraph {
  private:
    byte _pinDIN;
    byte _pinCS;
    byte _pinCLK;
    byte _chainedChips=0; //Número de chips MAX7219 encadenados. Inicialmente 0
    byte _xMax=0; //Anchura en pixels. Inicialmente 0
    const byte _yMax=8; //Altura en pixels
    const byte _pageMax=1; //Altura en páginas
    void _localCommand(byte command, byte value); //Envía un único comando
    void _globalCommand(byte command, byte value); //Envía un comando a todos los chips
  public:
    bool autoDraw=true; //Refresco automático. Por defecto sí
    RoJoSprite *v; //Puntero a sprite con la memoria de vídeo
    void reset(); //Reset
    bool begin(byte chainedChips,byte pinDIN, byte pinCS, byte pinCLK); //Inicialización
    ~RoJoMAX7219(); //Destructor
    void clear(byte color=0); //Limpia la memoria de vídeo
    void setBrightness(byte brightness); //Fija el brillo de los leds
    void draw(); //Dibuja la memoria de vídeo en el display
    bool drawPixel(int16_t x,int16_t y,uint16_t color); //Dibuja un pixel
    bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color); //Dibuja un rectángulo relleno
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    bool drawSprite(RoJoSprite *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoMAX7219.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


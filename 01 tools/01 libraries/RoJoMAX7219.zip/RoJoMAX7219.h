﻿/*
  Nombre de la librería: RoJoMAX7219.h
  Versión: 20180310
  Autor: Ramón Junquera
  Descripción:
    Gestión de cadena de chips MAX7219 conectados a matrices de leds.
*/

#ifndef RoJoMAX7219_h
#define RoJoMAX7219_h

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
//#define UseSD

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#ifdef UseSD //Si debemos utilizar una tarjeta SD...
  #include "RoJoSpriteSD.h"
#else //Si debemos utilizar SPIFFS
  #include "RoJoSprite.h"
#endif

class RoJoMAX7219
{
  private:
    byte _pinDIN_display;
    byte _pinCS_display;
    byte _pinCLK_display;
    byte _chainedChips; //Número de chips MAX7219 encadenados
    void _localCommand(byte command, byte value); //Envía un único comando
    void _globalCommand(byte command, byte value); //Envía un comando a todos los chips
  public:
    ~RoJoMAX7219(); //Destructor
    RoJoSprite *videoMem; //La memoria de vídeo es un sprite
    void begin(byte chainedChips,byte pinDIN, byte pinCS, byte pinCLK, byte pinCS_SD=SS);
    void setBrightness(byte brightness); //Fija el brillo de los leds
    void show(); //Envía memoria de vídeo a la cadena de chips
}; //Punto y coma obligatorio para que no de error

#endif


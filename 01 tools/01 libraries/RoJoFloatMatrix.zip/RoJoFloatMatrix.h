/*
 * Autor: Ramón Junquera
 * Fecha: 20200911
 * Tema: Gestión de matrices bidimensionales de tipo float
 */

#ifndef RoJoFloatMatrix_h
#define RoJoFloatMatrix_h

#include <Arduino.h>

class RoJoFloatMatrix {
  protected:
    uint16_t _rows=0; //Número de filas. Inicialmente ninguna
    uint16_t _cols=0; //Número de columnas. Inicialmente ninguna
    void _mCopy(RoJoFloatMatrix *A,uint16_t deltaRows,uint16_t deltaCols); //Copia con delta
  public:
    float **m; //Puntero a array de arrays: matriz
    void end(); //Descarga memoria
    ~RoJoFloatMatrix(); //Destructor
    bool redim(uint16_t rows,uint16_t cols); //Redimensionar
    RoJoFloatMatrix(uint16_t rows=0,uint16_t cols=0); //Constructor con tamaño
    RoJoFloatMatrix(RoJoFloatMatrix &A); //Constructor de asignación
    uint16_t cols(); //Número de columnas
    uint16_t rows(); //Número de filas
    bool T(RoJoFloatMatrix *A); //Traspuesta
    bool glueRows(RoJoFloatMatrix *A,RoJoFloatMatrix *B); //Pega filas de A y B
    bool glueCols(RoJoFloatMatrix *A,RoJoFloatMatrix *B); //Pega columnas de A y B
    bool maxminRangeCol(float *min,float *max,uint16_t firstCol,uint16_t lastCol); //Calcula máx y min de un rango de columnas
    bool maxmin(float *min,float *max); //Calcula máx y min
    bool maxminCol(float *min,float *max,uint16_t col); //Calcula máx y min de una columna
    bool fillRand(float minValue=-1,float maxValue=1); //Llena con aleatorios
    bool fill(float value); //Llena con una valor
    bool linspace(float minValue,float maxValue,uint16_t samples); //Rango
    bool f1(float (*f)(float),RoJoFloatMatrix *P); //Aplicación de fórmula de 1 parámetro
    bool f2(float (*f)(float,float),RoJoFloatMatrix *P0,RoJoFloatMatrix *P1); //Aplicación de fórmula de 2 parámetros
    bool eProd(RoJoFloatMatrix *A,RoJoFloatMatrix *B); //Producto escalar
    bool eProd(float v); //Producto escalar por un valor
    bool mProd(RoJoFloatMatrix *A,RoJoFloatMatrix *B); //Producto matricial
    bool mSum(RoJoFloatMatrix *A); //Suma matricial
    bool mCopy(RoJoFloatMatrix *A); //Copia matricial
    bool sumCol(RoJoFloatMatrix *A); //Suma la matriz columna a todas las columnas
    bool sumRow(RoJoFloatMatrix *A); //Suma la matriz fila a todas las filas
    uint16_t* scrambleList(); //Crea lista desordenada
    bool scramble(uint16_t *sList); //Desordena la matriz en base a la lista
    bool meanCols(RoJoFloatMatrix *A); //Valor promedio de las columnas
};

#endif

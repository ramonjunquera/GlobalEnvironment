/*
  Library name: RoJoRotary.h
  Version: 20171004
  Author: Ramón Junquera
  Description: Rotatory encoder driver
*/

#ifndef RoJoRotary_h
#define RoJoRotary_h

#include <Arduino.h>

class RoJoRotary
{
  private:  //Private methods & variables definition
    byte _pinA,_pinB; //Encoder reading pins
    volatile byte _pinStatus[3] = {3, 3, 3}; //Sequence values on current step
    byte _lastPinStatus=0;
  public: //Public methods & variables definition
    RoJoRotary(byte pinA, byte pinB); //Constructor
    volatile int stepsCounter=0;
    int16_t maxStepsCounter=32767; //2^15-1
    int16_t minStepsCounter=-maxStepsCounter;
    void update(); //Update step counter
}; //Mandatory to avoid error

#endif

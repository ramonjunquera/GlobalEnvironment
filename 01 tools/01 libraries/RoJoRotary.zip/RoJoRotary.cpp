/*
  Library name: RoJoRotary.h
  Version: 20171004
  Author: Ramón Junquera
  Description: Rotatory encoder driver
*/

#ifndef RoJoRotary_cpp
#define RoJoRotary_cpp

#include <Arduino.h>
#include "RoJoRotary.h"

RoJoRotary::RoJoRotary(byte pinA, byte pinB)
{
  //Constructor. It is executed when the object is created
  //Parameters: encoder reading pins

  //Reading pins are saved in private class variables
  _pinA=pinA;
  _pinB=pinB;
  //Set reading pins as input & we user internal resistors por pullup
  pinMode(_pinA, INPUT_PULLUP);
  pinMode(_pinB, INPUT_PULLUP);
}

void RoJoRotary::update()
{
  //Update step counter

  //Read current pins values
  byte currentPinStatus = digitalRead(_pinA) * 2 + digitalRead(_pinB);

  //If status has been changed...
  if(_lastPinStatus != currentPinStatus)
  {
    //Last status now will be current one
    _lastPinStatus=currentPinStatus;
    //If current status is 3 (end of step)...
    if (currentPinStatus == 3)
    {
      //We compose a single value of 3 saved states. Comparisons will be easier
      byte pinStatusValue = _pinStatus[0] * 16 + _pinStatus[1] * 4 + _pinStatus[2];
      //If this value is a clockwise step [1,0,2]=1*16+0*4+2=16+2=18 ...
      if (pinStatusValue == 18)
      {
          //...if we didn't reach to maximum...
          //...steps counter will be increased
          if(stepsCounter<maxStepsCounter) stepsCounter++;
      }
      //If the value is a counterclockwise step [2,0,1]=2*16+0*4+1=32+1=33 ...
      else if (pinStatusValue == 33)
      {
          //...if we didn't reach to minimum...
          //...steps counter will be decreased
          if(stepsCounter>minStepsCounter) stepsCounter--;
      }
      //Array will be deleted (fill with empty states)
      currentPinStatus = 3;
    }
    //We cross the 3 states
    for (byte i = 0; i < 3; i++)
    {
      //Is status value is empty (3)...we write an empty status without any other check
      //This ensures that the processed state and next ones will be empty
      if (currentPinStatus == 3) _pinStatus[i] = 3;
      //If processed status value is empty (3)...
      else if (_pinStatus[i] == 3)
      {
        //...we keep current status at this position
        _pinStatus[i] = currentPinStatus;
        //Next status will be emply
        currentPinStatus = 3;
      }
      //If processed status value is equal than current status value...next status will be empty
      else if (_pinStatus[i] == currentPinStatus) currentPinStatus = 3;
    }
  }
}

#endif



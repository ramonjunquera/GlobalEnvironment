/*
  Nombre de la librería: RoJoDictionary.h
  Autor: Ramón Junquera
  Fecha; 20181015
  Descripción:
    Gestión de diccionarios en memoria
    Guarda pares de valores (items) en memoria.
    Un registro consta de clave (key) y valor asociado (value).
    Las claves son únicas.
    Una clave es del typo byte. Por lo tanto el diccionario no puede tener más de 256 items.
    El valor es una serie de bytes. Haciendo un cast se puede incluir cualquier objeto.
*/

#ifndef RoJoDictionary_h
#define RoJoDictionary_h
#include <Arduino.h>

template <typename T>
struct RoJoDictionaryItem
{
  //Estructura de un nodo del diccionario
  byte key;
  T *value;
  RoJoDictionaryItem *nextItem;
};

template <typename T>
class RoJoDictionary
{
  private:  //Definición de métodos/variables privadas
    byte _count=0; //Número de registros
    RoJoDictionaryItem<T> *firstItem=nullptr; //Puntero a item inicial
  public: //Definición de métodos/variables públicas
    byte count(); //Número de items en el diccionario
    bool containsKey(byte key); //Contiene la clave indicada?
    bool remove(byte key); //Elimina una clave/item
    void clear(); //Borra el contenido del diccionario
    bool add(byte key,T *value); //Añade un nuevo item al diccionario
    void index(byte index,byte *key,T **value); //Obtiene los datos de una posición
    bool value(byte key,T **value); //Obtiene el valor de una clave  
}; //Punto y coma obligatorio para que no de error

#include "RoJoDictionary.cpp" //Obligatorio cuando se utilizan clases con templates

#endif

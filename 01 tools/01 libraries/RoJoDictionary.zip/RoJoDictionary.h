/*
  Nombre de la librería: RoJoDictionary.h
  Autor: Ramón Junquera
  Fecha; 20190704
  Descripción:
    Gestión de diccionarios en memoria
    Guarda pares de valores (items) en memoria.
    Un registro consta de clave (key) y valor asociado (value).
    Las claves son únicas.
    Los tipos de la clave y del valor son seleccionables.
    El máximo número de items es de 2^16-1 porque el contador es uint16_t
*/

#ifndef RoJoDictionary_h
#define RoJoDictionary_h

#include <Arduino.h>

template <typename Tkey,typename Tvalue>
struct RoJoDictionaryItem
{
  //Estructura de un nodo del diccionario
  Tkey key;
  Tvalue *value;
  RoJoDictionaryItem *nextItem;
};

template <typename Tkey,typename Tvalue>
class RoJoDictionary
{
  private:  //Definición de métodos/variables privadas
    uint16_t _count=0; //Número de registros
    RoJoDictionaryItem<Tkey,Tvalue> *firstItem=nullptr; //Puntero a item inicial
  public: //Definición de métodos/variables públicas
    uint16_t count(); //Número de items en el diccionario
    bool containsKey(Tkey key); //Contiene la clave indicada?
    bool remove(Tkey key); //Elimina una clave/item
    void clear(); //Borra el contenido del diccionario
    bool add(Tkey key,Tvalue *value); //Añade un nuevo item al diccionario
    void index(uint16_t index,Tkey *key,Tvalue **value); //Obtiene los datos de una posición
    bool value(Tkey key,Tvalue **value); //Obtiene el valor de una clave  
}; //Punto y coma obligatorio para que no de error

#include "RoJoDictionary.cpp" //Obligatorio cuando se utilizan clases con templates

#endif

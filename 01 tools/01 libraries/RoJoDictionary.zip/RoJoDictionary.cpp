/*
  Nombre de la librería: RoJoDictionary.h
  Autor: Ramón Junquera
  Fecha; 20190704
  Descripción:
    Gestión de diccionarios en memoria
    Guarda pares de valores (items) en memoria.
    Un registro consta de clave (key) y valor asociado (value).
    Las claves son únicas.
    Los tipos de la clave y del valor son seleccionables.
    El máximo número de items es de 2^16-1 porque el contador es uint16_t
*/

//Incluimos estas líneas para evitar que se repita la llamada a la definición de métodos
//puesto que la clase utiliza templates
#ifndef RoJoDictionary_cpp
#define RoJoDictionary_cpp

#include "RoJoDictionary.h"

//Devuelve el número de items en el diccionario
template<typename Tkey,typename Tvalue>
uint16_t RoJoDictionary<Tkey,Tvalue>::count()
{
  return _count;
}

//Indica si existe la clave indicada
template<typename Tkey,typename Tvalue>
bool RoJoDictionary<Tkey,Tvalue>::containsKey(Tkey key)
{
  //Puntero a item procesado actualmente
  RoJoDictionaryItem<Tkey,Tvalue> *item;
  //Comenzamos con el primer item del diccionario
  item=firstItem;
  //Mientras no lleguemos al final...
  while(item!=nullptr)
  {
    //Si el item actual es el que buscamos...lo hemos encontrado!
    if(item->key==key) return true;
    //Parece que este item no es. Pasamos al siguiente
    item=item->nextItem;
  }
  //Hemos terminado de mirar todos los items y no lo hemos encontrado
  return false;
}

//Elimina una clave/item
//Devuelve true si la clave existía
template<typename Tkey,typename Tvalue>
bool RoJoDictionary<Tkey,Tvalue>::remove(Tkey key)
{
  //Si no hay elementos...hemos terminado y el item no existía
  if(_count==0) return false;
  //Al menos hay un item!
  //Puntero a item anterior y actual
  RoJoDictionaryItem<Tkey,Tvalue> *previousItem,*currentItem;
  //Comenzamos tomando como item previo el primero
  previousItem=firstItem;
  //Y como actual el que apunta el primero
  currentItem=firstItem->nextItem;
  //Si el primer item es el que queremos eliminar...
  if(firstItem->key==key)
  {
    //...el primer item será al que apunte el primero
    firstItem=currentItem;
    //Primero borramos el valor del item
    delete previousItem->value;
    //Y después el propio item
    delete previousItem;
    //Tenemos un item menos
    _count--;
    //Hemos terminado. La clave sí existía
    return true;
  }
  //El item a eliminar no es el primero
  //Mientras exista un item actual...
  while(currentItem!=nullptr)
  {
    //Si el item actual es el que queremos borrar...
    if(currentItem->key==key)
    {
      //...el item anterior deberá apuntar al que apunta el actual
      previousItem->nextItem=currentItem->nextItem;
      //Primero borramos el valor del item
      delete currentItem->value;
      //Y después el propio item
      delete currentItem;
      //Tenemos un item menos
      _count--;
      //Hemos terminado. Hemos encontrado el item
      return true;
    }
    //Este item no es el que queremos borrar
    //Pasaremos al siguiente
    //El item anterior será el actual
    previousItem=currentItem;
    //Y el actual será el item al que apunta el actual
    currentItem=currentItem->nextItem;
  }
  //Hemos terminado de revisar todos los items y no lo hemos encontrado
  return false;
}

//Borra el contenido del diccionario (todos los items)
template<typename Tkey,typename Tvalue>
void RoJoDictionary<Tkey,Tvalue>::clear()
{
  //Mientras haya items en el diccionario...borramos el primero
  while(_count) remove(firstItem->key);
}


//Añade un nuevo item al diccionario
//Si ya existe lo actualiza
//Devuelve true si ya existía la clave
template<typename Tkey,typename Tvalue>
bool RoJoDictionary<Tkey,Tvalue>::add(Tkey key,Tvalue *value)
{
  //Borramos la clave si es que existe
  //Y anotamos si ya existía
  bool alreadyExists=remove(key);
  //Añadimos la nueva
  //Creamos un nodo nuevo
  RoJoDictionaryItem<Tkey,Tvalue> *item=new RoJoDictionaryItem<Tkey,Tvalue>;
  //Anotamos su clave
  item->key=key;
  //Anotamos su contenido
  item->value=value;
  //Apuntará al actual primer item (porque lo pondremos el primero
  item->nextItem=firstItem;
  //Y ahora será este el primer item
  firstItem=item;
  //Ya tenemos un item más
  _count++;
  //Respondemos si ya existía la clave
  return alreadyExists;
}

//Obtiene los datos de una posición
template<typename Tkey,typename Tvalue>
void RoJoDictionary<Tkey,Tvalue>::index(uint16_t index,Tkey *key,Tvalue **value)
{
  //Inicialmente el valor es un puntero nulo
  *value=nullptr;
  //Si nos piden un item inexistente...hemos terminado
  if(index>_count) return;
  //Nos piden un índice existente
  //Puntero de item procesado
  RoJoDictionaryItem<Tkey,Tvalue> *item;
  //Inicialmente el primero
  item=firstItem;
  //Índice del item procesado
  uint16_t currentIndex=0;
  //Mientras el índice procesado no sea el que queremos...el item actual será el siguiente
  while(currentIndex++<index) item=item->nextItem;
  //Tenemos el item solicitado
  //Anotamos la clave
  *key=item->key;
  //Anotamos el valor
  *value=item->value;
  //Hemos terminado
  return;
}

//Obtiene el valor de una clave
//Devuelve true si se ha encontrado el item
template<typename Tkey,typename Tvalue>
bool RoJoDictionary<Tkey,Tvalue>::value(Tkey key,Tvalue **value)
{
  //Puntero a item procesado actualmente
  RoJoDictionaryItem<Tkey,Tvalue> *item;
  //Comenzamos con el primer item del diccionario
  item=firstItem;
  //Mientras no lleguemos al final...
  while(item!=nullptr)
  {
    //Si el item actual es el que buscamos...
    if(item->key==key)
    {
      //...lo hemos encontrado!
      //Anotamos su valor
      *value=item->value;
      //Hemos terminado. Indicamos que lo hemos encontrado
      return true;
    }
    //Parece que este item no es. Pasamos al siguiente
    item=item->nextItem;
  }
  //Hemos terminado de mirar todos los items y no hemos encontrado lo que buscábamos
  //Devolvemos un puntero nulo
  *value=nullptr;
  //No lo hemos encontrado
  return false;
}

#endif

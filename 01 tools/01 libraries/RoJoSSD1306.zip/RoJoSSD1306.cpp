//Cambios:
//El contraste mínimo es 1

/*
  Nombre de la librería: RoJoSSD1306.h
  Versión: 20180524
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED I2C 0.96" 128x64 SSD1306

  Nota:
  El tamaño del buffer I2C de las distintas placas nos limita el número
  de bytes que podemos enviar en una petición.
  Tras muchas pruebas estos son los resultados:
    UNO/Nano:  16 bytes
    ESP8266:   30 bytes
    ESP32:     29 bytes
    RPi:      128 bytes
    
  Nota: En RPi el flujo del buffer de escritura lo gestiona la propia
  función, por lo tanto no tendría límite. Lo fijamos en 128 bytes que
  es la longitud de una fila.

  Nota:
  La memoria de vídeo del display es de 1Kb.
  El driver tiene una memoria de vídeo de trabajo (videoMem) y una memoria de vídeo del display (_videoMem)
  La memoria de vídeo de trabajo permite leer y escribir información directamente.
  La memoria de vídeo del display mantiene la información que se está mostrando en ese instante en el
  display (la última enviada).
  El método show() se encarga de sincronizar ambas. Las compara y envía solo las diferencias.
  Este sistema consige una tasa de refresco mucho más alta. El movimiento de un sprite por pantalla es
  muchísimo más rápido.
  Supnemos que lo que más ralentiza es el envío de la información por el bus I2C.
  Esto es cierto en placas rápidas (ESP/RPi). En placas lentas (Mega) la diferencia es mínima.
*/

#ifndef RoJoSSD1306_cpp
#define RoJoSSD1306_cpp

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
//#define UseSD

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#ifdef UseSD //Si debemos utilizar una terjeta SD...
  #include "RoJoSSD1306SD.h"
  #include "RoJoSpriteSD.h"
#else //Si debemos utilizar SPIFFS
  #include "RoJoSSD1306.h"
  #include "RoJoSprite.h"
#endif

void RoJoSSD1306::begin(byte pinCS_SD,byte pinSDA,byte pinSCL,byte pinRST)
{
  //Inicialización del display
  //Permite fijar el pin CS de la SD, el pin SDA de I2C, el pin SCL de I2C y el pin reset
  //del display (si lo tiene).

  //Si se ha indicado pin de reset...
  if(pinRST<255)
  {
    //...reseteamos
    pinMode(pinRST,OUTPUT);
    digitalWrite(pinRST,LOW);
    delay(50);
    digitalWrite(pinRST,HIGH);
  }

  //Si se ha indicado pin de I2C (SDA & SCL)...activamos el I2C personalizado
  if(pinSDA<255) Wire.begin(pinSDA,pinSCL);
  //...y si no...usamos una I2C con los pines por defecto
  else Wire.begin();
  
  //Fijamos la frecuencia del bus I2C a 700KHz
  //Sólo será efectiva si la velocidad del procesador está selecionada al máximo
  Wire.setClock(700000);
  
  //Secuencia de inicialización.
  //Creamos un buffer de bytes con todos los comandos
  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos

    ,0x8D //Rango de voltaje
    ,0x14 //Voltaje igual o superior a 3.3V

    ,0x20 //Orden de escritura gráfica
    ,0x00 //Modo horizontal

    ,0xC8 //Orientación vertical con los pines de conexión en la parte superior
    ,0xA1 //Orientación horizontal. De izquierda a derecha 0-->128

    ,0xDA //Filas entrelazadas
    ,0x10 //Modo no entrelazado

    ,0x81 //Ajustamos el contraste
    ,0x01 //Al mínimo

    ,0xAF //Encendemos el display
  };

  //Enviamos el buffer por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar comandos

  //Creamos el sprite de la memoria de vídeo
  videoMem = new RoJoSprite(pinCS_SD);
  //Dimensionamos el sprite de la memoria de vídeo
  (*videoMem).setSize(xMax,pagesMax);
  //Creamos el sprite de la memoria interna de vídeo
  _videoMem = new RoJoSprite(pinCS_SD);
  //Dimensionamos el sprite de la memoria interna de vídeo
  (*_videoMem).setSize(xMax,pagesMax);

  //Llenamos la memoria interna de vídeo con datos
  (*_videoMem).rect(0,0,xMax-1,yMax-1,1);
  //Obligamos a refrescar y escribir la memoria de vídeo
  //Con esto conseguimos limpiar el display y sincronizar las memorias de vídeo
  show();
  //Activamos el modo inverso. fondo=negro,dibujo=blanco
  reverse(true);
}

void RoJoSSD1306::_setPage(byte page)
{
  //Selecciona la página en la que se encribirá la información gráfica

  //Secuencia de inicialización.
  //Creamos un buffer de bytes con todos los comandos
  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos

    ,0x22 //Comando para definir el rango de páginas que utilizaremos : [0,7]
    ,page //Desde la página indicada
    ,0x07 //Hasta la última (7)
  };

  Wire.beginTransmission(_oledId); //Abrimos comunicación con el display
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar datos
  _initSetPage=true; //Se ha inicializado la página actual
}

void RoJoSSD1306::_setColumn(byte column)
{
  //Selecciona la columna en la que se encribirá la información gráfica

  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos

    ,0x21 //Comando para definir el rango de columnas que utilizaremos: [0,127]
    ,column //Desde la columna indicada
    ,0x7F //Hasta la última (127)
  };
  
  Wire.beginTransmission(_oledId); //Abrimos comunicación con el display
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar datos
}

void RoJoSSD1306::_sendGraphicBytes(byte page,byte firstColumn,byte lastColumn)
{
  //Envía por I2C datos gráficos
  //Se supone que ya tenemos preparada la posición de escritura en el display

  //Calculamos el número de bytes a enviar
  byte len=lastColumn-firstColumn+2;
  //Creamos un buffer para guardar lo que queremos enviar
  byte buffer[len];
  //El primer valor es 0x40 para indicar que se enviarán datos
  buffer[0]=0x40;
  //Copiamos el resto de datos
  for(byte i=1;i<len;i++) buffer[i]=(*_videoMem).getPage(firstColumn+i-1,page);
  //Abrimos comunicación con el display
  Wire.beginTransmission(_oledId); 
  //Enviamos el buffer al display
  Wire.write(buffer,len);
  //Hemos terminado de enviar datos
  Wire.endTransmission(); 
}

void RoJoSSD1306::show()
{
  //Envía al display las diferencias entre la memoria de vídeo de 
  //trabajo y la memoria interna de vídeo

  byte c; //Columna
  
  for(byte p=0;p<8;p++) //Recorremos todas las páginas
  {
    //Por ahora no se ha inicializado SetPage para la página actual
    _initSetPage=false;
    //Comenzamos por la primera columna
    c=0;
    //Mientras no hayamos procesado todas las columnas...
    while(c<xMax)
    {
      //Si el byte actual no se ha modificado...
      if((*videoMem).getPage(c,p)==(*_videoMem).getPage(c,p))
      {
        //...no tenemos en cuenta este byte. Pasaremos al siguiente
        c++;
      }
      else //El byte actual ha sido modificado y debe ser enviado
      {
        //Si no se ha inicializado SetPage...lo hacemos ahora
        if(!_initSetPage) _setPage(p);
        //Indicamos que el próximo byte a enviar se encuentra en esta columna
        _setColumn(c);
        //Consideramos este byte como procesado/enviado
        //Actualizamos su valor en la memoria de vídeo del display
        (*_videoMem).drawPage(c,p,(*videoMem).getPage(c,p),4);
        //Por ahora la última columna modificada es la primera
        byte lastChangedColumn=c;
        //Columna procesada = la siguiente a la primera
        byte processedColumn=c+1;
        //Mientras la columna procesada esté dentro del rango visible
        //y el rango de columnas sea inferior al máximo permitido por
        //el buffer I2C y llevamos menos de 5 bytes sin modificar...
        while(processedColumn<xMax && processedColumn-c<=_maxBufferLenthI2C && processedColumn-lastChangedColumn<=5)
        {
          //Si la columna procesada se debe enviar...
          if((*videoMem).getPage(processedColumn,p)!=(*_videoMem).getPage(processedColumn,p))
          {
            //...anotamos que la última columna con cambios es la actual
            lastChangedColumn=processedColumn;
            //Consideramos este byte como procesado/enviado
            (*_videoMem).drawPage(processedColumn,p,(*videoMem).getPage(processedColumn,p),4);
          }
          //Aumentamos la posición de la columna procesada
          processedColumn++;
        } //end while
        //Los bytes a enviar irán desde la primera columna: c
        //hasta el último modificado: lastChangedColumn
        _sendGraphicBytes(p,c,lastChangedColumn);
        //La primera columna pasará a ser la actual
        c=processedColumn;
      }
    }
  }
  //La escritura de datos en el bus I2C consume bastantes 
  //recursos del procesador, porque gestiona un buffer de salida.
  //Si escribimos gran cantidad de datos contínuamente podemos conseguir 
  //que la rutina que gestiona la escritura I2C no permita que el proceso
  //del timer del WatchDog (WDT) se refresque.
  //Si WDT consigue terminar la cuenta supondrá que el programa se ha
  //bloqueado y a continuación provocará un reset por software que
  //reiniciará la placa.
  //Para evitar que esto ocurra incluimos aquí un refresco manual del WDT
  //La función yield() en placas Arduino es igual que ESP.wdtFeed() en
  //ESP8266
  yield();
}

void RoJoSSD1306::reverse(bool reverseMode)
{
  //Fija el display en modo invertido/normal (blanco <-> negro)
  //Por defecto se encuentra en modo invertido
  //  reverseMode = false -> pixel encendido = negro
  //  reverseMode = true  -> pixel encendido = blanco
  
  //Secuencia de inicialización.
  //Creamos un buffer de bytes con todos los comandos
  byte commandBuffer[]=
  {
    0x00 //Indicamos que a continuación se enviarán comandos
    ,(byte)(reverseMode?0xA6:0xA7) //Dependiendo del parámetro aplicamos un modo u otro
  };
  //Enviamos el buffer por I2C
  Wire.beginTransmission(_oledId); //Abrimos conexión con el dispositivo
  Wire.write(commandBuffer,sizeof(commandBuffer));
  Wire.endTransmission(); //Hemos terminado de enviar comandos
}

RoJoSSD1306::~RoJoSSD1306()
{
  //Destructor

  //Borramos el sprite con la memoria de vídeo de trabajo e interna
  delete videoMem;
  delete _videoMem;
}

#endif

/*
  Nombre de la librería: RoJoILI9486.h
  Versión: 20190630
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RPI_ILI9486 SPI 3.5" 320x480

  Notas:
    En este display, todos los datos que se le envían son de 16 bits.
    Si hay datos de un byte (como los comandos o sus parámetros), aún así
    se deben enviar como valor de 16 bits.
*/

#ifndef RoJoILI9486_cpp
#define RoJoILI9486_cpp

#include <RoJoILI9486.h>

//Máxima frecuencia SPI soportada por el display
uint32_t RoJoILI9486::_maxFreqSPI()
{
  //ILI9486 no soporta más de 40MHz
  return 39999999;
}

// Envía al display un comando con sus correspondientes parámetros.
// Los parámetros son opcionales.
// Después de los parámetros, siempre hay que enviar uno adicional
// con valor negativo para indicar que no hay más.
void RoJoILI9486::_writeCommand(byte command,...)
{
  //ILI9486 envía la información (comando y parámetros) como datos de 16bits!!

  //Definimos la función con número de parámetros variable
  //Para este tipo de funciones es obligatorio un parámetro inicial
  //En este caso: byte command
  //... representa la lista variable de parámetros
  //... siempre debe ser el último parámetro

  //Definimos la variable que contendrá la lista de parámetros de la función
  va_list paramList;
  //Cargamos la lista con los parametros de la función.
  //Se debe indicar a partir de qué parámetro comienza la lista (por eso es obligatorio uno)
  va_start(paramList,command);

  //Nota:
  //No se puede saber cuántos elementos tiene la lista de parámetros
  //Las técnicas más comunes para trabajar con ellas son:
  //- El primer parámetro (obligatorio) indica el número de elementos
  //- El último parámetro de la lista tiene un valor especial para indicar que no hay más

  int paramValue; //Declaramos variable en la que extraeremos los valores de la lista
  digitalWrite(_pinDC,LOW); //Modo comandos
  SPI.transfer16(command); //Enviamos el comando
  //Todos los parámetros deben pasarse en modo datos
  //Lo activamos ahora y nos aseguramos que quedará así al finalizar
  digitalWrite(_pinDC,HIGH);
  //Extraemos el valor de la lista y si es válido...
  while((paramValue=va_arg(paramList,int))>=0)
  {
    //...enviamos el parámetro
    SPI.transfer16(paramValue);
  }
  //Hemos terminado de trabajar con la lista
  va_end(paramList);
}

// Configura la rotación
void RoJoILI9486::rotation(byte r)
{
  // r : posición conector : orientación : código
  //---  -----------------   -----------   -------
  // 0 : arriba dcha         vertical      0b01001000 = BGR(00001000) + MX(01000000)
  // 1 : arriba izda         apaisado      0b00101000 = BGR(00001000) + MV(00100000)
  // 2 : abajo izda          vertical      0b10001000 = BGR(00001000) + MY(10000000)
  // 3 : abajo dcha          apaisado      0b11101000 = BGR(00001000) + MV(00100000) + MX(01000000) + MY(10000000)
  
  //Nos aseguramos que es un valor permitido
  r%=4;
  
  _startSPI();
    //Memory access control
    //Código correspondiente a la rotación
    _writeCommand(0x36,_rotationCodes[r],-1);
    //Si la rotación es impar
    if(r%2)
    {
      //El formato será apaisado
      _xMax=_yMaxDefault;
      _yMax=_xMaxDefault;
    }
    else
    {
      //El formato será vertical
      _xMax=_xMaxDefault;
      _yMax=_yMaxDefault;
    }
  _endSPI();
}

// Activa/Desactiva el modo hibernación
void RoJoILI9486::sleep(bool mode)
{
  //En hibernación se desactiva del display, pero permite seguir dibujando
  //Cuando se salga de hibernación y se vuelva a activar se mostrará el resultado
  _startSPI();
    if(mode)
    {
      _writeCommand(0x10,-1); //Sleep IN
      _writeCommand(0x28,-1); //Display OFF
      delay(5);
    }
    else
    {
      _writeCommand(0x29,-1); //Display ON
      _writeCommand(0x11,-1); //Sleep OUT
      delay(120);
    }
  _endSPI();
}

//Define área de dibujo
//Sin gestión de SPI. No se comprueba coherencia de parámetros
void RoJoILI9486::_setCursorRangeY(int16_t y1,int16_t y2)
{
  //0x2B=Page Address Set
  _writeCommand(0x2B,(byte)(y1>>8),(byte)(y1 & 0xFF),(byte)(y2>>8),(byte)(y2 & 0xFF),-1);
}
void RoJoILI9486::_setCursorRangeX(int16_t x1,int16_t x2)
{
  //0x2A=Column Address Set
  _writeCommand(0x2A,(byte)(x1>>8),(byte)(x1 & 0xFF),(byte)(x2>>8),(byte)(x2 & 0xFF),-1);
  //Write memory
  _writeCommand(0x2C,-1);
}

//Dibuja un rectángulo relleno de un color
//Devuelve true si tiene parte visible
bool RoJoILI9486::block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color)
{
  //Intercambiamos coordenadas erróneas
  if(x1>x2) {int16_t tmp;tmp=x1;x1=x2;x2=tmp;}
  if(y1>y2) {int16_t tmp;tmp=y1;y1=y2;y2=tmp;}
  //Calculamos el área visible
  displayRange r=visibleRange(x1,y1,x2-x1+1,y2-y1+1);
  //Si no hay área visible...hemos terminado
  if(!r.visible) return false;

  _startSPI();
    _setCursorRange(r.x1,r.y1,r.x2,r.y2);
    for(uint16_t y=r.y1;y<=r.y2;y++)
      for(uint16_t x=r.x1;x<=r.x2;x++)
        SPI.transfer16(color);
  _endSPI();
  
  //Tiene parte visible
  return true;
}

//Anchura de display (dummy)
uint16_t RoJoILI9486::xMax()
{
  return _xMax;
}

//Altura de display (dummy)
uint16_t RoJoILI9486::yMax()
{
  return _yMax;
}

//Reset & inicialización
void RoJoILI9486::reset()
{
  
  //Hard reset
  digitalWrite(_pinRES,LOW);
  delay(20);
  digitalWrite(_pinRES,HIGH);
  delay(120);

  //En ILI9486 tras un hard reset se debe hacer un soft reset
  _startSPI();
    _writeCommand(0x01,-1); //Comando soft reset
    delay(5);
  _endSPI();

  //Comenzamos una transacción
  _startSPI();
    //Selecciona la profundidad de color de pixel (Interface Pixel Format)
    // 01010101 = 0101 (RGB 16 bits/pixel) + 0101 (CPU 16 bits/pixel). Sólo usamos el formato de 16bits, no de 18.
    _writeCommand(0x3A,0x55,-1); 
    //Selecciona la frecuencia de los circuitos de setup (Power Control 3)
    // 01000100 = 0100 (setup cycle for circuits 1/4/5 = 2H) + 0100 (setup cycle for circuits 2/3 = 8H)
    _writeCommand(0xC2,0x44,-1); 
    //(VCOM Control)
    // NV memory is not programmed
    // VCM_REG = -2
    // VCOM value from NV memory
    // VCM_OUT = -2
    _writeCommand(0xC5,0,0,0,0,-1); 
    //Set the gray scale voltage to adjust the gamma characteristics of the TFT panel (PGAMCTRL: Positive Gamma Control)
    //VP0,VP1,VP2,VP4,VP6,VP13,VP20,VP36 & VP27,VP43,VP50,VP57,VP59,VP61,VP62,VP63
    _writeCommand(0xE0,0x0F,0x1F,0x1C,0x0C,0x0F,0x08,0x48,0x98,0x37,0x0A,0x13,0x04,0x11,0x0D,0x00,-1);
    //Set the gray scale voltage to adjust the gamma characteristics of the TFT panel (NGAMCTRL: Negative Gamma Correction)
    //VN0,VN1,VN2,VN4,RVN6,VN13,VN20,VN36 & VN27,VN43,VN50,VN57,VN59,VN61,VN62,VN63
    _writeCommand(0xE1,0x0F,0x32,0x2E,0x0B,0x0D,0x05,0x47,0x75,0x37,0x06,0x10,0x03,0x24,0x20,0x00,-1);
    //(Display Inversion OFF)
    _writeCommand(0x20,-1); 
  _endSPI();

  //Rotación 0: 320x480. Vertical. Conector arriba dcha
  rotation(0);
  //Borramos el display
  clear();
  //Salimos del modo de bajo consumo
  sleep(false);
}

//Dibuja un pixel
//Devuelve true si lo consigue si el pixel es visible
bool RoJoILI9486::drawPixel(int16_t x,int16_t y,uint16_t color)
{
  //Si las coordenadas están fuera de rango...terminamos
  if(x<0 || x>=(int16_t)xMax() || y<0 || y>=(int16_t)yMax()) return false;

  _startSPI();
    _setCursorRange(x,y,x,y);
    SPI.transfer16(color);
  _endSPI();
  return true;
}

#endif

/*
  Nombre de la librería: RoJoILI9486.h
  Versión: 20190910
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RPI_ILI9486 SPI 3.5" 320x480
*/

#ifndef RoJoILI9486_h
#define RoJoILI9486_h

#include <Arduino.h>
#include <SPI.h> //Gestión SPI
#include <RoJoSprite.h> //Gestión de sprites
#include <RoJoGraph.h> //Gestión de gráficos avanzados

class RoJoILI9486:public RoJoGraph
{
  private:
    byte _pinDC; //Pin DC de display
    byte _pinRES; //Pin reset de display
    byte _pinCS; //Pin CS de display
    SPISettings _spiSetting; //Características de la conexión SPI
    byte _rotationCodes[4]={0b01001000,0b00101000,0b10001000,0b11101000}; //Configuraciones de rotación
    const uint16_t _xMaxDefault=320; //Anchura de display sin rotación
    const uint16_t _yMaxDefault=480; //Altura de display sin rotación
    uint16_t _xMax; //Anchura de display teniendo en cuenta la rotación
    uint16_t _yMax; //Altura de display teniendo en cuenta la rotación
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _setCursorRangeY(int16_t y1,int16_t y2);
    void _setCursorRangeX(int16_t x1,int16_t x2);
    void _setCursorRange(int16_t x1,int16_t y1,int16_t x2,int16_t y2);
    void _startCOMM(); //Inicia una transacción SPI
    void _endCOMM(); //Finaliza una transacción SPI
  public:
    void rotation(byte r); //Configura la rotación
    void sleep(bool mode); //Activa/Desactiva el modo hibernación
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color); //Dibuja un rectángulo relleno
    void reset(); //Reset
    bool drawPixel(int16_t x,int16_t y,uint16_t color); //Dibuja un pixel
    void begin(byte pinRES,byte pinDC,byte pinCS,uint32_t freqSPI=0); //Inicialización
    bool drawSprite(RoJoSprite *sprite,int16_t x=0,int16_t y=0); //Dibuja un sprite
    byte drawSprite(String filename,int16_t x=0,int16_t y=0); //Dibuja un sprite directamente de un archivo
    byte drawBMP(String filename,int16_t x=0,int16_t y=0); //Dibuja un bmp directamente de un archivo
    bool drawSpriteSync(RoJoSprite *source,RoJoSprite *destination,int16_t x=0,int16_t y=0); //Sincroniza dos sprites
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoILI9486.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


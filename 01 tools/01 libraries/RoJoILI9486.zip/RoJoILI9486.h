/*
  Nombre de la librería: RoJoILI9486.h
  Versión: 20190627
  Autor: Ramón Junquera
  Descripción:
    Gestión de display RPI_ILI9486 SPI 3.5" 320x480
*/

#ifndef RoJoILI9486_h
#define RoJoILI9486_h

#include <Arduino.h>
#include <RoJoDisplayDriver.h>

class RoJoILI9486:public RoJoDisplayDriver
{
  private:
    byte _rotationCodes[4]={0b01001000,0b00101000,0b10001000,0b11101000}; //Configuraciones de rotación
    const uint16_t _xMaxDefault=320; //Anchura de display sin rotación
    const uint16_t _yMaxDefault=480; //Altura de display sin rotación
    uint16_t _xMax; //Anchura de display teniendo en cuenta la rotación
    uint16_t _yMax; //Altura de display teniendo en cuenta la rotación
    uint32_t _maxFreqSPI(); //Máxima frecuencia SPI soportada por el display
    void _writeCommand(byte command,...); //Envía al display un comando con sus correspondientes parámetros
    void _setCursorRangeY(int16_t y1,int16_t y2);
    void _setCursorRangeX(int16_t x1,int16_t x2);
  public:
    void rotation(byte r); //Configura la rotación
    void sleep(bool mode); //Activa/Desactiva el modo hibernación
    uint16_t xMax(); //Anchura de display
    uint16_t yMax(); //Altura de display
    bool block(int16_t x1,int16_t y1,int16_t x2,int16_t y2,uint16_t color); //Dibuja un rectángulo relleno
    void reset(); //Reset
    bool drawPixel(int16_t x,int16_t y,uint16_t color); //Dibuja un pixel
}; //Punto y coma obligatorio para que no de error

#ifdef __arm__
  #include <RoJoILI9486.cpp> //Para guardar compatibilidad con RPi
#endif

#endif


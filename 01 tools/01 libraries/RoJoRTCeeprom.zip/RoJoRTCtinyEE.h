/*
  Nombre de la librería: RoJoRTCtinyEE.h
  Versión: 20191119
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión de la memoria EEPROM del módulo Tiny RTC I2C Real Time
*/

#ifndef RoJoRTCtinyEE_h
#define RoJoRTCtinyEE_h

#include <Arduino.h>
#include <Wire.h>

class RoJoRTCtinyEE {
  private:
    const byte _eepromID=0x50; //Identificador de la memoria en el bus I2C
  public:
    bool begin(); //Inicializa conexión
    byte peek(uint16_t address); //Obtiene el valor de una posición de memoria
    void poke(uint16_t address,byte value); //Escribe en una posición de memoria
};

#ifdef __arm__
  #include <RoJoRTCtinyEE.cpp> //Para guardar compatibilidad con RPi
#endif

#endif

/*
  Nombre de la librería: RoJoRTCtinyEE.h
  Versión: 20191119
  Autor: Ramón Junquera
  Descripción:
    Librería de gestión de la memoria EEPROM del módulo Tiny RTC I2C Real Time
*/

#ifndef RoJoRTCtinyEE_cpp
#define RoJoRTCtinyEE_cpp

#include <RoJoRTCtinyEE.h>

//Inicializa conexión
//Devuelve true si todo es correcto
bool RoJoRTCtinyEE::begin() {
  Wire.begin();
  //Habitualmente el bus I2C transmite con una frecuencia de 100KHz.
  //Con el siguiente comando lo incrementamos hasta 400KHz, si la placa lo permite.
  Wire.setClock(400000L);
  //Abrimos comunicación con la memoria EEPROM
  Wire.beginTransmission(_eepromID);
  //Se solicita finalizar la comunicación. Si ocurre algún error es que no se pudo encontrar
  return !Wire.endTransmission();
}

//Obtiene el valor de una posición de memoria
byte RoJoRTCtinyEE::peek(uint16_t address) {
  //Comenzamos la transmisión al dispositivo de la memoria EEPROM
  Wire.beginTransmission(_eepromID);
  
  //Creamos un buffer para la dirección en el que intercambiamos sus bytes
  byte buf[2]={(byte)(address>>8),(byte)(address & 0xFF)};
  //Enviamos el buffer con la dirección
  Wire.write(buf,2);

  //Hemos terminado la transmisión
  Wire.endTransmission();
  
  //Solicitamos la lectura de un byte de ese dispositivo
  Wire.requestFrom(_eepromID,(byte)1);
  //Obtenemos el byte y lo devolvemos
  return Wire.read();
}

//Escribe un byte en la EEPROM en la dirección indicada
void RoJoRTCtinyEE::poke(uint16_t address,byte value) {
  //Comenzamos la transmisión al dispositivo de la memoria EEPROM
  Wire.beginTransmission(_eepromID);
  //Creamos un buffer donde guardamos la dirección de memoria
  //con los bytes alto y bajo intercambiados, y el valor a escribir
  byte buf[3]={(byte)(address >> 8),(byte)(address & 0xFF),value};
  //Enviamos el buffer al dispositivo
  Wire.write(buf,3);
  //Hemos terminado la transmisión
  Wire.endTransmission();
  //Obligatorio esperar 5 ms para que no se ofusque el buffer
  delay(5);
}

#endif
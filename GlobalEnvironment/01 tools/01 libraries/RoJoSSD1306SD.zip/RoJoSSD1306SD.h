/*
  Nombre de la librería: RoJoSSD1306.h
  Versión: 20180206
  Autor: Ramón Junquera
  Descripción:
    Gestión de display OLED I2C 0.96" 128x64 SSD1306
*/

#ifndef RoJoSSD1306_h
#define RoJoSSD1306_h

//Si declaramos la siguiente línea utilizaremos una tarjeta SD como almacenamiento por defecto
//en vez de un sistema SPIFFS
#define UseSD

#include <Arduino.h>
#include <Wire.h> //Gestión de comunicaciones I2C
#ifdef UseSD //Si debemos utilizar una terjeta SD...
  #include "RoJoSpriteSD.h"
#else //Si debemos utilizar SPIFFS
  #include "RoJoSprite.h"
#endif

class RoJoSSD1306
{
  private:
    //Identificador del display en en bus I2C
    const byte _oledId=0x3C;
    //Máximo número de bytes a enviar por I2C en una petición.
    //Ddepende de la placa
#ifdef ESP8266
    const byte _maxBufferLenthI2C=30; //para ESP8266
#elif defined(ESP32)
    const byte _maxBufferLenthI2C=29; //para ESP32
#elif defined(ARDUINO_ARCH_AVR)
    const byte _maxBufferLenthI2C=16; //para placas Arduino
#else
    const byte _maxBufferLenthI2C=128; //para RPi
#endif    
    //Memoria del display. La primera dimensión es y=página.
    //La segunda es x=columna
    byte _videoMem[8][128];
    //Se ha inicializado la página actual?
    bool _initSetPage;
    //Indica la página en la que se escribirá la información gráfica
    void _setPage(byte page);
    //Indica la columna en la que se escribirá la información gráfica
    void _setColumn(byte column);
    //Envía datos de gráficos
    void _sendGraphicBytes(byte page,byte firstColumn,byte lastColumn);
    //Las coordenadas están dentro de la pantalla?
    bool _inScreen(int16_t x,int16_t y);
    //Aplica una máscara al byte de una página (de la memoria de vídeo)
    void _mask(byte page,byte x,byte mask,byte color);
    //Intercambia los valores de dos variables enteras
    void _swap(int16_t *a,int16_t *b);
    //Dibuja un rectángulo relleno
    void _rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte fillColor,bool withoutBorder);
    //Dibuja una línea horizontal
    void _lineH(int16_t y,int16_t x1,int16_t x2,byte color,bool withoutBorder);
  public:
    const byte xMax=128; //Anchura de display
    const byte yMax=64; //Altura de display
    //Inicialización
    void begin(uint32_t freq);
    void begin();
    //Memoria del display. La primera dimensión es y=página
    //La segunda es x=columna
    byte videoMem[8][128];
    //Borra la memoria de vídeo
    void clear();
    //Envía memoria de vídeo al display
    void show();
    //Activar/desactivar un pixel
    void setPixel(int16_t x,int16_t y,byte color);
    //Obtener el estado de un pixel
    bool getPixel(int16_t x,int16_t y);
    //Dibuja una línea vertical
    void lineV(int16_t x,int16_t y1,int16_t y2,byte color);
    //Dibuja una línea horizontal
    void lineH(int16_t y,int16_t x1,int16_t x2,byte color);
    //Dibuja un rectángulo relleno
    void rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte fillColor);
    //Dibuja rectángulo con borde y relleno
    void rect(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte fillColor,byte borderColor);
    //Dibuja una línea
    void line(int16_t x1,int16_t y1,int16_t x2,int16_t y2,byte color);
    //Dibuja un sprite en una página
    void drawSpritePage(int16_t x,int16_t page,RoJoSprite *sprite,byte color);
    //Dibuja un sprite en unas coordenadas
    void drawSprite(int16_t x,int16_t y,RoJoSprite *sprite,byte color);
    //Toma parte de la memoria de vídeo para crear un sprite
    void getSprite(int16_t x1,int16_t page1,int16_t x2,int16_t page2,RoJoSprite *sprite);
    //Fija el display en modo invertido (blanco <-> negro)
    void reverse(bool reserveMode);
}; //Punto y coma obligatorio para que no de error

#endif

